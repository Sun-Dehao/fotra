"use client";

/* ————————————————————————————————————————————————
   /unlock — the single-owner token gate (§6.1).
   FOTRA_TOKEN unset → you never see this page.
   Set → type the token once; it becomes an http-only
   cookie, compared constant-time server-side.
   ———————————————————————————————————————————————— */

import { useState } from "react";

export default function UnlockPage() {
  const [token, setToken] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function unlock() {
    if (!token.trim() || busy) return;
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/unlock", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token }),
      });
      if (res.ok) {
        window.location.href = "/";
        return;
      }
      const j = (await res.json().catch(() => ({}))) as { error?: string };
      setError(j.error ?? "that didn't work");
    } catch {
      setError("network error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="f-theme-swap grid h-dvh place-items-center bg-paper text-ink">
      <div className="w-full max-w-[320px] px-6">
        <div className="f-orb mx-auto" style={{ ["--orb-size" as string]: "72px", pointerEvents: "none" }} aria-hidden="true">
          <span className="f-orb-body" />
        </div>
        <h1 className="mt-6 text-center font-display text-lg font-semibold">fotra is locked</h1>
        <p className="mt-2 text-center text-sm text-dim leading-relaxed">
          one owner, one token. it was set as <code className="f-data">FOTRA_TOKEN</code> on the host.
        </p>
        <input
          type="password"
          value={token}
          onChange={(e) => setToken(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") void unlock();
            e.stopPropagation();
          }}
          placeholder="the token"
          aria-label="Owner token"
          className="mt-6 w-full rounded-md border border-rule bg-paper-2 px-3 py-2.5 text-sm text-ink placeholder:text-dim/60 outline-none focus:border-glow/60 transition-colors"
        />
        <button
          type="button"
          onClick={() => void unlock()}
          disabled={!token.trim() || busy}
          className="mt-3 w-full rounded-md bg-glow px-3 py-2.5 text-sm font-medium text-glow-ink transition-all hover:brightness-110 disabled:opacity-40 min-h-[44px]"
        >
          {busy ? "checking…" : "unlock"}
        </button>
        {error && <p className="mt-3 text-center text-sm text-danger">{error}</p>}
      </div>
    </main>
  );
}
