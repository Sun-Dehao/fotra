import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono, Space_Grotesk } from "next/font/google";
import { ThemeProvider } from "next-themes";
import { Toaster } from "@/components/ui/sonner";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const spaceGrotesk = Space_Grotesk({
  variable: "--font-space-grotesk",
  subsets: ["latin"],
  weight: ["500", "600", "700"],
});

export const metadata: Metadata = {
  title: "fotra",
  description:
    "A voice-first AI companion. One thread, forever. Screens, not prose. Bring your own brain.",
  icons: {
    icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><circle cx='50' cy='50' r='42' fill='%2334d399'/><circle cx='38' cy='38' r='14' fill='%23a7f3d0'/></svg>",
  },
};

export const viewport: Viewport = {
  themeColor: "#0d130f",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

/* pre-paint: coat (the skin — accent + mascot) + mode (the canvas) land before
   first frame — no flash, no hydration fight (next-themes reads the same fotra.mode key) */
const prePaint = `(function(){try{
var m=localStorage.getItem("fotra.mode");
var p=localStorage.getItem("fotra.persona.v1");
var s=localStorage.getItem("fotra.settings.v1");
var c=p?JSON.parse(p).coat:null;
if(!c&&s){var t=JSON.parse(s).theme;c=t==="ember"?"ember":"verdant";}
var coats=["iris","verdant","ember","ice","rose","mono"];
var d=document.documentElement;
d.dataset.coat=coats.indexOf(c)>=0?c:"verdant";
d.dataset.mode=(m==="light"?"light":"dark");
}catch(e){document.documentElement.dataset.coat="verdant";document.documentElement.dataset.mode="dark";}})();`;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" data-coat="verdant" data-mode="dark" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: prePaint }} />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${spaceGrotesk.variable} antialiased`}
      >
        <ThemeProvider
          attribute="data-mode"
          defaultTheme="dark"
          storageKey="fotra.mode"
          enableSystem={false}
          disableTransitionOnChange
        >
          {children}
          <Toaster position="top-center" />
        </ThemeProvider>
      </body>
    </html>
  );
}
