import FotraApp from "@/components/fotra/FotraApp";

export default function Page() {
  return <FotraApp />;
}
