import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { mcpConnect, mcpDisconnect, mcpToolId } from "@/lib/fotra/server/mcp";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/mcp — BYO tools via the Model Context Protocol
   GET list connected servers + their tools
   POST connect { name, url } (streamable HTTP)
   DELETE disconnect */

export async function GET() {
  const rows = await db.mcpServer.findMany({ orderBy: { createdAt: "desc" } });
  return Response.json({
    servers: rows.map((r) => {
      let tools: { name: string; description?: string; id: string }[] = [];
      try {
        tools = (JSON.parse(r.tools ?? "[]") as { name: string; description?: string }[]).map((t) => ({
          name: t.name,
          description: t.description,
          id: mcpToolId(r.name, t.name),
        }));
      } catch {
        /* none */
      }
      return { id: r.id, name: r.name, url: r.url, status: r.status, error: r.error, tools };
    }),
  });
}

export async function POST(req: NextRequest) {
  let b: { name?: string; url?: string };
  try {
    b = (await req.json()) as { name?: string; url?: string };
  } catch {
    return Response.json({ error: "bad body" }, { status: 400 });
  }
  const name = (b.name ?? "").trim().toLowerCase().replace(/[^a-z0-9-]+/g, "").slice(0, 24);
  const url = (b.url ?? "").trim();
  if (!name || !url) return Response.json({ error: "name and url are required" }, { status: 400 });
  const res = await mcpConnect(name, url);
  return Response.json(res, { status: res.ok ? 200 : 502 });
}

export async function DELETE(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id") ?? "";
  if (!id) return Response.json({ error: "id required" }, { status: 400 });
  await mcpDisconnect(id);
  return Response.json({ ok: true });
}
