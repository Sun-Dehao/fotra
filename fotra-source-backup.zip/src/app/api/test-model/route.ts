import { NextRequest } from "next/server";
import { authHeaders, chatUrl, explainResponse, explainThrown, modelsUrl, type Failure } from "@/lib/fotra/server/endpoint";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* ————————————————————————————————————————————————
   /api/test-model — the "connect" call
   Three honest steps before you trust a config:
   1. read the model list (proves reach + key, and means
      you never have to guess a model name)
   2. settle the model (yours if the account has it,
      else the closest one that exists)
   3. a real, tiny completion
   Any failure comes back as what is wrong + what to do.
   ———————————————————————————————————————————————— */

interface Body {
  baseUrl?: string;
  apiKey?: string;
  model?: string;
  /** list only — skip the completion */
  listOnly?: boolean;
}

async function listModels(baseUrl: string, apiKey: string): Promise<{ models: string[]; failure?: Failure }> {
  try {
    const res = await fetch(modelsUrl(baseUrl), {
      headers: { Accept: "application/json", ...authHeaders(baseUrl, apiKey) },
      cache: "no-store",
      signal: AbortSignal.timeout(12_000),
    });
    if (!res.ok) {
      // some hosts have no /models route at all — that is not a failure of the config
      if (res.status === 404 || res.status === 405) return { models: [] };
      return { models: [], failure: await explainResponse(res, baseUrl, { hadKey: !!apiKey }) };
    }
    const j = (await res.json()) as { data?: Array<{ id?: string; name?: string }>; models?: Array<{ id?: string; name?: string }> };
    const rows = j.data ?? j.models ?? [];
    const models = rows
      .map((m) => (m.id ?? m.name ?? "").replace(/^models\//, ""))
      .filter((id) => id && !/embed|whisper|tts|dall-e|image|moderation|rerank|audio|realtime|transcribe/i.test(id));
    return { models: [...new Set(models)].slice(0, 400) };
  } catch (err) {
    return { models: [], failure: explainThrown(err, baseUrl) };
  }
}

/** keep the asked-for model when the account has it; otherwise the nearest thing that exists */
function settleModel(wanted: string, models: string[]): string {
  if (models.length === 0 || models.includes(wanted)) return wanted;
  const w = wanted.toLowerCase();
  const family = w.split(/[-/:.]/).filter((p) => p.length > 2 && !/^\d+$/.test(p));
  const scored = models
    .map((id) => ({ id, score: family.reduce((n, part) => n + (id.toLowerCase().includes(part) ? 1 : 0), 0) }))
    .sort((a, b) => b.score - a.score);
  return scored[0] && scored[0].score > 0 ? scored[0].id : models[0];
}

export async function POST(req: NextRequest) {
  let body: Body;
  try {
    body = (await req.json()) as Body;
  } catch {
    return Response.json({ ok: false, error: "Bad request body." });
  }
  const baseUrl = body.baseUrl?.trim() ?? "";
  const apiKey = body.apiKey?.trim() ?? "";
  if (!baseUrl) return Response.json({ ok: false, error: "Pick a provider or enter an endpoint first." });

  const listed = await listModels(baseUrl, apiKey);
  if (listed.failure) {
    return Response.json({ ok: false, error: listed.failure.message, failure: listed.failure, models: [] });
  }
  if (body.listOnly) return Response.json({ ok: true, models: listed.models });

  const model = settleModel(body.model?.trim() ?? "", listed.models);
  if (!model) return Response.json({ ok: false, error: "Enter a model name.", models: listed.models });

  const t0 = Date.now();
  try {
    const res = await fetch(chatUrl(baseUrl), {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders(baseUrl, apiKey) },
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: "Reply with exactly: linked" }],
        max_tokens: 16,
        stream: false,
      }),
      signal: AbortSignal.timeout(45_000),
    });
    const latencyMs = Date.now() - t0;
    if (!res.ok) {
      const failure = await explainResponse(res, baseUrl, { hadKey: !!apiKey });
      return Response.json({ ok: false, error: failure.message, failure, latencyMs, models: listed.models, model });
    }
    const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const reply = data.choices?.[0]?.message?.content?.trim() || "(empty reply)";
    return Response.json({ ok: true, latencyMs, reply: reply.slice(0, 120), models: listed.models, model });
  } catch (err) {
    const failure = explainThrown(err, baseUrl);
    return Response.json({ ok: false, latencyMs: Date.now() - t0, error: failure.message, failure, models: listed.models, model });
  }
}
