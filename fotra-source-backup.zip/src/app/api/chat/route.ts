import { NextRequest } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* ————————————————————————————————————————————————
   /api/chat — BYO-model SSE proxy
   Your key goes server-side per request and is never
   logged, never stored. The browser only ever talks to
   this route, same-origin.
   ———————————————————————————————————————————————— */

interface ChatBody {
  baseUrl?: string;
  apiKey?: string;
  model?: string;
  temperature?: number;
  messages?: { role: string; content: string }[];
  stream?: boolean;
}

function normalizeUrl(base: string): string {
  let u = base.trim().replace(/\s+/g, "");
  if (!u) return "";
  if (!/^https?:\/\//i.test(u)) u = `https://${u}`;
  u = u.replace(/\/*$/, "");
  if (/\/chat\/completions$/.test(u)) return u;
  if (/\/v\d+$/.test(u)) return `${u}/chat/completions`;
  return `${u}/v1/chat/completions`;
}

export async function POST(req: NextRequest) {
  let body: ChatBody;
  try {
    body = (await req.json()) as ChatBody;
  } catch {
    return Response.json({ error: "Bad request body." }, { status: 400 });
  }

  const { baseUrl, apiKey, model, messages, temperature } = body;
  if (!baseUrl || !model || !Array.isArray(messages)) {
    return Response.json({ error: "baseUrl, model and messages are required." }, { status: 400 });
  }

  const url = normalizeUrl(baseUrl);
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (apiKey && apiKey.trim()) headers.Authorization = `Bearer ${apiKey.trim()}`;

  let upstream: Response;
  try {
    upstream = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify({ model, messages, temperature: temperature ?? 0.7, stream: true }),
      // @ts-expect-error -- req.signal typing varies across Next runtime versions
      signal: req.signal,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "network error";
    return Response.json({ error: `Couldn't reach ${url} — ${msg}` }, { status: 502 });
  }

  if (!upstream.ok || !upstream.body) {
    let detail = `${upstream.status} ${upstream.statusText}`;
    try {
      const j = (await upstream.json()) as { error?: { message?: string } | string };
      if (typeof j.error === "string") detail = j.error;
      else if (j.error?.message) detail = j.error.message;
    } catch {
      /* not json */
    }
    return Response.json({ error: detail }, { status: upstream.status ?? 502 });
  }

  // re-emit upstream SSE as our minimal wire format: data: {"t":"…"}
  const reader = upstream.body.getReader();
  const decoder = new TextDecoder();
  const encoder = new TextEncoder();
  let buffer = "";

  const stream = new ReadableStream<Uint8Array>({
    async pull(controller) {
      const { done, value } = await reader.read();
      if (done) {
        controller.enqueue(encoder.encode("data: [DONE]\n\n"));
        controller.close();
        return;
      }
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) continue;
        const payload = trimmed.slice(5).trim();
        if (!payload || payload === "[DONE]") continue;
        try {
          const obj = JSON.parse(payload) as {
            choices?: { delta?: { content?: string }; text?: string }[];
          };
          const t = obj.choices?.[0]?.delta?.content ?? obj.choices?.[0]?.text ?? "";
          if (t) controller.enqueue(encoder.encode(`data: ${JSON.stringify({ t })}\n\n`));
        } catch {
          /* malformed upstream line — skip */
        }
      }
    },
    cancel() {
      reader.cancel().catch(() => undefined);
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-store, no-transform",
      "X-Accel-Buffering": "no",
    },
  });
}
