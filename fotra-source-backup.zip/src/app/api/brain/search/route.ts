﻿import { NextRequest } from "next/server";
import { searchDoors } from "@/lib/fotra/server/websearch";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// GET /api/brain/search?q=… — which keyless search engines answer from this network right now
export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get("q")?.trim() || "weather today";
  return Response.json({ doors: await searchDoors(q) }, { headers: { "Cache-Control": "no-store" } });
}
