import { builtinBrainAvailable } from "@/lib/fotra/server/zai";
import { resolveRole } from "@/lib/fotra/server/providers";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/brain — which brains this install can actually run.
   The client asks once on boot so it never offers (or silently
   defaults to) a brain that isn't there. */

export async function GET() {
  const builtin = builtinBrainAvailable();
  let provider = false;
  let providerModel = "";
  try {
    const role = resolveRole("chat");
    provider = !!role;
    providerModel = role?.model ?? "";
  } catch {
    provider = false;
  }
  return Response.json(
    { builtin, provider, providerModel, search: builtin ? "builtin" : "duckduckgo" },
    { headers: { "Cache-Control": "no-store" } }
  );
}
