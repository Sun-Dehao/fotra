import { NextRequest } from "next/server";
import { activeProxy, probe } from "@/lib/fotra/server/endpoint";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/brain/reach — which providers will talk to THIS network.
   Model calls leave from this machine, so a provider that doesn't
   serve your location fails here exactly as it would in a run.
   No key is sent; each probe is one unauthenticated GET. */

export async function POST(req: NextRequest) {
  let body: { urls?: unknown };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return Response.json({ error: "bad body" }, { status: 400 });
  }
  const urls = (Array.isArray(body.urls) ? body.urls : [])
    .filter((u): u is string => typeof u === "string" && /^https?:\/\//i.test(u))
    .slice(0, 16);
  const reach = await Promise.all(urls.map((u) => probe(u)));
  return Response.json({ reach, proxy: activeProxy() }, { headers: { "Cache-Control": "no-store" } });
}
