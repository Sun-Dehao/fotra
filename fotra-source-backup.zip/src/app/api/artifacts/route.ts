import { NextRequest } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/artifacts — files the harness produced (code outputs, browser shots,
   agent-written files). The artifact ledger proves tools really ran. */

export async function GET(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId") ?? "";
  const id = req.nextUrl.searchParams.get("id");
  if (id) {
    const a = await db.artifact.findUnique({ where: { id } });
    if (!a) return Response.json({ error: "not found" }, { status: 404 });
    return Response.json(a);
  }
  if (!sessionId) return Response.json({ error: "sessionId or id required" }, { status: 400 });
  const rows = await db.artifact.findMany({ where: { sessionId }, orderBy: { ts: "desc" }, take: 100 });
  return Response.json({
    artifacts: rows.map((r) => ({ id: r.id, kind: r.kind, name: r.name, path: r.path, mime: r.mime, size: r.size, ts: r.ts.toISOString() })),
  });
}
