﻿import { NextRequest } from "next/server";
import { readSearchConfig, writeSearchConfig } from "@/lib/fotra/server/searchconfig";
import { googleSearch } from "@/lib/fotra/server/websearch";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// /api/search-config — Google Programmable Search credentials for web_search.
// GET says whether they are set (never returns the key). POST tests them with one real
// search and saves them only if it works. DELETE removes them.

export async function GET() {
  const cfg = readSearchConfig();
  return Response.json({ google: !!cfg, cx: cfg?.googleCx ?? "" }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(req: NextRequest) {
  const b = (await req.json().catch(() => ({}))) as { googleKey?: string; googleCx?: string };
  const googleKey = (b.googleKey ?? "").trim();
  const googleCx = (b.googleCx ?? "").trim();
  if (!googleKey || !googleCx) return Response.json({ ok: false, error: "Both the API key and the search engine ID are needed." });
  try {
    const hits = await googleSearch("weather today", 3, { googleKey, googleCx });
    writeSearchConfig({ googleKey, googleCx });
    return Response.json({ ok: true, results: hits.length });
  } catch (err) {
    return Response.json({ ok: false, error: err instanceof Error ? err.message : "Google refused the request." });
  }
}

export async function DELETE() {
  writeSearchConfig(null);
  return Response.json({ ok: true });
}
