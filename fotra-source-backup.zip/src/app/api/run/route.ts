import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { executeRun, subscribeRun, type ServerEvent } from "@/lib/fotra/server/engine";
import { startWorkers } from "@/lib/fotra/server/jobs";
import type { Persona, ThemeMode, Turn, UiPrefs } from "@/lib/fotra/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* ————————————————————————————————————————————————
   /api/run — the harness endpoint
   One voice turn → one server-side run: persisted,
   event-sourced, tool-using, steerable, abortable.
   The SSE writer is a SUBSCRIBER, not the owner —
   dropping the connection never kills the run
   (§6.2: disconnect ≠ abort; the log is the truth).
   ———————————————————————————————————————————————— */

interface RunBody {
  sessionId?: string;
  text: string;
  userTurnId: string;
  assistantTurnId: string;
  history: Turn[];
  persona: Persona;
  brain: "fotra" | "custom" | "provider";
  custom?: { baseUrl: string; apiKey: string; model: string; temperature: number };
  contextWindow?: number; // the model's context window — drives compaction (BYO models declare their own)
  ui?: UiPrefs;
  mode?: ThemeMode;
  feedback?: Array<{ emoji: string; note?: string; excerpt: string }>;
}

export async function POST(req: NextRequest) {
  startWorkers(); // idempotent — boots the job worker + reaper on first hit

  let body: RunBody;
  try {
    body = (await req.json()) as RunBody;
  } catch {
    return Response.json({ error: "bad body" }, { status: 400 });
  }
  if (!body.text?.trim() || !body.userTurnId || !body.assistantTurnId) {
    return Response.json({ error: "text, userTurnId and assistantTurnId are required" }, { status: 400 });
  }

  // session: load or create
  let sessionId = body.sessionId?.trim() ?? "";
  if (sessionId) {
    const exists = await db.session.findUnique({ where: { id: sessionId } });
    if (!exists) sessionId = "";
  }
  if (!sessionId) {
    const s = await db.session.create({ data: {} });
    sessionId = s.id;
  }

  const brain = body.brain === "custom" ? "custom" : body.brain === "provider" ? "provider" : "fotra";
  const run = await db.run.create({
    data: { sessionId, status: "running", brain },
  });

  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let closed = false;
      const send = (ev: ServerEvent) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(ev)}\n\n`));
        } catch {
          closed = true;
        }
      };

      // the engine emits the session identity as logged event #1 — the client
      // learns runId + assistantTurnId from the stream AND from any later replay
      const executing = executeRun({
        sessionId,
        runId: run.id,
        text: body.text.trim(),
        userTurnId: body.userTurnId,
        assistantTurnId: body.assistantTurnId,
        history: Array.isArray(body.history) ? body.history : [],
        persona: body.persona,
        brain,
        custom: body.custom ?? { baseUrl: "", apiKey: "", model: "", temperature: 0.7 },
        contextWindow: Number(body.contextWindow) > 0 ? Math.floor(Number(body.contextWindow)) : undefined,
        ui: body.ui && typeof body.ui === "object" ? body.ui : undefined,
        mode: body.mode === "light" ? "light" : "dark",
        feedback: Array.isArray(body.feedback) ? body.feedback.slice(-6) : undefined,
      });

      // the writer subscribes to the run's event bus — disconnect detaches, run continues
      const unsubscribe = subscribeRun(run.id, send);
      const detach = () => {
        unsubscribe();
        closed = true;
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      };
      req.signal.addEventListener("abort", detach, { once: true });

      await executing;

      // the run finished (or suspended) — flush and close this view
      req.signal.removeEventListener("abort", detach);
      detach();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-store, no-transform",
      "X-Accel-Buffering": "no",
    },
  });
}
