import { NextRequest } from "next/server";
import { steerRun } from "@/lib/fotra/server/engine";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/run/steer — push a message into a live run (queue-and-steer, server side) */
export async function POST(req: NextRequest) {
  try {
    const { runId, text } = (await req.json()) as { runId?: string; text?: string };
    if (!runId?.trim() || !text?.trim()) {
      return Response.json({ ok: false, error: "runId and text are required" }, { status: 400 });
    }
    const ok = steerRun(runId, text.trim());
    return Response.json({ ok, steered: ok });
  } catch {
    return Response.json({ ok: false, error: "bad body" }, { status: 400 });
  }
}
