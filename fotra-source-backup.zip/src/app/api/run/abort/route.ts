import { NextRequest } from "next/server";
import { abortRun } from "@/lib/fotra/server/engine";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/run/abort — barge-in: kill a live run server-side, partials are kept */
export async function POST(req: NextRequest) {
  try {
    const { runId } = (await req.json()) as { runId?: string };
    if (!runId?.trim()) {
      return Response.json({ ok: false, error: "runId is required" }, { status: 400 });
    }
    const ok = abortRun(runId);
    return Response.json({ ok, aborted: ok });
  } catch {
    return Response.json({ ok: false, error: "bad body" }, { status: 400 });
  }
}
