import { NextRequest } from "next/server";
import { providersStatus, loadProviders } from "@/lib/fotra/server/providers";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/providers — status lights for the BYO model layer (§6.6):
   which providers resolve, which roles are wired, and
   the file's own validation state. Values never leak —
   only env-var NAMES cross the wire. */

export async function GET() {
  const status = providersStatus();
  return Response.json(status, { headers: { "Cache-Control": "no-store" } });
}

/* quick validation answer for tooling */
export async function POST(req: NextRequest) {
  void req;
  const r = loadProviders();
  return Response.json(r.ok ? { ok: true } : { ok: false, error: r.error });
}
