import { NextRequest } from "next/server";
import { readInstructions, selfEditHistory, undoSelfEdit } from "@/lib/fotra/server/soul";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/self — the agent's edits to itself, inspectable and reversible.
   GET  → the standing instructions it wrote + the journal of changes
   POST → undo one edit ({editId}) or the latest ({}); returns the client
          actions that put the look/layout back */

export async function GET() {
  const [instructions, history] = await Promise.all([readInstructions(), selfEditHistory()]);
  return Response.json({ instructions, history }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(req: NextRequest) {
  let body: { editId?: string } = {};
  try {
    body = (await req.json()) as { editId?: string };
  } catch {
    /* empty body = undo the latest */
  }
  const res = await undoSelfEdit(typeof body.editId === "string" ? body.editId : undefined);
  return Response.json(res, { status: res.ok ? 200 : 409 });
}
