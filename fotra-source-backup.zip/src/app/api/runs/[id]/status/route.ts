import { NextRequest } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/runs/:id/status — reattach check: is the run worth
   reconnecting to (running | waiting), and which session
   does it belong to? */

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  void req;
  const { id } = await ctx.params;
  const run = await db.run.findUnique({ where: { id }, select: { status: true, brain: true, sessionId: true, startedAt: true } });
  if (!run) return Response.json({ error: "not found" }, { status: 404 });
  return Response.json(
    { id, status: run.status, brain: run.brain, sessionId: run.sessionId, startedAt: run.startedAt },
    { headers: { "Cache-Control": "no-store" } }
  );
}
