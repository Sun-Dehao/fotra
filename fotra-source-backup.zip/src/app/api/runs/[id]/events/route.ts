import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { runActive, subscribeRun, type ServerEvent } from "@/lib/fotra/server/engine";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* ————————————————————————————————————————————————
   GET /api/runs/:id/events?after=<seq>
   The reattach contract (§6.2): after a reload, tab
   switch or dropped connection the client replays the
   persisted event log from `after`, then tails the live
   stream if the run is still going. 15s heartbeats.
   Multiple tabs may all read; ownership is decided
   client-side (latest tab wins the composer).
   ———————————————————————————————————————————————— */

const HEARTBEAT_MS = 15_000;
const IDLE_CAP_MS = 20 * 60_000; // hard stop for a tail nobody is feeding

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const after = Math.max(0, Number(req.nextUrl.searchParams.get("after")) || 0);

  const run = await db.run.findUnique({
    where: { id },
    include: { events: { where: { seq: { gt: after } }, orderBy: { seq: "asc" } } },
  });
  if (!run) return Response.json({ error: "run not found" }, { status: 404 });

  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let closed = false;
      let unsubscribe: () => void = () => undefined;
      let heartbeat: ReturnType<typeof setInterval> | null = null;
      let capTimer: ReturnType<typeof setTimeout> | null = null;

      const send = (ev: ServerEvent) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(ev)}\n\n`));
        } catch {
          closed = true;
        }
      };
      const stop = () => {
        if (closed) return;
        closed = true;
        if (heartbeat) clearInterval(heartbeat);
        if (capTimer) clearTimeout(capTimer);
        unsubscribe();
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      };

      // 1) replay the persisted log
      const replayedTerminal = run.events.some((e) => ["done", "error", "waiting"].includes(e.kind));
      for (const ev of run.events) {
        try {
          send(JSON.parse(ev.data) as ServerEvent);
        } catch {
          /* skip corrupt row */
        }
      }

      // 2) live tail — only while the run is in memory AND hasn't already ended
      if (runActive(id) && !(replayedTerminal && run.status !== "waiting")) {
        unsubscribe = subscribeRun(id, (ev) => {
          send(ev);
          if (ev.type === "done" || ev.type === "error") {
            setTimeout(stop, 50); // let the event flush, then close
          } else if (ev.type === "waiting") {
            // waiting runs keep the tail open — a resume continues this same log
          }
        });
        capTimer = setTimeout(stop, IDLE_CAP_MS);
      } else {
        setTimeout(stop, 50);
      }

      heartbeat = setInterval(() => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(": hb\n\n"));
        } catch {
          stop();
        }
      }, HEARTBEAT_MS);

      req.signal.addEventListener("abort", stop, { once: true });
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-store, no-transform",
      "X-Accel-Buffering": "no",
    },
  });
}
