import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { resumeRun, type ServerEvent } from "@/lib/fotra/server/engine";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* ————————————————————————————————————————————————
   POST /api/runs/:id/resume  { answer: string }
   The human answered a suspended run (ask_user card,
   budget pause, or the same question spoken aloud —
   one path for touch and voice). The run picks up
   with its state intact and streams as SSE from the
   same event log. Idempotent: a run that moved on
   answers 409 with its status.
   ———————————————————————————————————————————————— */

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  let answer = "";
  try {
    const body = (await req.json()) as { answer?: string };
    answer = String(body.answer ?? "");
  } catch {
    return Response.json({ error: "bad body" }, { status: 400 });
  }

  const run = await db.run.findUnique({ where: { id } });
  if (!run) return Response.json({ error: "run not found" }, { status: 404 });
  if (run.status !== "waiting") {
    return Response.json({ error: `run is ${run.status}, not waiting` }, { status: 409 });
  }

  // seed subscriber attached to the handle AT claim time — nothing slips through
  const subs = new Set<(ev: ServerEvent) => void>();
  let buffer: ServerEvent[] = [];
  let writer: ((ev: ServerEvent) => void) | null = null;
  let stopFn: () => void = () => undefined;
  subs.add((ev) => {
    if (writer) writer(ev);
    else buffer.push(ev);
    if (ev.type === "done" || ev.type === "error") setTimeout(stopFn, 60); // let it flush
  });

  const res = await resumeRun(id, answer, subs);
  if (!res.ok) {
    return Response.json({ error: res.error }, { status: 409 });
  }

  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      let closed = false;
      const send = (ev: ServerEvent) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(ev)}\n\n`));
        } catch {
          closed = true;
        }
      };
      const stop = () => {
        if (closed) return;
        closed = true;
        clearInterval(cap);
        clearInterval(poll);
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      };

      // flush anything the run emitted between claim and now
      writer = send;
      stopFn = stop;
      for (const ev of buffer) send(ev);
      buffer = [];

      // backstops: wall clock + DB status (the subscriber itself stops on done/error)
      const cap = setTimeout(stop, 180_000);
      const poll = setInterval(() => {
        void db.run
          .findUnique({ where: { id }, select: { status: true } })
          .then((r) => {
            if (closed) return;
            if (r && ["done", "interrupted", "error"].includes(r.status)) stop();
          })
          .catch(() => stop());
      }, 1000);

      req.signal.addEventListener("abort", stop, { once: true });
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-store, no-transform",
      "X-Accel-Buffering": "no",
    },
  });
}
