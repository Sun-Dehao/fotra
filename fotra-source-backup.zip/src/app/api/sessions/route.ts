import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/sessions — the session switcher's feed.
   Lists every recorded session (newest activity first)
   with a title (first user turn), turn count and when
   it was last touched. The thread stays one-event-
   sourced forever; sessions are the branches you jump
   between (the oh-my-pi sessions-as-trees story, at
   cockpit scale). */

export async function GET() {
  const sessions = await db.session.findMany({
    orderBy: { lastAt: "desc" },
    take: 40,
    include: {
      turns: {
        orderBy: { ts: "asc" },
        where: { role: "user" },
        take: 1,
        select: { text: true },
      },
      _count: { select: { turns: true, runs: true } },
    },
  });

  return Response.json(
    {
      sessions: sessions.map((s) => {
        const first = s.turns[0]?.text?.trim() ?? "";
        const title = first
          ? first.replace(/\s+/g, " ").slice(0, 64) + (first.length > 64 ? "…" : "")
          : "(no messages yet)";
        return {
          id: s.id,
          title,
          turnCount: s._count.turns,
          runCount: s._count.runs,
          createdAt: s.createdAt.toISOString(),
          lastAt: s.lastAt.toISOString(),
          current: false, // the client marks which one it's on
        };
      }),
    },
    { headers: { "Cache-Control": "no-store" } },
  );
}
