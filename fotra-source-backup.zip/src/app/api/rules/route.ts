import { NextResponse } from "next/server";
import { listRules, createRule, updateRule, deleteRule, testRules, dropRuleCache } from "@/lib/fotra/server/ttsr";

/* /api/rules — TTSR stream-rule CRUD + live test (the oh-my-pi time-traveling
   stream rules surface). Rules sit dormant until the model's live output goes
   off-script; then the stream is cut, the rule injected, the reply regenerated. */

export async function GET() {
  const rules = await listRules();
  return NextResponse.json({ rules });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { name?: string; pattern?: string; reminder?: string; test?: string };
  if (typeof body.test === "string") {
    const hits = await testRules(body.test);
    return NextResponse.json({ hits });
  }
  const res = await createRule(String(body.name ?? ""), String(body.pattern ?? ""), String(body.reminder ?? ""));
  if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
  return NextResponse.json({ rule: res.rule });
}

export async function PATCH(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { id?: string; name?: string; pattern?: string; reminder?: string; enabled?: boolean };
  if (!body.id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const res = await updateRule(body.id, { name: body.name, pattern: body.pattern, reminder: body.reminder, enabled: body.enabled });
  if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id") ?? "";
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const ok = await deleteRule(id);
  dropRuleCache();
  return NextResponse.json({ ok });
}
