import { NextRequest } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/todo — the agent's visible task board (todo_write tool state) */

export async function GET(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId") ?? "";
  if (!sessionId) return Response.json({ error: "sessionId required" }, { status: 400 });
  const items = await db.todoItem.findMany({ where: { sessionId }, orderBy: { ord: "asc" } });
  return Response.json({ items: items.map((i) => ({ text: i.text, status: i.status })) });
}
