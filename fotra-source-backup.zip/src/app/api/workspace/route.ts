import { NextRequest } from "next/server";
import { listFiles, wsRead, wsWrite } from "@/lib/fotra/server/workspace";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/workspace — the session's file space (agent-written + sandbox outputs)
   GET  ?sessionId= [&path=]   list files, or read one file
   POST { sessionId, path, content }  write (manual edit from the files rail) */

export async function GET(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId") ?? "";
  const path = req.nextUrl.searchParams.get("path");
  if (!sessionId) return Response.json({ error: "sessionId required" }, { status: 400 });
  if (path) {
    const r = await wsRead(sessionId, path);
    return Response.json(r, { status: r.ok ? 200 : 404 });
  }
  const files = await listFiles(sessionId);
  return Response.json({ files });
}

export async function POST(req: NextRequest) {
  let b: { sessionId?: string; path?: string; content?: string };
  try {
    b = (await req.json()) as { sessionId?: string; path?: string; content?: string };
  } catch {
    return Response.json({ error: "bad body" }, { status: 400 });
  }
  if (!b.sessionId || !b.path) return Response.json({ error: "sessionId and path are required" }, { status: 400 });
  const w = await wsWrite(b.sessionId, b.path, b.content ?? "");
  return Response.json(w, { status: w.ok ? 200 : 400 });
}
