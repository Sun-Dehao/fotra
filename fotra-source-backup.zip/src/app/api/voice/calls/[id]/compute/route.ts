import { NextRequest } from "next/server";
import { computeCall } from "@/lib/fotra/server/realtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/voice/calls/:id/compute — the ask_fotra delegation.
   Steering when a run holds the thread; the spoken answer when
   a run waits on the human; a fresh tooled run otherwise.
   Deduped by toolCallId, capped at 6 per call, ≤90s. */

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    const body = (await req.json()) as { toolCallId?: string; request?: string };
    if (!body.toolCallId?.trim() || !body.request?.trim()) {
      return Response.json({ error: "toolCallId and request are required" }, { status: 400 });
    }
    const text = await computeCall(id, body.toolCallId, body.request);
    return Response.json({ text }, { headers: { "Cache-Control": "no-store" } });
  } catch (err) {
    return Response.json(
      { error: err instanceof Error ? err.message : "compute failed" },
      { status: 500 }
    );
  }
}
