import { NextRequest } from "next/server";
import { activateCall } from "@/lib/fotra/server/realtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/voice/calls/:id/active — the peer connection came up;
   the 15-minute cap starts now. */

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  void req;
  const { id } = await ctx.params;
  const ok = activateCall(id);
  return Response.json({ ok }, { status: ok ? 200 : 404, headers: { "Cache-Control": "no-store" } });
}
