import { NextRequest } from "next/server";
import { endCall } from "@/lib/fotra/server/realtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/voice/calls/:id/end — hang up both legs, write the receipt
   (a quiet chip in the thread: "voice call · 21:14 · 3:42 · 2 turns"). */

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  let transcript = "";
  try {
    const body = (await req.json()) as { transcript?: string };
    transcript = String(body.transcript ?? "").slice(0, 20000);
  } catch {
    /* empty body is fine */
  }
  const res = await endCall(id, transcript);
  return Response.json(res, { status: res.ok ? 200 : 404, headers: { "Cache-Control": "no-store" } });
}
