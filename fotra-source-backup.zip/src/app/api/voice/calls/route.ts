import { NextRequest } from "next/server";
import { beginCall, realtimeKey } from "@/lib/fotra/server/realtime";
import { startWorkers } from "@/lib/fotra/server/jobs";
import type { Persona } from "@/lib/fotra/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/voice/calls — begin a realtime call.
   The browser sends its WebRTC SDP offer; the server relays
   it to the provider with the session config (semantic VAD,
   barge-in, transcription, the ask_fotra tool). The provider
   key never touches the browser (§6.3). */

export async function POST(req: NextRequest) {
  startWorkers();
  const { key, model, source } = realtimeKey();
  if (!key) {
    return Response.json(
      {
        error: "realtime voice needs a server-side OpenAI key",
        hint: `set OPENAI_API_KEY in .env.local${model ? ` (model: ${model})` : ""} — or switch to browser voice in Settings → voice. ${source ? `key source detected: ${source}` : "no key source found"}.`,
      },
      { status: 501 }
    );
  }
  try {
    const body = (await req.json()) as { sessionId?: string; sdp?: string; voice?: string; persona?: Persona };
    if (!body.sessionId?.trim() || !body.sdp?.trim()) {
      return Response.json({ error: "sessionId and sdp are required" }, { status: 400 });
    }
    const res = await beginCall({
      sessionId: body.sessionId,
      sdp: body.sdp,
      voice: (body.voice ?? "alloy").slice(0, 32),
      persona: body.persona ?? { name: "Fotra", tagline: "", aura: "calm", mascot: "dot", coat: "iris", voiceURI: null, voiceRate: 1, voicePitch: 1 },
    });
    return Response.json(res, { headers: { "Cache-Control": "no-store" } });
  } catch (err) {
    return Response.json(
      { error: err instanceof Error ? err.message : "could not connect the call" },
      { status: 502 }
    );
  }
}
