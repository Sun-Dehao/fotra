import { NextRequest } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/unlock — the single-owner token gate (§6.1).
   FOTRA_TOKEN unset → the app is open (localhost mode).
   FOTRA_TOKEN set → mutations need the token (header or
   cookie), compared constant-time. This route exchanges
   a typed token for the cookie. */

function expectedToken(): string {
  return (process.env.FOTRA_TOKEN ?? "").trim();
}

/** constant-time compare — same-length check first, then XOR-accumulate */
export function tokensMatch(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export async function GET() {
  return Response.json(
    { locked: !!expectedToken() },
    { headers: { "Cache-Control": "no-store" } }
  );
}

export async function POST(req: NextRequest) {
  const expected = expectedToken();
  if (!expected) return Response.json({ ok: true, note: "open mode — no token needed" });
  let token = "";
  try {
    const body = (await req.json()) as { token?: string };
    token = String(body.token ?? "");
  } catch {
    return Response.json({ error: "bad body" }, { status: 400 });
  }
  if (!tokensMatch(token, expected)) {
    return Response.json({ error: "that's not the token" }, { status: 401 });
  }
  const res = Response.json({ ok: true });
  res.headers.append(
    "Set-Cookie",
    `fotra_token=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${60 * 60 * 24 * 30}`
  );
  return res;
}
