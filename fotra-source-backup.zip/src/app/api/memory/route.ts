import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { vaultDeleteFact, vaultEditFact } from "@/lib/fotra/server/vault";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/memory — the memory viewer's backing (§6.5):
   provenance, edit, delete, search. Every mutation also
   rewrites the git vault — history is the trust story. */

export async function GET(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId")?.trim();
  if (!sessionId) return Response.json({ error: "sessionId is required" }, { status: 400 });
  const rows = await db.memory.findMany({ where: { sessionId }, orderBy: { ts: "desc" }, take: 200 });
  return Response.json({
    memories: rows.map((m) => ({ id: m.id, fact: m.fact, topic: m.topic, origin: m.origin, source: m.source, ts: m.ts })),
  });
}

export async function PATCH(req: NextRequest) {
  try {
    const body = (await req.json()) as { sessionId?: string; id?: string; fact?: string; topic?: string };
    if (!body.sessionId?.trim() || !body.id?.trim() || !body.fact?.trim()) {
      return Response.json({ error: "sessionId, id and fact are required" }, { status: 400 });
    }
    const ok = await vaultEditFact(body.sessionId, body.id, body.fact, body.topic);
    return Response.json({ ok }, { status: ok ? 200 : 404 });
  } catch {
    return Response.json({ error: "bad body" }, { status: 400 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const body = (await req.json()) as { sessionId?: string; id?: string };
    if (!body.sessionId?.trim() || !body.id?.trim()) {
      return Response.json({ error: "sessionId and id are required" }, { status: 400 });
    }
    const ok = await vaultDeleteFact(body.sessionId, body.id);
    return Response.json({ ok }, { status: ok ? 200 : 404 });
  } catch {
    return Response.json({ error: "bad body" }, { status: 400 });
  }
}
