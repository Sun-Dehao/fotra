import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { fireRoutine, nextFire, parseSchedule } from "@/lib/fotra/server/routines";
import type { Persona } from "@/lib/fotra/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/routines — the proactive layer (Dots background tasks, OpenClaw jobs)
   GET  list (with next-fire preview)
   POST create  { sessionId, name, prompt, schedule }
   PATCH toggle | run-now
   DELETE remove */

interface Body {
  id?: string;
  sessionId?: string;
  name?: string;
  prompt?: string;
  schedule?: string;
  action?: "toggle" | "run";
}

const persona: Persona = { name: "fotra", tagline: "", aura: "calm", mascot: "dot", coat: "iris", voiceURI: null, voiceRate: 1, voicePitch: 1 };

export async function GET(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId") ?? "";
  const rows = sessionId
    ? await db.routine.findMany({ where: { sessionId }, orderBy: { createdAt: "desc" } })
    : await db.routine.findMany({ orderBy: { createdAt: "desc" }, take: 50 });
  return Response.json({
    routines: rows.map((r) => ({
      id: r.id,
      sessionId: r.sessionId,
      name: r.name,
      prompt: r.prompt,
      schedule: r.schedule,
      active: r.active,
      lastRunAt: r.lastRunAt?.toISOString() ?? null,
      nextRunAt: r.nextRunAt.toISOString(),
      nextPreview: nextFire(r.schedule)?.toISOString() ?? null,
      lastNote: r.lastNote,
      valid: parseSchedule(r.schedule).kind !== "invalid",
    })),
  });
}

export async function POST(req: NextRequest) {
  let b: Body;
  try {
    b = (await req.json()) as Body;
  } catch {
    return Response.json({ error: "bad body" }, { status: 400 });
  }
  const name = (b.name ?? "").trim().slice(0, 80);
  const prompt = (b.prompt ?? "").trim().slice(0, 2000);
  const schedule = (b.schedule ?? "").trim().slice(0, 80);
  const sessionId = (b.sessionId ?? "").trim();
  if (!name || !prompt || !sessionId) return Response.json({ error: "name, prompt and sessionId are required" }, { status: 400 });
  if (parseSchedule(schedule).kind === "invalid") {
    return Response.json({ error: 'schedule must be like "every 30 minutes" or "daily at 08:00"' }, { status: 400 });
  }
  const next = nextFire(schedule);
  if (!next) return Response.json({ error: "bad schedule" }, { status: 400 });
  const r = await db.routine.create({ data: { sessionId, name, prompt, schedule, nextRunAt: next } });
  return Response.json({ routine: { id: r.id, name: r.name } });
}

export async function PATCH(req: NextRequest) {
  let b: Body;
  try {
    b = (await req.json()) as Body;
  } catch {
    return Response.json({ error: "bad body" }, { status: 400 });
  }
  if (!b.id) return Response.json({ error: "id required" }, { status: 400 });
  if (b.action === "run") {
    const out = await fireRoutine(b.id, persona);
    return Response.json(out);
  }
  const r = await db.routine.findUnique({ where: { id: b.id } });
  if (!r) return Response.json({ error: "not found" }, { status: 404 });
  await db.routine.update({ where: { id: b.id }, data: { active: !r.active } });
  return Response.json({ ok: true, active: !r.active });
}

export async function DELETE(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id") ?? "";
  if (!id) return Response.json({ error: "id required" }, { status: 400 });
  await db.routine.delete({ where: { id } }).catch(() => undefined);
  return Response.json({ ok: true });
}
