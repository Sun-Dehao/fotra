import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { vaultExportMarkdown, vaultSearch } from "@/lib/fotra/server/vault";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/session — the harness's record: turns, runs, tool calls, memories.
   Powers hydration, the memory panel and honest debugging.
   ?export=md  → full thread export as markdown (download)
   ?q=term     → keyword search across every turn (the log is greppable by design) */

export async function GET(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id")?.trim();
  if (!id) return Response.json({ error: "id is required" }, { status: 400 });

  // export — the whole thread as markdown
  if (req.nextUrl.searchParams.get("export") === "md") {
    const md = await vaultExportMarkdown(id);
    return new Response(md, {
      headers: {
        "Content-Type": "text/markdown; charset=utf-8",
        "Content-Disposition": `attachment; filename="fotra-thread-${id.slice(0, 8)}.md"`,
        "Cache-Control": "no-store",
      },
    });
  }

  // search — grep the append-only turn log
  const q = req.nextUrl.searchParams.get("q")?.trim();
  if (q) {
    const turns = await db.turn.findMany({
      where: { sessionId: id, text: { contains: q } },
      orderBy: { ts: "asc" },
    });
    return Response.json({
      query: q,
      hits: turns.map((t) => ({ id: t.id, role: t.role, text: t.text.slice(0, 400), ts: t.ts })),
    });
  }

  const session = await db.session.findUnique({
    where: { id },
    include: {
      turns: { orderBy: { ts: "asc" } },
      memories: { orderBy: { ts: "desc" } },
      runs: {
        orderBy: { startedAt: "desc" },
        take: 20,
        include: { toolCalls: true },
      },
    },
  });
  if (!session) return Response.json({ error: "not found" }, { status: 404 });

  const memoryHits = await vaultSearch(id, q ?? "").catch(() => []);
  void memoryHits;

  return Response.json({
    sessionId: session.id,
    summary: session.summary,
    turns: session.turns.map((t) => ({
      id: t.id, role: t.role, text: t.text, origin: t.origin, interrupted: t.interrupted, ts: t.ts,
    })),
    memories: session.memories.map((m) => ({ id: m.id, fact: m.fact, topic: m.topic, origin: m.origin, source: m.source, ts: m.ts })),
    runs: session.runs.map((r) => ({
      id: r.id, status: r.status, brain: r.brain, steps: r.steps, tokens: r.tokens,
      steerMsgs: r.steerMsgs ? (JSON.parse(r.steerMsgs) as string[]) : [],
      startedAt: r.startedAt, endedAt: r.endedAt,
      tools: r.toolCalls.map((c) => ({ name: c.name, ok: c.ok, ms: c.ms })),
    })),
  });
}
