import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { startRoutineTicker } from "@/lib/fotra/server/routines";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* /api/session/poll — the ambient channel. Routines fire in the background;
   the client polls this to discover new turns (routine results land as system
   + assistant turns) and routine state changes while the tab idles. */

export async function GET(req: NextRequest) {
  startRoutineTicker(); // idempotent
  const sessionId = req.nextUrl.searchParams.get("sessionId") ?? "";
  const sinceRaw = req.nextUrl.searchParams.get("since");
  if (!sessionId) return Response.json({ error: "sessionId required" }, { status: 400 });
  const since = sinceRaw ? new Date(sinceRaw) : new Date(Date.now() - 120_000);
  const turns = await db.turn.findMany({
    where: { sessionId, ts: { gt: since } },
    orderBy: { ts: "asc" },
    take: 40,
  });
  const routines = await db.routine.findMany({ where: { sessionId }, orderBy: { createdAt: "desc" } });
  return Response.json({
    now: new Date().toISOString(),
    newTurns: turns.map((t) => ({ id: t.id, role: t.role, text: t.text.slice(0, 3000), origin: t.origin, ts: t.ts.toISOString(), interrupted: t.interrupted })),
    routines: routines.map((r) => ({ id: r.id, name: r.name, active: r.active, lastNote: r.lastNote, nextRunAt: r.nextRunAt.toISOString() })),
  });
}
