import type { MetadataRoute } from "next";

/* PWA-light (§7): installable, honest — no offline pretensions. */
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "fotra",
    short_name: "fotra",
    description: "a voice-first ai companion with a real agent harness",
    start_url: "/",
    display: "standalone",
    background_color: "#0a0f0c",
    theme_color: "#34d399",
    icons: [
      {
        src: "/icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "any",
      },
    ],
  };
}
