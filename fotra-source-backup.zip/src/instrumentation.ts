/* ————————————————————————————————————————————————
   FOTRA — server boot hook (runtime dispatcher)
   Edge-safe stub: the real boot lives in
   instrumentation-node.ts, imported only under nodejs.
   ———————————————————————————————————————————————— */

export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    await import("./instrumentation-node");
  }
}
