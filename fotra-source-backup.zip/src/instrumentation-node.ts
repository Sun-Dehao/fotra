/* ————————————————————————————————————————————————
   FOTRA — server boot (node runtime only)
   Boots the background workers (job queue + reaper)
   and validates providers.json. Key hygiene is a
   culture, not advice: a pasted sk- key in the tracked
   file hard-fails production and loudly degrades dev.
   ———————————————————————————————————————————————— */

export async function register() {
  const { startWorkers } = await import("@/lib/fotra/server/jobs");
  const { loadProviders } = await import("@/lib/fotra/server/providers");
  const { startRoutineTicker } = await import("@/lib/fotra/server/routines");

  startWorkers();
  startRoutineTicker();

  const r = loadProviders();
  if (r.ok) {
    console.log("[fotra] providers.json valid");
  } else {
    const msg = `[fotra] ${r.error}`;
    if (process.env.NODE_ENV === "production") {
      console.error(msg);
      console.error("[fotra] refusing to run half-configured — fix the file, then restart.");
      process.exit(1);
    } else {
      console.warn(msg);
    }
  }
}
