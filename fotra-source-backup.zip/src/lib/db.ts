import path from 'node:path'
import { mkdirSync } from 'node:fs'
import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

/* The generated client remembers the folder it was generated in and resolves a relative
   sqlite path against that — so moving the project breaks it. Resolve the file against
   where the app is running instead, and make sure its folder exists. */
function databaseUrl(): string {
  const raw = (process.env.DATABASE_URL ?? 'file:../db/fotra.db').trim()
  if (!raw.startsWith('file:')) return raw
  const p = raw.slice(5)
  if (path.isAbsolute(p)) return raw
  const abs = path.resolve(process.cwd(), 'prisma', p)
  try {
    mkdirSync(path.dirname(abs), { recursive: true })
  } catch {
    /* the open below will say what is wrong */
  }
  return `file:${abs.replace(/\\/g, '/')}`
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ['error'],
    datasources: { db: { url: databaseUrl() } },
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
