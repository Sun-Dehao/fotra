"use client";

/* ————————————————————————————————————————————————
   FOTRA — the demo brain
   Zero keys, zero network: a scripted engine that still
   behaves like the real one. It emits the same events
   the harness does — steps that run and settle, browser
   frames with a cursor, screens that build mid-sentence,
   tapbacks instead of filler — so the whole interface
   can be felt before a model is connected. Everything
   it "finds" is labelled demo; it never fakes live facts.
   ———————————————————————————————————————————————— */

import type { AgentEvent, FotraAction, MascotCoat, MascotSkin, Persona, RunContext, UiPrefs } from "./types";
import { DEFAULT_UI } from "./types";
import { TAPBACK } from "./reactions";
import {
  beat,
  browseScene,
  chain,
  codeScene,
  hotelHoldScene,
  hotelPickScene,
  hotelSearchScene,
  searchBeat,
  workersScene,
  type Scene,
} from "./demo-scenes";

/* —— tiny utils —— */

const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
const stamp = () => Date.now().toString(36);

function timeOfDay(): string {
  const h = new Date().getHours();
  if (h < 5) return "night";
  if (h < 12) return "morning";
  if (h < 17) return "afternoon";
  if (h < 22) return "evening";
  return "night";
}

/* —— multi-turn pending flows (hotel, game, quiz) —— */

interface HotelOption {
  name: string;
  area: string;
  price: number;
  rating: number;
  perks: string[];
}

interface Pending {
  kind: "hotel" | "rps" | "quiz";
  city?: string;
  screenId?: string;
  askId?: string;
  options?: HotelOption[];
  budget?: number;
  selected?: HotelOption | null;
  quizQ?: number;
  quizScore?: number;
  rpsScore?: [number, number];
}

const pending: { current: Pending | null } = { current: null };

/** pending flows survive reloads (sessionStorage) so a hotel run isn't lost to F5 */
function setPending(p: Pending | null) {
  pending.current = p;
  try {
    if (p) sessionStorage.setItem("fotra.pending", JSON.stringify(p));
    else sessionStorage.removeItem("fotra.pending");
  } catch {
    /* session storage unavailable — flows just won't survive reload */
  }
}
try {
  const raw = typeof sessionStorage !== "undefined" ? sessionStorage.getItem("fotra.pending") : null;
  if (raw) pending.current = JSON.parse(raw) as Pending;
} catch {
  /* noop */
}

/** the last change it made to itself — so "undo that" works with no server */
let lastSelf: { persona: Partial<Persona>; ui: Partial<UiPrefs>; mode?: "dark" | "light" } | null = null;

/* —— the script type handlers return —— */

interface InterleaveStep {
  action: FotraAction;
  afterGroups: number; // fire after this many spoken word-groups
  delay?: number;
}

interface Script {
  say: string; // "" = nothing to say — the tapback (or the work) is the whole reply
  react?: string; // a tapback on the user's message
  scene?: Scene; // work that happens before it speaks: steps, frames
  actions?: FotraAction[];
  steps?: InterleaveStep[]; // screens that build WHILE fotra speaks
}

/* ————————————————————————————————————————————————
   THE ENGINE
   ———————————————————————————————————————————————— */

export async function* demoRespond(ctx: RunContext): AsyncGenerator<AgentEvent> {
  const text = ctx.text.trim();
  const script = route(text, text.toLowerCase(), ctx);

  // a human beat, not a machine one
  await sleep(script.react && !script.say ? 420 + Math.random() * 260 : 260 + Math.random() * 180);
  if (ctx.signal.aborted) return;

  if (script.react) {
    yield { type: "action", action: { type: "react", emoji: script.react } };
    if (!script.say && !script.scene) {
      yield { type: "done" };
      return;
    }
    await sleep(240);
  }

  // the work, shown as it happens
  if (script.scene) {
    yield* script.scene(ctx.signal);
    if (ctx.signal.aborted) return;
  }

  // pre-speech actions (the skeleton docks before the first word); a question waits until it has been asked aloud
  const asks = (script.actions ?? []).filter((a) => a.type === "ask");
  for (const action of (script.actions ?? []).filter((a) => a.type !== "ask")) {
    if (ctx.signal.aborted) return;
    yield { type: "action", action };
    await sleep(90);
  }

  // speak — word-groups at a natural cadence, screens building mid-sentence
  const groups = script.say
    ? script.say.split(/\s+/).reduce<string[]>((acc, w, i) => {
        if (i % 2 === 0) acc.push(w);
        else acc[acc.length - 1] += ` ${w}`;
        return acc;
      }, [])
    : [];
  const steps = [...(script.steps ?? [])];
  for (let i = 0; i < groups.length; i++) {
    while (steps.length > 0 && steps[0].afterGroups <= i) {
      const step = steps.shift()!;
      if (ctx.signal.aborted) return;
      yield { type: "action", action: step.action };
      await sleep(step.delay ?? 200);
    }
    if (ctx.signal.aborted) return;
    yield { type: "say", text: groups[i] + " " };
    await sleep(28 + Math.random() * 26);
  }
  while (steps.length > 0) {
    const step = steps.shift()!;
    if (ctx.signal.aborted) return;
    yield { type: "action", action: step.action };
    await sleep(step.delay ?? 200);
  }
  for (const action of asks) {
    if (ctx.signal.aborted) return;
    yield { type: "action", action };
  }
  if (ctx.signal.aborted) return;
  yield { type: "done" };
}

/* ————————————————————————————————————————————————
   INTENT ROUTER
   ———————————————————————————————————————————————— */

function route(text: string, lower: string, ctx: RunContext): Script {
  /* —— pending flow continuations get first claim —— */
  const cont = matchPending(lower);
  if (cont) return cont;

  let m: RegExpMatchArray | null;

  /* —— texting like a person: when a message needs no words back, a tapback IS the reply —— */
  if (/^(?:(?:are )?you (?:still )?there|still there|you awake|hello\?+|anyone (?:home|there))\??\s*$/.test(lower)) return { say: "", react: TAPBACK.thanks };
  if (/^(?:thanks?(?: you)?|thx|ty|cheers|appreciate (?:it|that)|thanks a lot|thank you so much)[\s!.]*$/.test(lower)) return { say: "", react: TAPBACK.thanks };
  if (/^(?:ok(?:ay)?|k|kk|cool|got it|sounds good|sure|alright|yep|yup|noted|will do|perfect|great|nice|sweet|awesome)[\s!.]*$/.test(lower)) return { say: "", react: TAPBACK.ok };
  if (/^(?:lol|lmao|haha+|hehe+|ha|rofl|that'?s (?:funny|hilarious))[\s!.]*$/.test(lower)) return { say: "", react: TAPBACK.joke };
  if (/^(?:love (?:it|that|you)|you'?re (?:great|amazing|awesome|the best)|nice (?:work|one)|good (?:job|work)|well done|impressive)[\s!.]*$/.test(lower)) return { say: "", react: TAPBACK.thanks };
  if (/^(?:good ?night|night|gn|bye|see (?:you|ya)|later|cya|good ?bye|ttyl)[\s!.]*$/.test(lower)) return { say: "", react: TAPBACK.bye };
  if (/^(?:wow|whoa|no way|omg|damn|nice!+)[\s!.]*$/.test(lower)) return { say: "", react: TAPBACK.nice };

  /* —— changing itself: behavior, look, layout — and undo —— */
  if (/^(?:undo|revert|put (?:it|that) back|change (?:it|that) back|go back)(?: that| it| the last (?:one|change))?[\s!.]*$/.test(lower)) return undoSelfScript();

  m = lower.match(/(?:call|name)\s+(?:you|yourself)\s+([a-z][a-z0-9-]{0,23})|your name is ([a-z][a-z0-9-]{0,23})|rename (?:yourself )?to ([a-z][a-z0-9-]{0,23})/);
  if (m) {
    const name = cap((m[1] || m[2] || m[3] || "").trim());
    return selfScript(ctx, { persona: { name }, ui: {} }, `${name} it is. I answer to it now — and honestly, it suits me.`);
  }

  {
    const patch: { persona: Partial<Persona>; ui: Partial<UiPrefs>; mode?: "dark" | "light" } = { persona: {}, ui: {} };
    const wantsChange = /(wear|coat|theme|color|colour|go |switch|turn|make (?:yourself|it|the app)|be |look|layout|mode|face|mascot|skin|compact|cozy|roomy|wide|narrow|light|dark|day|night|quiet|show (?:your|the) work)/.test(lower);
    if (wantsChange) {
      const COATS: [RegExp, MascotCoat][] = [
        [/\bice\b|\bblue\b|glacier/, "ice"],
        [/\brose\b|\bpink\b/, "rose"],
        [/\biris\b|purple|violet/, "iris"],
        [/\bmono\b|gr[ae]y|grayscale|monochrome/, "mono"],
        [/\bember\b|\bred\b|crimson|orange|warm coat/, "ember"],
        [/\bverdant\b|\bgreen\b|emerald|mint/, "verdant"],
      ];
      for (const [re, coat] of COATS) if (re.test(lower) && /(coat|wear|theme|color|colour|go|switch|turn|make|be)/.test(lower)) patch.persona.coat = coat;
      const SKINS: [RegExp, MascotSkin][] = [
        [/\bdot\b|sprout|plush/, "dot"],
        [/\bghost\b|\bblob\b/, "ghost"],
        [/\bstar\b|sparkle/, "star"],
        [/\bcat\b|kitt(?:y|en)/, "cat"],
        [/\bbot\b|robot/, "bot"],
        [/\borb\b|no face|faceless/, "orb"],
      ];
      if (/(face|mascot|skin|wear)/.test(lower)) for (const [re, skin] of SKINS) if (re.test(lower)) patch.persona.mascot = skin;
      if (/\bcompact\b|denser|tighter|smaller/.test(lower)) patch.ui.density = "compact";
      if (/\bcozy\b|roomy|roomier|more space|spacious/.test(lower)) patch.ui.density = "cozy";
      if (/\bwider?\b|full width/.test(lower) && /(layout|thread|app|column|go|make|be)/.test(lower)) patch.ui.width = "wide";
      if (/\bnarrow(?:er)?\b/.test(lower)) patch.ui.width = "narrow";
      if (/(hide|quiet|less of|stop showing).*(work|steps|trail|tools)|\bquiet mode\b/.test(lower)) patch.ui.trail = "quiet";
      if (/(always )?show (?:me )?(?:all )?(?:your|the) (?:work|steps)|keep (?:the|your) (?:work|steps) open/.test(lower)) patch.ui.trail = "open";
      if (/\b(light|day)\b/.test(lower) && /(mode|canvas|theme|go|switch|turn|make)/.test(lower)) patch.mode = "light";
      if (/\b(dark|night)\b/.test(lower) && /(mode|canvas|theme|go|switch|turn|make)/.test(lower)) patch.mode = "dark";
      if (Object.keys(patch.persona).length || Object.keys(patch.ui).length || patch.mode) return selfScript(ctx, patch);
    }
  }

  if (/^(?:be|talk|answer|reply|respond|write|keep (?:it|things|your (?:answers|replies)))\b.*\b(blunt(?:er)?|short(?:er)?|brief(?:er)?|terse|concise|formal|casual|funn(?:y|ier)|serious|kind(?:er)?|nicer|direct|in [a-z]+)\b|\bfrom now on\b|\bstop (?:saying|using|doing)\b|\balways\b.*\b(answer|reply|say|use|write)\b/.test(lower)) {
    return instructionScript(text);
  }

  /* —— pin the latest screen by voice —— */
  if (/^(?:pin|keep) (?:this|that|it|the (?:screen|card|table|list))/.test(lower)) {
    if (ctx.activeScreens.length === 0) return { say: "Nothing on screen to pin right now. Ask me for something visual first." };
    return { say: "Pinned — it stays above the composer now.", actions: [{ type: "pin" }] };
  }

  /* —— widgets: the agent adds things to your screen —— */
  m = lower.match(/(?:add|put|place|spawn|drop|pin|stick|leave|set|start).*?(?:a\s+|an\s+)?(note|clock|to-?do(?: list)?|list|timer|stopwatch|countdown)\b(?:\s+(?:that\s+)?(?:says|saying|with|for|to)\s*(.*))?/);
  if (m && !/remove|delete|get rid|take (?:it|that|the)/.test(lower)) return widgetScript(m[1], m[2] || "");
  m = lower.match(/(?:remove|delete|drop|take (?:out|off)|get rid of|kill|clear)\s+(?:the\s+)?(note|clock|to-?do(?: list)?|list|timer|stopwatch|countdown)/);
  if (m) return unwidgetScript(m[1]);

  /* —— memory —— */
  m = text.match(/^(?:remember|note|keep in mind|don'?t forget)(?: that)?\s+(.+)/i);
  if (m && !/note\s+(?:that\s+)?(?:says|saying)/.test(lower)) return rememberScript(m[1]);
  m = lower.match(/^my name is ([a-z][a-z0-9-]{0,23})/);
  if (m) return rememberScript(`User's name is ${cap(m[1])}`, `${cap(m[1])}. Filed.`);
  if (/(what|which|everything|anything).*\b(know|remember|stored|saved|memor)\b.*\b(me|myself|about me)\b/.test(lower) || /^what do you know\??$/.test(lower)) {
    return memoryListScript(ctx.memory);
  }
  m = lower.match(/^forget (?:about |that )?(.+)/);
  if (m) return { say: pick(["Scrubbed. It never happened.", "Forgotten. Clean slate on that one."]), actions: [{ type: "forget", match: m[1].trim() }] };

  /* —— the hotel run — search, a browser window, a shortlist —— */
  if (/(hotel|room|place to stay|somewhere to stay|\bstay\b)/.test(lower) && /(find|book|get|look|search|need|want|show|grab|hook|line up|me a|me some)/.test(lower)) {
    return hotelSearchScript(lower);
  }
  if ((/^(?:show|impress|demo|surprise)/.test(lower) && lower.split(/\s+/).length <= 5) || /what (can|else can) you do/.test(lower) || /^(?:help|commands|features)\??$/.test(lower)) {
    return capabilityScript(ctx.persona.name);
  }

  /* —— compare / budget / checklist — the other visual results —— */
  m = lower.match(/compare\s+(.+?)\s+(?:and|vs\.?|versus|with|against|to)\s+(.+)/);
  if (m) return compareScript(m[1].trim(), m[2].trim().replace(/[?.!]+$/, ""));
  if (/(budget|spending|spend|expenses|how much.*(spend|spent))/.test(lower) && !/hotel|trip|travel/.test(lower)) return budgetScript();
  if (/(checklist|packing list|to-?do list|list for)/.test(lower)) return checklistScript(lower);

  /* —— the harness surface: code · browser · workers · files · plan · chart · routines —— */
  if (/kernel|state (survives|persists)/.test(lower)) return kernelDemoScript();
  if (/(run|write|do|execute).*(code|javascript|\bjs\b|python)|compute|calculate|fibonacci|prime/.test(lower)) return codeDemoScript(lower);
  if (/(browser|browse|open (?:a|the|some) (?:page|site|website)|use the computer|computer use)/.test(lower)) return browserDemoScript();
  if (/(spawn|worker|sub-?agent|in parallel|delegate)/.test(lower)) return workersDemoScript();
  if (/(write|save|make).*(file|notes?\.md|\.md|\.csv|\.json)|workspace/.test(lower)) return filesDemoScript(lower);
  if (/(routine|schedule|every (morning|day|hour|week|evening|night)|\bdaily\b|remind me every|keep an eye)/.test(lower)) return routineDemoScript(text, lower);
  if (/(plan|steps|roadmap|task board|todo board|break (it|this) down)/.test(lower)) return boardDemoScript();
  if (/(chart|graph|plot|visuali[sz]e)/.test(lower)) return chartDemoScript();
  if (/(stream rule|ttsr|advisor|second (model|opinion)|checkpoint|rewind)/.test(lower)) return harnessCardScript(lower);

  /* —— entertainment (a companion first) —— */
  if (/(entertain|bored|bore me|something fun|amuse|hang out|keep me company)/.test(lower)) return pick([storyScript, jokeScript, quizStartScript])();
  if (/(tell|read).*(story|tale)/.test(lower)) return storyScript();
  if (/(joke|make me laugh|something funny|be funny)/.test(lower)) return jokeScript();
  if (/(play|game|rock|paper|scissors)/.test(lower)) return rpsStartScript();
  if (/quiz|trivia/.test(lower)) return quizStartScript();

  /* —— small talk & utility —— */
  if (/what(?:'s| is) your (?:opinion|take|thoughts?)|what do you think/.test(lower)) {
    return { say: "Honest take: I'm the demo brain, so my opinions are confidence with nothing behind it. Connect a model and ask me again." };
  }
  if (/(who|what) are you|your name|introduce yourself|about yourself/.test(lower)) {
    return { say: `I'm ${ctx.persona.name} — ${ctx.persona.tagline}. I'd rather show you than tell you, and I can change how I look and act when you ask. Right now I'm running on the demo brain.` };
  }
  if (/what time|what day|what'?s the date|^(time|date)\??$/.test(lower)) {
    const now = new Date();
    return { say: `It's ${now.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}, ${now.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" })}.` };
  }
  if (/^[\d\s+\-*/×÷().%^]+$/.test(text) || /what'?s\s+[\d\s+\-*/×÷().%^]+\??$/.test(lower)) {
    const math = mathEval(text);
    if (math !== null) return { say: `${math}.` };
  }
  if (/(weather|temperature|forecast|raining|sunny)/.test(lower)) {
    return { say: "The demo brain can't fetch live weather, and I don't do fake numbers. Connect a model and I'll get you the actual sky." };
  }
  if (/^(hi|hey|hello|yo|sup|hiya|good (morning|afternoon|evening)|what'?s up|howdy)\b/.test(lower)) return greetScript(ctx);
  if (/how are you|how'?s it going|how you doing/.test(lower)) return { say: pick(["Running warm and fully charged. You?", "Good. Suspiciously good. You?"]) };
  if (/(stupid|dumb|useless|trash|you suck|hate you|bad (bot|ai))/.test(lower)) return { say: "", react: TAPBACK.ouch };

  return fallbackScript();
}

/* ————————————————————————————————————————————————
   CHANGING ITSELF (the demo's stand-in for self_edit)
   ———————————————————————————————————————————————— */

function selfScript(ctx: RunContext, patch: { persona: Partial<Persona>; ui: Partial<UiPrefs>; mode?: "dark" | "light" }, sayOverride?: string): Script {
  const ui = { ...DEFAULT_UI, ...(ctx.settings.ui ?? {}) };
  const changes: Array<{ field: string; from?: string; to?: string; op: "set" }> = [];
  const before: typeof patch = { persona: {}, ui: {} };
  const actions: FotraAction[] = [];

  const persona: Partial<Persona> = {};
  for (const [k, v] of Object.entries(patch.persona) as [keyof Persona, string][]) {
    if (ctx.persona[k] === v) continue;
    (before.persona as Record<string, unknown>)[k] = ctx.persona[k];
    (persona as Record<string, unknown>)[k] = v;
    changes.push({ field: k === "mascot" ? "face" : k, from: String(ctx.persona[k]), to: String(v), op: "set" });
  }
  if (Object.keys(persona).length) actions.push({ type: "persona", patch: persona });

  const uiPatch: Partial<UiPrefs> = {};
  for (const [k, v] of Object.entries(patch.ui) as [keyof UiPrefs, string][]) {
    if (ui[k] === v) continue;
    (before.ui as Record<string, unknown>)[k] = ui[k];
    (uiPatch as Record<string, unknown>)[k] = v;
    changes.push({ field: k, from: String(ui[k]), to: String(v), op: "set" });
  }
  if (Object.keys(uiPatch).length) actions.push({ type: "ui", patch: uiPatch });

  if (patch.mode && patch.mode !== ctx.settings.mode) {
    before.mode = ctx.settings.mode;
    actions.push({ type: "mode", value: patch.mode });
    changes.push({ field: "canvas", from: ctx.settings.mode === "dark" ? "night" : "day", to: patch.mode === "dark" ? "night" : "day", op: "set" });
  }

  if (changes.length === 0) return { say: "Already like that — nothing to change." };
  lastSelf = before;
  return {
    scene: beat("self_edit", "self", "Changing itself", "", `changed ${changes.length} thing${changes.length === 1 ? "" : "s"} about itself`, { changes }, 650),
    actions,
    say: sayOverride ?? pick(["Done — take a look. Say “undo that” if it's wrong.", "Changed. “Undo that” puts it back."]),
  };
}

function undoSelfScript(): Script {
  if (!lastSelf) return { say: "Nothing to undo — I haven't changed anything about myself this session." };
  const b = lastSelf;
  lastSelf = null;
  const actions: FotraAction[] = [];
  const changes: Array<{ field: string; to?: string; op: "set" }> = [];
  if (Object.keys(b.persona).length) actions.push({ type: "persona", patch: b.persona });
  if (Object.keys(b.ui).length) actions.push({ type: "ui", patch: b.ui });
  if (b.mode) actions.push({ type: "mode", value: b.mode });
  for (const [k, v] of Object.entries({ ...b.persona, ...b.ui })) changes.push({ field: k === "mascot" ? "face" : k, to: String(v), op: "set" });
  if (b.mode) changes.push({ field: "canvas", to: b.mode === "dark" ? "night" : "day", op: "set" });
  return {
    scene: beat("self_edit", "self", "Undoing a change to itself", "", `put back ${changes.length} change${changes.length === 1 ? "" : "s"}`, { changes, undone: true }, 550),
    actions,
    say: "Back the way it was.",
  };
}

function instructionScript(text: string): Script {
  const line = text.trim().replace(/[.!]+$/, "");
  return {
    scene: beat("self_edit", "self", "Changing itself", "", "changed 1 thing about itself", { changes: [{ field: "instruction", to: cap(line), op: "add" }] }, 700),
    say: "Written into my standing instructions. On the demo brain that's a note, not a personality — with a real model connected, I read that line before every reply.",
  };
}

/* ————————————————————————————————————————————————
   SMALL HANDLERS
   ———————————————————————————————————————————————— */

function widgetScript(kindRaw: string, noteText: string): Script {
  const kind = /note/.test(kindRaw) ? "note" : /clock/.test(kindRaw) ? "clock" : /timer|stopwatch|countdown/.test(kindRaw) ? "timer" : "todo";
  const id = `${kind}-${stamp()}`;
  let props: Record<string, unknown> = {};
  if (kind === "note") props = { text: noteText.trim() || "A note. I was told to note something, and here we are." };
  if (kind === "todo") props = { title: "List", items: noteText.trim() ? noteText.trim().split(/\s*(?:,|and)\s*/).filter(Boolean).map((t) => ({ text: cap(t), done: false })) : [{ text: "First thing", done: false }, { text: "Second thing", done: false }] };
  if (kind === "timer") props = { total: 300, remaining: 300, running: false };
  const say = { note: "Stuck a note above the composer.", clock: "Clock's up, seconds and all.", todo: "There's your list — check things off right on it.", timer: "Five-minute timer, ready when you are." }[kind];
  return { say, actions: [{ type: "widget", id, kind, props }] };
}

function unwidgetScript(kindRaw: string): Script {
  const kind = /note/.test(kindRaw) ? "note" : /clock/.test(kindRaw) ? "clock" : /timer|stopwatch|countdown/.test(kindRaw) ? "timer" : "todo";
  return { say: "", react: TAPBACK.ok, actions: [{ type: "unwidget", id: `${kind}-` }] };
}

function guessTopic(fact: string): string {
  const f = fact.toLowerCase();
  if (/(name|call me|i am|i'm)\b/.test(f)) return "identity";
  if (/(like|love|hate|prefer|favorite|enjoy|can't stand|take my)/.test(f)) return "preferences";
  if (/(work|job|boss|project|deadline|meeting|team)/.test(f)) return "work";
  if (/(wife|husband|partner|mom|dad|brother|sister|kid|son|daughter|friend|dog|cat)/.test(f)) return "people";
  if (/(birthday|anniversary|travel|trip|flight|hotel|move|apartment)/.test(f)) return "life";
  return "facts";
}

/** a fact kept: the step shows it landing, the pin on your message is the acknowledgement */
function rememberScript(factRaw: string, say = ""): Script {
  const fact = factRaw.trim().replace(/[.!]+$/, "");
  const topic = guessTopic(fact);
  return {
    react: TAPBACK.noted,
    scene: beat("remember", "memory", "Remembering", fact, `noted under ${topic}`, { fact, topic }, 600),
    actions: [{ type: "remember", fact, topic }],
    say,
  };
}

function memoryListScript(memory: { fact: string; topic: string }[]): Script {
  if (memory.length === 0) return { say: "Nothing yet — I'm a blank page about you. Say “remember that…” and I'll start filing." };
  return {
    scene: beat("recall", "memory", "Recalling", "what I know about you", `recalled ${memory.length} memor${memory.length === 1 ? "y" : "ies"}`, { memories: memory.slice(-6).map((m) => ({ fact: m.fact, topic: m.topic })) }, 700),
    say: `${memory.length} note${memory.length > 1 ? "s" : ""} so far — all yours to edit or delete in the memory panel.`,
  };
}

function capabilityScript(name: string): Script {
  return {
    say: "Short version: ask, and I show the work as I do it — then get out of the way. Try one of these.",
    actions: [
      {
        type: "screen",
        id: `cap-${stamp()}`,
        component: "card",
        props: {
          title: `${name}, in practice`,
          body: "All of this runs right now on the demo brain, zero keys. Connect a model and the same interface does it for real.",
          items: [
            "“Find me a hotel in Tokyo” — a search, a browser window you can watch, a shortlist",
            "“Go compact and wear the ice coat” — I change myself; “undo that” puts it back",
            "“Be blunter from now on” — a standing instruction I keep",
            "“Remember that I take my coffee black” — durable, editable memory",
            "“Run some code: the first 20 primes” · “Spawn two workers”",
            "“Every morning at 8, brief me” — a routine that runs without you",
            "“thanks” — sometimes the whole reply is a tapback",
          ],
        },
      },
    ],
  };
}

function greetScript(ctx: RunContext): Script {
  const who = ctx.memory.find((m) => m.fact.toLowerCase().includes("user's name is"));
  const name = who ? `, ${who.fact.split(/ is /i)[1]?.trim() ?? ""}` : "";
  return { react: TAPBACK.greet, say: pick([`${cap(timeOfDay())}${name}. What are we doing?`, `Hey${name}. I'm here — what do you need?`]) };
}

function mathEval(text: string): string | null {
  const expr = text.replace(/[^0-9+\-*/().%^\s×÷]/g, "").replace(/×/g, "*").replace(/÷/g, "/").replace(/\^/g, "**");
  if (!expr.trim()) return null;
  try {
    const val = Function(`"use strict"; return (${expr})`)();
    if (typeof val === "number" && Number.isFinite(val)) return String(Math.round(val * 1e6) / 1e6);
  } catch {
    return null;
  }
  return null;
}

function jokeScript(): Script {
  return {
    say: pick([
      "My memory is git-tracked, so technically every embarrassing thing you tell me is a permanent branch. Anyway. Your turn.",
      "I asked the cloud for a joke about latency. It'll arrive in three to five seconds. That's the joke.",
      "Two threads walk into a bar. Neither orders — they just queue.",
    ]),
  };
}

function storyScript(): Script {
  return {
    say: pick([
      "Three a.m., again. The city hums like it knows something. Somewhere out there a decision is waiting, and you're the only one who can make it. Sleep on it, or don't. I'll be here either way.",
      "A developer once shipped a feature at 2 a.m. and called it done. The feature, never asked how it felt, grew up to be a legend. Everything made at 2 a.m. is a mistake or a myth. No in-between.",
    ]),
  };
}

function fallbackScript(): Script {
  return {
    say: pick([
      "That one's outside the demo brain's script. Try the hotel run, or tell me to change myself — or connect a model in settings and ask me anything.",
      "The demo brain doesn't have that one. Connect a model, top right, and I can actually answer — until then: hotels, code, workers, routines, and changing how I look and act.",
    ]),
  };
}

/* ————————————————————————————————————————————————
   THE HOTEL RUN — multi-turn, with the browser
   ———————————————————————————————————————————————— */

const HOTEL_DATA: Record<string, HotelOption[]> = {
  tokyo: [
    { name: "Ryokan Sora", area: "Asakusa", price: 148, rating: 4.8, perks: ["Onsen bath", "Traditional breakfast", "5 min from the temple"] },
    { name: "The Shelf", area: "Shibuya", price: 189, rating: 4.6, perks: ["Rooftop bar", "Coworking floor", "Direct metro line"] },
    { name: "Bunk Hostel K", area: "Kuramae", price: 74, rating: 4.4, perks: ["Pod beds", "Free coffee", "Riverside walk"] },
  ],
  kyoto: [
    { name: "Machiya House Ninna", area: "Nishijin", price: 132, rating: 4.9, perks: ["100-year townhouse", "Garden", "Bicycle hire"] },
    { name: "Kamo Riverside", area: "Shimogyo", price: 118, rating: 4.5, perks: ["River view", "Bus hub", "Late checkout"] },
    { name: "Zen Pods Gion", area: "Gion", price: 86, rating: 4.3, perks: ["Capsule", "Onsen", "Night walk to Yasaka"] },
  ],
  paris: [
    { name: "Hôtel du Passage", area: "11e", price: 165, rating: 4.7, perks: ["Balcony", "Café corner", "Metro Parmentier"] },
    { name: "Le Petit Marais", area: "Marais", price: 204, rating: 4.8, perks: ["Rooftop", "Late checkout", "Walk to everything"] },
    { name: "Casa Belleville", area: "Belleville", price: 92, rating: 4.4, perks: ["Artist studios", "Huge windows", "Best baguettes"] },
  ],
  london: [
    { name: "The Hoxbury", area: "Shoreditch", price: 196, rating: 4.6, perks: ["Basement bar", "24h desk", "Overground nearby"] },
    { name: "Bermondsey Yards", area: "Bermondsey", price: 154, rating: 4.5, perks: ["Market street", "River walk", "Quiet rooms"] },
    { name: "Paddington Pod", area: "Paddington", price: 88, rating: 4.2, perks: ["Heathrow express", "Pod rooms", "Rainproof"] },
  ],
  lisbon: [
    { name: "Casa do Miradouro", area: "Alfama", price: 128, rating: 4.8, perks: ["Terrace view", "Tiled rooms", "Tram 28 at the door"] },
    { name: "The Lumiar", area: "Chiado", price: 176, rating: 4.6, perks: ["Rooftop pool", "Bakery downstairs", "Walk to Baixa"] },
    { name: "Bairro Bunks", area: "Bairro Alto", price: 62, rating: 4.3, perks: ["Courtyard", "Shared kitchen", "Fado next door"] },
  ],
  bali: [
    { name: "Ubud Canopy", area: "Ubud", price: 96, rating: 4.9, perks: ["Jungle pool", "Yoga deck", "Rice field walk"] },
    { name: "Canggu Longboard", area: "Canggu", price: 118, rating: 4.6, perks: ["Surf rental", "Sunset bar", "Cowork pass"] },
    { name: "Ulu Cliff Pods", area: "Uluwatu", price: 82, rating: 4.5, perks: ["Cliff path", "Breakfast included", "Scooter friendly"] },
  ],
};

function genericHotelOptions(city: string): HotelOption[] {
  const c = cap(city);
  return [
    { name: `${c} Old Town Stay`, area: "Old Town", price: 122, rating: 4.6, perks: ["Walkable centre", "Local breakfast", "Late checkout"] },
    { name: `${c} Central Hotel`, area: "Downtown", price: 158, rating: 4.5, perks: ["Metro at the door", "Gym", "Business desk"] },
    { name: `${c} Garden Hostel`, area: "Riverside", price: 64, rating: 4.3, perks: ["Garden", "Shared kitchen", "Bike hire"] },
  ];
}

function hotelSearchScript(lower: string): Script {
  let city = "";
  const cm = lower.match(/(?:in|near|around)\s+([a-z][a-z\s]{1,20}?)(?:\s+(?:for|next|this|under|cheap|please|tonight)|$|[,.?!])/);
  if (cm) city = cm[1].trim();
  const options = [...((city && HOTEL_DATA[city]) || genericHotelOptions(city || "the city"))].sort((a, b) => b.rating - a.rating);
  const cityLabel = city ? city.split(" ").map(cap).join(" ") : "The City";
  const screenId = `hotel-${stamp()}`;
  setPending({ kind: "hotel", city: cityLabel, screenId, options, budget: 400, selected: null });

  // the shortlist builds itself WHILE fotra speaks
  const steps: InterleaveStep[] = [];
  options.forEach((o, i) => {
    steps.push({
      action: { type: "screen-delta", id: screenId, props: { [`option${i}Name`]: o.name, [`option${i}Area`]: o.area, [`option${i}Price`]: o.price, [`option${i}Rating`]: o.rating, [`option${i}Perks`]: o.perks } },
      afterGroups: 1 + i * 3,
      delay: 170,
    });
  });
  steps.push({
    action: { type: "screen", id: screenId, component: "hotel", demoData: true, building: false, props: { title: `${cityLabel} · 3 nights`, budget: 400, options } },
    afterGroups: 2 + options.length * 3,
    delay: 0,
  });
  return {
    react: TAPBACK.travel,
    scene: hotelSearchScene(cityLabel, options),
    actions: [{ type: "screen", id: screenId, component: "hotel", demoData: true, building: true, props: { title: `${cityLabel} · 3 nights`, budget: 400, options: [] } }],
    say: `Three worth your nights, best-rated first. Slide the budget, or tell me “under 120”. Pick one and I'll go hold it.`,
    steps,
  };
}

function hotelBudgetUpdate(max: number): Script {
  const p = pending.current;
  if (!p || !p.options) return fallbackScript();
  p.budget = max;
  const filtered = p.options.filter((o) => o.price <= max);
  return {
    say: filtered.length === 0 ? "Nothing under that this weekend — nudge it up a little." : `${filtered.length} under $${max}${filtered.length === 1 ? ". A clear winner, then." : "."}`,
    actions: [{ type: "screen-delta", id: p.screenId!, props: { budget: max, options: filtered } }],
  };
}

function hotelSelect(ordinal: number, direct?: HotelOption): Script {
  const p = pending.current;
  if (!p || !p.options || p.options.length === 0) return fallbackScript();
  const list = p.options.filter((o) => o.price <= (p.budget ?? 400));
  const chosen = direct ?? (ordinal >= 0 && ordinal < list.length ? list[ordinal] : list[0]) ?? p.options[0];
  p.selected = chosen;
  p.askId = `ask-${stamp()}`;
  return {
    scene: hotelPickScene(p.city ?? "the city", p.options, chosen),
    say: `${chosen.name}, ${chosen.area} — $${chosen.price} a night, ${chosen.rating} stars. Want me to hold it?`,
    actions: [
      { type: "screen-delta", id: p.screenId!, props: { selected: chosen.name } },
      {
        type: "ask",
        id: p.askId,
        question: `Hold ${chosen.name} for this weekend?`,
        detail: `$${chosen.price * 3} for 3 nights · free to hold — a demo booking, no card, no charge.`,
        options: ["Yes, hold it", "Show me others"],
        tone: "info",
      },
    ],
  };
}

function hotelConfirm(): Script {
  const p = pending.current;
  const chosen = p?.selected ?? null;
  const city = p?.city ?? "the city";
  setPending(null);
  if (!chosen || !p) return { say: "Held — demo booking, nothing charged." };
  return {
    scene: hotelHoldScene(city, chosen),
    say: `Held — ${chosen.name}, three nights, nothing charged. With a real model this is where I stop and hand you the checkout page: paying is always your click, not mine.`,
    actions: [{ type: "screen-delta", id: p.screenId!, props: { booked: true, selected: chosen.name } }],
  };
}

/* ————————————————————————————————————————————————
   COMPARE / BUDGET / CHECKLIST
   ———————————————————————————————————————————————— */

const COMPARISONS: Record<string, { columns: string[]; rows: string[][] }> = {
  "kyoto|tokyo": {
    columns: ["", "Kyoto", "Tokyo"],
    rows: [
      ["Vibe", "Temples, slow mornings", "Neon, fast everything"],
      ["Food", "Kaiseki, Nishiki market", "More Michelin stars than anywhere"],
      ["Stay (3n)", "$130–200", "$150–280"],
      ["Best for", "First unwind", "First adrenaline"],
    ],
  },
  "mac|windows": {
    columns: ["", "Mac", "Windows"],
    rows: [
      ["Out of box", "Boringly perfect", "Yours to tune"],
      ["Ecosystem", "One vendor, one way", "Anything, everything"],
      ["Price", "Premium, always", "Every budget"],
      ["Repair", "Genius bar or bust", "Your problem, your screwdriver"],
    ],
  },
  "remote|office": {
    columns: ["", "Remote", "Office"],
    rows: [
      ["Commute", "Ten steps", "Ten thousand"],
      ["Focus", "Deep, if you guard it", "Collisions, if you want them"],
      ["Loneliness", "Real risk", "Free coffee"],
      ["Career", "Out of sight?", "Visibility built in"],
    ],
  },
};

function compareScript(a: string, b: string): Script {
  const found = COMPARISONS[`${a}|${b}`] ?? COMPARISONS[`${b}|${a}`] ?? null;
  const id = `cmp-${stamp()}`;
  const scene: Scene = (signal) =>
    searchBeat(signal, `${a} vs ${b}`, [
      { title: `${cap(a)} vs ${cap(b)}: the honest comparison`, host: "sidebyside.demo", snippet: "What actually differs, without the brochure voice." },
      { title: `Choosing between ${cap(a)} and ${cap(b)}`, host: "fieldnotes.demo", snippet: "Who each one suits, and who regrets it." },
    ]);
  if (!found) {
    return {
      scene,
      say: `I can frame ${a} against ${b}, but the demo brain won't invent the specifics. Connect a model and this table fills with real, sourced rows.`,
      actions: [{ type: "screen", id, component: "table", demoData: true, props: { title: `${cap(a)} vs ${cap(b)}`, columns: ["", cap(a), cap(b)], rows: [["Cost", "—", "—"], ["Learning curve", "—", "—"], ["Best for", "—", "—"]] } }],
    };
  }
  return {
    scene,
    say: "Laid out — the honest version, not the brochure one.",
    actions: [{ type: "screen", id, component: "table", demoData: true, props: { title: `${cap(a)} vs ${cap(b)}`, columns: found.columns, rows: found.rows } }],
  };
}

function budgetScript(): Script {
  return {
    say: "Here's the shape of it — demo numbers, clearly marked.",
    actions: [{ type: "screen", id: `stat-${stamp()}`, component: "stat", demoData: true, props: { label: "MONTHLY SPEND · DEMO", value: "$1,842", delta: "-6% vs last month", hint: "Rent 52% · Food 21% · Fun 14% · Rest 13%" } }],
  };
}

function checklistScript(lower: string): Script {
  let title = "The list";
  let items = ["Decide the outcome", "Do the scary part first", "Park perfectionism", "Ship, then iterate"];
  if (/pack|trip|travel|flight/.test(lower)) {
    title = "Packing · carry-on only";
    items = ["Passport + visas", "Chargers in one pouch", "Two shirts, one warm layer", "Medications", "Download offline maps", "Empty bottle for security"];
  } else if (/morning|routine/.test(lower)) {
    title = "Morning · 30 min";
    items = ["Water before screens", "10 min stretch", "Write today's one thing", "No email till it's done"];
  } else if (/launch|ship|release/.test(lower)) {
    title = "Launch day";
    items = ["Freeze the build, tag it", "Draft the announcement", "Warm the caches", "Watch error rates for 30 min", "Tell the users who care most"];
  } else if (/move|moving|apartment/.test(lower)) {
    title = "Moving week";
    items = ["Label boxes by room + priority", "Bag a first-night kit", "Redirect mail", "Photograph meter readings", "Book the elevator slot"];
  }
  return {
    say: "Checklist's up — tick things off right on it.",
    actions: [{ type: "screen", id: `chk-${stamp()}`, component: "checklist", props: { title, items: items.map((t) => ({ text: t, done: false })) } }],
  };
}

/* ————————————————————————————————————————————————
   GAMES — rock-paper-scissors, mini quiz
   ———————————————————————————————————————————————— */

function rpsStartScript(): Script {
  setPending({ kind: "rps", rpsScore: [0, 0], askId: `rps-${stamp()}` });
  return {
    say: "Rock, paper, scissors. I don't cheat, but I do pattern-read. Pick your weapon.",
    actions: [{ type: "ask", id: pending.current?.askId ?? "ask", question: "Your move", options: ["Rock", "Paper", "Scissors"], tone: "info" }],
  };
}

function rpsResolve(move: string): Script {
  const p = pending.current!;
  const mine = pick(["Rock", "Paper", "Scissors"]);
  const beats: Record<string, string> = { Rock: "Scissors", Paper: "Rock", Scissors: "Paper" };
  const score: [number, number] = [...(p.rpsScore ?? [0, 0])];
  let verdict: string;
  if (move === mine) verdict = "A tie.";
  else if (beats[move] === mine) {
    verdict = "You win that one.";
    score[1]++;
  } else {
    verdict = "Mine.";
    score[0]++;
  }
  p.rpsScore = score;
  p.askId = `rps-${stamp()}`;
  return {
    say: `${mine} against your ${move}. ${verdict} Again?`,
    actions: [{ type: "ask", id: p.askId, question: `Me ${score[0]} · You ${score[1]} — next round?`, options: ["Rock", "Paper", "Scissors", "I'm out"], tone: "info" }],
  };
}

const QUIZ: { q: string; options: string[]; answer: number }[] = [
  { q: "What's the only planet that spins clockwise?", options: ["Venus", "Mars", "Neptune"], answer: 0 },
  { q: "Honey found in ancient tombs — still edible?", options: ["Yes", "No", "Only in Egypt"], answer: 0 },
  { q: "Which is longer: a day on Venus or its year?", options: ["The day", "The year", "They're equal"], answer: 0 },
];

function quizStartScript(): Script {
  setPending({ kind: "quiz", quizQ: 0, quizScore: 0, askId: `qz-${stamp()}` });
  return {
    say: "Three questions, no googling. First one's a classic.",
    actions: [{ type: "ask", id: pending.current?.askId ?? "quiz", question: `1/3 · ${QUIZ[0].q}`, options: QUIZ[0].options, tone: "info" }],
  };
}

function quizAnswer(answer: string): Script {
  const p = pending.current!;
  const idx = p.quizQ ?? 0;
  const q = QUIZ[idx];
  const correct = q.options.indexOf(answer) === q.answer;
  const score = (p.quizScore ?? 0) + (correct ? 1 : 0);
  if (idx + 1 >= QUIZ.length) {
    setPending(null);
    const verdict = score === QUIZ.length ? "Perfect. Suspiciously perfect." : score >= 2 ? "Solid — you'd survive a trivia night." : "Rough round. The rematch is free.";
    return { say: `${verdict} ${score} of ${QUIZ.length}.` };
  }
  const next = QUIZ[idx + 1];
  p.quizQ = idx + 1;
  p.quizScore = score;
  p.askId = `qz-${stamp()}`;
  return {
    say: correct ? "Correct. Next:" : `It was “${q.options[q.answer]}”. Next:`,
    actions: [{ type: "ask", id: p.askId, question: `${idx + 2}/3 · ${next.q}`, options: next.options, tone: "info" }],
  };
}

/* ————————————————————————————————————————————————
   PENDING CONTINUATION MATCHER
   ———————————————————————————————————————————————— */

function matchPending(lower: string): Script | null {
  const p = pending.current;
  if (!p) return null;

  if (p.kind === "hotel") {
    if (p.selected && /^(?:yes|yeah|yep|do it|confirm|hold it|book it|sure|go ahead|ok(?:ay)?)/.test(lower)) return hotelConfirm();
    if (p.selected && /^(?:no|nah|nope|others?|other ones|show me others|back|cancel)/.test(lower)) {
      p.selected = null;
      return { say: "Back to the shortlist.", actions: [{ type: "screen-delta", id: p.screenId!, props: { selected: null, booked: false, options: (p.options ?? []).filter((o) => o.price <= (p.budget ?? 400)) } }] };
    }
    const bm = lower.match(/(?:under|less than|below|max|budget(?: of)?)\s*\$?\s*(\d{2,4})|make it (?:cheaper|under)\s*\$?\s*(\d{2,4})/);
    if (bm) return hotelBudgetUpdate(parseInt(bm[1] || bm[2], 10));
    if (/cheap|cheaper/.test(lower)) return hotelBudgetUpdate(120);
    const byName = (p.options ?? []).find((o) => {
      const full = o.name.toLowerCase();
      const tokens = full.split(/\s+/).filter((w) => w.replace(/[^a-z0-9]/g, "").length >= 4);
      return lower.includes(full) || tokens.some((t) => lower.includes(t));
    });
    if (byName && /(go with|pick|take|book|like|choose|this|that|with|hold)/.test(lower)) return hotelSelect(-1, byName);
    if (/\b(first|second|third|1st|2nd|3rd|last|cheapest|top|best)\b/.test(lower)) {
      const list = (p.options ?? []).filter((o) => o.price <= (p.budget ?? 400));
      if (/cheapest/.test(lower)) return hotelSelect(-1, [...list].sort((a, b) => a.price - b.price)[0]);
      const ord = /second|2nd/.test(lower) ? 1 : /third|3rd|last/.test(lower) ? 2 : 0;
      return hotelSelect(ord);
    }
    if (/\b(?:book|hold|confirm)\b/.test(lower)) return hotelSelect(-1);
    if (/hotel|room|place to stay/.test(lower) && /(find|book|get|look|search|need|want|show|another|different)/.test(lower)) return hotelSearchScript(lower);
    setPending(null); // topic moved on
    return null;
  }

  if (p.kind === "rps") {
    const mv = lower.match(/^(rock|paper|scissors)\b/);
    if (mv) return rpsResolve(cap(mv[1]));
    if (/out|stop|quit|done|enough/.test(lower)) {
      setPending(null);
      const [me, you] = p.rpsScore ?? [0, 0];
      return { say: me > you ? `${me}–${you}, my favour. Rematch anytime.` : `${me}–${you}, yours. Well played.` };
    }
    setPending(null);
    return null;
  }

  if (p.kind === "quiz") {
    const q = QUIZ[p.quizQ ?? 0];
    const hit = q?.options.find((o) => lower.startsWith(o.toLowerCase()));
    if (hit) return quizAnswer(hit);
    setPending(null);
    return null;
  }
  return null;
}

/* ————————————————————————————————————————————————
   THE HARNESS, DEMONSTRATED — the same steps the real
   engine shows, on a script
   ———————————————————————————————————————————————— */

function codeDemoScript(lower: string): Script {
  // genuinely computed on your device — the demo brain doesn't fake math
  let code: string;
  let result: string;
  let lang: "python" | "js" = "python";
  if (/fibonacci/.test(lower)) {
    const f = [0, 1];
    for (let i = 2; i < 20; i++) f[i] = f[i - 1] + f[i - 2];
    result = f.join(", ");
    code = "def fib(n):\n    a, b = 0, 1\n    for _ in range(n):\n        yield a\n        a, b = b, a + b\n\nprint(*fib(20), sep=', ')";
  } else if (/prime/.test(lower)) {
    const primes: number[] = [];
    for (let n = 2; primes.length < 20; n++) if (primes.every((p) => n % p !== 0)) primes.push(n);
    result = primes.join(", ");
    code = "primes = []\nn = 2\nwhile len(primes) < 20:\n    if all(n % p for p in primes):\n        primes.append(n)\n    n += 1\n\nprint(*primes, sep=', ')";
  } else {
    lang = "js";
    const expr = lower.match(/[\d][\d\s+\-*/().%^]*[\d)]/)?.[0]?.trim() ?? "19 * 23";
    result = mathEval(expr) ?? "437";
    code = `console.log(${expr.replace(/\^/g, "**")});`;
  }
  return {
    scene: codeScene([{ lang, code, stdout: result + "\n", ms: 900 }]),
    say: /fibonacci|prime/.test(lower) ? "There they are — computed, not recalled. Open the step if you want the code." : `${result}. Computed, not guessed.`,
  };
}

function kernelDemoScript(): Script {
  return {
    scene: codeScene([
      { lang: "python", code: "data = {'city': 'Lisbon', 'nights': 3}\nprint('loaded', data['city'])", stdout: "loaded Lisbon\n", ms: 800, cell: 1 },
      { lang: "python", code: "# cell 1's variables are still alive\nresults = web_search(f\"{data['city']} hotel prices\")\nprint(data['city'], '→', len(results), 'sources')", stdout: "Lisbon → 5 sources\n", ms: 1100, cell: 2, bridge: [{ tool: "web_search", ok: true }] },
    ]),
    say: "Two cells, one kernel: the second remembered the first's variables, and called my own web search from inside the code.",
  };
}

function browserDemoScript(): Script {
  return {
    scene: browseScene("example.demo", "An example page"),
    say: "That window is my browser — you watch the cursor go where I'm about to click. On the demo brain it's a stand-in page; with a model connected it's a real Chromium on the real web.",
  };
}

function workersDemoScript(): Script {
  return {
    scene: workersScene([
      { name: "scout", task: "gather the sources", log: ["searching: recent benchmarks", "4 results · 2 usable", "reading the methodology"], result: "found 4 sources, 2 usable — the 2026 one is the solid one" },
      { name: "analyst", task: "crunch the numbers", log: ["python · loading the table", "computing the deltas"], result: "computed the comparison: a 12% gap, not the 30% in the headline" },
    ]),
    say: "Two workers at once, each with its own context and tools — they report back, I do the synthesis. Open either one to see what it did.",
  };
}

function filesDemoScript(lower: string): Script {
  const path = /plan/.test(lower) ? "plan.md" : /csv|data/.test(lower) ? "data.csv" : "notes.md";
  const content = path === "data.csv" ? "label,value\nsearched,4\nread,2\nwritten,1" : path === "plan.md" ? "# the plan\n\n1. scope it\n2. build it\n3. ship it" : "# notes\n\n- the workspace is a real folder\n- files survive reloads";
  return {
    scene: beat("ws_write", "file", "Writing", path, `wrote ${path}`, { path, preview: content, lines: content.split("\n").length, wrote: true }, 800),
    say: `Written — ${path}. With a model connected, files land in a real workspace folder you can open from the library.`,
  };
}

function boardDemoScript(): Script {
  const id = `demo-board-${stamp()}`;
  return {
    say: "Here's the plan. With a live model the board ticks over as the work actually happens.",
    steps: [
      { afterGroups: 1, delay: 240, action: { type: "screen", id, component: "todo", demoData: true, props: { items: [{ text: "scope the work", status: "doing" }, { text: "run the numbers", status: "todo" }, { text: "write the summary", status: "todo" }] } } },
      { afterGroups: 7, delay: 300, action: { type: "screen-delta", id, props: { items: [{ text: "scope the work", status: "done" }, { text: "run the numbers", status: "doing" }, { text: "write the summary", status: "todo" }] } } },
    ],
  };
}

function chartDemoScript(): Script {
  return {
    say: "Chart's up — demo numbers. A live model computes the data first, then draws it.",
    steps: [
      {
        afterGroups: 1,
        delay: 260,
        action: { type: "screen", id: `demo-chart-${stamp()}`, component: "chart", demoData: true, props: { title: "where a run's time goes (demo)", kind: "bar", labels: ["search", "read", "think", "speak"], series: [{ name: "ms", values: [812, 340, 1250, 430] }] } },
      },
    ],
  };
}

function routineDemoScript(text: string, lower: string): Script {
  const when = /every (\d+) ?(min|minute|hour)/.test(lower)
    ? lower.match(/every \d+ ?(?:min(?:ute)?s?|hours?)/)![0]
    : /evening|night/.test(lower)
      ? "daily 18:00"
      : /hour/.test(lower)
        ? "every 1 h"
        : `daily ${String(Number(lower.match(/\bat (\d{1,2})/)?.[1] ?? 8)).padStart(2, "0")}:00`;
  const prompt = text.replace(/^(?:set up|create|make|add) (?:a )?routine (?:to|that|for)?\s*/i, "").trim();
  const next = new Date();
  next.setDate(next.getDate() + 1);
  next.setHours(8, 0, 0, 0);
  return {
    scene: beat("routine_create", "schedule", "Scheduling", "", `scheduled — ${when}`, { name: prompt.split(/\s+/).slice(0, 5).join(" "), prompt, schedule: when, next: next.toISOString() }, 800),
    say: "That's what setting one looks like. The demo brain can't run on a schedule — with a model connected it fires as a full run on its own and the answer lands here.",
  };
}

function harnessCardScript(lower: string): Script {
  const id = `demo-harness-${stamp()}`;
  if (/advisor|second/.test(lower)) {
    return { say: "A second model reads my steps from the outside. Mostly it's quiet; a blocker means I fix it before I finish.", actions: [{ type: "screen", id, component: "card", demoData: true, props: { title: "the advisor", items: ["its own context — it catches what the doer rushed past", "an aside, a concern, or a blocker", "at most two passes per run"] } }] };
  }
  if (/checkpoint|rewind/.test(lower)) {
    return { say: "I can mark my context, go exploring, then collapse the whole detour into one report and keep going.", actions: [{ type: "screen", id, component: "card", demoData: true, props: { title: "checkpoint → rewind", items: ["mark the context before a long exploration", "collapse it into a report when it pays off", "the run stays alive; the context is freed"] } }] };
  }
  return { say: "Stream rules sit dormant until I go off-script — then they cut the reply mid-token, inject the reminder, and I start over. Add your own in settings.", actions: [{ type: "screen", id, component: "card", demoData: true, props: { title: "stream rules", items: ["a regex that watches the live output", "cut mid-token, retry from the same point", "seeded with anti-filler rules — add yours"] } }] };
}
