"use client";

/* ————————————————————————————————————————————————
   FOTRA — realtime voice (the OpenDots useVoice port)
   WebRTC to the provider; the server relays the SDP so
   the key never touches the browser. One data channel
   ("oai-events") carries the provider events: captions
   both directions, semantic-VAD barge-in (caption clears
   on speech_started), and the single ask_fotra tool that
   delegates into the same harness as the text thread.
   15-minute cap with a 14:30 notice. Receipts land in
   the thread when the call ends.
   ———————————————————————————————————————————————— */

import { useFotra } from "./store";
import { uid } from "./types";
import type { Persona } from "./types";

export type CallStatus = "idle" | "connecting" | "active" | "ending";
export type CallPhase = "listening" | "thinking" | "speaking";

interface CallSession {
  pc: RTCPeerConnection;
  stream: MediaStream;
  audio: HTMLAudioElement;
  channel: RTCDataChannel;
  id?: string;
  transcript: string[];
  capTimer?: ReturnType<typeof setTimeout>;
  noticeTimer?: ReturnType<typeof setTimeout>;
  disconnectTimer?: ReturnType<typeof setTimeout>;
  cancelled: boolean;
  controlFailures: number;
}

interface RealtimeState {
  status: CallStatus;
  phase: CallPhase;
  error: string;
  muted: boolean;
  speakerMuted: boolean;
  startedAt: number | null;
  caption: string;
  userCaption: string;
  warn14: boolean; // 14:30 notice fired
}

const state: RealtimeState = {
  status: "idle",
  phase: "listening",
  error: "",
  muted: false,
  speakerMuted: false,
  startedAt: null,
  caption: "",
  userCaption: "",
  warn14: false,
};

let session: CallSession | null = null;
let generation = 0;
let connecting = false;
let ending = false;

const listeners = new Set<() => void>();
function notify() {
  for (const fn of listeners) fn();
}
/** subscribe to call-state changes (React useSyncExternalStore-friendly) */
export function subscribeCalls(fn: () => void): () => void {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}
export function callState(): RealtimeState {
  return state;
}
function patch(p: Partial<RealtimeState>) {
  Object.assign(state, p);
  // mirror the call into the app phase so the mascot reacts during calls too
  const s = useFotra.getState();
  const callLive = state.status === "active" || state.status === "connecting" || p.status === "active" || p.status === "connecting";
  if (p.phase && callLive && !s.readOnly) {
    useFotra.setState({ phase: p.phase });
  }
  if (p.status === "idle" && (s.phase === "listening" || s.phase === "speaking")) {
    // the call ended — hands the phase back (a text run finishes to idle on its own)
    useFotra.setState({ phase: "idle" });
  }
  notify();
}

const get = useFotra.getState;

/* ————————————————————————————————————————————————
   START — mic → RTCPeerConnection → server SDP relay
   ———————————————————————————————————————————————— */

export async function startCall(): Promise<void> {
  if (session || connecting || ending) return;
  connecting = true;
  const attempt = ++generation;
  patch({ status: "connecting", error: "", phase: "listening", caption: "", userCaption: "", warn14: false, startedAt: null });

  const s = get();
  const sessionId = s.settings.sessionId?.trim();
  if (!sessionId) {
    patch({ status: "idle", error: "say something in text first — the voice call continues that thread" });
    connecting = false;
    return;
  }

  let stream: MediaStream | undefined;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    if (attempt !== generation) {
      stream.getTracks().forEach((t) => t.stop());
      return;
    }

    const pc = new RTCPeerConnection();
    const audio = new Audio();
    audio.autoplay = true;
    const channel = pc.createDataChannel("oai-events");
    const current: CallSession = {
      pc,
      audio,
      stream,
      channel,
      transcript: [],
      cancelled: false,
      controlFailures: 0,
    };
    session = current;

    stream.getTracks().forEach((track) => pc.addTrack(track, stream!));
    pc.ontrack = (event) => {
      if (current.cancelled) return;
      audio.srcObject = event.streams[0] ?? new MediaStream([event.track]);
      void audio.play().catch(() => {
        if (!current.cancelled) patch({ error: "audio playback was blocked — check browser audio permissions" });
      });
    };
    pc.onconnectionstatechange = () => {
      if (current.cancelled) return;
      if (pc.connectionState === "connected") {
        clearTimeout(current.disconnectTimer);
        patch({ status: "active", startedAt: state.startedAt ?? Date.now() });
        if (current.id) {
          void fetch(`/api/voice/calls/${current.id}/active`, { method: "POST" }).catch(() => undefined);
        }
      }
      if (pc.connectionState === "disconnected" && !current.disconnectTimer) {
        current.disconnectTimer = setTimeout(() => {
          current.disconnectTimer = undefined;
          if (current.cancelled || pc.connectionState !== "disconnected") return;
          patch({ error: "the voice connection dropped" });
          void endCall();
        }, 5000);
      }
      if (pc.connectionState === "failed") {
        patch({ error: "the voice connection dropped" });
        void endCall();
      }
    };

    channel.onmessage = (event) => {
      if (current.cancelled) return;
      let data: Record<string, unknown>;
      try {
        const parsed: unknown = JSON.parse(String(event.data));
        if (!parsed || typeof parsed !== "object") return;
        data = parsed as Record<string, unknown>;
      } catch {
        return;
      }

      // barge-in: the user started speaking — clear the caption, listen
      if (data.type === "input_audio_buffer.speech_started") {
        patch({ phase: "listening", caption: "" });
      }
      if (data.type === "response.output_audio_transcript.delta" && typeof data.delta === "string") {
        patch({ phase: "speaking", caption: state.caption + (data.delta as string) });
      }
      if (data.type === "output_audio_buffer.stopped") patch({ phase: "listening" });
      if (data.type === "response.created") {
        patch({ phase: "thinking", caption: "" });
      }
      if (typeof data.transcript === "string") {
        if (data.type === "conversation.item.input_audio_transcription.completed") {
          current.transcript.push(`you: ${data.transcript}`);
          patch({ userCaption: data.transcript });
        }
        if (data.type === "response.output_audio_transcript.done") {
          current.transcript.push(`fotra: ${data.transcript}`);
        }
      }
      if (data.type === "error") {
        patch({ error: "the voice provider reported a session error — end the call and retry" });
      }

      // ask_fotra — the delegation into the harness
      if (data.type !== "response.function_call_arguments.done" || data.name !== "ask_fotra" || typeof data.call_id !== "string" || !current.id) {
        return;
      }
      patch({ phase: "thinking" });
      void (async () => {
        let output = "";
        try {
          const args = JSON.parse(String(data.arguments ?? "{}")) as { request?: string };
          const res = await fetch(`/api/voice/calls/${current.id}/compute`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ toolCallId: data.call_id, request: String(args.request ?? "") }),
          });
          const j = (await res.json()) as { text?: string; error?: string };
          output = j.text ?? `compute failed: ${j.error ?? "unknown"}`;
        } catch (err) {
          output = `compute failed: ${err instanceof Error ? err.message : "unknown"}`;
        }
        if (!current.cancelled && channel.readyState === "open") {
          channel.send(JSON.stringify({ type: "conversation.item.create", item: { type: "function_call_output", call_id: data.call_id, output } }));
          channel.send(JSON.stringify({ type: "response.create" }));
        }
      })();
    };

    // the 14:30 notice + 15:00 cap
    current.noticeTimer = setTimeout(() => patch({ warn14: true }), 14 * 60_000 + 30_000);
    current.capTimer = setTimeout(() => void endCall(), 15 * 60_000);

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);

    const persona: Persona = get().persona;
    const res = await fetch("/api/voice/calls", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId, sdp: offer.sdp, voice: get().settings.realtimeVoice || "alloy", persona }),
    });
    if (!res.ok) {
      const j = (await res.json().catch(() => ({}))) as { error?: string; hint?: string };
      throw new Error(j.hint || j.error || `the relay refused the call (HTTP ${res.status})`);
    }
    const j = (await res.json()) as { id: string; sdp: string };
    current.id = j.id;
    if (current.cancelled) {
      void fetch(`/api/voice/calls/${j.id}/end`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ transcript: "" }) }).catch(() => undefined);
      return;
    }
    await pc.setRemoteDescription({ type: "answer", sdp: j.sdp });
  } catch (err) {
    if (attempt !== generation) {
      stream?.getTracks().forEach((t) => t.stop());
      return;
    }
    const current = session;
    if (current?.id) {
      void fetch(`/api/voice/calls/${current.id}/end`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ transcript: "" }), keepalive: true }).catch(() => undefined);
    }
    closeMedia();
    patch({ status: "idle", error: err instanceof Error ? err.message : "could not connect the call" });
  } finally {
    if (attempt === generation) connecting = false;
  }
}

/* ————————————————————————————————————————————————
   END — receipt + cleanup
   ———————————————————————————————————————————————— */

export async function endCall(): Promise<void> {
  const current = session;
  if (ending || !current) {
    if (!current) patch({ status: "idle" });
    return;
  }
  ending = true;
  generation++;
  current.cancelled = true;
  current.stream.getTracks().forEach((t) => {
    t.enabled = false;
  });
  current.audio.pause();
  patch({ status: "ending" });
  try {
    if (current.id) {
      const res = await fetch(`/api/voice/calls/${current.id}/end`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transcript: current.transcript.join("\n").slice(0, 20000) }),
      });
      const j = (await res.json().catch(() => ({}))) as { receipt?: string };
      // the receipt lands as a quiet chip in the thread
      if (j.receipt) {
        const store = get();
        const id = `vc-${uid("t")}`;
        store.pushSystemTurn?.(id, j.receipt);
        // server already persisted it; local thread mirrors it for instant view
      }
    }
  } catch {
    patch({ error: "the call ended, but its receipt could not be saved" });
  } finally {
    closeMedia();
    ending = false;
    patch({ status: "idle", phase: "listening", caption: "", userCaption: "", warn14: false });
  }
}

function closeMedia() {
  const current = session;
  if (!current) return;
  current.cancelled = true;
  current.stream.getTracks().forEach((t) => t.stop());
  try {
    current.channel.close();
  } catch {
    /* already closed */
  }
  try {
    current.pc.close();
  } catch {
    /* already closed */
  }
  current.audio.pause();
  current.audio.srcObject = null;
  clearTimeout(current.capTimer);
  clearTimeout(current.noticeTimer);
  clearTimeout(current.disconnectTimer);
  session = null;
}

export function toggleMute() {
  const next = !state.muted;
  session?.stream.getAudioTracks().forEach((t) => {
    t.enabled = !next;
  });
  patch({ muted: next });
}

export function toggleSpeaker() {
  const next = !state.speakerMuted;
  if (session) session.audio.muted = next;
  patch({ speakerMuted: next });
}

/** page unload — hang up cleanly */
export function teardownCall(): void {
  const current = session;
  generation++;
  closeMedia();
  if (current?.id) {
    void fetch(`/api/voice/calls/${current.id}/end`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ transcript: current.transcript.join("\n").slice(0, 20000) }),
      keepalive: true,
    }).catch(() => undefined);
  }
}
