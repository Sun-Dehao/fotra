/* ————————————————————————————————————————————————
   REACTIONS — tapbacks, both ways.
   You react to what it said; it sometimes reacts to
   what you said. A reaction you leave is feedback: it
   rides into the next run, and a thumbs-down can carry
   a word about what was off.

   This file is the ONE place emoji live in the source
   (as escaped code points — the slop gate stays strict
   everywhere else): they are data here, never decoration.
   ———————————————————————————————————————————————— */

export interface ReactionChoice {
  emoji: string;
  label: string;
  /** a negative reaction offers a quick "what was off?" */
  asksWhy?: boolean;
}

export const REACTIONS: ReactionChoice[] = [
  { emoji: "\u{1F44D}", label: "good" },
  { emoji: "\u{2764}\u{FE0F}", label: "love it" },
  { emoji: "\u{1F602}", label: "funny" },
  { emoji: "\u{1F62E}", label: "whoa" },
  { emoji: "\u{1F525}", label: "fire" },
  { emoji: "\u{1F44E}", label: "not this", asksWhy: true },
];

export const WHY_CHIPS = ["too long", "too short", "not what I asked", "wrong", "wrong tone"];

/** what the demo brain taps back with — the real brain picks its own */
export const TAPBACK = {
  thanks: "\u{2764}\u{FE0F}",
  joke: "\u{1F602}",
  greet: "\u{1F44B}",
  noted: "\u{1F4CC}",
  ouch: "\u{1FAE0}",
  nice: "\u{1F525}",
  ok: "\u{1F44D}",
  bye: "\u{1F44B}",
  travel: "\u{2708}\u{FE0F}",
} as const;
