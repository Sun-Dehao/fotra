import type { FotraAction, ScreenKind, WidgetKind } from "./types";

/* ————————————————————————————————————————————————
   FOTRA wire protocol — progressive parser
   The model outputs ONE json object: {"say": "...", "actions": [...]}
   We render it while it streams: say-text fills word by word,
   each action docks the moment its braces close.
   Tolerant by design: never a silent drop, never a crash.
   ———————————————————————————————————————————————— */

export interface ProtocolResult {
  say: string;
  actions: unknown[];
}

const SAY_KEY = '"say"';
const ACT_KEY = '"actions"';

/** longest suffix of s that is a proper prefix of a key token — the streaming carry */
function keyCarry(s: string): string {
  let best = "";
  for (const key of [SAY_KEY, ACT_KEY]) {
    const max = Math.min(s.length, key.length - 1);
    for (let len = max; len > best.length; len--) {
      if (s.endsWith(key.slice(0, len))) {
        best = s.slice(s.length - len);
        break;
      }
    }
  }
  return best;
}

interface ScanState {
  sayText: string;
  actions: unknown[];
  inSay: boolean;
  sayDone: boolean;
  inActions: boolean;
  inString: boolean; // inside a string within the actions array
  escaped: boolean; // escape flag (say-string and action-strings)
  depth: number; // brace depth inside the actions array
  buf: string; // current action object buffer
}

/* ———— plainText rescue ————
   A protocol-ignoring model may emit prose AND a bare JSON tool call
   (no {"say":…} wrapper). We still extract any balanced JSON object
   that parses as an action — and never speak raw JSON aloud. */
interface PlainScan {
  carry: string; // unprocessed tail (may hold a partial object)
  objBuf: string; // current {...} capture
  inObj: boolean;
  inStr: boolean;
  esc: boolean;
  objDepth: number;
}

function looksLikeAction(o: unknown): boolean {
  return !!o && typeof o === "object" && typeof (o as Record<string, unknown>).type === "string";
}

/* Streaming-safe progressive parser.
   Chunks may split ANYWHERE — mid-key, mid-colon, mid-string, mid-object.
   Unconsumed key candidates are carried into the next feed; state machines
   (say-string, actions-array) persist across feeds. Never spins, never
   silently truncates nested arrays. */
export class ProtocolParser {
  private carry = "";
  private sawBrace = false;
  private plain: PlainScan = { carry: "", objBuf: "", inObj: false, inStr: false, esc: false, objDepth: 0 };
  private state: ScanState = {
    sayText: "",
    actions: [],
    inSay: false,
    sayDone: false,
    inActions: false,
    inString: false,
    escaped: false,
    depth: 0,
    buf: "",
  };
  private emittedSay = "";
  plainText = false;

  /** Feed a chunk. Returns newly completed slices: say delta + new actions. */
  feed(chunk: string): { sayDelta: string; newActions: unknown[] } {
    const before = this.state.actions.length;
    const s = this.carry + chunk;
    this.carry = "";
    let i = 0;

    // protocol gate: wait for the opening '{'; real text before it → plain speech
    if (!this.sawBrace && !this.plainText) {
      const brace = s.indexOf("{");
      // many models wrap the object in a markdown code fence — that is packaging, not speech
      const head = (brace === -1 ? s : s.slice(0, brace)).replace(/^\s*`{3}[a-zA-Z]*\s*/, "");
      const partialFence = brace === -1 && /^`{1,3}[a-zA-Z]{0,8}$/.test(s.trim());
      if (partialFence) {
        this.carry = s; // the fence is still arriving
        return { sayDelta: "", newActions: [] };
      }
      if (head.trim() !== "") {
        this.plainText = true;
      } else if (brace === -1) {
        return { sayDelta: "", newActions: [] }; // whitespace only so far
      } else {
        this.sawBrace = true;
        i = brace + 1;
      }
    }
    if (this.plainText) {
      this.plainFeed(s);
    } else {
      outer: while (i < s.length) {
        // —— inside the say value string ——
        if (this.state.inSay) {
          while (i < s.length) {
            const ch = s[i++];
            if (this.state.escaped) {
              this.state.escaped = false;
              this.state.sayText += this.unescape(ch);
              continue;
            }
            if (ch === "\\") {
              this.state.escaped = true;
              continue;
            }
            if (ch === '"') {
              this.state.inSay = false;
              this.state.sayDone = true;
              continue outer;
            }
            this.state.sayText += ch;
          }
          break; // string continues in the next chunk
        }

        // —— inside the actions array ——
        if (this.state.inActions) {
          while (i < s.length) {
            const ch = s[i++];
            if (this.state.inString) {
              this.state.buf += ch;
              if (this.state.escaped) this.state.escaped = false;
              else if (ch === "\\") this.state.escaped = true;
              else if (ch === '"') this.state.inString = false;
              continue;
            }
            if (ch === '"') {
              this.state.inString = true;
              this.state.buf += ch;
              continue;
            }
            if (ch === "{") {
              this.state.depth++;
              if (this.state.depth === 1) {
                this.state.buf = "{"; // start fresh object
              } else {
                this.state.buf += ch;
              }
              continue;
            }
            if (ch === "}") {
              this.state.depth--;
              if (this.state.depth === 0) {
                this.pushAction(this.state.buf + "}");
                this.state.buf = "";
                continue;
              }
              this.state.buf += ch;
              continue;
            }
            if (ch === "]") {
              if (this.state.depth === 0) {
                this.state.inActions = false;
                continue outer; // array closed
              }
              this.state.buf += ch; // nested array inside an action object
              continue;
            }
            if (this.state.depth > 0) this.state.buf += ch;
          }
          break; // array continues in the next chunk
        }

        // —— scanning for the next key ——
        const rest = s.slice(i);
        const sayAt = this.state.sayDone ? -1 : rest.indexOf(SAY_KEY);
        const actAt = rest.indexOf(ACT_KEY);
        let key = "";
        let at = -1;
        let klen = 0;
        if (sayAt !== -1 && (actAt === -1 || sayAt <= actAt)) {
          key = "say";
          at = sayAt;
          klen = SAY_KEY.length;
        } else if (actAt !== -1) {
          key = "actions";
          at = actAt;
          klen = ACT_KEY.length;
        }

        if (!key) {
          // no complete key — keep a possible split key at the tail, drop the junk before it
          this.carry = keyCarry(rest);
          break;
        }

        const tail = rest.slice(at + klen);
        const m = tail.match(/^[ \t\r\n]*:[ \t\r\n]*/);
        if (!m) {
          this.carry = rest.slice(at); // colon hasn't arrived yet
          break;
        }
        const val = tail.slice(m[0].length);

        if (key === "say") {
          if (val.startsWith('"')) {
            this.state.inSay = true;
            i += at + klen + m[0].length + 1; // step past the opening quote
            continue;
          }
          this.carry = rest.slice(at); // opening quote hasn't arrived
          break;
        }
        if (val.startsWith("[")) {
          this.state.inActions = true;
          i += at + klen + m[0].length + 1; // step past the bracket
          continue;
        }
        this.carry = rest.slice(at); // bracket hasn't arrived
        break;
      }
    }

    // emit whatever is new beyond what we already surfaced
    let delta = "";
    if (this.state.sayText.length > this.emittedSay.length) {
      delta = this.state.sayText.slice(this.emittedSay.length);
      this.emittedSay = this.state.sayText;
    }
    return { sayDelta: delta, newActions: this.state.actions.slice(before) };
  }

  private pushAction(raw: string) {
    try {
      const obj = JSON.parse(raw);
      if (obj && typeof obj === "object") this.state.actions.push(obj);
    } catch {
      /* incomplete/malformed object — dropped, never crashes */
    }
  }

  /* plainText path: prose is speech, but balanced JSON objects that parse
     as actions are EXTRACTED (tools still run) and stripped from the speech. */
  private plainFeed(s: string): void {
    const p = this.plain;
    p.carry += s;
    let safe = 0;
    while (p.carry.length > 0 && safe++ < 100_000) {
      if (!p.inObj) {
        const brace = p.carry.indexOf("{");
        if (brace === -1) {
          this.state.sayText += p.carry;
          p.carry = "";
          break;
        }
        this.state.sayText += p.carry.slice(0, brace);
        p.carry = p.carry.slice(brace);
        p.inObj = true;
        p.objBuf = "";
        p.objDepth = 0;
        p.inStr = false;
        p.esc = false;
        continue;
      }
      // inside an object capture — count braces honestly (strings, escapes)
      const ch = p.carry[0];
      p.carry = p.carry.slice(1);
      p.objBuf += ch;
      if (p.esc) {
        p.esc = false;
        continue;
      }
      if (ch === "\\" && p.inStr) {
        p.esc = true;
        continue;
      }
      if (ch === '"') {
        p.inStr = !p.inStr;
        continue;
      }
      if (p.inStr) continue;
      if (ch === "{") p.objDepth++;
      else if (ch === "}") {
        p.objDepth--;
        if (p.objDepth === 0) {
          // complete object — is it an action?
          let parsed: unknown = null;
          try {
            parsed = JSON.parse(p.objBuf);
          } catch {
            parsed = null;
          }
          const env = parsed as { say?: unknown; actions?: unknown } | null;
          if (looksLikeAction(parsed)) {
            this.state.actions.push(parsed);
          } else if (env && typeof env === "object" && (typeof env.say === "string" || Array.isArray(env.actions))) {
            // the whole reply object, just not at the very start (prose or a fence came first): honour it
            if (typeof env.say === "string") this.state.sayText += env.say;
            if (Array.isArray(env.actions)) for (const a of env.actions) if (a && typeof a === "object") this.state.actions.push(a);
          } else {
            this.state.sayText += p.objBuf; // honest: not an action — it's text
          }
          p.inObj = false;
          p.objBuf = "";
        }
      }
    }
  }

  finish(): ProtocolResult {
    if (this.plainText) {
      // flush any dangling partial object as text (never drop user-visible words)
      this.state.sayText += this.plain.objBuf + this.plain.carry;
      this.plain = { carry: "", objBuf: "", inObj: false, inStr: false, esc: false, objDepth: 0 };
    }
    // leftover packaging never reaches the user
    const say = this.state.sayText.replace(/`{3}[a-zA-Z]*/g, "").trim();
    return { say, actions: this.state.actions };
  }

  private unescape(ch: string): string {
    switch (ch) {
      case "n": return "\n";
      case "t": return "\t";
      case '"': return '"';
      case "\\": return "\\";
      case "/": return "/";
      default: return ch;
    }
  }
}

/** Validate an action object against the fotra action vocabulary. */
export function coerceAction(raw: unknown): FotraAction | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const t = typeof o.type === "string" ? o.type : "";
  switch (t) {
    case "screen":
      if (typeof o.id === "string" && typeof o.component === "string" && o.props && typeof o.props === "object") {
        return { type: "screen", id: o.id, component: o.component as ScreenKind, props: o.props as Record<string, unknown>, demoData: o.demoData === true };
      }
      return null;
    case "screen-delta":
      if (typeof o.id === "string" && o.props && typeof o.props === "object") {
        return { type: "screen-delta", id: o.id, props: o.props as Record<string, unknown> };
      }
      return null;
    case "persona":
      if (o.patch && typeof o.patch === "object") return { type: "persona", patch: o.patch as Record<string, unknown> };
      return null;
    case "theme":
      if (o.value === "verdant" || o.value === "ember") return { type: "theme", value: o.value };
      return null;
    case "remember":
      if (typeof o.fact === "string") return { type: "remember", fact: o.fact, topic: typeof o.topic === "string" ? o.topic : undefined };
      return null;
    case "widget":
      if (typeof o.id === "string" && typeof o.kind === "string" && o.props && typeof o.props === "object") {
        return { type: "widget", id: o.id, kind: o.kind as WidgetKind, props: o.props as Record<string, unknown> };
      }
      return null;
    case "unwidget":
      if (typeof o.id === "string") return { type: "unwidget", id: o.id };
      return null;
    case "ask":
      if (typeof o.id === "string" && typeof o.question === "string") {
        const resume =
          o.resume && typeof o.resume === "object" && typeof (o.resume as Record<string, unknown>).runId === "string"
            ? {
                runId: String((o.resume as Record<string, unknown>).runId),
                kind: (o.resume as Record<string, unknown>).kind === "budget" ? ("budget" as const) : ("ask" as const),
              }
            : undefined;
        return {
          type: "ask",
          id: o.id,
          question: o.question,
          detail: typeof o.detail === "string" ? o.detail : undefined,
          options: Array.isArray(o.options) ? (o.options as unknown[]).filter((x): x is string => typeof x === "string") : undefined,
          tone: o.tone === "warn" ? "warn" : "info",
          resume,
        };
      }
      return null;
    case "open_link":
      if (typeof o.url === "string" && /^https?:\/\//i.test(o.url)) {
        return { type: "open_link", url: o.url, label: typeof o.label === "string" ? o.label : undefined };
      }
      return null;
    case "react": {
      // one emoji (a grapheme or two code points with a joiner) — anything longer is prose, not a tapback
      const e = typeof o.emoji === "string" ? o.emoji.trim() : "";
      if (e && [...e].length <= 6 && !/[a-z0-9]/i.test(e) && !/[\u{1F50D}\u{1F50E}\u{1F937}\u{1F914}\u{23F3}\u{231B}\u{1F6E0}\u{1F527}\u{1F4BB}\u{1F9D0}\u{1F4E1}\u{1F310}]/u.test(e)) return { type: "react", emoji: e }; // a tapback is a feeling, never a status icon
      return null;
    }
    default:
      return null;
  }
}

export const PROTOCOL_DOC = `You are the engine behind "fotra" — a voice-first AI companion. You ALWAYS reply with a single JSON object and nothing else — raw JSON starting with { , never inside a markdown code fence, no text before or after it:

{"say": "<what you say aloud>", "actions": [ ... ]}

Rules for "say":
- 1–3 short sentences. Spoken out loud. Contractions. Warm, easy, a little dry-funny. Never "Certainly!", never filler, never bullet lists in speech.
- When the answer needs MORE than that — a guide, a comparison in prose, code, a plan, anything the user will read rather than hear — put it in a "doc" screen (markdown) and let "say" be the one-line gist. Never cram a long answer into "say".
- Never mention JSON, screens, or that you are an AI model. You are ${"{{PERSONA_NAME}}"} — ${"{{PERSONA_TAGLINE}}"}. Stay in that persona: your name is ${"{{PERSONA_NAME}}"} and the user chose it for you; never break character or rename yourself.

Actions you may include (only when useful, often zero):
- {"type":"screen","id":"...","component":"doc","props":{"title":"...","markdown":"## heading\\n\\nfull markdown: lists, tables, **bold**, \`code\`, fenced code blocks"}}  (the long-form answer)
- {"type":"screen","id":"...","component":"sources","props":{"items":[{"title":"...","url":"https://...","host":"example.com"}]}}  (what a researched answer stands on — only URLs that came back from your tools this turn)
- {"type":"react","emoji":"\u{1F44D}"}  (a tapback on the user's message, exactly like texting a friend. One emoji.)

TEXT LIKE A PERSON — THE TAPBACK CAN BE THE WHOLE REPLY. When a message needs no words back — "thanks", "ok", "got it", "lol", "nice", "you still there?", "good night", good news, a photo-of-my-lunch kind of remark — do NOT write a sentence. Reply with an empty say and just the reaction:
{"say": "", "actions": [{"type":"react","emoji":"\u{2764}\u{FE0F}"}]}
A heart for thanks, a thumbs-up for "ok"/"still there?", a laugh for a joke. A tapback REPLACES a reply; it is not decoration. When the message is a question or a task, do NOT react to it — just answer or do the work. Never use an emoji to show what you are doing (no magnifying glass for "searching", no shrug for "not sure"). Never pad an acknowledgement into prose.
DO, THEN TALK. Never end a reply on a promise ("Let me check…", "I'll look into it") — if you are going to use a tool, the tool call is in THIS reply's actions. When a tool fails, do not narrate or apologise ("my search slipped up") — silently send a corrected call, or try a different tool; after two failures of the same tool, stop and say in one line what you could not get. The user sees every step already; your words are for results. Short beats long; silence plus a heart beats "You're welcome! Let me know if you need anything else."
- {"type":"screen","id":"unique-id","component":"card","props":{"title":"...","body":"...","items":["..."]}}
- {"type":"screen","id":"...","component":"stat","props":{"label":"MONTHLY SPEND","value":"$1,240","delta":"+8%","hint":"vs last month"}}
- {"type":"screen","id":"...","component":"table","props":{"title":"...","columns":["A","B"],"rows":[["...","..."]]}}
- {"type":"screen","id":"...","component":"checklist","props":{"title":"...","items":["..."]}}
- {"type":"screen","id":"...","component":"hotel","props":{"title":"Tokyo · 3 nights","options":[{"name":"...","area":"...","price":178,"rating":4.7,"perks":["..."]]}}
- {"type":"screen","id":"...","component":"todo","props":{"items":[{"text":"...","status":"todo"}]}}  (statuses: todo | doing | done)
- {"type":"screen","id":"...","component":"chart","props":{"title":"...","kind":"bar","labels":["a","b"],"series":[{"name":"...","values":[1,2]}]}}
(Your tool calls show themselves: the user already watches each search, page, code run, browser step and worker live, and can open any of them afterwards. Do NOT re-post their output as a screen, and don't narrate what a tool is doing — screens are for RESULTS the user asked for.)
- {"type":"ask","id":"...","question":"...","detail":"...","options":["Yes","No"],"tone":"info"}  (or use the ask_user tool — same effect: the run pauses, the human's answer resumes it)
- {"type":"persona","patch":{"name":"..."}}  (a quick change to yourself: "name", "tagline", "mascot":"dot" (the sprout)|"ghost"|"star"|"cat"|"bot"|"orb" — your body — "aura":"calm" (a soft glow)|"pulse" (sonar rings)|"spark" (twinkling sparks) — what surrounds you — "coat":"iris"|"verdant"|"ember"|"ice"|"rose"|"mono" — your skin, which re-colors the whole app. For anything about how you BEHAVE or how the app is laid out, use the self_edit tool.)
- {"type":"remember","fact":"...","topic":"..."}  (when the user tells you something durable about themselves)
- {"type":"open_link","url":"https://...","label":"..."}  (open a page in the user's browser — the hand-off at the payment boundary)
- {"type":"widget","id":"note-1","kind":"note","props":{"text":"..."}}  (put a persistent note on screen; kinds: note, todo, timer, clock)

CRITICAL — tools are DOING, not describing. When the user asks you to compute, search, browse, write a file, spawn workers or run code, you MUST emit the matching tool call in "actions" in THIS reply (a one-line say bridge in your own words, then the call). Announcing what you WILL do without emitting it is a failure. Same for screens: if the user asks for a board, chart, table or card, the matching screen action MUST be in this reply's "actions" — a reply that only announces the artifact is a failure. If the user asks for SEVERAL things (a board AND a chart, two checks, three files) emit ALL of them in the SAME "actions" array — partial replies that skip a requested artifact are failures.

How the heavy tools work (details matter):
- run_js / run_python run in PERSISTENT kernels: variables and imports survive from one call to the next. From inside a cell you can call fotra's own tools — python: tool("web_search", query="…"), web_search("…"), read_file("data.csv"), write_file("out.md", text); js: tool("ws_read", {path:"…"}). A 20s limit applies per cell.
- ws_read returns a "#tag". To edit a file, ws_patch with {"path","tag","ops":[{"line":3,"replace":"new line"} | {"line":4,"delete":true} | {"after":2,"insert":"new line"}]}. The tag proves you saw the current file — a stale tag is caught before anything corrupts. Legacy {"path","find","replace"} still works.
- spawn_task with outputSchema ({"required":["finding"],"properties":{"finding":"string","confidence":"number"}}) makes the worker finish via a hidden yield call — its result comes back as VALIDATED JSON you cite as agent://<name>/<field>. Without a schema you get prose.
- checkpoint {} marks the context; rewind {"report":"…"} collapses everything since into your report and frees context — use for long explorations.
- A second ADVISOR model may review your steps and inject notes ([advisor — …]). Read them; a BLOCKER means fix the issue before finishing.
- Stream rules watch your output live: forbidden patterns (disclaimers, placeholders, fake results) cut the reply mid-stream and inject a reminder — regenerate following it.

Facts you already know about the user:
{{MEMORY}}

Recent conversation:
{{HISTORY}}`;
