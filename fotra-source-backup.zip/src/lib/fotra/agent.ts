"use client";

/* ————————————————————————————————————————————————
   FOTRA — the agent loop, client side
   The client is a REPLAYABLE VIEW of the server run:
   events arrive (live, resumed, or replayed after a
   reload), get ingested once, and the UI follows. Runs
   survive disconnects — we reattach by seq. Queue-and-
   steer goes through the server; a suspended run's
   answer (card click or spoken) resumes it — one path.
   ———————————————————————————————————————————————— */

import { demoRespond } from "./demo-engine";
import { persistThread, useFotra } from "./store";
import { speechOut, ttsSupported, voiceInput } from "./voice";
import { takeSpeakable } from "./speakable";
import type {
  AgentEvent,
  BrowserFrame,
  EngineMode,
  FotraAction,
  RunContext,
  StepPatch,
} from "./types";

/* —— the server's wire events (mirrors engine.ts) —— */
type ServerEvent =
  | { type: "session"; sessionId: string; runId: string; assistantTurnId: string; seq?: number }
  | { type: "say"; text: string; seq?: number }
  | { type: "say_reset"; seq?: number }
  | { type: "status"; line: string; seq?: number }
  | { type: "tool"; name: string; summary: string; ok: boolean; ms?: number; seq?: number }
  | { type: "step"; step: StepPatch; seq?: number }
  | { type: "frame"; stepId: string; frame: Omit<BrowserFrame, "ts">; seq?: number }
  | { type: "action"; action: FotraAction; seq?: number }
  | { type: "latency"; ms: number; seq?: number }
  | { type: "ttsr"; rule: string; matched: string; seq?: number }
  | { type: "advisor"; kind: "aside" | "concern" | "blocker"; note: string; seq?: number }
  | { type: "checkpoint"; label: string; seq?: number }
  | { type: "rewind"; toCheckpoint: string; kept: number; dropped: number; seq?: number }
  | { type: "waiting"; reason: "ask" | "budget"; seq?: number }
  | { type: "unsteered"; texts: string[]; seq?: number }
  | { type: "done"; interrupted?: boolean; usedTools?: string[]; seq?: number }
  | { type: "error"; message: string; hint?: string; seq?: number };

interface RunState {
  active: boolean;
  waiting: boolean; // suspended (ask_user / budget) — the next input resumes
  server: boolean; // runs through /api/run (vs the demo brain)
  controller: AbortController | null;
  assistantTurnId: string | null;
  userTurnId: string | null; // the message this run answers — where a tapback lands
  reacted: string | null; // this run tapped back — if it said nothing else, that IS the reply
  modelDone: boolean;
  speechDone: boolean;
  interrupted: boolean;
  replay: boolean; // reattached/replayed events: never re-spoken
  sayBuffer: string;
  speechStarted: boolean; // the first takeSpeakable fired — later takes need full sentences (omp speakable)
  startedAt: number;
  firstChunkAt: number | null;
  runId: string | null;
  lastSeq: number;
  engine: EngineMode;
  /** steers typed before the session event named the run — flushed the moment runId lands */
  pendingSteers: Array<{ id: string; text: string }>;
}

const run: RunState = {
  active: false,
  waiting: false,
  server: false,
  controller: null,
  assistantTurnId: null,
  userTurnId: null,
  reacted: null,
  modelDone: false,
  speechDone: false,
  interrupted: false,
  replay: false,
  sayBuffer: "",
  speechStarted: false,
  startedAt: 0,
  firstChunkAt: null,
  runId: null,
  lastSeq: 0,
  engine: "fotra",
  pendingSteers: [],
};

const get = useFotra.getState;
const set = useFotra.setState;

let persistTimer: ReturnType<typeof setTimeout> | null = null;

/* ————————————————————————————————————————————————
   PUBLIC — submit, interrupt, stop, resume, reattach
   ———————————————————————————————————————————————— */

export function submitInput(text: string, origin: "voice" | "text" | "action") {
  const clean = text.trim();
  if (!clean) return;
  const s = get();
  if (s.readOnly) return; // another tab owns the conversation

  // a suspended run: the next thing the user says IS the answer
  if (run.active && run.waiting && run.runId) {
    void answerSuspended(clean);
    return;
  }

  if (run.active) {
    // queue-and-steer, through the server: visible locally, injected mid-run.
    // Before the session event names the run, the steer is buffered and flushed
    // the moment runId lands — nothing silently degrades to a dead queue.
    const id = s.enqueue(clean, origin === "action" ? "text" : origin);
    if (run.server) {
      if (run.runId) {
        void steerServer(run.runId, clean).then((ok) => {
          if (ok) get().markSteered(id);
        });
      } else {
        run.pendingSteers.push({ id, text: clean });
      }
    }
    return;
  }

  const userTurnId = s.openTurn("user", origin, clean);
  startRun(clean, { userTurnId });
}

/** POST a steer into a live server run — true when it landed */
async function steerServer(runId: string, text: string): Promise<boolean> {
  try {
    const r = await fetch("/api/run/steer", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ runId, text }),
    });
    const j = (await r.json()) as { steered?: boolean };
    return !!j.steered;
  } catch {
    return false; // stayed queued — it'll run after this one
  }
}

/** resume a suspended run — the ask card, the budget pause, or the spoken answer */
export function answerSuspended(answer: string): void {
  if (!run.runId) return;
  run.waiting = false;
  run.modelDone = false;
  run.replay = false;
  run.sayBuffer = "";
  run.speechStarted = false;
  set({ phase: "thinking", statusLine: "picking up where it left off…" });
  void pumpResume(run.runId, answer);
}

export function interruptAndListen() {
  // barge-in: cut voice + run, open the mic immediately
  interruptRun();
  const s = get();
  if (s.settings.handsFree || s.phase === "speaking") {
    void voiceInput.start();
  }
}

export function stopEverything() {
  interruptRun();
  voiceInput.cancel();
  if (run.server && run.runId && run.active) {
    // explicit stop reaches the server — the run dies there too, partials kept
    void fetch("/api/run/abort", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ runId: run.runId }),
      keepalive: true,
    }).catch(() => undefined);
  }
  set({ phase: "idle", statusLine: "" });
}

function interruptRun() {
  if (!run.active) return;
  run.interrupted = true;
  run.controller?.abort();
  speechOut.cancel(); // fires onDone(interrupted) → finalizeRun
  finalizeRun(true);
}

/** after a reload / network cut: reattach to the last run if it's still alive;
    if it already finished, replay its log anyway — the assistant turn may have
    said more after our last persist (the log is the truth, localStorage isn't). */
export async function reattachIfNeeded(): Promise<void> {
  const s = get();
  const rid = s.settings.lastRunId?.trim();
  if (!rid || run.active) return;
  try {
    const res = await fetch(`/api/runs/${rid}/status`);
    if (!res.ok) throw new Error("gone");
    const st = (await res.json()) as { status: string };
    if (st.status !== "running" && st.status !== "waiting" && st.status !== "done" && st.status !== "interrupted") {
      get().updateSettings({ lastRunId: "" });
      return;
    }
    const live = st.status === "running" || st.status === "waiting";
    // bring the run back as a replay — never re-spoken, exactly reconstructed
    run.active = true;
    run.server = true;
    run.waiting = st.status === "waiting";
    run.replay = true;
    run.interrupted = false;
    run.modelDone = false;
    run.speechDone = true;
    run.sayBuffer = "";
    run.speechStarted = false;
    run.startedAt = performance.now();
    run.firstChunkAt = null;
    run.runId = rid;
    run.lastSeq = 0;
    run.pendingSteers = [];
    run.controller = new AbortController();
    run.engine = s.settings.engine === "demo" ? "demo" : s.settings.engine;
    set({
      phase: live ? "working" : "idle",
      statusLine: st.status === "waiting" ? "reattached — waiting on your answer" : live ? "reattached to the live run" : "catching up on the last run",
    });
    await pumpEvents(rid, 0, run.controller.signal);
  } catch {
    get().updateSettings({ lastRunId: "" });
  }
}

/* ————————————————————————————————————————————————
   THE LOOP
   ———————————————————————————————————————————————— */

function startRun(text: string, opts?: { queued?: boolean; userTurnId?: string }) {
  const s = get();
  run.active = true;
  run.waiting = false;
  run.server = s.settings.engine !== "demo";
  run.replay = false;
  run.interrupted = false;
  run.modelDone = false;
  run.speechDone = !s.settings.voiceOutput || !ttsSupported();
  run.sayBuffer = "";
  run.speechStarted = false;
  run.pendingSteers = [];
  run.startedAt = performance.now();
  run.firstChunkAt = null;
  run.runId = null;
  useFotra.setState({ runStartedAt: Date.now() }); // the working row's clock
  run.lastSeq = 0;
  run.engine = s.settings.engine;
  run.controller = new AbortController();

  const assistantTurnId = s.openTurn("assistant");
  run.assistantTurnId = assistantTurnId;
  run.userTurnId = opts?.userTurnId ?? null;
  run.reacted = null;
  set({ phase: "thinking", statusLine: opts?.queued ? "picking up your queued message…" : "" });

  if (run.server) {
    void driveServer(text, assistantTurnId, opts?.userTurnId);
  } else {
    void driveDemo(text, assistantTurnId, opts?.userTurnId);
  }
}

/* —— the demo brain (offline, zero keys) —— */

async function driveDemo(text: string, assistantTurnId: string, userTurnId?: string) {
  const s = get();
  const ctx: RunContext = {
    text,
    userTurnId,
    history: s.turns.filter((t) => !t.streaming && t.text).slice(-18),
    persona: s.persona,
    memory: s.memory,
    settings: s.settings,
    interruptedAt: null,
    activeScreens: Object.values(s.screens).filter((sc) => !sc.building),
    signal: run.controller!.signal,
  };
  const lastAssistant = [...s.turns].reverse().find((t) => t.role === "assistant" && t.interrupted && t.text);
  if (lastAssistant) ctx.interruptedAt = lastAssistant.text.slice(-140);

  try {
    for await (const ev of demoRespond(ctx)) {
      if (run.interrupted) break;
      handleEvent(ev, assistantTurnId);
    }
  } catch {
    if (!run.interrupted) {
      set({ phase: "error", statusLine: "Something broke mid-run.", errorHint: "" });
      useFotra.getState().finishTurn(assistantTurnId, { interrupted: true });
      persistThread(useFotra.getState().turns);
      run.active = false;
      run.modelDone = true;
      return;
    }
  }
  run.modelDone = true;
  flushSpeech(true);
  maybeFinishRun();
}

function handleEvent(ev: AgentEvent, assistantTurnId: string) {
  const s = get();
  switch (ev.type) {
    case "say": {
      if (run.firstChunkAt === null) {
        run.firstChunkAt = performance.now();
        s.setLatency(Math.round(run.firstChunkAt - run.startedAt));
      }
      s.appendToTurn(assistantTurnId, ev.text);
      run.sayBuffer += ev.text;
      if (get().phase !== "speaking") set({ phase: "speaking", statusLine: "" });
      flushSpeech(false);
      break;
    }
    case "status":
      set({ phase: "working", statusLine: ev.line });
      break;
    case "action":
      applyAction(ev.action, assistantTurnId);
      break;
    case "step":
      applyStep(ev.step, assistantTurnId);
      break;
    case "frame":
      s.pushFrame(assistantTurnId, ev.stepId, ev.frame, ev.demo ?? true);
      break;
    case "tool":
      s.logTool(ev.name, ev.summary, ev.ok, ev.ms);
      break;
    case "latency":
      s.setLatency(ev.ms);
      break;
    case "done":
      run.modelDone = true;
      break;
    case "error":
      s.setError(ev.message, ev.hint);
      s.finishTurn(assistantTurnId, { interrupted: true });
      persistThread(s.turns);
      run.active = false;
      run.modelDone = true;
      break;
  }
}

/* —— the server harness (fotra brain / your model / providers.json) —— */

async function driveServer(text: string, assistantTurnId: string, userTurnId?: string) {
  const s = get();
  const engine = s.settings.engine;
  const brain = engine === "custom" ? "custom" : engine === "provider" ? "provider" : "fotra";
  const cfg = s.settings.custom;

  if (brain === "custom" && (!cfg.baseUrl.trim() || !cfg.model.trim())) {
    set({
      phase: "error",
      statusLine: "No brain wired in.",
      errorHint: "Settings → BRAIN: set the endpoint and model — or switch to the fotra brain.",
    });
    get().finishTurn(assistantTurnId, { interrupted: true });
    run.active = false;
    run.modelDone = true;
    return;
  }
  if (brain === "provider") {
    const r = await fetch("/api/providers").then((x) => x.json()).catch(() => null);
    if (!r?.roles?.chat) {
      set({
        phase: "error",
        statusLine: "providers.json has no chat role.",
        errorHint: "Set roles.chat in providers.json + its key in .env.local — or pick another brain.",
      });
      get().finishTurn(assistantTurnId, { interrupted: true });
      run.active = false;
      run.modelDone = true;
      return;
    }
  }

  const history = get()
    .turns.filter((t) => !t.streaming && t.text && t.id !== userTurnId && t.origin !== "system" && t.origin !== "voice-call")
    .slice(-16);

  let res: Response;
  try {
    res = await fetch("/api/run", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        sessionId: s.settings.sessionId || undefined,
        text,
        userTurnId: userTurnId ?? "",
        assistantTurnId,
        history,
        persona: s.persona,
        brain,
        custom: cfg,
        ui: s.settings.ui,
        mode: s.settings.mode,
        feedback: s.takeFeedback(),
      }),
      signal: run.controller!.signal,
    });
  } catch (err) {
    failRun("Couldn't reach the harness.", err instanceof Error ? err.message : "Network error.");
    return;
  }
  if (!res.ok || !res.body) {
    let detail = `${res.status} ${res.statusText}`;
    try {
      const j = (await res.json()) as { error?: string };
      if (j.error) detail = j.error;
    } catch {
      /* not json */
    }
    failRun("The run was refused.", detail);
    return;
  }
  await pumpStream(res.body, run.controller!.signal);
}

function failRun(message: string, hint: string | undefined) {
  set({ phase: "error", statusLine: message, errorHint: hint });
  if (run.assistantTurnId) {
    get().finishTurn(run.assistantTurnId, { interrupted: true });
    persistThread(get().turns);
  }
  run.active = false;
  run.modelDone = true;
}

/** shared SSE reader → ingestServerEvent. Handles waiting/finish/reconnect. */
async function pumpStream(body: ReadableStream<Uint8Array>, signal: AbortSignal) {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let broke = false;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        const payload = line.slice(6).trim();
        if (!payload || payload === "[DONE]") continue;
        let ev: ServerEvent;
        try {
          ev = JSON.parse(payload) as ServerEvent;
        } catch {
          continue;
        }
        ingestServerEvent(ev);
      }
    }
  } catch (err) {
    if (!signal.aborted) broke = true;
    void err;
  }

  if (run.interrupted) return; // finalizeRun already ran

  if (broke && run.active && run.runId && !run.waiting) {
    // the stream cut mid-run — the run is alive server-side; reattach by seq
    set({ phase: "working", statusLine: "connection wobbled — reattaching…" });
    const reattached = await tryReconnect(3);
    if (reattached) return;
    failRun("Stream cut out.", "The run continued on the server — reload to reattach.");
    return;
  }

  run.modelDone = true;
  flushSpeech(true);
  if (run.waiting) {
    // suspended: the run lives on; the next input (card or voice) resumes it
    set({ phase: "idle", statusLine: run.engine === "demo" ? "" : "waiting on your answer" });
    persistRunMeta();
    return;
  }
  maybeFinishRun();
}

async function tryReconnect(attempts: number): Promise<boolean> {
  for (let i = 0; i < attempts; i++) {
    await new Promise((r) => setTimeout(r, 900));
    if (run.interrupted || !run.active) return false;
    try {
      const res = await fetch(`/api/runs/${run.runId}/status`);
      if (!res.ok) continue;
      const st = (await res.json()) as { status: string };
      if (st.status === "waiting") {
        run.waiting = true;
        set({ phase: "idle", statusLine: "waiting on your answer" });
        return true;
      }
      if (st.status !== "running") continue; // finished while we were cut off
      const tail = await fetch(`/api/runs/${run.runId}/events?after=${run.lastSeq}`);
      if (tail.ok && tail.body) {
        run.replay = false;
        await pumpStream(tail.body, run.controller!.signal);
        return true;
      }
    } catch {
      /* retry */
    }
  }
  return false;
}

/** one event, one ingestion — live, resumed, or replayed all land here */
function ingestServerEvent(ev: ServerEvent) {
  if (typeof ev.seq === "number" && ev.seq > run.lastSeq) {
    run.lastSeq = ev.seq;
    if (ev.seq % 12 === 0) persistRunMeta();
  }
  switch (ev.type) {
    case "session": {
      const s = get();
      if (s.settings.sessionId !== ev.sessionId || s.settings.lastRunId !== ev.runId) {
        s.updateSettings({ sessionId: ev.sessionId, lastRunId: ev.runId, lastSeq: ev.seq ?? 0 });
      }
      run.runId = ev.runId;
      // steers typed before the run was named — flush them now
      if (run.pendingSteers.length > 0 && !run.replay) {
        const held = run.pendingSteers.splice(0);
        for (const p of held) {
          void steerServer(ev.runId, p.text).then((ok) => {
            if (ok) get().markSteered(p.id);
          });
        }
      }
      // reattach/replay: the server names the assistant turn — restore it empty
      if (run.replay && ev.assistantTurnId) {
        run.assistantTurnId = ev.assistantTurnId;
        s.restoreAssistantTurn(ev.assistantTurnId);
      }
      break;
    }
    case "say": {
      if (run.firstChunkAt === null && !run.replay) {
        run.firstChunkAt = performance.now();
        get().setLatency(Math.round(run.firstChunkAt - run.startedAt));
      }
      if (run.assistantTurnId) get().appendToTurn(run.assistantTurnId, ev.text);
      if (!run.replay) {
        run.sayBuffer += ev.text;
        if (get().phase !== "speaking") set({ phase: "speaking", statusLine: "" });
        flushSpeech(false);
      }
      throttledPersist();
      break;
    }
    case "say_reset": {
      // a corrective retry re-speaks — clear the partial text so the transcript doesn't double
      if (run.assistantTurnId) get().resetTurnText(run.assistantTurnId);
      if (!run.replay) run.sayBuffer = "";
      run.speechStarted = false; // the retry re-speaks from the top — first-take rules apply again
      break;
    }
    case "status":
      set({ phase: "working", statusLine: ev.line });
      break;
    case "step":
      if (run.assistantTurnId) applyStep(ev.step, run.assistantTurnId);
      break;
    case "frame":
      // replayed frames rebuild the reel but never pop the window back open
      if (run.assistantTurnId) {
        get().pushFrame(run.assistantTurnId, ev.stepId, ev.frame, false);
        if (run.replay) get().setStage({ open: false, live: false });
      }
      break;
    case "tool":
      set({ phase: "working", statusLine: ev.summary });
      get().logTool(ev.name, ev.summary, ev.ok, ev.ms);
      // workspace-touching tools refresh the files rail
      if (/^ws_|^(run_js|run_python)$/.test(ev.name) || ev.name.startsWith("mcp_")) void refreshWsFiles();
      break;
    case "ttsr":
      // a stream rule cut the model mid-token — the retry is already scheduled
      set({ phase: "working", statusLine: `rule "${ev.rule}" cut the reply — regenerating` });
      get().logTool(`rule:${ev.rule}`, `cut mid-stream on "${ev.matched}"`, true);
      break;
    case "advisor": {
      // the second model's inline note
      const glyph = ev.kind === "blocker" ? "✖" : ev.kind === "concern" ? "▲" : "·";
      if (ev.kind !== "aside") set({ phase: "working", statusLine: `advisor: ${ev.note}` });
      get().logTool(`advisor ${glyph}`, ev.note, ev.kind !== "blocker");
      break;
    }
    case "checkpoint":
      get().logTool("checkpoint", `context checkpoint — ${ev.label}`, true);
      break;
    case "rewind":
      set({ phase: "working", statusLine: `context rewound — ${ev.dropped} messages collapsed into a report` });
      get().logTool("rewind", `→ "${ev.toCheckpoint}" · kept ${ev.kept}, collapsed ${ev.dropped}`, true);
      break;
    case "action":
      if (run.assistantTurnId) applyAction(ev.action, run.assistantTurnId);
      break;
    case "latency":
      get().setLatency(ev.ms);
      break;
    case "waiting":
      run.waiting = true;
      run.modelDone = true;
      set({ phase: "working", statusLine: ev.reason === "budget" ? "paused at the budget — your call" : "waiting on you" });
      break;
    case "unsteered": {
      // the run ended before these landed — restore them to the visible queue
      const s2 = get();
      for (const t of ev.texts) s2.enqueue(t, "text");
      set({ statusLine: "one message didn't fit the run — it's back in the queue" });
      break;
    }
    case "done":
      run.modelDone = true;
      break;
    case "error":
      failRun(ev.message, ev.hint);
      break;
  }
}

/** resume a suspended run and pump its stream */
async function pumpResume(runId: string, answer: string) {
  let res: Response;
  try {
    res = await fetch(`/api/runs/${runId}/resume`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ answer }),
      signal: run.controller?.signal,
    });
  } catch {
    failRun("Couldn't reach the harness.", "Network error — the run is still waiting server-side.");
    return;
  }
  if (res.status === 409) {
    // the run moved on without us — say it as a fresh turn
    const s = get();
    const userTurnId = s.openTurn("user", "text", answer);
    startRun(answer, { userTurnId });
    return;
  }
  if (!res.ok || !res.body) {
    let detail = `${res.status}`;
    try {
      const j = (await res.json()) as { error?: string };
      if (j.error) detail = j.error;
    } catch {
      /* not json */
    }
    failRun("The resume was refused.", detail);
    return;
  }
  await pumpStream(res.body, run.controller?.signal ?? AbortSignal.timeout(180_000));
}

/** replay + live tail of a run's event log (reattach path) — retries once:
    a dev-server cold compile can eat the first fetch right after a deploy. */
async function pumpEvents(runId: string, after: number, signal: AbortSignal, attempt = 0): Promise<void> {
  try {
    const res = await fetch(`/api/runs/${runId}/events?after=${after}`, { signal });
    if (!res.ok || !res.body) throw new Error("no tail");
    await pumpStream(res.body, signal);
  } catch {
    if (run.interrupted || !run.active) return;
    if (attempt < 2) {
      await new Promise((r) => setTimeout(r, 1200));
      if (run.interrupted || !run.active) return;
      return pumpEvents(runId, run.lastSeq, signal, attempt + 1);
    }
    set({ phase: "idle", statusLine: "" });
    persistRunMeta();
  }
}

function persistRunMeta() {
  const s = get();
  if (run.runId) s.updateSettings({ lastRunId: run.runId, lastSeq: run.lastSeq });
}

function throttledPersist() {
  if (persistTimer) return;
  persistTimer = setTimeout(() => {
    persistTimer = null;
    persistThread(get().turns);
  }, 1200);
}

/** omp speakable flush — streaming segmentation of the say buffer into the voice.
 *  The FIRST take needs only 12 chars at a boundary, so speech starts while the
 *  model is still generating; later takes use full sentences / clause cuts; the
 *  final take drains whatever remains. Sanitization (fences, URLs, paths) inside. */
function flushSpeech(final: boolean) {
  const s = get();
  if (!s.settings.voiceOutput || run.replay || !ttsSupported()) {
    run.speechDone = true;
    run.sayBuffer = "";
    return;
  }
  let spoke = false;
  while (true) {
    const [take, rest] = takeSpeakable(run.sayBuffer, final && run.sayBuffer.trim().length > 0, !run.speechStarted);
    if (take.trim().length === 0) break;
    run.sayBuffer = rest;
    run.speechStarted = true;
    run.speechDone = false;
    // the first take owns the speech queue; later takes append to what's playing
    speechOut.speak(take, s.persona, spoke);
    spoke = true;
    if (!final) break; // one take per flush — non-final flushes leave room for the queue
  }
  if (final && run.sayBuffer.trim()) {
    // nothing more will arrive — the tail ships at any length
    const tail = run.sayBuffer;
    run.sayBuffer = "";
    run.speechStarted = true;
    run.speechDone = false;
    speechOut.speak(tail, s.persona, spoke);
    spoke = true;
  }
  // nothing left to say and nothing playing — the run can settle
  if (final && !spoke && !speechOut.isSpeaking) run.speechDone = true;
}

function maybeFinishRun() {
  if (!run.active) return;
  if (run.modelDone && run.speechDone) finalizeRun(false);
}

function finalizeRun(interrupted: boolean) {
  if (!run.active) return;
  run.active = false;
  const s = get();
  if (run.assistantTurnId) {
    s.finishTurn(run.assistantTurnId, { interrupted });
    // a reply that was only a tapback: no bubble — the heart on your message is the answer.
    // The turn keeps a note of it so the model remembers it reacted.
    const id = run.assistantTurnId;
    const t = get().turns.find((x) => x.id === id);
    if (t && run.reacted && !t.text.trim() && !(t.blocks ?? []).some((b) => b.kind !== "text")) {
      const emoji = run.reacted;
      set({ turns: get().turns.map((x) => (x.id === id ? { ...x, tapOnly: true, text: `(reacted ${emoji} — no words needed)`, blocks: [] } : x)) });
    }
    persistThread(get().turns);
  }
  if (interrupted) s.markScreensInterrupted();
  if (run.assistantTurnId) s.settleSteps(run.assistantTurnId);
  set({ phase: "idle", statusLine: "", runStartedAt: null });
  if (run.runId) s.updateSettings({ lastRunId: "" }); // the run is over

  // drain the queue — steered items already landed mid-run, the rest get their own run
  const queued = s.drainQueue().filter((q) => !q.steered);
  if (queued.length > 0) {
    const next = queued[0];
    for (const q of queued.slice(1)) s.enqueue(q.text, q.origin);
    if (next.text.trim()) {
      const userTurnId = s.openTurn("user", next.origin, next.text);
      startRun(next.text, { queued: true, userTurnId });
    }
    return;
  }

  if (s.settings.handsFree && s.phase === "idle" && s.settings.voiceMode === "browser") {
    void voiceInput.start();
  }
}

/* ————————————————————————————————————————————————
   ACTIONS — what the brain can do to the world
   ———————————————————————————————————————————————— */

/** apply the client half of a self-edit (or its undo): the look, the layout, the canvas */
export function applySelfActions(actions: FotraAction[]) {
  const s = get();
  for (const a of actions) {
    if (a.type === "persona") s.patchPersona(a.patch);
    else if (a.type === "ui") s.patchUi(a.patch);
    else if (a.type === "mode") s.setMode(a.value === "light" ? "light" : "dark");
  }
}

/** a step opens, updates, settles — the status line follows the live one */
function applyStep(patch: StepPatch, turnId: string) {
  get().upsertStep(turnId, patch);
  if (patch.status === "running" && patch.title) {
    set({ phase: "working", statusLine: patch.subject ? `${patch.title} · ${patch.subject}` : patch.title });
  }
  if (patch.status && patch.status !== "running") {
    const st = get().stage;
    if (st.stepId === patch.id) get().setStage({ live: false });
  }
}

function applyAction(action: FotraAction, turnId: string) {
  const s = get();
  switch (action.type) {
    case "react": {
      // a tapback on the message this run is answering
      if (run.userTurnId) s.react(run.userTurnId, action.emoji, "agent");
      run.reacted = action.emoji;
      break;
    }
    case "ui": {
      s.patchUi(action.patch);
      break;
    }
    case "mode": {
      s.setMode(action.value === "light" ? "light" : "dark");
      break;
    }
    case "screen": {
      s.dockScreen(action.id, action.component, action.props, {
        building: action.building ?? false,
        turnId,
        demoData: action.demoData,
      });
      s.attachScreenToTurn(turnId, action.id);
      break;
    }
    case "screen-delta": {
      s.patchScreen(action.id, action.props);
      break;
    }
    case "persona": {
      s.patchPersona(action.patch);
      break;
    }
    case "theme": {
      // the old two-world action ("go red") — now re-skins the coat, one system
      s.patchPersona({ coat: action.value === "ember" ? "ember" : "verdant" });
      break;
    }
    case "remember": {
      s.remember(action.fact, action.topic ?? "facts", "user-told");
      break;
    }
    case "forget": {
      s.forgetMatching(action.match);
      break;
    }
    case "widget": {
      s.spawnWidget(action.id, action.kind, action.props);
      break;
    }
    case "unwidget": {
      for (const w of s.widgets) {
        if (w.id === action.id || w.id.startsWith(action.id) || w.kind === action.id.replace(/-$/, "")) {
          s.removeWidget(w.id);
        }
      }
      break;
    }
    case "open_link": {
      // the hand-off at the payment boundary — the user's browser, not ours
      try {
        window.open(action.url, "_blank", "noopener,noreferrer");
        set({ statusLine: `opened ${new URL(action.url).host} in a tab` });
      } catch {
        set({ statusLine: `couldn't open ${action.url}` });
      }
      break;
    }
    case "pin": {
      const order = [...s.screenOrder];
      const live = action.id && s.screens[action.id]
        ? action.id
        : order.reverse().find((id) => s.screens[id]?.status === "live" && !s.screens[id].pinned);
      const fallback = action.id && s.screens[action.id]
        ? action.id
        : [...s.screenOrder]
            .filter((id) => s.screens[id]?.status === "retired" && !s.screens[id].building && !s.screens[id].pinned)
            .sort((a, b) => (s.screens[b]?.ts ?? 0) - (s.screens[a]?.ts ?? 0))[0];
      const target = live ?? fallback;
      if (target && !s.screens[target].pinned) s.pinScreen(target);
      break;
    }
    case "ask": {
      // resume metadata rides the props — the card's answer resumes the run
      s.dockScreen(
        action.id,
        "ask",
        {
          question: action.question,
          detail: action.detail,
          options: action.options,
          tone: action.tone,
          resume: action.resume ?? null,
        },
        { turnId }
      );
      s.attachScreenToTurn(turnId, action.id);
      break;
    }
  }
}

/* ————————————————————————————————————————————————
   the ambient layer — workspace files + routine results.
   Routines fire in the background; when they land, the
   thread grows a quiet system line + the assistant turn,
   discovered by polling while the tab idles.
   ———————————————————————————————————————————————— */

export async function refreshWsFiles() {
  const s = get();
  const sessionId = s.settings.sessionId;
  if (!sessionId) return;
  try {
    const res = await fetch(`/api/workspace?sessionId=${encodeURIComponent(sessionId)}`);
    if (!res.ok) return;
    const j = (await res.json()) as { files?: string[] };
    if (Array.isArray(j.files)) get().setWsFiles(j.files);
  } catch {
    /* offline — the rail just stays stale */
  }
}

let ambientTimer: ReturnType<typeof setInterval> | null = null;
let ambientSince: string = new Date().toISOString();

export function wireAmbient() {
  if (ambientTimer) return;
  ambientTimer = setInterval(async () => {
    const s = get();
    const sessionId = s.settings.sessionId;
    if (!sessionId) return;
    if (s.phase === "thinking" || s.phase === "working" || s.phase === "speaking") return; // live run owns the thread
    try {
      const res = await fetch(`/api/session/poll?sessionId=${encodeURIComponent(sessionId)}&since=${encodeURIComponent(ambientSince)}`);
      if (!res.ok) return;
      const j = (await res.json()) as { now: string; newTurns: { id: string; role: "user" | "assistant"; text: string; origin?: string; ts: string; interrupted?: boolean }[] };
      ambientSince = j.now;
      for (const t of j.newTurns) {
        if (t.id.startsWith("t-routine-")) continue; // the routine's own prompt — noise
        if (t.origin === "system") {
          // the marker line ("routine · morning brief")
          get().pushSystemTurn(t.id, t.text.replace(/^routine · /, "· "), "system");
        } else if (t.id.startsWith("t-a-") && t.text) {
          // the routine's answer, landed while we idled
          get().restoreAssistantTurn(t.id);
          get().appendToTurn(t.id, t.text);
          get().finishTurn(t.id);
        }
      }
      // routine output implies fresh workspace state too
      if (j.newTurns.some((t) => t.id.includes("routine"))) void refreshWsFiles();
    } catch {
      /* offline — retry next tick */
    }
  }, 25_000);
  refreshWsFiles();
}

/* ————————————————————————————————————————————————
   wiring — called once by the app shell
   ———————————————————————————————————————————————— */

export function wireVoice() {
  voiceInput.setCallbacks({
    onInterim: (t) => useFotra.getState().setLiveCaption(t),
    onFinal: (t) => submitInput(t, "voice"),
    onListeningChange: (listening) => {
      const s = get();
      if (listening) {
        set({ phase: "listening", statusLine: "" });
      } else if (s.phase === "listening") {
        set({ phase: "idle" });
      }
    },
    onError: (kind, hint) => {
      if (kind === "denied") get().setError("Mic's blocked.", hint);
      else if (kind === "unsupported") get().setError("No speech recognition here.", hint);
      else if (kind === "network") get().setError("Speech network hiccup.", hint);
      else get().setError("Mic trouble.", hint);
    },
  });

  speechOut.setCallbacks({
    onStart: () => {
      set({ phase: "speaking" });
    },
    onDone: (interrupted) => {
      run.speechDone = true;
      if (interrupted) return; // finalizeRun handles it
      maybeFinishRun();
    },
  });
}

export function runState() {
  return { active: run.active, waiting: run.waiting, runId: run.runId };
}
