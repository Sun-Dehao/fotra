"use client";

/* ————————————————————————————————————————————————
   FOTRA — voice layer
   In:  Web Speech recognition. Tap to talk, silence sends.
        Real mic energy drives the orb (AnalyserNode → CSS var).
   Out: speechSynthesis, omp-speakable-chunked, persona-tuned voice.
   Interrupt: cancel TTS mid-word; the orb and captions cut together.
   ———————————————————————————————————————————————— */

import type { Persona } from "./types";
import { segmentSpeech } from "./speakable";

/* —— minimal typings for SpeechRecognition —— */
interface SRAlternative { transcript: string; confidence: number }
interface SRResult { readonly length: number; isFinal: boolean; [index: number]: SRAlternative }
interface SRResultList { readonly length: number; [index: number]: SRResult }
interface SREvent extends Event { resultIndex: number; results: SRResultList }
interface SRErrorEvent extends Event { error: string }
interface SpeechRecognitionLike extends EventTarget {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  start(): void;
  stop(): void;
  abort(): void;
  onresult: ((e: SREvent) => void) | null;
  onerror: ((e: SRErrorEvent) => void) | null;
  onend: (() => void) | null;
  onstart: (() => void) | null;
}
type SRCtor = new () => SpeechRecognitionLike;

function getSRCtor(): SRCtor | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as { SpeechRecognition?: SRCtor; webkitSpeechRecognition?: SRCtor };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export const speechInputSupported = (): boolean => getSRCtor() !== null;
export const ttsSupported = (): boolean =>
  typeof window !== "undefined" && "speechSynthesis" in window;

/* ————————————————————————————————————————————————
   INPUT — a single controller instance
   ———————————————————————————————————————————————— */

interface VoiceInputCallbacks {
  onInterim?: (text: string) => void;
  onFinal?: (text: string) => void;
  onListeningChange?: (listening: boolean) => void;
  onError?: (kind: "denied" | "network" | "unsupported" | "failed", hint?: string) => void;
}

class VoiceInput {
  private rec: SpeechRecognitionLike | null = null;
  private active = false;
  private wantActive = false;
  private energyCtx: AudioContext | null = null;
  private energyStream: MediaStream | null = null;
  private raf = 0;
  private silenceTimer = 0;
  private finals: string[] = [];
  private lastInterimAt = 0;
  private cb: VoiceInputCallbacks = {};
  private levelCb: ((level: number) => void) | null = null;

  setCallbacks(cb: VoiceInputCallbacks) {
    this.cb = { ...this.cb, ...cb };
  }

  /** subscribe to live mic energy (0–1, ~60fps) — the mascot's pulse source */
  onLevel(cb: ((level: number) => void) | null) {
    this.levelCb = cb;
  }

  /** the live mic stream (for waveform viz) — null when not listening */
  get stream(): MediaStream | null {
    return this.energyStream;
  }

  get listening(): boolean {
    return this.active;
  }

  async start(): Promise<void> {
    if (this.wantActive) return;
    const SRC = getSRCtor();
    if (!SRC) {
      this.cb.onError?.("unsupported", "This browser has no speech recognition. Chrome or Edge will. Typing works everywhere.");
      return;
    }
    if (!this.rec) {
      const rec = new SRC();
      rec.lang = "en-US";
      rec.continuous = true;
      rec.interimResults = true;
      rec.maxAlternatives = 1;
      rec.onresult = (e) => this.handleResult(e);
      rec.onerror = (e) => this.handleError(e);
      rec.onend = () => this.handleEnd();
      this.rec = rec;
    }
    this.wantActive = true;
    this.finals = [];
    try {
      this.rec.start();
    } catch {
      /* already started — fine */
    }
    this.setActive(true);
    this.startEnergy();
  }

  /** stop and submit whatever was said */
  stop(send = true) {
    if (!this.wantActive) return;
    this.wantActive = false;
    try {
      this.rec?.stop();
    } catch {
      /* noop */
    }
    this.stopEnergy();
    this.setActive(false);
    window.clearTimeout(this.silenceTimer);
    if (send && this.finals.length > 0) {
      const text = this.finals.join(" ").trim();
      this.finals = [];
      if (text) this.cb.onFinal?.(text);
    } else {
      this.finals = [];
    }
    this.cb.onInterim?.("");
  }

  /** stop without submitting (cancel) */
  cancel() {
    this.stop(false);
  }

  private setActive(v: boolean) {
    if (this.active === v) return;
    this.active = v;
    this.cb.onListeningChange?.(v);
  }

  private handleResult(e: SREvent) {
    let interim = "";
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const r = e.results[i];
      const t = r[0]?.transcript ?? "";
      if (r.isFinal) {
        const clean = t.trim();
        if (clean) this.finals.push(clean);
        this.lastInterimAt = Date.now();
        this.armSilence();
      } else {
        interim += t;
      }
    }
    if (interim) this.lastInterimAt = Date.now();
    this.cb.onInterim?.(interim.trim());
    // user resumed speaking — hold the silence timer
    if (interim) window.clearTimeout(this.silenceTimer);
  }

  /** after a final result, 1.4s of silence sends the turn (hands-free feel) */
  private armSilence() {
    window.clearTimeout(this.silenceTimer);
    this.silenceTimer = window.setTimeout(() => {
      if (this.finals.length > 0) {
        const text = this.finals.join(" ").trim();
        this.finals = [];
        this.wantActive = false;
        try {
          this.rec?.stop();
        } catch {
          /* noop */
        }
        this.stopEnergy();
        this.setActive(false);
        this.cb.onInterim?.("");
        if (text) this.cb.onFinal?.(text);
      }
    }, 1400);
  }

  private handleError(e: SRErrorEvent) {
    if (e.error === "no-speech" || e.error === "aborted") return; // benign
    if (e.error === "not-allowed" || e.error === "service-not-allowed") {
      this.wantActive = false;
      this.setActive(false);
      this.stopEnergy();
      this.cb.onError?.(
        "denied",
        "Chrome needs mic permission. Click the lock/icon left of the address bar → Microphone → Allow, then try again."
      );
      return;
    }
    if (e.error === "network") {
      this.cb.onError?.("network", "Speech recognition needs a connection. Type for now — everything else works.");
      return;
    }
    this.cb.onError?.("failed", `Mic error: ${e.error}`);
  }

  private handleEnd() {
    if (this.wantActive) {
      // Chrome ends the session on silence; restart to stay live
      try {
        this.rec?.start();
      } catch {
        /* restart race — onend will fire again or user retries */
      }
      return;
    }
    // ended for real; if finals never fired the silence timer, flush them
    if (this.finals.length > 0) {
      const text = this.finals.join(" ").trim();
      this.finals = [];
      this.cb.onInterim?.("");
      if (text) this.cb.onFinal?.(text);
    }
    this.stopEnergy();
    this.setActive(false);
  }

  /* —— real mic energy → --mic-level CSS var (no react re-renders) —— */
  private async startEnergy() {
    if (this.energyCtx) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.energyStream = stream;
      const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new Ctx();
      this.energyCtx = ctx;
      const src = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 512;
      src.connect(analyser);
      const buf = new Uint8Array(analyser.frequencyBinCount);
      const loop = () => {
        if (!this.energyCtx) return;
        analyser.getByteTimeDomainData(buf);
        let sum = 0;
        for (let i = 0; i < buf.length; i++) {
          const v = (buf[i] - 128) / 128;
          sum += v * v;
        }
        const rms = Math.sqrt(sum / buf.length);
        const level = Math.min(1, Math.max(0, (rms - 0.02) / 0.22));
        const eased = level * level; // perceptual curve
        document.documentElement.style.setProperty("--mic-level", eased.toFixed(3));
        this.levelCb?.(eased); // the mascot subscribes — no react re-render, it feeds a MotionValue
        this.raf = requestAnimationFrame(loop);
      };
      this.raf = requestAnimationFrame(loop);
    } catch {
      /* energy viz is optional — recognition may still work */
    }
  }

  private stopEnergy() {
    cancelAnimationFrame(this.raf);
    this.raf = 0;
    document.documentElement.style.setProperty("--mic-level", "0");
    this.energyStream?.getTracks().forEach((t) => t.stop());
    this.energyStream = null;
    if (this.energyCtx) {
      this.energyCtx.close().catch(() => undefined);
      this.energyCtx = null;
    }
  }
}

export const voiceInput = new VoiceInput();

/* ————————————————————————————————————————————————
   OUTPUT — persona-tuned TTS with a speak queue
   ———————————————————————————————————————————————— */

interface SpeechOutCallbacks {
  onDone?: (interrupted: boolean) => void;
  onStart?: () => void;
}

class SpeechOut {
  private queue: string[] = [];
  private speaking = false;
  private interrupted = false;
  private spkRaf = 0;
  private spkStart = 0;
  private cb: SpeechOutCallbacks = {};
  private voices: SpeechSynthesisVoice[] = [];

  constructor() {
    if (ttsSupported()) {
      const load = () => {
        this.voices = window.speechSynthesis.getVoices();
      };
      load();
      window.speechSynthesis.onvoiceschanged = load;
    }
  }

  setCallbacks(cb: SpeechOutCallbacks) {
    this.cb = { ...this.cb, ...cb };
  }

  get isSpeaking(): boolean {
    return this.speaking;
  }

  /** split text into speakable chunks — the omp speakable segmenter: sanitizes
   *  markdown (fences swallowed, URLs→hosts, paths→basenames), then segments
   *  with the tuned constants (soft clause 160 / hard max 280) */
  private chunk(text: string): string[] {
    const segs = segmentSpeech(text);
    if (segs.length > 0) return segs;
    return [text];
  }

  private pickVoice(persona: Persona): SpeechSynthesisVoice | null {
    if (!ttsSupported()) return null;
    if (persona.voiceURI) {
      const match = this.voices.find((v) => v.voiceURI === persona.voiceURI);
      if (match) return match;
    }
    const prefs = [
      (v: SpeechSynthesisVoice) => v.name.includes("Google US English"),
      (v: SpeechSynthesisVoice) => /Microsoft.*(Aria|Jenny|Ana|Guy).*Natural/i.test(v.name),
      (v: SpeechSynthesisVoice) => v.name.includes("Google UK English Female"),
      (v: SpeechSynthesisVoice) => /en[-_]US/i.test(v.lang),
      (v: SpeechSynthesisVoice) => /^en/i.test(v.lang),
    ];
    for (const pref of prefs) {
      const found = this.voices.find(pref);
      if (found) return found;
    }
    return null;
  }

  speak(text: string, persona: Persona, append = false) {
    if (!ttsSupported() || !text.trim()) {
      if (!append) this.cb.onDone?.(false);
      return;
    }
    const chunks = this.chunk(text);
    if (append && this.speaking) {
      this.queue.push(...chunks);
      return;
    }
    this.queue = chunks;
    this.interrupted = false;
    this.speaking = true;
    this.cb.onStart?.();
    this.speakNext(persona);
  }

  private speakNext(persona: Persona) {
    if (this.interrupted) return;
    const next = this.queue.shift();
    if (!next) {
      this.finish(false);
      return;
    }
    const u = new SpeechSynthesisUtterance(next);
    const voice = this.pickVoice(persona);
    if (voice) u.voice = voice;
    u.rate = persona.voiceRate;
    u.pitch = persona.voicePitch;
    u.volume = 1;
    // Browsers sometimes never fire onend (no audio device, a background tab, an engine that
    // stalls). A run must not hang on that: each chunk advances exactly once — on end, on error,
    // or when the watchdog decides the voice isn't coming (never started) or should be done by now.
    let settled = false;
    let watchdog = 0;
    const advance = () => {
      if (settled) return;
      settled = true;
      window.clearTimeout(watchdog);
      cancelAnimationFrame(this.spkRaf);
      document.documentElement.style.setProperty("--spk-level", "0");
      // small gap between sentences for natural cadence
      window.setTimeout(() => this.speakNext(persona), 60);
    };
    const giveUp = () => {
      if (settled) return;
      try {
        window.speechSynthesis.cancel(); // may fire onerror/onend synchronously — advance() is idempotent
      } catch {
        /* noop */
      }
      advance();
    };
    u.onstart = () => {
      this.spkStart = performance.now();
      this.pulseSpeaker();
      window.clearTimeout(watchdog);
      watchdog = window.setTimeout(giveUp, 4000 + (next.length * 95) / Math.max(0.6, persona.voiceRate));
    };
    u.onend = advance;
    u.onerror = advance;
    try {
      window.speechSynthesis.speak(u);
      watchdog = window.setTimeout(giveUp, 2500); // it never even started
    } catch {
      this.finish(false);
    }
  }

  /** gentle output-level animation while a chunk plays */
  private pulseSpeaker() {
    const loop = () => {
      if (!this.speaking) return;
      const t = (performance.now() - this.spkStart) / 1000;
      const level = 0.35 + 0.3 * Math.abs(Math.sin(t * 5.2)) + 0.15 * Math.abs(Math.sin(t * 11.7));
      document.documentElement.style.setProperty("--spk-level", Math.min(1, level).toFixed(3));
      this.spkRaf = requestAnimationFrame(loop);
    };
    this.spkRaf = requestAnimationFrame(loop);
  }

  /** barge-in: cut the voice mid-word */
  cancel() {
    if (!this.speaking) return;
    this.interrupted = true;
    this.queue = [];
    this.speaking = false;
    if (ttsSupported()) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        /* noop */
      }
    }
    cancelAnimationFrame(this.spkRaf);
    document.documentElement.style.setProperty("--spk-level", "0");
    this.cb.onDone?.(true);
  }

  private finish(interrupted: boolean) {
    this.speaking = false;
    this.queue = [];
    cancelAnimationFrame(this.spkRaf);
    document.documentElement.style.setProperty("--spk-level", "0");
    this.cb.onDone?.(interrupted);
  }
}

export const speechOut = new SpeechOut();
