"use client";

/* ————————————————————————————————————————————————
   FOTRA — client state (zustand)
   One store: the conversation, the screens, the persona,
   the memory, the widgets, the queue. Persisted by hand
   (localStorage) with secret-scrubbing at write time.
   ———————————————————————————————————————————————— */

import { create } from "zustand";
import { toast } from "sonner";
import {
  DEFAULT_PERSONA,
  DEFAULT_SETTINGS,
  DEFAULT_UI,
  uid,
  type BrowserFrame,
  type BrowserStage,
  type Reaction,
  type Step,
  type StepPatch,
  type TurnBlock,
  type UiPrefs,
  type MemoryFact,
  type MascotCoat,
  type Persona,
  type Phase,
  type ThemeMode,
  type ToolActivity,
  type QueuedMessage,
  type ScreenInstance,
  type ScreenKind,
  type Settings,
  type Turn,
  type WidgetInstance,
  type WidgetKind,
} from "./types";

const LS = {
  settings: "fotra.settings.v1",
  persona: "fotra.persona.v1",
  memory: "fotra.memory.v1",
  thread: "fotra.thread.v1",
  screens: "fotra.screens.v1",
  widgets: "fotra.widgets.v1",
  pinned: "fotra.pinned.v1",
  onboarded: "fotra.onboarded.v1",
  threads: "fotra.threads.v1",
  threadId: "fotra.thread.id",
} as const;

/* —— the thread archive ————————————————————————————————
   Every conversation is kept in this browser, whatever brain
   answered it — with its steps and screens, which the server log
   does not replay. The server session id rides along so a thread
   you come back to keeps its server-side context. */
export interface SavedThread {
  id: string;
  sessionId: string;
  title: string;
  updatedAt: number;
  turns: Turn[];
  screens: { order: string[]; screens: Record<string, ScreenInstance> };
}
const MAX_THREADS = 40;

export function loadThreads(): SavedThread[] {
  try {
    const raw = localStorage.getItem(LS.threads);
    const list = raw ? (JSON.parse(raw) as SavedThread[]) : [];
    return Array.isArray(list) ? list.filter((t) => t && t.id && Array.isArray(t.turns)) : [];
  } catch {
    return [];
  }
}

function saveThreads(list: SavedThread[]) {
  let keep = list.slice().sort((a, b) => b.updatedAt - a.updatedAt).slice(0, MAX_THREADS);
  // storage is finite: when it fills, the oldest threads go first, never the write
  while (keep.length > 0) {
    try {
      localStorage.setItem(LS.threads, JSON.stringify(keep));
      break;
    } catch {
      keep = keep.slice(0, Math.max(0, keep.length - 3));
    }
  }
  if (typeof window !== "undefined") window.dispatchEvent(new Event("fotra:threads"));
}

function threadTitle(turns: Turn[]): string {
  const first = turns.find((t) => t.role === "user" && t.text.trim());
  const text = (first?.text ?? turns.find((t) => t.text.trim())?.text ?? "untitled").replace(/\s+/g, " ").trim();
  return text.length > 60 ? text.slice(0, 59) + "…" : text;
}

function freshThreadId(): string {
  const id = uid("th");
  try {
    localStorage.setItem(LS.threadId, id);
  } catch {
    /* noop */
  }
  return id;
}

/** one-time codes and key-shaped strings never reach disk */
function scrub(s: string): string {
  return s
    .replace(/\bsk-[A-Za-z0-9_\-]{8,}\b/g, "[redacted-key]")
    .replace(/\b\d{3}[- ]?\d{3}[- ]?\d{4}\b/g, "[redacted-phone]");
}

function loadJSON<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return { ...fallback, ...JSON.parse(raw) } as T;
  } catch {
    return fallback;
  }
}

function saveJSON(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage full or unavailable — the app keeps working */
  }
}

interface FotraStore {
  hydrated: boolean;
  phase: Phase;
  statusLine: string;
  errorHint: string;
  onboarded: boolean;

  turns: Turn[];
  screens: Record<string, ScreenInstance>;
  screenOrder: string[];
  widgets: WidgetInstance[];
  queue: QueuedMessage[];

  persona: Persona;
  memory: MemoryFact[];
  settings: Settings;
  threadId: string; // the saved thread this conversation is written to

  liveCaption: string;
  lastLatencyMs: number | null;
  bloom: number; // increments to trigger orb bloom on persona change
  runStartedAt: number | null; // epoch ms — drives the working row's elapsed (omp working-row steal)
  settingsOpen: boolean;
  memoryOpen: boolean;
  readOnly: boolean; // another tab owns the conversation (multi-tab contract)

  // —— the stage: the live computer-use window (exists only while there is something to watch) ——
  stage: BrowserStage;
  upsertStep: (turnId: string, patch: StepPatch) => void;
  pushFrame: (turnId: string, stepId: string, frame: Omit<BrowserFrame, "ts">, demo?: boolean) => void;
  setStage: (patch: Partial<BrowserStage>) => void;
  settleSteps: (turnId: string) => void; // a run ended — nothing is "running" anymore

  // —— reactions ——
  react: (turnId: string, emoji: string, by: Reaction["by"], note?: string) => void;
  takeFeedback: () => Array<{ emoji: string; note?: string; excerpt: string }>; // unsent user reactions → the next run

  // —— the app's own layout (the agent can change it) ——
  patchUi: (patch: Partial<UiPrefs>) => void;

  // —— harness telemetry (the activity rail) ——
  toolActivity: ToolActivity[]; // newest first, capped — every tool call the run made
  wsFiles: string[]; // workspace file listing (agent-written + sandbox outputs)
  logTool: (name: string, summary: string, ok: boolean, ms?: number) => void;
  setWsFiles: (files: string[]) => void;

  // —— lifecycle ——
  hydrate: () => void;
  setPhase: (p: Phase, statusLine?: string) => void;
  setStatusLine: (line: string) => void;
  setError: (msg: string, hint?: string) => void;
  clearError: () => void;
  setOnboarded: () => void;
  setSettingsOpen: (open: boolean) => void;
  setMemoryOpen: (open: boolean) => void;

  // —— turns ——
  openTurn: (role: "user" | "assistant", origin?: Turn["origin"], text?: string) => string;
  restoreAssistantTurn: (id: string) => void; // reattach: bring the server-named turn back, empty
  pushSystemTurn: (id: string, text: string, origin?: "system" | "voice-call") => void; // quiet lines: receipts, consolidation
  appendToTurn: (id: string, chunk: string) => void;
  resetTurnText: (id: string) => void; // say_reset: a corrective retry re-speaks — clear the partial text
  finishTurn: (id: string, opts?: { interrupted?: boolean }) => void;
  attachScreenToTurn: (turnId: string, screenId: string) => void;
  resetThread: () => void;

  // —— screens ——
  dockScreen: (id: string, component: ScreenKind, props: Record<string, unknown>, opts?: { building?: boolean; turnId?: string; demoData?: boolean }) => void;
  patchScreen: (id: string, props: Record<string, unknown>) => void;
  finishScreen: (id: string) => void;
  setScreenBuilding: (id: string, building: boolean) => void;
  retireUnpinned: () => void;
  dismissScreen: (id: string) => void;
  markScreensInterrupted: () => void;
  togglePin: (id: string) => void;
  pinScreen: (id: string) => void;
  setExpanded: (id: string, expanded: boolean) => void;
  resolveAsk: (id: string, choice: string) => void;

  // —— widgets ——
  spawnWidget: (id: string, kind: WidgetKind, props: Record<string, unknown>) => void;
  patchWidget: (id: string, props: Record<string, unknown>) => void;
  removeWidget: (id: string) => void;

  // —— queue ——
  enqueue: (text: string, origin: "voice" | "text") => string;
  markSteered: (id: string) => void; // landed mid-run server-side — don't re-send after
  removeQueued: (id: string) => void;
  drainQueue: () => QueuedMessage[];

  // —— persona / theme / memory / settings ——
  patchPersona: (patch: Partial<Persona>) => void;
  setCoat: (coat: MascotCoat) => void; // the skin — app accent + mascot together
  setMode: (mode: ThemeMode) => void; // dark | light — the canvas under the accent
  switchSession: (id: string) => Promise<void>; // jump to another recorded session (thread replays from the server log)
  newSession: () => void; // fresh thread — the next server run mints a new session id
  openThread: (id: string) => void; // reopen a thread saved in this browser, steps and screens intact
  deleteThread: (id: string) => void;
  remember: (fact: string, topic: string, origin: MemoryFact["origin"]) => void;
  forgetMatching: (match: string) => number;
  removeFact: (id: string) => void;
  updateSettings: (patch: Partial<Settings>) => void;
  setLiveCaption: (t: string) => void;
  setLatency: (ms: number | null) => void;
  setReadOnly: (readOnly: boolean) => void;
}

const COATS: MascotCoat[] = ["iris", "verdant", "ember", "ice", "rose", "mono"];

/** the coat is the theme: it drives data-coat, which colors the whole app */
function applyCoatToDom(coat: MascotCoat, mode: ThemeMode = "dark") {
  if (typeof document === "undefined") return;
  document.documentElement.dataset.coat = COATS.includes(coat) ? coat : "verdant";
  document.documentElement.dataset.mode = mode;
}

export const useFotra = create<FotraStore>((set, get) => ({
  hydrated: false,
  phase: "idle",
  statusLine: "",
  errorHint: "",
  onboarded: false,

  turns: [],
  screens: {},
  screenOrder: [],
  widgets: [],
  queue: [],

  persona: DEFAULT_PERSONA,
  memory: [],
  settings: DEFAULT_SETTINGS,
  threadId: "",

  liveCaption: "",
  lastLatencyMs: null,
  bloom: 0,
  runStartedAt: null,
  settingsOpen: false,
  memoryOpen: false,
  readOnly: false,
  toolActivity: [],
  wsFiles: [],
  stage: { stepId: null, turnId: null, live: false, frames: [], open: false, size: "pip" },

  hydrate: () => {
    const rawSettings = loadJSON<Settings>(LS.settings, DEFAULT_SETTINGS);
    const rawPersona = loadJSON<Persona>(LS.persona, DEFAULT_PERSONA);
    // migration — the old two-world setting becomes the coat (the coat is the theme now):
    // an explicitly chosen coat wins; otherwise the remembered world carries over; else verdant
    const legacy = (rawSettings as { theme?: string }).theme;
    let coat: MascotCoat = COATS.includes(rawPersona.coat) ? rawPersona.coat : legacy === "ember" ? "ember" : "verdant";
    if (rawPersona.coat === "iris" && legacy === "ember") coat = "ember"; // iris was the old default — the world wins
    // the old faces map onto the new bodies
    const oldSkin = rawPersona.mascot as string;
    const mascot = (oldSkin === "blob" ? "ghost" : oldSkin === "pi" ? "star" : ["dot", "ghost", "star", "cat", "bot", "orb"].includes(oldSkin) ? oldSkin : "dot") as Persona["mascot"];
    const persona: Persona = { ...DEFAULT_PERSONA, ...rawPersona, coat, mascot };
    const settings: Settings = {
      ...rawSettings,
      mode: rawSettings.mode === "light" ? "light" : "dark",
      ui: { ...DEFAULT_UI, ...(rawSettings.ui ?? {}) },
    };
    let memory: MemoryFact[] = [];
    let turns: Turn[] = [];
    let widgets: WidgetInstance[] = [];
    let screens: Record<string, ScreenInstance> = {};
    let screenOrder: string[] = [];
    try {
      const rawMem = localStorage.getItem(LS.memory);
      if (rawMem) memory = JSON.parse(rawMem) as MemoryFact[];
      const rawThread = localStorage.getItem(LS.thread);
      if (rawThread) {
        turns = (JSON.parse(rawThread) as Turn[]).slice(-120).map((t) => ({
          ...t,
          streaming: false,
          screenIds: t.screenIds ? [...new Set(t.screenIds)] : undefined,
          // nothing survives a reload mid-flight: a step that was running is simply over
          steps: t.steps
            ? Object.fromEntries(Object.entries(t.steps).map(([id, st]) => [id, st.status === "running" ? { ...st, status: "done" as const } : st]))
            : undefined,
        }));
      }
      const rawWidgets = localStorage.getItem(LS.widgets);
      if (rawWidgets) widgets = JSON.parse(rawWidgets) as WidgetInstance[];
      const rawScreens = localStorage.getItem(LS.screens);
      if (rawScreens) {
        const parsed = JSON.parse(rawScreens) as { order: string[]; screens: Record<string, ScreenInstance> };
        screenOrder = parsed.order ?? [];
        screens = Object.fromEntries(
          screenOrder
            .map((id) => [id, { ...(parsed.screens?.[id] as ScreenInstance), expanded: false }] as const)
            .filter(([, sc]) => !!sc && !!sc.component)
        );
      } else {
        const rawPinned = localStorage.getItem(LS.pinned);
        if (rawPinned) {
          const list = JSON.parse(rawPinned) as ScreenInstance[];
          screens = Object.fromEntries(list.map((sc) => [sc.id, { ...sc, expanded: false }]));
          screenOrder = list.map((sc) => sc.id);
        }
      }
    } catch {
      /* corrupt storage — start fresh rather than crash */
    }
    let onboarded = false;
    try {
      onboarded = localStorage.getItem(LS.onboarded) === "1";
    } catch {
      /* noop */
    }
    // settings is the source of truth — sync next-themes' key so the provider never
    // fights the store on boot (a stale/missing fotra.mode would stomp back to dark)
    try {
      if (localStorage.getItem("fotra.mode") !== settings.mode) {
        localStorage.setItem("fotra.mode", settings.mode);
      }
    } catch {
      /* noop */
    }
    applyCoatToDom(persona.coat, settings.mode);
    let threadId = "";
    try {
      threadId = localStorage.getItem(LS.threadId) ?? "";
    } catch {
      /* noop */
    }
    if (!threadId) threadId = freshThreadId();
    set({
      hydrated: true,
      threadId,
      settings,
      persona,
      memory,
      turns,
      widgets,
      screens,
      screenOrder,
      onboarded,
    });
  },

  setPhase: (p, statusLine) =>
    set((s) => ({ phase: p, statusLine: statusLine ?? (p === s.phase ? s.statusLine : "") })),
  setStatusLine: (line) => set({ statusLine: line }),
  setError: (msg, hint) => set({ phase: "error", statusLine: msg, errorHint: hint ?? "" }),
  clearError: () => set({ phase: "idle", statusLine: "", errorHint: "" }),
  setOnboarded: () => {
    try {
      localStorage.setItem(LS.onboarded, "1");
    } catch {
      /* noop */
    }
    set({ onboarded: true });
  },
  setSettingsOpen: (open) => set({ settingsOpen: open, memoryOpen: false }),
  setMemoryOpen: (open) => set({ memoryOpen: open, settingsOpen: false }),

  openTurn: (role, origin, text = "") => {
    const id = uid(role === "user" ? "u" : "a");
    set((s) => ({
      turns: [
        ...s.turns,
        { id, role, text, origin, streaming: role === "assistant", ts: Date.now(), ...(role === "assistant" ? { blocks: [] } : {}) },
      ],
    }));
    return id;
  },

  /** reattach: the server names the assistant turn — bring it back empty and streaming */
  restoreAssistantTurn: (id) =>
    set((s) => {
      const exists = s.turns.find((t) => t.id === id);
      if (exists) {
        // a replay rebuilds the turn from the log — words, steps and screens all come back in order
        return { turns: s.turns.map((t) => (t.id === id ? { ...t, text: "", streaming: true, interrupted: false, blocks: [], steps: {}, screenIds: [] } : t)) };
      }
      return { turns: [...s.turns, { id, role: "assistant" as const, text: "", streaming: true, ts: Date.now(), blocks: [] }] };
    }),

  /** quiet lines in the thread — voice receipts, "memory consolidated", never toasts */
  pushSystemTurn: (id, text, origin = "system") =>
    set((s) => {
      if (s.turns.some((t) => t.id === id)) return s;
      return { turns: [...s.turns, { id, role: "assistant" as const, text, origin, ts: Date.now() }] };
    }),

  appendToTurn: (id, chunk) =>
    set((s) => ({
      turns: s.turns.map((t) => {
        if (t.id !== id) return t;
        // words continue the last text block, or open a new one after work/screens — the timeline stays in order
        const blocks = t.blocks ? [...t.blocks] : undefined;
        let gap = "";
        if (blocks) {
          const last = blocks[blocks.length - 1];
          if (last?.kind === "text") blocks[blocks.length - 1] = { kind: "text", text: last.text + chunk };
          else {
            blocks.push({ kind: "text", text: chunk });
            // words resuming after work are a new paragraph in the plain text too (copy, history)
            if (t.text && !/\s$/.test(t.text)) gap = "\n\n";
          }
        }
        return { ...t, text: t.text + gap + chunk, ...(blocks ? { blocks } : {}) };
      }),
    })),

  resetTurnText: (id) =>
    set((s) => ({
      turns: s.turns.map((t) => (t.id === id ? { ...t, text: "", ...(t.blocks ? { blocks: t.blocks.filter((b) => b.kind !== "text") } : {}) } : t)),
    })),

  finishTurn: (id, opts) =>
    set((s) => ({
      turns: s.turns.map((t) =>
        t.id === id ? { ...t, streaming: false, interrupted: opts?.interrupted, ms: t.ms ?? Math.max(0, Date.now() - t.ts) } : t
      ),
    })),

  attachScreenToTurn: (turnId, screenId) =>
    set((s) => ({
      turns: s.turns.map((t) =>
        t.id === turnId && !t.screenIds?.includes(screenId)
          ? {
              ...t,
              screenIds: [...(t.screenIds ?? []), screenId],
              ...(t.blocks ? { blocks: [...t.blocks, { kind: "screen", id: screenId } as TurnBlock] } : {}),
            }
          : t
      ),
    })),

  /** a tool call as the user watches it: opened on start, patched while it runs, settled when it lands */
  upsertStep: (turnId, patch) =>
    set((s) => ({
      turns: s.turns.map((t) => {
        if (t.id !== turnId) return t;
        const steps = { ...(t.steps ?? {}) };
        const prev = steps[patch.id];
        if (prev) {
          steps[patch.id] = { ...prev, ...patch, data: patch.data ? { ...(prev.data ?? {}), ...patch.data } : prev.data };
          return { ...t, steps };
        }
        const step: Step = {
          tool: "tool",
          kind: "other",
          title: "Working",
          status: "running",
          ...patch,
          ts: Date.now(),
        };
        steps[patch.id] = step;
        // consecutive steps share one group — a batch of parallel calls reads as one piece of work
        const blocks = [...(t.blocks ?? [])];
        const last = blocks[blocks.length - 1];
        if (last?.kind === "steps") blocks[blocks.length - 1] = { kind: "steps", ids: [...last.ids, patch.id] };
        else blocks.push({ kind: "steps", ids: [patch.id] });
        return { ...t, steps, blocks };
      }),
    })),

  settleSteps: (turnId) =>
    set((s) => ({
      turns: s.turns.map((t) => {
        if (t.id !== turnId || !t.steps) return t;
        const running = Object.values(t.steps).some((st) => st.status === "running");
        if (!running) return t;
        return {
          ...t,
          steps: Object.fromEntries(Object.entries(t.steps).map(([id, st]) => [id, st.status === "running" ? { ...st, status: "error" as const, summary: st.summary ?? "stopped" } : st])),
        };
      }),
      stage: { ...s.stage, live: false },
    })),

  /** one frame of computer use. A frame without a picture (the cursor heading somewhere) keeps the last picture. */
  pushFrame: (turnId, stepId, frame, demo) =>
    set((s) => {
      const fresh = s.stage.turnId !== turnId; // a new run's browsing starts a new reel
      const prevFrames = fresh ? [] : s.stage.frames;
      const last = prevFrames[prevFrames.length - 1];
      const next: BrowserFrame = {
        ...frame,
        shot: frame.shot ?? last?.shot,
        title: frame.title ?? last?.title,
        cursor: frame.cursor ?? last?.cursor,
        ts: Date.now(),
      };
      const pref = s.settings.ui?.stage ?? "pip";
      return {
        stage: {
          stepId,
          turnId,
          demo: demo ?? (fresh ? false : s.stage.demo),
          live: true,
          frames: [...prevFrames, next].slice(-40),
          // it pops up on its own the first time there is something to watch; once dismissed it stays dismissed for the run
          open: fresh ? pref !== "off" : s.stage.open,
          size: fresh ? (pref === "wide" ? "wide" : "pip") : s.stage.size,
        },
      };
    }),

  setStage: (patch) => set((s) => ({ stage: { ...s.stage, ...patch } })),

  /** the user toggles their own reaction; the agent's tapback just lands */
  react: (turnId, emoji, by, note) =>
    set((s) => {
      const turns = s.turns.map((t) => {
        if (t.id !== turnId) return t;
        const list = t.reactions ?? [];
        if (by === "agent") {
          return { ...t, reactions: [...list.filter((r) => r.by !== "agent"), { emoji, by, ts: Date.now() }] };
        }
        const mine = list.find((r) => r.by === "user");
        const rest = list.filter((r) => r.by !== "user");
        if (mine && mine.emoji === emoji && note === undefined) return { ...t, reactions: rest }; // tap again = take it back
        return { ...t, reactions: [...rest, { emoji, by, note: note ?? (mine?.emoji === emoji ? mine.note : undefined), ts: Date.now() }] };
      });
      saveJSON(LS.thread, turns.slice(-120));
      return { turns };
    }),

  takeFeedback: () => {
    const out: Array<{ emoji: string; note?: string; excerpt: string }> = [];
    const turns = get().turns.map((t) => {
      if (t.role !== "assistant" || !t.reactions?.some((r) => r.by === "user" && !r.sent)) return t;
      return {
        ...t,
        reactions: t.reactions.map((r) => {
          if (r.by !== "user" || r.sent) return r;
          out.push({ emoji: r.emoji, note: r.note, excerpt: t.text.slice(0, 200) });
          return { ...r, sent: true };
        }),
      };
    });
    if (out.length > 0) set({ turns });
    return out;
  },

  patchUi: (patch) =>
    set((s) => {
      const settings = { ...s.settings, ui: { ...DEFAULT_UI, ...(s.settings.ui ?? {}), ...patch } };
      saveJSON(LS.settings, settings);
      return { settings, bloom: s.bloom + 1 };
    }),

  resetThread: () => {
    set((s) => ({ turns: [], screens: {}, screenOrder: [], queue: [], phase: "idle", statusLine: "", stage: { ...s.stage, open: false, live: false, frames: [], turnId: null, stepId: null } }));
    try {
      localStorage.removeItem(LS.thread);
      localStorage.removeItem(LS.pinned);
    } catch {
      /* noop */
    }
    saveThreads(loadThreads().filter((t) => t.id !== get().threadId));
  },

  dockScreen: (id, component, props, opts) =>
    set((s) => {
      const existing = s.screens[id];
      const screen: ScreenInstance = {
        id,
        component,
        props,
        status: "live",
        pinned: existing?.pinned ?? false,
        expanded: false,
        building: opts?.building ?? false,
        turnId: opts?.turnId,
        demoData: opts?.demoData,
        resolved: existing?.resolved ?? null,
        ts: Date.now(),
      };
      const order = existing ? s.screenOrder : [...s.screenOrder, id];
      return { screens: { ...s.screens, [id]: screen }, screenOrder: order };
    }),

  patchScreen: (id, props) =>
    set((s) => {
      const screen = s.screens[id];
      if (!screen) return s;
      return {
        screens: {
          ...s.screens,
          [id]: { ...screen, props: { ...screen.props, ...props } },
        },
      };
    }),

  finishScreen: (id) =>
    set((s) => {
      const screen = s.screens[id];
      if (!screen) return s;
      return { screens: { ...s.screens, [id]: { ...screen, building: false, status: "live" } } };
    }),

  setScreenBuilding: (id, building) =>
    set((s) => {
      const screen = s.screens[id];
      if (!screen) return s;
      return { screens: { ...s.screens, [id]: { ...screen, building } } };
    }),

  retireUnpinned: () =>
    set((s) => {
      const screens = { ...s.screens };
      for (const id of s.screenOrder) {
        const sc = screens[id];
        if (sc && !sc.pinned && sc.status === "live") screens[id] = { ...sc, status: "retired" };
      }
      persistPinned(screens);
      return { screens };
    }),

  dismissScreen: (id) =>
    set((s) => {
      const screen = s.screens[id];
      if (!screen) return s;
      const screens: Record<string, ScreenInstance> = { ...s.screens, [id]: { ...screen, status: "retired", pinned: false, expanded: false } };
      persistPinned(screens);
      return { screens };
    }),

  markScreensInterrupted: () =>
    set((s) => {
      const screens = { ...s.screens };
      for (const id of s.screenOrder) {
        const sc = screens[id];
        if (sc && sc.building) screens[id] = { ...sc, status: "interrupted", building: false };
      }
      return { screens };
    }),

  togglePin: (id) =>
    set((s) => {
      const screen = s.screens[id];
      if (!screen) return s;
      const screens = { ...s.screens, [id]: { ...screen, pinned: !screen.pinned } };
      persistPinned(screens);
      return { screens };
    }),

  /** pin (and rescue from retirement) — voice: “pin this” */
  pinScreen: (id) =>
    set((s) => {
      const screen = s.screens[id];
      if (!screen) return s;
      const screens: Record<string, ScreenInstance> = { ...s.screens, [id]: { ...screen, pinned: true, status: "live" } };
      persistPinned(screens);
      return { screens };
    }),

  setExpanded: (id, expanded) =>
    set((s) => {
      const screen = s.screens[id];
      if (!screen) return s;
      return { screens: { ...s.screens, [id]: { ...screen, expanded } } };
    }),

  resolveAsk: (id, choice) =>
    set((s) => {
      const screen = s.screens[id];
      if (!screen) return s;
      return { screens: { ...s.screens, [id]: { ...screen, resolved: choice } } };
    }),

  spawnWidget: (id, kind, props) =>
    set((s) => {
      const widgets = [...s.widgets.filter((w) => w.id !== id), { id, kind, props, ts: Date.now() }];
      saveJSON(LS.widgets, widgets);
      return { widgets };
    }),

  patchWidget: (id, props) =>
    set((s) => {
      const widgets = s.widgets.map((w) => (w.id === id ? { ...w, props: { ...w.props, ...props } } : w));
      saveJSON(LS.widgets, widgets);
      return { widgets };
    }),

  removeWidget: (id) =>
    set((s) => {
      const widgets = s.widgets.filter((w) => w.id !== id);
      saveJSON(LS.widgets, widgets);
      return { widgets };
    }),

  enqueue: (text, origin) => {
    const id = uid("q");
    set((s) => ({ queue: [...s.queue, { id, text, origin, ts: Date.now() }] }));
    return id;
  },

  markSteered: (id) =>
    set((s) => ({ queue: s.queue.map((q) => (q.id === id ? { ...q, steered: true } : q)) })),

  removeQueued: (id) => set((s) => ({ queue: s.queue.filter((q) => q.id !== id) })),

  drainQueue: () => {
    const q = get().queue;
    set({ queue: [] });
    return q;
  },

  patchPersona: (patch) => {
    set((s) => {
      const persona = { ...s.persona, ...patch };
      if (patch.coat) applyCoatToDom(patch.coat, s.settings.mode);
      saveJSON(LS.persona, scrubPersona(persona));
      return { persona, bloom: patch.aura || patch.name || patch.coat || patch.mascot ? s.bloom + 1 : s.bloom };
    });
  },

  /** the coat — the one skin: re-colors the app accent, the mesh orb and the face together */
  setCoat: (coat) => {
    applyCoatToDom(coat, get().settings.mode);
    set((s) => {
      const persona = { ...s.persona, coat };
      saveJSON(LS.persona, scrubPersona(persona));
      return { persona, bloom: s.bloom + 1 };
    });
  },

  /** dark | light — writes both the store's settings and next-themes' key (fotra.mode) so the pre-paint never fights the provider */
  setMode: (mode) => {
    applyCoatToDom(get().persona.coat, mode);
    try {
      localStorage.setItem("fotra.mode", mode);
    } catch {
      /* noop */
    }
    set((s) => {
      const settings = { ...s.settings, mode };
      saveJSON(LS.settings, settings);
      return { settings, bloom: s.bloom + 1 };
    });
  },

  /** jump to a recorded session — the server log replays into the thread; screens/widgets of the old one retire */
  switchSession: async (id) => {
    const cur = get().settings.sessionId;
    if (id === cur) return;
    const local = loadThreads().find((t) => t.sessionId === id);
    if (local) {
      get().openThread(local.id);
      return;
    }
    archiveCurrent();
    try {
      const res = await fetch(`/api/session?id=${encodeURIComponent(id)}`);
      if (!res.ok) {
        toast.error("couldn't load that session", { description: `the server said ${res.status}` });
        return;
      }
      const j = (await res.json()) as {
        turns?: Array<{ id: string; role: string; text: string; origin?: string; ts: string; interrupted?: boolean }>;
      };
      const turns: Turn[] = (j.turns ?? []).map((t) => ({
        id: t.id,
        role: t.role === "user" ? "user" : "assistant",
        text: t.text,
        origin: (t.origin as Turn["origin"]) ?? undefined,
        streaming: false,
        interrupted: t.interrupted ?? undefined,
        ts: new Date(t.ts).getTime(),
      }));
      set((s) => ({
        turns,
        screens: {},
        screenOrder: [],
        queue: [],
        phase: "idle" as Phase,
        statusLine: "",
        errorHint: "",
        settings: { ...s.settings, sessionId: id, lastRunId: "", lastSeq: 0 },
        threadId: freshThreadId(),
        stage: { ...s.stage, open: false, live: false, frames: [], turnId: null, stepId: null },
      }));
      saveJSON(LS.thread, turns.slice(-120));
      saveJSON(LS.settings, { ...get().settings }); // the switch survives a reload
      try {
        localStorage.removeItem(LS.pinned);
        localStorage.removeItem(LS.screens);
      } catch {
        /* noop */
      }
      archiveCurrent();
    } catch {
      toast.error("couldn't load that session", { description: "network error — try again" });
    }
  },

  /** fresh thread — the next server run mints a new session id */
  newSession: () => {
    archiveCurrent();
    set((s) => ({
      threadId: freshThreadId(),
      stage: { ...s.stage, open: false, live: false, frames: [], turnId: null, stepId: null },
      turns: [],
      screens: {},
      screenOrder: [],
      queue: [],
      phase: "idle" as Phase,
      statusLine: "",
      errorHint: "",
      settings: { ...s.settings, sessionId: "", lastRunId: "", lastSeq: 0 },
    }));
    saveJSON(LS.settings, { ...get().settings }); // the fresh session id survives a reload
    try {
      localStorage.removeItem(LS.thread);
      localStorage.removeItem(LS.pinned);
      localStorage.removeItem(LS.screens);
    } catch {
      /* noop */
    }
  },

  openThread: (id) => {
    if (id === get().threadId) return;
    archiveCurrent();
    const t = loadThreads().find((x) => x.id === id);
    if (!t) return;
    const order = t.screens?.order ?? [];
    const screens = Object.fromEntries(order.map((sid) => [sid, t.screens.screens[sid]] as const).filter(([, sc]) => !!sc && !!sc.component));
    set((s) => ({
      threadId: t.id,
      turns: t.turns.map((x) => ({ ...x, streaming: false })),
      screens,
      screenOrder: order.filter((sid) => !!screens[sid]),
      queue: [],
      phase: "idle" as Phase,
      statusLine: "",
      errorHint: "",
      settings: { ...s.settings, sessionId: t.sessionId ?? "", lastRunId: "", lastSeq: 0 },
      stage: { ...s.stage, open: false, live: false, frames: [], turnId: null, stepId: null },
    }));
    saveJSON(LS.settings, { ...get().settings });
    saveJSON(LS.thread, get().turns);
    saveJSON(LS.screens, { order: get().screenOrder, screens });
    try {
      localStorage.setItem(LS.threadId, t.id);
      localStorage.removeItem(LS.pinned);
    } catch {
      /* noop */
    }
  },

  deleteThread: (id) => {
    saveThreads(loadThreads().filter((t) => t.id !== id));
    if (id === get().threadId) get().newSession();
  },

  remember: (fact, topic, origin) => {
    const f: MemoryFact = { id: uid("m"), fact: scrub(fact), topic, origin, ts: Date.now() };
    set((s) => {
      const memory = [...s.memory, f];
      saveJSON(LS.memory, memory);
      return { memory };
    });
  },

  forgetMatching: (match) => {
    const lower = match.toLowerCase();
    const before = get().memory.length;
    set((s) => {
      const memory = s.memory.filter((m) => !m.fact.toLowerCase().includes(lower));
      saveJSON(LS.memory, memory);
      return { memory };
    });
    return before - get().memory.length;
  },

  removeFact: (id) =>
    set((s) => {
      const memory = s.memory.filter((m) => m.id !== id);
      saveJSON(LS.memory, memory);
      return { memory };
    }),

  updateSettings: (patch) => {
    set((s) => {
      const settings = { ...s.settings, ...patch };
      saveJSON(LS.settings, settings);
      return { settings };
    });
  },

  setLiveCaption: (t) => set({ liveCaption: t }),
  setLatency: (ms) => set({ lastLatencyMs: ms }),
  setReadOnly: (readOnly) => set({ readOnly }),
  logTool: (name, summary, ok, ms) =>
    set((s) => ({
      toolActivity: [
        { id: uid("act"), name, summary, ok, ms, ts: Date.now() },
        ...s.toolActivity,
      ].slice(0, 60),
    })),
  setWsFiles: (files) => set({ wsFiles: files }),
}));

function scrubPersona(p: Persona): Persona {
  return { ...p, name: scrub(p.name).slice(0, 24), tagline: scrub(p.tagline).slice(0, 80) };
}
function persistPinned(screens: Record<string, ScreenInstance>) {
  try {
    const pinned = Object.values(screens).filter((s) => s.pinned && s.status !== "retired");
    localStorage.setItem(LS.pinned, JSON.stringify(pinned.map((s) => ({ ...s, expanded: false }))));
  } catch {
    /* noop */
  }
}

/** call after each assistant turn settles — thread + its screens persist together */
export function persistThread(turns: Turn[]) {
  saveJSON(
    LS.thread,
    turns.slice(-120).map((t) => ({
      ...t,
      text: scrub(t.text),
      blocks: t.blocks?.map((b) => (b.kind === "text" ? { ...b, text: scrub(b.text) } : b)),
    }))
  );
  archiveCurrent();
  const s = useFotra.getState();
  const order = s.screenOrder.slice(-30);
  saveJSON(LS.screens, {
    order,
    screens: Object.fromEntries(order.map((id) => [id, { ...s.screens[id], expanded: false }])),
  });
}

/** write the conversation on screen into the archive (a thread with nothing said is not a thread) */
function archiveCurrent() {
  const s = useFotra.getState();
  const turns = s.turns.filter((t) => !t.streaming || t.text);
  if (!s.threadId || !turns.some((t) => t.role === "user")) return;
  const order = s.screenOrder.slice(-30);
  const entry: SavedThread = {
    id: s.threadId,
    sessionId: s.settings.sessionId ?? "",
    title: threadTitle(turns),
    updatedAt: turns[turns.length - 1]?.ts ?? Date.now(),
    turns: turns.slice(-120).map((t) => ({
      ...t,
      streaming: false,
      text: scrub(t.text),
      blocks: t.blocks?.map((b) => (b.kind === "text" ? { ...b, text: scrub(b.text) } : b)),
    })),
    screens: { order, screens: Object.fromEntries(order.map((id) => [id, { ...s.screens[id], expanded: false }])) },
  };
  const list = loadThreads();
  const prev = list.find((t) => t.id === entry.id);
  if (prev && prev.turns.length === entry.turns.length && prev.sessionId === entry.sessionId && prev.updatedAt === entry.updatedAt) return;
  saveThreads([entry, ...list.filter((t) => t.id !== entry.id)]);
}
