﻿import { homedir } from "node:os";
import path from "node:path";
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";

// Google Programmable Search credentials — kept in the app's own data folder on this machine,
// outside the memory vault, never sent anywhere but googleapis.com.
export interface SearchConfig {
  googleKey: string;
  googleCx: string;
}

function file(): string {
  const home = process.env.FOTRA_HOME?.trim() || path.join(homedir(), ".fotra");
  return path.join(home, "search.json");
}

export function readSearchConfig(): SearchConfig | null {
  const envKey = (process.env.GOOGLE_SEARCH_KEY ?? "").trim();
  const envCx = (process.env.GOOGLE_SEARCH_CX ?? "").trim();
  if (envKey && envCx) return { googleKey: envKey, googleCx: envCx };
  try {
    if (!existsSync(file())) return null;
    const j = JSON.parse(readFileSync(file(), "utf8")) as Partial<SearchConfig>;
    return j.googleKey && j.googleCx ? { googleKey: j.googleKey, googleCx: j.googleCx } : null;
  } catch {
    return null;
  }
}

export function writeSearchConfig(cfg: SearchConfig | null): void {
  if (!cfg) {
    rmSync(file(), { force: true });
    return;
  }
  mkdirSync(path.dirname(file()), { recursive: true });
  writeFileSync(file(), JSON.stringify(cfg, null, 2), "utf8");
}
