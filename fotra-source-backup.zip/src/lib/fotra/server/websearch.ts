import { builtinBrainAvailable, zaiClient } from "./zai";
import { readSearchConfig, type SearchConfig } from "./searchconfig";

/* ————————————————————————————————————————————————
   web search — two backends, one shape.
   The built-in SDK search when it exists; otherwise a
   keyless fallback that reads DuckDuckGo's HTML results
   page. The fallback is what makes a bring-your-own-model
   install able to search at all.
   ———————————————————————————————————————————————— */

export interface SearchHit {
  title: string;
  url: string;
  host: string;
  date?: string;
  snippet: string;
}

function clip(s: string, n: number): string {
  return s.length > n ? s.slice(0, n) + "…" : s;
}

function decodeEntities(s: string): string {
  return s
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#x27;|&#39;/g, "'")
    .replace(/&#x2F;/g, "/")
    .replace(/&nbsp;/g, " ")
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)));
}

function strip(html: string): string {
  return decodeEntities(html.replace(/<[^>]+>/g, "")).replace(/\s+/g, " ").trim();
}

function hostOf(u: string): string {
  try {
    return new URL(u).host.replace(/^www\./, "");
  } catch {
    return "";
  }
}

/** DuckDuckGo wraps result links in a redirect — unwrap to the real destination */
function unwrap(href: string): string {
  let h = decodeEntities(href);
  if (h.startsWith("//")) h = `https:${h}`;
  try {
    const u = new URL(h, "https://duckduckgo.com");
    const real = u.searchParams.get("uddg");
    return real || u.toString(); // searchParams already percent-decodes
  } catch {
    return h;
  }
}

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";

async function page(url: string, init: RequestInit, signal?: AbortSignal): Promise<string> {
  const res = await fetch(url, {
    ...init,
    cache: "no-store",
    headers: { "User-Agent": UA, Accept: "text/html", "Accept-Language": "en-US,en;q=0.8", ...(init.headers ?? {}) },
    signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(12_000)]) : AbortSignal.timeout(12_000),
  });
  // 202 is DuckDuckGo's "prove you're a browser" page — treat it as a miss, not as zero results
  if (res.status !== 200) throw new Error(`search backend answered ${res.status}`);
  return res.text();
}

/** the full results page: title, link, snippet per result */
function parseHtml(html: string, num: number): SearchHit[] {
  const hits: SearchHit[] = [];
  const blocks = html.split(/<div[^>]+class="[^"]*\bresult\b[^"]*"/i).slice(1);
  for (const block of blocks) {
    const a = block.match(/<a[^>]+class="[^"]*result__a[^"]*"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i);
    if (!a) continue;
    const url = unwrap(a[1]);
    if (!/^https?:\/\//i.test(url) || /duckduckgo\.com\/(y\.js|l\/)/.test(url)) continue; // ads and unwrapped redirects
    const sn = block.match(/class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/(?:a|div|span)>/i);
    hits.push({ title: clip(strip(a[2]), 140), url, host: hostOf(url), snippet: clip(sn ? strip(sn[1]) : "", 400) });
    if (hits.length >= num) break;
  }
  return hits;
}

/** the lite page: a table of links, each followed by a snippet cell */
function parseLite(html: string, num: number): SearchHit[] {
  const hits: SearchHit[] = [];
  const re = /<a[^>]+href="([^"]+)"[^>]*class=['"]result-link['"][^>]*>([\s\S]*?)<\/a>([\s\S]*?)(?=<a[^>]+class=['"]result-link['"]|$)/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html)) && hits.length < num) {
    const url = unwrap(m[1]);
    if (!/^https?:\/\//i.test(url) || /duckduckgo\.com\/(y\.js|l\/)/.test(url)) continue;
    const sn = m[3].match(/class=['"]result-snippet['"][^>]*>([\s\S]*?)<\/td>/i);
    hits.push({ title: clip(strip(m[2]), 140), url, host: hostOf(url), snippet: clip(sn ? strip(sn[1]) : "", 400) });
  }
  return hits;
}

/** Bing's plain results page */
function parseBing(html: string, num: number): SearchHit[] {
  const hits: SearchHit[] = [];
  const blocks = html.split(/<li class="b_algo"/i).slice(1);
  for (const block of blocks) {
    const a = block.match(/<h2[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i);
    if (!a) continue;
    let url = decodeEntities(a[1]);
    // bing wraps some links: /ck/a?...&u=a1<base64url>
    const wrapped = url.match(/[?&]u=a1([A-Za-z0-9_-]+)/);
    if (wrapped) {
      try {
        url = Buffer.from(wrapped[1].replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8");
      } catch {
        /* keep the wrapped link */
      }
    }
    if (!/^https?:\/\//i.test(url)) continue;
    const sn = block.match(/<p[^>]*class="[^"]*b_lineclamp[^"]*"[^>]*>([\s\S]*?)<\/p>/i) ?? block.match(/<div class="b_caption"[^>]*>[\s\S]*?<p[^>]*>([\s\S]*?)<\/p>/i);
    hits.push({ title: clip(strip(a[2]), 140), url, host: hostOf(url), snippet: clip(sn ? strip(sn[1]) : "", 400) });
    if (hits.length >= num) break;
  }
  return hits;
}

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** repeat questions cost nothing, and a burst of them never reaches the backend twice */
const cache = new Map<string, { at: number; hits: SearchHit[] }>();
const CACHE_MS = 5 * 60_000;

/** several doors, tried in turn — a search engine telling us to slow down is a reason to use the next one, not to fail */
async function duckSearch(query: string, num: number, signal?: AbortSignal): Promise<SearchHit[]> {
  const key = `${num}:${query.toLowerCase()}`;
  const cached = cache.get(key);
  if (cached && Date.now() - cached.at < CACHE_MS) return cached.hits;
  const hits = await keylessSearch(query, num, signal);
  if (hits.length > 0) {
    cache.set(key, { at: Date.now(), hits });
    if (cache.size > 200) cache.delete(cache.keys().next().value as string);
  }
  return hits;
}

async function keylessSearch(query: string, num: number, signal?: AbortSignal): Promise<SearchHit[]> {
  const q = encodeURIComponent(query);
  const tries: Array<() => Promise<SearchHit[]>> = [
    async () => parseHtml(await page(`https://html.duckduckgo.com/html/?q=${q}`, {}, signal), num),
    async () => parseHtml(await page("https://html.duckduckgo.com/html/", { method: "POST", body: `q=${q}`, headers: { "Content-Type": "application/x-www-form-urlencoded" } }, signal), num),
    async () => parseLite(await page(`https://lite.duckduckgo.com/lite/?q=${q}`, {}, signal), num),
    async () => parseBing(await page(`https://www.bing.com/search?q=${q}&setlang=en`, {}, signal), num),
    // last: the first door again after a breath — "slow down" answers usually clear in a second or two
    async () => {
      await wait(1800);
      return parseHtml(await page(`https://html.duckduckgo.com/html/?q=${q}`, {}, signal), num);
    },
  ];
  let lastErr: unknown = null;
  for (const attempt of tries) {
    if (signal?.aborted) break;
    try {
      const hits = await attempt();
      if (hits.length > 0) return hits;
    } catch (err) {
      lastErr = err;
    }
  }
  if (lastErr) throw new Error("every search engine turned the request away just now — wait a few seconds, or use open_link / the browser on a specific site instead");
  return [];
}
/** Google, through its official Programmable Search API — your key, your quota */
export async function googleSearch(query: string, num: number, cfg: SearchConfig, signal?: AbortSignal): Promise<SearchHit[]> {
  const u = new URL("https://www.googleapis.com/customsearch/v1");
  u.searchParams.set("key", cfg.googleKey);
  u.searchParams.set("cx", cfg.googleCx);
  u.searchParams.set("q", query);
  u.searchParams.set("num", String(Math.min(Math.max(num, 1), 10)));
  const res = await fetch(u, { cache: "no-store", signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(12_000)]) : AbortSignal.timeout(12_000) });
  const j = (await res.json().catch(() => ({}))) as {
    error?: { message?: string };
    items?: Array<{ title?: string; link?: string; snippet?: string; displayLink?: string }>;
  };
  if (!res.ok) throw new Error(`google search: ${j.error?.message ?? res.status}`);
  return (j.items ?? [])
    .filter((it) => it.link)
    .map((it) => ({ title: clip(it.title ?? "", 140), url: it.link as string, host: (it.displayLink || hostOf(it.link as string)).replace(/^www\./, ""), snippet: clip((it.snippet ?? "").replace(/\s+/g, " "), 400) }));
}

export async function webSearch(query: string, num: number, signal?: AbortSignal): Promise<{ hits: SearchHit[]; backend: "builtin" | "duckduckgo" | "google" }> {
  const cfg = readSearchConfig();
  if (cfg) {
    try {
      const hits = await googleSearch(query, num, cfg, signal);
      if (hits.length > 0) return { hits, backend: "google" };
    } catch {
      /* quota spent or key revoked — the keyless engines still answer */
    }
  }
  if (builtinBrainAvailable()) {
    try {
      const client = await zaiClient();
      const results = (await client.functions.invoke("web_search", { query, num })) as Array<{
        url: string; name: string; snippet: string; host_name: string; date: string;
      }>;
      const hits = (Array.isArray(results) ? results : []).slice(0, num).map((r) => ({
        title: r.name,
        url: r.url,
        host: (r.host_name || hostOf(r.url)).replace(/^www\./, ""),
        date: r.date,
        snippet: clip(r.snippet ?? "", 400),
      }));
      if (hits.length > 0) return { hits, backend: "builtin" };
    } catch {
      /* fall through to the keyless backend */
    }
  }
  return { hits: await duckSearch(query, num, signal), backend: "duckduckgo" };
}

/** for diagnostics: which keyless doors answer right now */
export async function searchDoors(query: string): Promise<Record<string, number | string>> {
  const q = encodeURIComponent(query);
  const doors: Record<string, () => Promise<SearchHit[]>> = {
    ddgHtml: async () => parseHtml(await page(`https://html.duckduckgo.com/html/?q=${q}`, {}), 5),
    ddgLite: async () => parseLite(await page(`https://lite.duckduckgo.com/lite/?q=${q}`, {}), 5),
    bing: async () => parseBing(await page(`https://www.bing.com/search?q=${q}&setlang=en`, {}), 5),
  };
  const out: Record<string, number | string> = {};
  for (const [name, fn] of Object.entries(doors)) {
    try {
      out[name] = (await fn()).length;
    } catch (err) {
      out[name] = err instanceof Error ? err.message : "failed";
    }
  }
  return out;
}
