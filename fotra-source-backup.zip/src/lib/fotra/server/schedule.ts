/* ————————————————————————————————————————————————
   Schedule grammar for routines — pure functions, no
   imports, so both the ticker and the tool belt can
   use them without an import cycle.
   Accepts what people actually say: "every 30 minutes",
   "every 2 hours", "hourly", "daily at 8", "every
   morning", "every day at 6:30pm", "daily@08:00".
   ———————————————————————————————————————————————— */

export type ParsedSchedule =
  | { kind: "every"; minutes: number }
  | { kind: "daily"; hour: number; minute: number }
  | { kind: "invalid" };

export function parseSchedule(s: string): ParsedSchedule {
  const str = s.trim().toLowerCase();
  let m = str.match(/every\s+(\d+)\s*(?:m|min|mins|minutes?)\b/);
  if (m) return { kind: "every", minutes: Math.max(1, Math.min(1440, parseInt(m[1], 10))) };
  m = str.match(/every\s+(\d+)\s*(?:h|hr|hrs|hours?)\b/);
  if (m) return { kind: "every", minutes: Math.max(1, Math.min(1440, parseInt(m[1], 10) * 60)) };
  if (/\b(hourly|every hour)\b/.test(str)) return { kind: "every", minutes: 60 };
  if (/\bevery (half hour|30)\b/.test(str)) return { kind: "every", minutes: 30 };

  m = str.match(/(?:daily|every\s*day|each day|every (?:morning|evening|night|afternoon))\s*(?:at|@)?\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/);
  if (m) {
    let hour = parseInt(m[1], 10);
    const minute = m[2] ? parseInt(m[2], 10) : 0;
    if (m[3] === "pm" && hour < 12) hour += 12;
    if (m[3] === "am" && hour === 12) hour = 0;
    if (!m[3] && /evening|night/.test(str) && hour < 12) hour += 12;
    if (hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59) return { kind: "daily", hour, minute };
  }
  // a time of day with no number: sensible defaults
  if (/every morning|each morning/.test(str)) return { kind: "daily", hour: 8, minute: 0 };
  if (/every afternoon/.test(str)) return { kind: "daily", hour: 14, minute: 0 };
  if (/every evening/.test(str)) return { kind: "daily", hour: 18, minute: 0 };
  if (/every night/.test(str)) return { kind: "daily", hour: 21, minute: 0 };
  if (/^daily$|^every\s*day$/.test(str)) return { kind: "daily", hour: 9, minute: 0 };
  return { kind: "invalid" };
}

export function nextFire(s: string, from = new Date()): Date | null {
  const p = parseSchedule(s);
  if (p.kind === "invalid") return null;
  if (p.kind === "every") return new Date(from.getTime() + p.minutes * 60_000);
  const d = new Date(from);
  d.setHours(p.hour, p.minute, 0, 0);
  if (d <= from) d.setDate(d.getDate() + 1);
  return d;
}

export function describeSchedule(s: string): string {
  const p = parseSchedule(s);
  if (p.kind === "every") return p.minutes % 60 === 0 ? `every ${p.minutes / 60} h` : `every ${p.minutes} min`;
  if (p.kind === "daily") return `daily ${String(p.hour).padStart(2, "0")}:${String(p.minute).padStart(2, "0")}`;
  return "invalid schedule";
}
