import { authHeaders, chatUrl } from "./endpoint";
import { db } from "@/lib/db";
import { zaiClient } from "./zai";
import { ProtocolParser } from "@/lib/fotra/protocol";
import type { EmitFn } from "./events";
import { runTool, freshBudget, type ToolBudget } from "./tools";
import { resolveRole, completeRole } from "./providers";

/* ————————————————————————————————————————————————
   FOTRA — sub-agents v2 (the pi/OpenClaw spawn_task
   pattern + oh-my-pi's TYPED RESULTS)
   A worker is a REAL run — its own Run row (linked
   to the parent), its own event log, its own tool
   budget — but focused: a terse system prompt, 3
   steps max, no ask_user, no nesting.
   NEW (omp `task` port): the caller may attach an
   outputSchema — the worker then finishes via a
   hidden `yield` tool whose payload is VALIDATED
   (missing fields → corrective retry, 3 attempts,
   then accept best-effort). The parent reads the
   validated object directly — no prose to parse.
   omp ref: task/{structured-subagent,executor},
   tools/yield.ts, finalizeSubprocessOutput.
   ———————————————————————————————————————————————— */

const WORKER_STEPS = 3;
const MAX_PARALLEL = 3;
const YIELD_RETRIES = 3;


/** a lite JSON schema: field → primitive type, plus required list */
export interface OutputSchema {
  required?: string[];
  properties?: Record<string, "string" | "number" | "boolean" | "object" | "array">;
}

export interface WorkerSpec {
  name: string;
  task: string;
  outputSchema?: OutputSchema;
}

export interface WorkerResult {
  name: string;
  ok: boolean;
  result: string; // the worker's final say (prose fallback)
  structured?: unknown; // the VALIDATED yield payload, if schema was requested
  yieldTried?: boolean;
  tools: string[];
  ms: number;
}

const WORKER_BANNED = new Set(["ask_user", "spawn_task", "mcp_connect"]);

function schemaDoc(schema: OutputSchema): string {
  const fields = Object.entries(schema.properties ?? {});
  const req = new Set(schema.required ?? []);
  return fields.map(([k, t]) => `- "${k}": ${t}${req.has(k) ? " (required)" : ""}`).join("\n");
}

function validateYield(schema: OutputSchema, payload: unknown): { ok: boolean; missing: string[]; badType: string[] } {
  const missing: string[] = [];
  const badType: string[] = [];
  const obj = (payload && typeof payload === "object" ? payload : {}) as Record<string, unknown>;
  for (const f of schema.required ?? []) {
    if (!(f in obj) || obj[f] === null || obj[f] === undefined || obj[f] === "") missing.push(f);
  }
  for (const [f, want] of Object.entries(schema.properties ?? {})) {
    const v = obj[f];
    if (v === undefined || v === null) continue;
    const got = Array.isArray(v) ? "array" : typeof v;
    if (got !== want && !(want === "number" && got === "number")) {
      if (got !== want) badType.push(`${f}: wanted ${want}, got ${got}`);
    }
  }
  return { ok: missing.length === 0 && badType.length === 0, missing, badType };
}

/** Spawn workers in parallel. Each gets its own run + loop; progress is
    emitted into the parent's stream as updated Worker screens. */
export async function spawnWorkers(
  specs: WorkerSpec[],
  parent: {
    sessionId: string;
    parentRunId: string;
    emit: EmitFn;
    brain: "fotra" | "custom" | "provider";
    custom: { baseUrl: string; apiKey: string; model: string; temperature: number };
    signal: AbortSignal;
  }
): Promise<WorkerResult[]> {
  const batch = specs.slice(0, MAX_PARALLEL);
  const results = await Promise.all(batch.map((s) => runWorker(s, parent)));
  return results;
}

async function runWorker(
  spec: WorkerSpec,
  parent: Parameters<typeof spawnWorkers>[1]
): Promise<WorkerResult> {
  const t0 = Date.now();
  const name = spec.name || "worker";
  const runId = `w-${parent.parentRunId}-${name.toLowerCase().replace(/[^a-z0-9]+/g, "")}-${Date.now().toString(36)}`;
  // the worker is one step in the parent's trail — it shows what it is doing, then what it found
  const stepId = `worker-${parent.parentRunId}-${name.toLowerCase().replace(/[^a-z0-9]+/g, "")}`;
  const log: string[] = [];
  const progress = async (phase: "working" | "done" | "error", note: string) => {
    if (phase === "working" && note) log.push(note);
    await parent.emit({
      type: "step",
      step: {
        id: stepId,
        tool: "spawn_task",
        kind: "worker",
        title: name,
        subject: spec.task.slice(0, 140),
        status: phase === "working" ? "running" : phase,
        summary: note.slice(0, 140),
        ...(phase === "working" ? {} : { ms: Date.now() - t0 }),
        data: { name, task: spec.task.slice(0, 240), phase, note: note.slice(0, 200), log: log.slice(-6) },
      },
    });
  };
  await db.run.create({
    data: { id: runId, sessionId: parent.sessionId, status: "running", brain: parent.brain, parentRunId: parent.parentRunId, workerName: name, origin: "worker" },
  }).catch(() => undefined);
  await progress("working", "");
  await parent.emit({ type: "status", line: `${name} is on it…` });

  const budget: ToolBudget = freshBudget();
  const used: string[] = [];
  let result = "";
  let structured: unknown;
  let yieldTried = false;
  try {
    const schemaBlock = spec.outputSchema
      ? `\nSTRUCTURED OUTPUT — required. When the task is complete (or you've done all you can), your FINAL reply must include this tool call with real values:
{"type":"tool","name":"yield","args":{${Object.keys(spec.outputSchema.properties ?? {})
          .map((f) => `"${f}": <${spec.outputSchema.properties?.[f]}>`)
          .join(", ")}}}
Fields:
${schemaDoc(spec.outputSchema)}
The parent reads this object directly — fill every field with the actual findings, no placeholders.`
      : "";

    const system = `You are ${name}, a focused worker agent spawned by fotra to do ONE task and report back.

TASK: ${spec.task}
${schemaBlock}
Rules:
- Complete the task autonomously. Use tools when they genuinely help (search, code, files, memory).
- You cannot ask the human questions. You cannot spawn workers. Make reasonable assumptions and note them.
${spec.outputSchema ? "- Your final say line should be ONE short sentence; the real deliverable is the yield call's fields." : "- Your FINAL say is the entire deliverable the parent sees — no greeting, no padding, just the result, complete and tight."}
- If you can't finish, say exactly what you got and what's missing${spec.outputSchema ? " (still emit the yield call with whatever you have)" : ""}.`;

    const messages: { role: "system" | "user" | "assistant"; content: string }[] = [
      { role: "system", content: system },
      { role: "user", content: `Do the task: ${spec.task}` },
    ];

    let yieldAttempts = 0;
    for (let step = 0; step < WORKER_STEPS; step++) {
      if (parent.signal.aborted) throw new Error("aborted");
      const raw = await completeBrain(parent.brain, parent.custom, messages);
      const parser = new ProtocolParser();
      let say = "";
      const tools: { name: string; args: Record<string, unknown> }[] = [];
      for (const chunk of raw.match(/[\s\S]{1,64}/g) ?? []) {
        const { sayDelta, newActions } = parser.feed(chunk);
        if (sayDelta) say += sayDelta;
        for (const a of newActions) {
          if (a && typeof a === "object" && (a as Record<string, unknown>).type === "tool") {
            const o = a as { name?: unknown; args?: unknown };
            if (typeof o.name === "string" && !WORKER_BANNED.has(o.name)) {
              tools.push({ name: o.name, args: (o.args && typeof o.args === "object" ? o.args : {}) as Record<string, unknown> });
            }
          }
        }
      }
      const fin = parser.finish();
      if (fin.say && !say) say = fin.say;

      // the hidden yield tool — typed results, the omp task contract
      const yieldCall = tools.find((t) => t.name === "yield");
      if (yieldCall && spec.outputSchema) {
        yieldTried = true;
        yieldAttempts++;
        const v = validateYield(spec.outputSchema, yieldCall.args);
        if (v.ok) {
          structured = yieldCall.args;
          result = say || "(yielded structured result)";
          break;
        }
        if (yieldAttempts >= YIELD_RETRIES) {
          // omp behavior: 3 strikes → accept best-effort, flag what's missing
          structured = yieldCall.args;
          result = `${say || ""} [yield accepted best-effort — missing: ${v.missing.join(", ") || "none"}; type issues: ${v.badType.join("; ") || "none"}]`.trim();
          break;
        }
        messages.push({ role: "assistant", content: raw.slice(0, 3000) });
        messages.push({
          role: "user",
          content: `[harness] Your yield call is INVALID — missing required fields: ${v.missing.join(", ") || "none"}; type problems: ${v.badType.join("; ") || "none"}. Re-emit the yield tool call with every field filled with real values.`,
        });
        await progress("working", `result was incomplete (attempt ${yieldAttempts}) — asking again`);
        continue;
      }

      const exec = tools.filter((t) => t.name !== "yield");
      if (exec.length === 0) {
        result = say || raw;
        break;
      }
      messages.push({ role: "assistant", content: raw.slice(0, 3000) });
      let anyOk = false;
      for (const call of exec.slice(0, 3)) {
        const res = await runTool(call.name, call.args, {
          sessionId: parent.sessionId,
          runId,
          signal: parent.signal,
          emit: parent.emit,
          persona: { name, tone: "worker" },
          brain: parent.brain,
          custom: parent.custom,
        });
        used.push(call.name);
        if (res.ok) anyOk = true;
        messages.push({ role: "user", content: `TOOL RESULT for ${call.name} (${res.ok ? "ok" : "failed"}):\n${JSON.stringify(res.data).slice(0, 6000)}` });
        await progress("working", res.summary.slice(0, 80));
      }
      if (step === WORKER_STEPS - 1) result = say || "(worker ran out of steps)";
      if (!anyOk && !say) result = "the worker hit tool failures — partial results only";
    }
    if (!result) result = "(worker returned nothing)";
    if (spec.outputSchema && !structured) {
      result = `${result}\n[note: the worker never emitted a valid yield — the prose above is all the parent got]`;
    }
    await db.run.update({ where: { id: runId }, data: { status: "done", endedAt: new Date(), steps: used.length } }).catch(() => undefined);
    await progress("done", result.replace(/\s+/g, " ").slice(0, 140));
    return { name, ok: true, result: result.slice(0, 4000), structured, yieldTried, tools: used, ms: Date.now() - t0 };
  } catch (err) {
    const msg = err instanceof Error ? err.message : "worker failed";
    await db.run.update({ where: { id: runId }, data: { status: "error", error: msg.slice(0, 300), endedAt: new Date() } }).catch(() => undefined);
    await progress("error", msg.slice(0, 110));
    return { name, ok: false, result: `(worker failed: ${msg})`, tools: used, ms: Date.now() - t0 };
  }
}

async function completeBrain(
  brain: "fotra" | "custom" | "provider",
  custom: { baseUrl: string; apiKey: string; model: string; temperature: number },
  messages: { role: string; content: string }[]
): Promise<string> {
  if (brain === "fotra") {
    const res = await Promise.race([
      (await zaiClient()).chat.completions.create({ messages: messages as never, thinking: { type: "disabled" } }),
      new Promise<never>((_, rej) => setTimeout(() => rej(new Error("worker brain timeout")), 90_000)),
    ]);
    return res.choices[0]?.message?.content ?? "";
  }
  if (brain === "provider") {
    // the smol role: cheap fan-out (omp resolves subagents to `smol`)
    const role = resolveRole("small") ?? resolveRole("chat");
    if (!role) throw new Error("no provider role");
    return completeRole(role, messages as never);
  }
  // BYO — non-streaming is fine for workers (they don't surface live deltas)
  const url = chatUrl(custom.baseUrl);
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...authHeaders(custom.baseUrl, custom.apiKey) },
    body: JSON.stringify({ model: custom.model, messages, temperature: custom.temperature ?? 0.6, stream: false }),
    signal: AbortSignal.timeout(90_000),
  });
  if (!res.ok) throw new Error(`BYO ${res.status}`);
  const j = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  return j.choices?.[0]?.message?.content ?? "";
}
