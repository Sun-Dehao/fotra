import { db } from "@/lib/db";
import { zaiClient } from "./zai";
import { vaultDaily } from "./vault";
import { resolveRole, completeRole } from "./providers";
import { HANDOFF_PROMPT } from "./compaction";

/* ————————————————————————————————————————————————
   FOTRA — background jobs
   In-process queue with leases claimed by compare-and-set
   on SQLite rows (the openmuse pattern, zero infra).
   Nap compression never blocks the next reply; the daily
   memory consolidation runs at most once per day. Progress
   lands in the thread as quiet system lines — never toasts.
   ———————————————————————————————————————————————— */

const LEASE_MS = 90_000;
const TICK_MS = 15_000;

interface JobRow {
  id: string;
  kind: string;
  payload: string;
}

const g = globalThis as unknown as { fotraWorker?: boolean; fotraDailyAt?: number };

/** claim: pending rows, or running rows whose lease expired — CAS via updateMany */
async function claimJob(): Promise<JobRow | null> {
  const staleBefore = new Date(Date.now() - LEASE_MS);
  const candidates = await db.job.findMany({
    where: {
      OR: [
        { status: "pending" },
        { status: "running", leaseUntil: { lt: staleBefore } },
      ],
    },
    orderBy: { createdAt: "asc" },
    take: 1,
  });
  const job = candidates[0];
  if (!job) return null;

  const res = await db.job.updateMany({
    where: {
      id: job.id,
      OR: [
        { status: "pending" },
        { status: "running", leaseUntil: { lt: staleBefore } },
      ],
    },
    data: { status: "running", leaseUntil: new Date(Date.now() + LEASE_MS), attempts: { increment: 1 }, updatedAt: new Date() },
  });
  if (res.count === 0) return null; // another worker won the race
  return { id: job.id, kind: job.kind, payload: job.payload };
}

async function finishJob(id: string, ok: boolean, error?: string): Promise<void> {
  await db.job.update({
    where: { id },
    data: { status: ok ? "done" : "error", error: error?.slice(0, 500), leaseUntil: null, doneAt: new Date(), updatedAt: new Date() },
  }).catch(() => undefined);
}

async function heartbeat(id: string): Promise<ReturnType<typeof setInterval>> {
  return setInterval(() => {
    void db.job.update({
      where: { id, status: "running" },
      data: { leaseUntil: new Date(Date.now() + LEASE_MS) },
    }).catch(() => undefined);
  }, LEASE_MS / 3);
}

/* —— the jobs —— */

/** nap compression: fold old turns into the rolling session summary (OptMem).
    Runs as a job so the next reply is never blocked; last-good summary serves meanwhile.
    v5: the prompt is omp's structured handoff format (steal, not remake — their
    compaction-summary.md, battle-tested at 88% benchmark pass) capped for the 1500-char column. */
async function runCompact(payload: { sessionId: string; brain: string; custom?: unknown }): Promise<string> {
  const session = await db.session.findUnique({
    where: { id: payload.sessionId },
    include: { turns: { orderBy: { ts: "asc" } } },
  });
  if (!session) return "session gone";
  if (session.turns.length <= 26) return "nothing to compact";

  const keep = 20;
  const old = session.turns.slice(0, session.turns.length - keep);
  if (old.length === 0) return "nothing to compact";
  const upTo = old[old.length - 1].id;
  if (session.summaryUpTo === upTo) return "summary already fresh";

  const transcript = old
    .map((t) => `${t.role === "user" ? "user" : "fotra"}: ${t.text.slice(0, 500)}`)
    .join("\n")
    .slice(-16000);

  const prompt = [
    { role: "system" as const, content: HANDOFF_PROMPT + "\nKeep the whole summary under 250 words — it replaces the older turns in the next prompt." },
    { role: "user" as const, content: transcript },
  ];

  let summary = "";
  try {
    if (payload.brain === "provider") {
      const small = resolveRole("small");
      summary = small ? await completeRole(small, prompt) : "";
    }
    if (!summary) {
      const zai = await zaiClient();
      summary = (await zai.chat.completions.create({ messages: prompt as never, thinking: { type: "disabled" } })).choices[0]?.message?.content ?? "";
    }
  } catch {
    return "compaction model call failed — will retry on the next turn";
  }

  if (!summary.trim()) return "empty summary — skipped";
  await db.session.update({
    where: { id: payload.sessionId },
    data: { summary: summary.slice(0, 1500), summaryUpTo: upTo },
  });
  return `memory consolidated · ${old.length} older turns folded`;
}

/** daily job: organize the memory vault (Instinct tier) — at most once per 24h. */
async function runDaily(): Promise<string> {
  if (g.fotraDailyAt && Date.now() - g.fotraDailyAt < 24 * 3600_000) return "daily already ran";
  g.fotraDailyAt = Date.now();

  const sessions = await db.session.findMany({ include: { memories: true } });
  const busy = sessions.filter((s) => s.memories.length >= 12);
  if (busy.length === 0) return "vault too small to consolidate";

  // one model pass: group + generalize the freshest notes per session
  let moved = 0;
  for (const s of busy.slice(0, 3)) {
    const facts = s.memories.slice(0, 40).map((m) => ({ fact: m.fact, topic: m.topic }));
    try {
      const zai = await zaiClient();
      const res = await zai.chat.completions.create({
        messages: [
          { role: "system", content: "You organize memory notes. Given notes (fact + topic), return ONLY a JSON object mapping topic -> array of merged/generalized facts (max 3 per topic, dated corrections merged, one-time details dropped). No prose." },
          { role: "user", content: JSON.stringify(facts) },
        ] as never,
        thinking: { type: "disabled" },
      });
      const raw = res.choices[0]?.message?.content ?? "{}";
      const start = raw.indexOf("{");
      const plan = JSON.parse(raw.slice(start === -1 ? 0 : start)) as Record<string, string[]>;
      const r = await vaultDaily(async () => plan);
      moved += r.moved;
    } catch {
      /* this session's consolidation failed — others still run */
    }
  }
  return moved > 0 ? `vault consolidated · ${moved} notes organized` : "vault needed nothing";
}

/* —— progress surfaces as a quiet system line in the thread —— */
async function systemLine(sessionId: string | undefined, text: string): Promise<void> {
  if (!sessionId) return;
  await db.turn.create({
    data: { id: `sys-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`, sessionId, role: "assistant", text, origin: "system" },
  }).catch(() => undefined);
}

/* —— the worker loop —— */
export function startWorkers(): void {
  if (g.fotraWorker) return;
  g.fotraWorker = true;

  // zombie-run reaper (crashed server, hung model call): 15 min hard stop
  void reaper();
  setInterval(() => { void reaper(); }, 5 * 60_000).unref?.();

  setInterval(() => {
    void (async () => {
      const job = await claimJob();
      if (!job) return;
      const hb = await heartbeat(job.id);
      try {
        let line = "";
        let sessionId: string | undefined;
        if (job.kind === "compact") {
          const p = JSON.parse(job.payload) as { sessionId: string; brain: string; custom?: unknown };
          sessionId = p.sessionId;
          line = await runCompact(p);
        } else if (job.kind === "daily") {
          line = await runDaily();
        } else {
          line = `unknown job kind: ${job.kind}`;
        }
        await finishJob(job.id, true);
        if (line.startsWith("memory consolidated") || line.startsWith("vault consolidated")) {
          await systemLine(sessionId, line);
        }
      } catch (err) {
        await finishJob(job.id, false, err instanceof Error ? err.message : "job error");
      } finally {
        clearInterval(hb);
      }
    })();
  }, TICK_MS).unref?.();

  // daily cadence: enqueue once per 24h when the server is alive
  setInterval(() => {
    void db.job.findFirst({ where: { kind: "daily", createdAt: { gt: new Date(Date.now() - 24 * 3600_000) } } })
      .then((recent) => {
        if (!recent) return db.job.create({ data: { kind: "daily", payload: "{}", status: "pending" } });
        return null;
      })
      .catch(() => undefined);
  }, 60 * 60_000).unref?.();
}

async function reaper(): Promise<void> {
  await db.run.updateMany({
    where: { status: "running", startedAt: { lt: new Date(Date.now() - 15 * 60_000) } },
    data: { status: "error", error: "watchdog: run exceeded 15 minutes", endedAt: new Date() },
  }).catch(() => undefined);
}

/** enqueue nap compression — fire and forget, never blocks the reply */
export function enqueueCompact(sessionId: string, brain: string): void {
  void (async () => {
    const pending = await db.job.findFirst({
      where: { kind: "compact", status: { in: ["pending", "running"] }, payload: { contains: sessionId } },
    });
    if (pending) return;
    await db.job.create({
      data: { kind: "compact", payload: JSON.stringify({ sessionId, brain }), status: "pending" },
    }).catch(() => undefined);
  })();
}
