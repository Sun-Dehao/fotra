import { zaiClient } from "./zai";
import { resolveRole, completeRole } from "./providers";
import type { EmitFn } from "./events";

/* ————————————————————————————————————————————————
   FOTRA — the advisor (the oh-my-pi port)
   A second model reads every turn the main agent
   takes and injects a note inline — a quiet aside, a
   concern, or a hard blocker. It runs on its own
   context, so it catches what the doer rushed past.
   The main agent sees the note and course-corrects,
   or tells the user why it won't.
   omp refs: src/advisor/{runtime,advise-tool,
   emission-guard}.ts — simplified: fotra's advisor
   reviews each completed step (not mid-stream), at
   most ADVISOR_MAX per run, never blocking the main
   reply's latency (it runs after the step's tools).
   ———————————————————————————————————————————————— */

const ADVISOR_MAX_PER_RUN = 2;
const ADVISOR_TOKEN_BUDGET = 700;


export interface AdvisorNote {
  kind: "aside" | "concern" | "blocker";
  note: string;
}

/** review one step: user ask + the model's reply + tool results → a note (or none) */
export async function adviseStep(input: {
  userText: string;
  reply: string;
  toolLines: string[]; // "web_search(ok): searched: …"
  brain: "fotra" | "custom" | "provider";
}): Promise<AdvisorNote | null> {
  const sys = `You are fotra's advisor — a second, skeptical model that reviews the main agent's work from the outside. Read the step and answer with EXACTLY one JSON object, no prose:

{"kind":"none"}
  — the work is fine; say nothing
{"kind":"aside","note":"one tight sentence"}
  — a small improvement or context the agent missed
{"kind":"concern","note":"one tight sentence"}
  — something plausibly wrong or incomplete that the agent should double-check
{"kind":"blocker","note":"one tight sentence"}
  — the reply is factually wrong, ignored the user's actual question, or claims work that did not happen

Rules: judge only what's shown. "none" is the most common answer. Never invent facts. The note is shown to the agent AND the user — make it specific, not generic.`;

  const user = `USER ASKED: ${input.userText.slice(0, 800)}

AGENT'S STEP (reply + tools):
${input.reply.slice(0, 1200) || "(no spoken reply yet)"}
${input.toolLines.length ? input.toolLines.slice(0, 8).map((l) => `- ${l}`).join("\n") : "(no tools this step)"}`;

  try {
    let raw = "";
    if (input.brain === "provider") {
      const role = resolveRole("chat");
      if (role) raw = await completeRole(role, [{ role: "system", content: sys }, { role: "user", content: user }]);
    }
    if (!raw.trim()) {
      const res = await Promise.race([
        (await zaiClient()).chat.completions.create({
          messages: [
            { role: "system", content: sys },
            { role: "user", content: user },
          ] as never,
          thinking: { type: "disabled" },
        }),
        new Promise<never>((_, rej) => setTimeout(() => rej(new Error("advisor timeout")), 20_000)),
      ]);
      raw = res.choices[0]?.message?.content ?? "";
    }
    // extract JSON from the reply (models sometimes wrap it)
    const m = raw.match(/\{[\s\S]*\}/);
    if (!m) return null;
    const j = JSON.parse(m[0]) as { kind?: string; note?: string };
    if (j.kind === "aside" || j.kind === "concern" || j.kind === "blocker") {
      const note = String(j.note ?? "").trim().slice(0, 300);
      if (note) return { kind: j.kind, note };
    }
    return null;
  } catch {
    return null; // the advisor never breaks the run
  }
}

export function advisorBudget(): number {
  return ADVISOR_MAX_PER_RUN;
}

export function advisorTokenBudget(): number {
  return ADVISOR_TOKEN_BUDGET;
}

/** emit + return the injection text for the next model call */
export async function deliverNote(note: AdvisorNote, emit: EmitFn): Promise<string> {
  await emit({ type: "advisor", kind: note.kind, note: note.note });
  const tag = note.kind === "blocker" ? "BLOCKER" : note.kind === "concern" ? "CONCERN" : "aside";
  return `[advisor — a second model reviewed your last step: ${tag}] ${note.note}${note.kind === "blocker" ? " — fix this in your next reply before finishing." : ""}`;
}
