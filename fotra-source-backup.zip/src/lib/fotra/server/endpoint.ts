/* ————————————————————————————————————————————————
   endpoint — one place that knows how to talk to an
   openai-compatible host: where its routes live, which
   headers it wants, and what a failure actually means.
   Every request leaves from THIS machine (there is no
   cloud server in between), so "is this provider served
   where I am" is a question about this network — and
   one we can answer by asking.
   ———————————————————————————————————————————————— */

/** the API root: ".../v1", ".../v1beta/openai", ".../openai/v1" — never the chat route itself */
export function apiRoot(base: string): string {
  let u = base.trim().replace(/\s+/g, "");
  if (!u) return "";
  if (!/^https?:\/\//i.test(u)) u = `https://${u}`;
  u = u.replace(/\/*$/, "").replace(/\/chat\/completions$/, "");
  if (/\/(v\d+\w*|openai)$/.test(u)) return u;
  return `${u}/v1`;
}

export function chatUrl(base: string): string {
  const root = apiRoot(base);
  return root ? `${root}/chat/completions` : "";
}

export function modelsUrl(base: string): string {
  const root = apiRoot(base);
  return root ? `${root}/models` : "";
}

export function authHeaders(base: string, apiKey?: string): Record<string, string> {
  const h: Record<string, string> = {};
  const key = apiKey?.trim();
  if (key) h.Authorization = `Bearer ${key}`;
  // Anthropic's native routes (model listing) want their own header pair; the compat chat route takes Bearer
  if (/(^|\.)anthropic\.com/i.test(hostOf(base))) {
    if (key) h["x-api-key"] = key;
    h["anthropic-version"] = "2023-06-01";
  }
  return h;
}

export function hostOf(base: string): string {
  try {
    return new URL(apiRoot(base)).host;
  } catch {
    return "";
  }
}

export function isLocalHost(base: string): boolean {
  return /^(localhost|127\.0\.0\.1|\[::1\]|0\.0\.0\.0|.*\.local)(:\d+)?$/i.test(hostOf(base));
}

export type FailKind = "region" | "key" | "model" | "quota" | "network" | "local-down" | "other";

export interface Failure {
  kind: FailKind;
  /** one plain sentence: what is wrong */
  message: string;
  /** one plain sentence: what to do about it */
  hint: string;
  /** the provider's own words, clipped */
  raw: string;
}

const REGION_RE = /unsupported_country|country, region, or territory|not (?:available|supported) in your (?:country|region)|user location is not supported|region.{0,24}not supported|request not allowed|geo.?(?:block|restrict)|sanction/i;

async function bodyText(res: Response): Promise<string> {
  try {
    const text = await res.text();
    try {
      const j = JSON.parse(text) as { error?: { message?: string; code?: string } | string; message?: string };
      if (typeof j.error === "string") return j.error;
      if (j.error?.message) return j.error.code ? `${j.error.message} (${j.error.code})` : j.error.message;
      if (j.message) return j.message;
    } catch {
      /* not json */
    }
    return text.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 300);
  } catch {
    return "";
  }
}

/** turn a non-OK response into something a person can act on */
export async function explainResponse(res: Response, base: string, opts: { hadKey: boolean }): Promise<Failure> {
  const raw = (await bodyText(res)) || `${res.status} ${res.statusText}`;
  const host = hostOf(base);
  const s = res.status;
  if (REGION_RE.test(raw) || (s === 403 && !opts.hadKey) || s === 451) {
    return {
      kind: "region",
      message: `${host} is refusing requests from this network's location.`,
      hint: "This provider doesn't serve where this computer's traffic comes out. Pick one marked reachable (OpenRouter carries most models and serves most regions), or turn on a VPN / system proxy and restart the app so it picks the proxy up.",
      raw,
    };
  }
  if (s === 401 || (s === 403 && opts.hadKey) || /invalid.{0,12}api.?key|incorrect api key|valid api key|api key not valid|authentication/i.test(raw)) {
    return {
      kind: "key",
      message: opts.hadKey ? `${host} rejected that key.` : `${host} needs an API key.`,
      hint: opts.hadKey ? "Check it was copied whole, belongs to this provider, and hasn't been revoked." : "Paste the key from the provider's dashboard.",
      raw,
    };
  }
  if (s === 404 || /model.{0,40}(not found|does not exist|not exist|unknown|invalid)|no such model/i.test(raw)) {
    return { kind: "model", message: "The provider doesn't know that model name.", hint: "Pick one from the model list — it is read live from your account.", raw };
  }
  if (s === 402 || s === 429 || /quota|billing|credit|insufficient|rate limit/i.test(raw)) {
    return { kind: "quota", message: "The key works, but the account is out of credit or rate-limited.", hint: "Add credit on the provider's billing page, or wait a minute and retry.", raw };
  }
  return { kind: "other", message: `${host} answered ${s}.`, hint: "The provider's own message is below.", raw };
}

/** turn a thrown fetch error (DNS, refused, timeout, TLS) into something a person can act on */
export function explainThrown(err: unknown, base: string): Failure {
  const host = hostOf(base) || base;
  const e = err as { name?: string; message?: string; cause?: { code?: string; message?: string } } | null;
  const code = e?.cause?.code ?? "";
  const raw = [e?.message, code, e?.cause?.message].filter(Boolean).join(" · ").slice(0, 300);
  if (isLocalHost(base)) {
    return {
      kind: "local-down",
      message: `Nothing is listening at ${host}.`,
      hint: "Start the local model server (Ollama, LM Studio…) and make sure a model is loaded, then try again.",
      raw,
    };
  }
  const timedOut = e?.name === "TimeoutError" || e?.name === "AbortError" || /timeout|UND_ERR_CONNECT_TIMEOUT|ETIMEDOUT/i.test(raw);
  return {
    kind: "network",
    message: timedOut ? `${host} didn't answer from this network.` : `Couldn't reach ${host} from this network.`,
    hint: "Either the address is wrong, you're offline, or this network blocks the provider (common where it isn't served). Try one marked reachable, or use a VPN / system proxy and restart the app.",
    raw,
  };
}

/** the proxy this server process is sending outbound requests through, if any */
export function activeProxy(): string | null {
  if (process.env.NODE_USE_ENV_PROXY !== "1") return null;
  return process.env.HTTPS_PROXY || process.env.https_proxy || process.env.HTTP_PROXY || process.env.http_proxy || null;
}

export interface Reach {
  url: string;
  host: string;
  /** ok = answers here · blocked = refuses this location · down = no answer */
  state: "ok" | "blocked" | "down";
  ms: number;
  note: string;
}

/** ask a provider's public door whether it will talk to this network — no key involved */
export async function probe(base: string): Promise<Reach> {
  const url = modelsUrl(base);
  const host = hostOf(base);
  const t0 = Date.now();
  try {
    const res = await fetch(url, { method: "GET", headers: { Accept: "application/json", ...authHeaders(base) }, cache: "no-store", signal: AbortSignal.timeout(7000) });
    const ms = Date.now() - t0;
    // 401/400/404/200 all mean the door opened; only a location refusal counts as blocked
    if (res.ok || [400, 401, 404, 405, 429].includes(res.status)) {
      await res.body?.cancel().catch(() => undefined);
      return { url: base, host, state: "ok", ms, note: `answers from here · ${ms}ms` };
    }
    const f = await explainResponse(res, base, { hadKey: false });
    if (f.kind === "region") return { url: base, host, state: "blocked", ms, note: "refuses this network's location" };
    return { url: base, host, state: "ok", ms, note: `answers from here · ${ms}ms` };
  } catch (err) {
    const f = explainThrown(err, base);
    return { url: base, host, state: "down", ms: Date.now() - t0, note: f.kind === "local-down" ? "not running on this machine" : "no answer from this network" };
  }
}
