import type { BrowserFrame, FotraAction, Persona, StepPatch, ThemeMode, UiPrefs } from "@/lib/fotra/types";

/* ————————————————————————————————————————————————
   FOTRA — the wire vocabulary (shared by engine,
   tools and routes; no import cycles)
   One event stream per run: persisted (the log is
   the truth) and fanned to live subscribers.
   ———————————————————————————————————————————————— */

export type ServerEvent =
  | { type: "session"; sessionId: string; runId: string; assistantTurnId: string; seq?: number }
  | { type: "say"; text: string; seq?: number }
  | { type: "say_reset"; seq?: number } // the model is re-speaking after a corrective nudge — clear the partial turn text
  | { type: "status"; line: string; seq?: number }
  | { type: "tool"; name: string; summary: string; ok: boolean; ms?: number; seq?: number }
  // a tool call as the user watches it: opened when the call starts, patched while it runs, settled when it lands
  | { type: "step"; step: StepPatch; seq?: number }
  // one frame of computer use — the screenshot, where the cursor is heading, what it is doing
  | { type: "frame"; stepId: string; frame: Omit<BrowserFrame, "ts">; seq?: number }
  | { type: "action"; action: FotraAction; seq?: number }
  | { type: "latency"; ms: number; seq?: number }
  | { type: "ttsr"; rule: string; matched: string; seq?: number } // a stream rule cut the model mid-token — the retry is already scheduled
  | { type: "advisor"; kind: "aside" | "concern" | "blocker"; note: string; seq?: number } // the second model's inline note
  | { type: "rewind"; toCheckpoint: string; kept: number; dropped: number; seq?: number } // context collapsed to a checkpoint + report
  | { type: "checkpoint"; label: string; seq?: number }
  | { type: "waiting"; reason: "ask" | "budget"; seq?: number }
  | { type: "unsteered"; texts: string[]; seq?: number } // steering that never drained — the client restores them to its queue
  | { type: "done"; interrupted?: boolean; usedTools?: string[]; seq?: number }
  | { type: "error"; message: string; hint?: string; seq?: number };

/** progress emitter handed to tools — anything a tool wants to show the
     user mid-flight (screenshots, worker phases) streams into the run. */
export type EmitFn = (ev: ServerEvent) => Promise<void>;

/** everything a tool executor may need about its run */
export interface ToolCtx {
  sessionId: string;
  runId: string;
  signal: AbortSignal;
  emit: EmitFn;
  /** fan an event to whoever is watching right now WITHOUT writing it to the log —
      for the in-between frames of computer use, which are motion, not record */
  emitLive?: EmitFn;
  /** the id of the step this call is rendering into (set by the engine per call) */
  stepId?: string;
  /** how the agent looks and is laid out right now — what a self-edit diffs against */
  self?: { persona: Persona; ui: UiPrefs; mode: ThemeMode };
  persona: { name: string; tone: string };
  brain: "fotra" | "custom" | "provider";
  custom: { baseUrl: string; apiKey: string; model: string; temperature: number };
}
