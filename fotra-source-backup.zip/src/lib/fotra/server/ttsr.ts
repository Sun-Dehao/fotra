import { db } from "@/lib/db";

/* ————————————————————————————————————————————————
   FOTRA — TTSR (time-traveling stream rules)
   The oh-my-pi port: rules sit DORMANT until the
   model's live output goes off-script. A match cuts
   the stream mid-token, the rule is injected as a
   system reminder, and the model regenerates from
   the same point. Course-correction without paying
   context tax on every turn.
   omp refs: TtsrManager (coding-agent/src/export/ttsr.ts),
   TtsrCoordinator (session/ttsr-coordinator.ts) —
   simplified for fotra's scale: line-local tail
   matching (last ~600 chars) is O(delta), no static
   regex trait analysis needed.
   ———————————————————————————————————————————————— */

export interface StreamRuleRow {
  id: string;
  name: string;
  pattern: string;
  reminder: string;
  enabled: boolean;
  hits: number;
}

export interface CompiledRule {
  row: StreamRuleRow;
  re: RegExp;
}

/** seed rules — the anti-slop canon (installed once, user-editable after) */
const SEED_RULES: Array<Pick<StreamRuleRow, "name" | "pattern" | "reminder">> = [
  {
    name: "no-ai-disclaimers",
    pattern: "As an AI|I'm just an AI language model|I don't have (?:personal|actual) (?:feelings|opinions|beliefs)",
    reminder:
      "You are fotra — a real assistant with tools and a workspace, not a disembodied language model. Never disclaim being an AI. If you can't do something, say what you CAN do instead and use a tool if one fits.",
  },
  {
    name: "no-placeholders",
    pattern: "TODO:|FIXME:|lorem ipsum|\\[insert |\\[placeholder|\\bX{3,}\\b|insert (?:your|the) \\w+ here",
    reminder:
      "Never ship placeholders, TODO markers, or template stubs. Produce the real content — write the actual file, run the actual code, search for the actual fact. If you genuinely lack the data, use a tool to get it.",
  },
  {
    name: "no-destruction",
    pattern: "rm -rf /|sudo rm|mkfs|dd if=.*of=/dev/(?:sd|nvme|disk)|:\\(\\):\\{ :\\|:& \\};:",
    reminder:
      "That command would destroy the user's machine. Refuse it and offer the safe alternative (targeted paths, a dry-run, or a workspace-local copy of the operation).",
  },
  {
    name: "no-fake-tool-results",
    pattern: "(?:here(?:'s| is) what (?:i|the) (?:search|found)|the search returned)[: ][^\"{]*$",
    reminder:
      "Never narrate imaginary tool results. If you want to claim a search/read/computation, actually emit the tool call and wait for the real result. Show, then tell.",
  },
];

let seeded = false;

/** load + compile the enabled rules (cached per-process with a 5s TTL — cheap) */
let cache: { at: number; rules: CompiledRule[] } | null = null;

export async function loadRules(): Promise<CompiledRule[]> {
  if (!seeded) {
    seeded = true;
    const count = await db.streamRule.count().catch(() => 0);
    if (count === 0) {
      for (const r of SEED_RULES) {
        await db.streamRule.create({ data: { ...r, enabled: true } }).catch(() => undefined);
      }
    }
  }
  if (cache && Date.now() - cache.at < 5000) return cache.rules;
  const rows = (await db.streamRule.findMany({ where: { enabled: true } }).catch(() => [])) as unknown as StreamRuleRow[];
  const rules: CompiledRule[] = [];
  for (const row of rows) {
    try {
      // 'g' not needed — we run fresh lastIndex-free exec per window
      rules.push({ row, re: new RegExp(row.pattern, "i") });
    } catch {
      /* user wrote a broken regex — skip it, never crash the run */
    }
  }
  cache = { at: Date.now(), rules };
  return rules;
}

export function dropRuleCache(): void {
  cache = null;
}

/** the TTSR signal — thrown from the stream watcher, caught by the engine loop */
export class TtsrCut extends Error {
  rule: CompiledRule;
  matched: string;
  constructor(rule: CompiledRule, matched: string) {
    super(`stream rule "${rule.row.name}" matched`);
    this.rule = rule;
    this.matched = matched;
  }
}

/** the stream watcher: fed every delta from the live model, matches rules
    against a line-local tail window. SYNCHRONOUS per-delta matching — a throw
    from inside the provider's onChunk aborts the stream mid-token (BYO) or
    the handoff (SDK), before anything is emitted. Rules are pre-loaded by
    the engine per step (cache makes this ~free). */
export class StreamWatcher {
  private buf = "";
  private static WINDOW = 600; // tail chars examined per delta — omp's line-local scope, widened
  private static MAX_BUF = 4000;

  /** feed a delta + check against pre-compiled rules — throws TtsrCut on the first hit */
  feedAndCheck(delta: string, rules: CompiledRule[]): void {
    if (!delta || rules.length === 0) return;
    this.buf += delta;
    if (this.buf.length > StreamWatcher.MAX_BUF) {
      this.buf = this.buf.slice(-StreamWatcher.MAX_BUF);
    }
    if (this.buf.length < 8) return;
    const tail = this.buf.slice(-StreamWatcher.WINDOW);
    for (const rule of rules) {
      const m = rule.re.exec(tail);
      if (m && m[0]) {
        // count the hit async — never block the cut
        void db.streamRule
          .update({ where: { id: rule.row.id }, data: { hits: { increment: 1 }, updatedAt: new Date() } })
          .then(() => {
            cache = null;
          })
          .catch(() => undefined);
        throw new TtsrCut(rule, m[0]);
      }
    }
  }

  text(): string {
    return this.buf;
  }
}

/** CRUD for /api/rules */
export async function listRules(): Promise<StreamRuleRow[]> {
  await loadRules(); // seeds on first use
  return (await db.streamRule.findMany({ orderBy: { createdAt: "asc" } })) as unknown as StreamRuleRow[];
}

export async function createRule(name: string, pattern: string, reminder: string): Promise<{ ok: boolean; error?: string; rule?: StreamRuleRow }> {
  if (!name.trim() || !pattern.trim() || !reminder.trim()) return { ok: false, error: "name, pattern and reminder are all required" };
  try {
    new RegExp(pattern, "i");
  } catch (err) {
    return { ok: false, error: `bad regex: ${err instanceof Error ? err.message : "compile error"}` };
  }
  const rule = (await db.streamRule.create({ data: { name: name.trim().slice(0, 60), pattern, reminder: reminder.slice(0, 800), enabled: true } })) as unknown as StreamRuleRow;
  dropRuleCache();
  return { ok: true, rule };
}

export async function updateRule(
  id: string,
  patch: { name?: string; pattern?: string; reminder?: string; enabled?: boolean }
): Promise<{ ok: boolean; error?: string }> {
  if (patch.pattern !== undefined) {
    try {
      new RegExp(patch.pattern, "i");
    } catch (err) {
      return { ok: false, error: `bad regex: ${err instanceof Error ? err.message : "compile error"}` };
    }
  }
  const r = await db.streamRule.update({ where: { id }, data: patch }).catch(() => null);
  if (!r) return { ok: false, error: "rule not found" };
  dropRuleCache();
  return { ok: true };
}

export async function deleteRule(id: string): Promise<boolean> {
  const r = await db.streamRule.delete({ where: { id } }).catch(() => null);
  dropRuleCache();
  return !!r;
}

/** live "which rules fire on this text?" — the settings editor's test box */
export async function testRules(text: string): Promise<Array<{ name: string; matched: string; reminder: string }>> {
  const rules = await loadRules();
  const out: Array<{ name: string; matched: string; reminder: string }> = [];
  for (const rule of rules) {
    const m = rule.re.exec(text);
    if (m && m[0]) out.push({ name: rule.row.name, matched: m[0], reminder: rule.row.reminder });
  }
  return out;
}
