import { execFile } from "node:child_process";
import { promises as fs } from "node:fs";
import path from "node:path";
import { homedir } from "node:os";
import { promisify } from "node:util";

import { db } from "@/lib/db";

/* ————————————————————————————————————————————————
   FOTRA — the memory vault
   ~/.fotra/memory/*.md — per-topic markdown, every
   edit a git commit. Instinct-proven: inspectable,
   portable, syncable, and the git history IS the
   trust story. SQLite stays as the fast index; the
   markdown files are the source of truth.
   ———————————————————————————————————————————————— */

const exec = promisify(execFile);

/** FOTRA_HOME defaults to ~/.fotra; the sandbox maps it inside the project. */
export function fotraHome(): string {
  return process.env.FOTRA_HOME?.trim() || path.join(homedir(), ".fotra");
}

/** commit whatever changed under memory/ — for modules that keep their own files in the vault (the soul) */
export async function vaultCommit(message: string): Promise<void> {
  await commit(message);
}

export function vaultDir(): string {
  return path.join(fotraHome(), "memory");
}

function corePath(): string {
  return path.join(vaultDir(), "core.md");
}

function topicPath(topic: string): string {
  const slug = topic.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40) || "facts";
  return path.join(vaultDir(), "topics", `${slug}.md`);
}

/* —— secrets never reach disk (scrubbed at WRITE time, not by a later job) —— */
export function scrub(s: string): string {
  return s
    .replace(/\bsk-[A-Za-z0-9_\-]{8,}\b/g, "[redacted-key]")
    .replace(/\b(?:ghp|gho|github_pat)_[A-Za-z0-9_]{8,}\b/g, "[redacted-token]")
    .replace(/\b\d{3}[- ]?\d{3}[- ]?\d{4}\b/g, "[redacted-phone]")
    .replace(/\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b/g, "[redacted-card]")
    .replace(/\b\d{6}\b/g, (m, off, str) => {
      // a bare 6-digit number is only OTP-shaped next to code-ish words
      const ctx = (str.slice(Math.max(0, off - 40), off) + " " + str.slice(off + 6, off + 46)).toLowerCase();
      return /code|otp|verif|pin/.test(ctx) ? "[redacted-code]" : m;
    });
}

/* —— git: every edit is a commit; a missing git degrades to plain files —— */
let gitChecked = false;
let gitOk = false;

async function ensureGit(): Promise<boolean> {
  if (gitChecked) return gitOk;
  try {
    await fs.mkdir(vaultDir(), { recursive: true });
    await fs.mkdir(path.join(vaultDir(), "topics"), { recursive: true });
    const gitDir = path.join(fotraHome(), ".git");
    try {
      await fs.access(gitDir);
    } catch {
      await exec("git", ["init"], { cwd: fotraHome() });
      await exec("git", ["config", "user.name", "fotra"], { cwd: fotraHome() });
      await exec("git", ["config", "user.email", "fotra@local"], { cwd: fotraHome() });
      await exec("git", ["config", "commit.gpgsign", "false"], { cwd: fotraHome() });
    }
    gitOk = true;
  } catch {
    gitOk = false; // no git binary — files still work, history is a nice-to-have
  }
  gitChecked = true;
  return gitOk;
}

async function commit(message: string): Promise<void> {
  if (!(await ensureGit())) return;
  try {
    await exec("git", ["add", "-A", "memory"], { cwd: fotraHome() });
    await exec("git", ["commit", "-m", message, "--no-verify", "--quiet"], { cwd: fotraHome() });
  } catch {
    /* nothing changed / commit raced — never fatal */
  }
}

async function writeFileSafe(file: string, content: string): Promise<void> {
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, content, "utf8");
}

async function readFileSafe(file: string): Promise<string> {
  try {
    return await fs.readFile(file, "utf8");
  } catch {
    return "";
  }
}

/* ————————————————————————————————————————————————
   WRITE — remember / forget / edit / delete
   Both stores are updated: SQLite (index, fast search)
   and the vault (markdown + git commit, the record).
   ———————————————————————————————————————————————— */

export interface RememberInput {
  sessionId: string;
  fact: string;
  topic: string;
  origin: string;
  source?: string;
  factId?: string; // reuse a caller-provided id (client memory sync)
}

export async function vaultRemember(input: RememberInput): Promise<{ ok: boolean; note?: string; id?: string }> {
  const fact = scrub(input.fact.trim()).slice(0, 400);
  if (!fact) return { ok: false, note: "empty fact" };
  const topic = scrub(input.topic.trim() || "facts").slice(0, 40);

  // SQLite index — dedupe first
  const dup = await db.memory.findFirst({
    where: { sessionId: input.sessionId, fact: { contains: fact.slice(0, 60) } },
  });
  if (dup) return { ok: true, note: "already knew that", id: dup.id };

  const row = await db.memory.create({
    data: {
      id: input.factId || undefined,
      sessionId: input.sessionId,
      fact,
      topic,
      origin: input.origin,
      source: input.source?.slice(0, 200),
    },
  });

  // vault: dated line in the topic file
  const date = new Date().toISOString().slice(0, 10);
  const tp = topicPath(topic);
  const existing = await readFileSafe(tp);
  const header = `# ${topic}\n\n`;
  const body = existing || header;
  const next = body.endsWith("\n") || body === header ? body : body + "\n";
  await writeFileSafe(tp, `${next}- ${fact} _(${date}${input.source ? ` · via ${input.source}` : ""})_\n`);
  await commit(`remember(${topic}): ${fact.slice(0, 60)}`);

  // core block grows from the freshest memories (capped at read time, not write time)
  return { ok: true, id: row.id };
}

export async function vaultForget(sessionId: string, match: string): Promise<{ deleted: string[] }> {
  const needle = scrub(match.trim().toLowerCase());
  if (!needle) return { deleted: [] };

  const hits = await db.memory.findMany({ where: { sessionId, fact: { contains: match } } });
  if (hits.length === 0) return { deleted: [] };
  await db.memory.deleteMany({ where: { id: { in: hits.map((h) => h.id) } } });

  // remove the lines from every topic file they appear in
  const topics = [...new Set(hits.map((h) => h.topic))];
  for (const topic of topics) {
    const tp = topicPath(topic);
    const text = await readFileSafe(tp);
    if (!text) continue;
    const kept = text
      .split("\n")
      .filter((line) => {
        const low = line.toLowerCase();
        return !hits.some((h) => low.includes(h.fact.slice(0, 60).toLowerCase()));
      })
      .join("\n");
    if (kept !== text) await writeFileSafe(tp, kept);
  }
  await commit(`forget: ${needle.slice(0, 60)}`);
  return { deleted: hits.map((h) => h.fact) };
}

export async function vaultEditFact(sessionId: string, factId: string, newText: string, newTopic?: string): Promise<boolean> {
  const row = await db.memory.findFirst({ where: { id: factId, sessionId } });
  if (!row) return false;
  const text = scrub(newText.trim()).slice(0, 400);
  if (!text) return false;
  const oldTopic = row.topic;
  const topic = newTopic?.trim() || row.topic;

  // rewrite the vault line
  const removeFrom = topicPath(oldTopic);
  const cur = await readFileSafe(removeFrom);
  if (cur.includes(row.fact.slice(0, 60))) {
    await writeFileSafe(removeFrom, cur.split("\n").filter((l) => !l.toLowerCase().includes(row.fact.slice(0, 60).toLowerCase())).join("\n"));
  }
  const date = new Date().toISOString().slice(0, 10);
  const tp = topicPath(topic);
  const body = (await readFileSafe(tp)) || `# ${topic}\n\n`;
  await writeFileSafe(tp, `${body}${body.endsWith("\n") ? "" : "\n"}- ${text} _(${date} · edited by user)_\n`);

  await db.memory.update({ where: { id: factId }, data: { fact: text, topic } });
  await commit(`edit memory: ${text.slice(0, 60)}`);
  return true;
}

export async function vaultDeleteFact(sessionId: string, factId: string): Promise<boolean> {
  const row = await db.memory.findFirst({ where: { id: factId, sessionId } });
  if (!row) return false;
  await db.memory.delete({ where: { id: factId } });
  const tp = topicPath(row.topic);
  const cur = await readFileSafe(tp);
  if (cur) {
    await writeFileSafe(
      tp,
      cur.split("\n").filter((l) => !l.toLowerCase().includes(row.fact.slice(0, 60).toLowerCase())).join("\n")
    );
  }
  await commit(`delete memory: ${row.fact.slice(0, 60)}`);
  return true;
}

/* ————————————————————————————————————————————————
   READ — the core block (prompt) + search + export
   ———————————————————————————————————————————————— */

/** The core memory block: markdown sections, injected into every system
    prompt, capped at ~2k tokens (8k chars). Freshest facts win. */
export async function vaultReadCore(sessionId: string): Promise<string> {
  const rows = await db.memory.findMany({
    where: { sessionId },
    orderBy: { ts: "desc" },
    take: 40,
  });
  if (rows.length === 0) return "(nothing durable yet — learn some)";

  const byTopic = new Map<string, string[]>();
  for (const r of rows) {
    const list = byTopic.get(r.topic) ?? [];
    list.push(r.fact);
    byTopic.set(r.topic, list);
  }
  let block = "";
  for (const [topic, facts] of byTopic) {
    block += `## ${topic}\n`;
    for (const f of facts) block += `- ${f}\n`;
    block += "\n";
  }
  return block.slice(0, 8000);
}

/** Keyword search across both tiers: the SQLite index AND the vault files
    (older consolidated topics live only in markdown). No vector DB in v1. */
export async function vaultSearch(sessionId: string, query: string): Promise<Array<{ fact: string; topic: string; where: "index" | "vault" }>> {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const out: Array<{ fact: string; topic: string; where: "index" | "vault" }> = [];
  const seen = new Set<string>();

  const rows = await db.memory.findMany({
    where: { sessionId, OR: [{ fact: { contains: query } }, { topic: { contains: query } }] },
    orderBy: { ts: "desc" },
    take: 20,
  });
  for (const r of rows) {
    out.push({ fact: r.fact, topic: r.topic, where: "index" });
    seen.add(r.fact.slice(0, 60).toLowerCase());
  }

  // grep the vault topics (covers consolidated/archived material)
  try {
    const topicsDir = path.join(vaultDir(), "topics");
    const files = await fs.readdir(topicsDir).catch(() => [] as string[]);
    for (const f of files.slice(0, 50)) {
      if (!f.endsWith(".md")) continue;
      const text = await readFileSafe(path.join(topicsDir, f));
      for (const line of text.split("\n")) {
        if (!line.startsWith("- ")) continue;
        if (line.toLowerCase().includes(q) && !seen.has(line.slice(2, 62).toLowerCase())) {
          out.push({ fact: line.replace(/ _\(.*\)_$/, "").slice(2, 400), topic: f.replace(".md", ""), where: "vault" });
          if (out.length >= 40) return out;
        }
      }
    }
  } catch {
    /* vault unreadable — index results still count */
  }
  return out;
}

/** Export everything the harness knows about a session as markdown. */
export async function vaultExportMarkdown(sessionId: string): Promise<string> {
  const session = await db.session.findUnique({
    where: { id: sessionId },
    include: { turns: { orderBy: { ts: "asc" } }, memories: { orderBy: { ts: "asc" } } },
  });
  if (!session) return "# not found\n";

  let md = `# fotra thread export\n\nsession \`${session.id}\` · exported ${new Date().toISOString()}\n\n`;
  if (session.summary) md += `## compacted history\n\n${session.summary}\n\n`;
  md += `## memory (${session.memories.length})\n\n`;
  for (const m of session.memories) md += `- **${m.topic}** — ${m.fact} _(${m.origin}, ${m.ts.toISOString().slice(0, 10)})_\n`;
  md += `\n## transcript (${session.turns.length} turns)\n\n`;
  for (const t of session.turns) {
    const who = t.role === "user" ? "you" : t.origin === "system" ? "system" : "fotra";
    md += `**${who}**: ${t.text}${t.interrupted ? " _(interrupted)_" : ""}\n\n`;
  }
  return md;
}

/* ————————————————————————————————————————————————
   MEMORY v2 (the oh-my-pi mnemopi lessons, on fotra's
   git-markdown vault)
   recall — scored retrieval: token overlap × recency
             decay (no embeddings in the zero-key
             build; the seam is documented)
   learn  — capture a reusable LESSON as a skill file
             (vault/skills/*.md) that auto-injects when
             its triggers match a future ask
   omp refs: mnemopi/src/core/beam/{recall,consolidate},
   coding-agent tools/{learn,manage-skill} — fotra's
   store stays markdown+git (the blueprint's Instinct
   decision), scoring is the port.
   ———————————————————————————————————————————————— */

export interface ScoredMemory {
  fact: string;
  topic: string;
  score: number;
  when: string;
  where: "index" | "vault";
}

/** recall: scored search — token overlap × recency decay, deduped, capped */
export async function vaultRecall(sessionId: string, query: string, limit = 8): Promise<ScoredMemory[]> {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const tokens = new Set(q.split(/[^a-z0-9]+/).filter((t) => t.length > 2));
  const now = Date.now();
  const seen = new Set<string>();
  const out: ScoredMemory[] = [];

  const rows = await db.memory.findMany({ where: { sessionId }, orderBy: { ts: "desc" }, take: 120 }).catch(() => []);
  const push = (fact: string, topic: string, ts: Date, where: "index" | "vault") => {
    const key = fact.slice(0, 60).toLowerCase();
    if (seen.has(key)) return;
    const hay = `${fact} ${topic}`.toLowerCase();
    let overlap = 0;
    for (const t of tokens) if (hay.includes(t)) overlap++;
    if (overlap === 0) return;
    const ageDays = Math.max(0, (now - ts.getTime()) / 86_400_000);
    const recency = Math.exp(-ageDays / 30); // omp's exponential recency decay
    out.push({
      fact,
      topic,
      score: Math.round((overlap / Math.max(1, tokens.size) * 0.75 + recency * 0.25) * 100) / 100,
      when: ts.toISOString().slice(0, 10),
      where,
    });
  };
  for (const r of rows) push(r.fact, r.topic, r.ts, "index");

  // the vault tier (consolidated history lives only in markdown)
  try {
    const topicsDir = path.join(vaultDir(), "topics");
    const files = await fs.readdir(topicsDir).catch(() => [] as string[]);
    for (const f of files.slice(0, 50)) {
      if (!f.endsWith(".md")) continue;
      const text = await readFileSafe(path.join(topicsDir, f));
      for (const line of text.split("\n")) {
        if (!line.startsWith("- ")) continue;
        push(line.replace(/ _\(.*\)_$/, "").slice(2, 400), f.replace(".md", ""), new Date(), "vault");
      }
    }
  } catch {
    /* vault unreadable — index results still count */
  }

  return out.sort((a, b) => b.score - a.score).slice(0, limit);
}

/* —— skills: reusable lessons, markdown + git, auto-injected on trigger —— */

function skillsDir(): string {
  return path.join(vaultDir(), "skills");
}

function skillPath(slug: string): string {
  return path.join(skillsDir(), `${slug}.md`);
}

export interface SkillInfo {
  slug: string;
  triggers: string[];
  body: string;
}

/** capture a reusable lesson as a skill; it injects when triggers match.
    ALSO lands in the memory index — lessons are memories too, so recall finds them. */
export async function vaultLearn(lesson: string, name?: string, triggersRaw?: string[], sessionId?: string): Promise<{ ok: boolean; slug: string; note?: string }> {
  const body = scrub(lesson.trim()).slice(0, 1200);
  if (!body) return { ok: false, slug: "", note: "empty lesson" };
  const slug =
    (name || body.slice(0, 30))
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 32) || "lesson";
  const triggers = (triggersRaw ?? autoTriggers(body)).map((t) => t.toLowerCase().replace(/[^a-z0-9 -]/g, "").trim()).filter(Boolean).slice(0, 6);
  const header = `# skill: ${name || slug}\n\ntriggers: ${triggers.join(", ")}\nlearned: ${new Date().toISOString().slice(0, 10)}\n\n`;
  const existing = await readFileSafe(skillPath(slug));
  await writeFileSafe(skillPath(slug), `${header}${body}\n`);
  // the lesson is also a memory — recall (scored retrieval) finds it
  if (sessionId) {
    const dup = await db.memory.findFirst({ where: { sessionId, fact: { contains: body.slice(0, 60) } } }).catch(() => null);
    if (!dup) await db.memory.create({ data: { sessionId, fact: body, topic: "lessons", origin: "agent-learned", source: `skill:${slug}` } }).catch(() => undefined);
  }
  await commit(`${existing ? "update" : "learn"} skill(${slug}): ${body.slice(0, 50)}`);
  return { ok: true, slug, note: `skill "${slug}" saved — it fires on: ${triggers.join(", ") || "(manual)"}` };
}

function autoTriggers(body: string): string[] {
  // pull the most distinctive words — cheap, no model call
  const stop = new Set(["the", "and", "for", "that", "this", "with", "when", "you", "your", "are", "was", "not", "but", "has", "have", "from", "they", "them", "its", "it's", "use", "using", "always", "never", "should", "must", "will"]);
  const counts = new Map<string, number>();
  for (const w of body.toLowerCase().split(/[^a-z0-9']+/)) {
    if (w.length < 4 || stop.has(w)) continue;
    counts.set(w, (counts.get(w) ?? 0) + 1);
  }
  return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([w]) => w);
}

export async function vaultSkills(): Promise<SkillInfo[]> {
  const out: SkillInfo[] = [];
  const files = await fs.readdir(skillsDir()).catch(() => [] as string[]);
  for (const f of files.slice(0, 30)) {
    if (!f.endsWith(".md")) continue;
    const text = await readFileSafe(path.join(skillsDir(), f));
    const trigM = text.match(/^triggers: (.*)$/m);
    const triggers = (trigM ? trigM[1] : "").split(",").map((t) => t.trim()).filter(Boolean);
    out.push({ slug: f.replace(".md", ""), triggers, body: text.slice(0, 700) });
  }
  return out;
}

/** which skills fire for this user text? (injected into the system prompt) */
export async function matchSkills(text: string): Promise<SkillInfo[]> {
  const t = ` ${text.toLowerCase()} `;
  const all = await vaultSkills();
  const fired = all.filter((s) => s.triggers.some((tr) => tr.length > 3 && t.includes(tr)));
  return fired.slice(0, 3);
}

export async function vaultForgetSkill(slug: string): Promise<boolean> {
  const p = skillPath(slug.replace(/[^a-z0-9-]/g, ""));
  try {
    await fs.unlink(p);
    await commit(`forget skill(${slug})`);
    return true;
  } catch {
    return false;
  }
}

/* ————————————————————————————————————————————————
   DAILY CONSOLIDATION — the Instinct tier. A background
   job moves aging index rows into organized topic files
   (generalize, date corrections), so the core block stays
   small while nothing is ever lost.
   ———————————————————————————————————————————————— */

export async function vaultDaily(organize: (facts: Array<{ fact: string; topic: string }>) => Promise<Record<string, string[]>>): Promise<{ moved: number }> {
  await ensureGit();
  const sessions = await db.session.findMany({ include: { memories: true } });
  let moved = 0;
  for (const s of sessions) {
    if (s.memories.length < 12) continue; // nothing worth consolidating yet
    const plan = await organize(s.memories.map((m) => ({ fact: m.fact, topic: m.topic })));
    const date = new Date().toISOString().slice(0, 10);
    for (const [topic, lines] of Object.entries(plan)) {
      if (!Array.isArray(lines) || lines.length === 0) continue;
      const tp = topicPath(topic);
      const body = (await readFileSafe(tp)) || `# ${topic}\n\n`;
      const additions = lines
        .filter((l) => typeof l === "string" && l.trim())
        .map((l) => `- ${scrub(l).slice(0, 400)} _(${date} · consolidated)_`)
        .join("\n");
      if (additions) {
        await writeFileSafe(tp, `${body}${body.endsWith("\n") ? "" : "\n"}${additions}\n`);
        moved += lines.length;
      }
    }
  }
  if (moved > 0) await commit(`daily consolidation: ${moved} notes organized`);
  return { moved };
}
