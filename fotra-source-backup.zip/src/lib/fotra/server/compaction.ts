import { db } from "@/lib/db";
import type { Persona, Turn } from "@/lib/fotra/types";

/* ————————————————————————————————————————————————
   FOTRA — CONTEXT COMPACTION (the oh-my-pi port)
   Stolen — deliberately, per owner instruction — from
   omp: packages/agent/src/compaction/* (MIT, Stencil Labs
   / badlogic). Their numbers, their notices, their handoff
   prompt; adapted to fotra's flat string messages.

   Two tiers, omp's exact ladder:
   1. PRUNE (cheap, in-place, cache-friendly): blank old
      oversized TOOL RESULT messages outside the protect
      window + superseded ws_read bodies. Only applies when
      savings clear a floor — churn for pennies is a loss.
   2. COMPACT (expensive, rebuild): when the prompt would
      pass window − reserve, summarize everything before the
      kept tail into a structured handoff document (their
      prompt, verbatim) and splice it in as the new prefix.
      The summary persists on the session so the NEXT run's
      buildMessages injects it (the summaryBlock hook).

   omp refs + their exact constants:
   · pruning.ts     DEFAULT_PRUNE_CONFIG { protectTokens: 40_000, minimumSavings: 20_000 }
   · pruning.ts     SUPERSEDED_NOTICE / USELESS_NOTICE (exact strings)
   · compaction.ts  DEFAULT_RESERVE_TOKENS = 16384; reserve = max(15% window, floor)
   · compaction.ts  summary budget = floor(0.8 × reserve)
   · prompts/compaction-summary.md — the handoff prompt, verbatim below
   Seam (kept honest): we estimate tokens at chars/4 — no
   local tokenizer; the window comes from RunParams
   (BYO models declare their own) or env, default 128k.
   ———————————————————————————————————————————————— */

export interface Msg {
  role: "system" | "user" | "assistant";
  content: string;
}

/* —— their exact notices (pruning.ts) —— */
export const SUPERSEDED_NOTICE = "[Superseded by a newer read of this file]";
export const USELESS_NOTICE = "[Uneventful result elided]";
export const PRUNED_NOTICE = "[Older tool output elided — context reclaimed]";

/* —— their exact reserve math (compaction.ts) —— */
export const DEFAULT_RESERVE_TOKENS = 16384;
export const DEFAULT_WINDOW_TOKENS = 131_072;

export function resolveWindow(p: { contextWindow?: number }): number {
  const w = p.contextWindow && p.contextWindow > 0 ? p.contextWindow : Number(process.env.FOTRA_CONTEXT_WINDOW ?? 0) || DEFAULT_WINDOW_TOKENS;
  return Math.max(2048, Math.floor(w));
}

/** omp resolveBudgetReserveTokens: max(15% of window, floor) — with a small-window
    clamp (our one adaptation: BYO models/tests can declare windows below the 16k floor;
    omp never sees those) so the reserve can't swallow the whole window. */
export function resolveReserve(window: number): number {
  return Math.min(Math.max(Math.floor(window * 0.15), DEFAULT_RESERVE_TOKENS), Math.floor(window * 0.6));
}

/** their summary budget: floor(0.8 × reserve) (compaction.ts:198) */
export function summaryBudget(window: number): number {
  return Math.floor(0.8 * resolveReserve(window));
}

/* —— their prune constants, scaled for small windows (protect 40k of a 8k
      window is a no-op; omp runs against 200k hosts) —— */
export function protectTokens(window: number): number {
  return Math.min(40_000, Math.floor(window * 0.3));
}
export function minimumSavings(window: number): number {
  return Math.min(20_000, Math.floor(window * 0.25));
}

/* —— the honest seam: chars/4 estimation, no tokenizer dependency —— */
export function estTokens(text: string): number {
  return Math.ceil(text.length / 4);
}
function estMessages(messages: Msg[]): number {
  return messages.reduce((n, m) => n + estTokens(m.content) + 4, 0);
}

/** the tool-result message shape the engine emits (engine.ts toolMsgs) */
const TOOL_RESULT_RE = /^TOOL RESULT for (\w+)(?::\w+)? \((?:ok|failed)\):?\s*\n?/;

function isToolResult(m: Msg): boolean {
  return m.role === "user" && TOOL_RESULT_RE.test(m.content);
}
function toolNameOf(m: Msg): string {
  return m.content.match(TOOL_RESULT_RE)?.[1] ?? "";
}
/** ws_read results carry {"path":…} in the body — the supersede key (omp: newer read wins) */
function readPathOf(m: Msg): string | null {
  if (toolNameOf(m) !== "ws_read") return null;
  const mt = m.content.match(/"path"\s*:\s*"([^"]+)"/);
  return mt ? mt[1] : null;
}

export interface PruneResult {
  prunedCount: number;
  tokensSaved: number;
  undo: () => void;
}

/** TIER 1 — omp pruning, adapted to flat messages: walk tool results newest→oldest,
    the newest `protectTokens` stay intact; older oversized (or superseded) ones get
    blanked to an exact omp-style notice. Skipped entirely unless savings clear
    `minimumSavings` — their rule, because mutating context that's warm in the
    provider's prompt cache costs more than it saves. The last WARM_TAIL messages
    are never touched (omp cacheWarmSuffixTokens). */
export function pruneMessages(messages: Msg[], window: number): PruneResult {
  const NOTHING: PruneResult = { prunedCount: 0, tokensSaved: 0, undo: () => {} };
  const protect = protectTokens(window);
  const floor = minimumSavings(window);
  // never churn the already-sent suffix (omp cacheWarmSuffixTokens). Scaled to the
  // window: 8 flat messages can BE the whole context on a small window — omp sizes
  // this by tokens, we size it by window share, clamped to their 8-message cap.
  const warmTail = Math.max(3, Math.min(8, Math.floor(window / 4000)));
  const lastIdx = messages.length - warmTail; // indices >= lastIdx are untouchable

  const results: Array<{ idx: number; size: number; path: string | null }> = [];
  for (let i = 0; i < lastIdx; i++) {
    if (isToolResult(messages[i])) results.push({ idx: i, size: estTokens(messages[i].content), path: readPathOf(messages[i]) });
  }
  if (results.length === 0) return NOTHING;

  // newest successful read of each path supersedes every older one (omp supersedeKey)
  const newestRead = new Map<string, number>();
  for (const r of results) if (r.path !== null) newestRead.set(r.path, r.idx);

  let protectedTokens = 0;
  let cut = results.length; // everything from cut..oldest is eligible
  for (let k = results.length - 1; k >= 0; k--) {
    if (protectedTokens >= protect) break;
    protectedTokens += results[k].size;
    cut = k;
  }
  const eligible = results.slice(0, cut);

  const steps: Array<() => void> = [];
  let saved = 0;
  for (const r of eligible) {
    const supersededBy = r.path !== null && newestRead.get(r.path)! > r.idx;
    const oversized = r.size > 500; // ~2k chars — anything smaller isn't worth a cache churn
    if (!supersededBy && !oversized) continue;
    const msg = messages[r.idx];
    const notice = supersededBy ? SUPERSEDED_NOTICE : PRUNED_NOTICE;
    const before = msg.content;
    const head = msg.content.match(TOOL_RESULT_RE)?.[0] ?? "TOOL RESULT: ";
    msg.content = `${head}${notice}`;
    saved += r.size - estTokens(msg.content);
    steps.push(() => {
      msg.content = before;
    });
  }
  if (saved < floor || steps.length === 0) {
    for (const s of steps) s(); // below the floor — undo, omp's minimumSavings rule
    return NOTHING;
  }
  return {
    prunedCount: steps.length,
    tokensSaved: saved,
    undo: () => {
      for (const s of steps) s();
    },
  };
}

/** their handoff prompt — prompts/compaction-summary.md, verbatim (MIT) */
export const HANDOFF_PROMPT = `You MUST summarize the conversation above into a structured handoff summary for another LLM to resume the task.

IMPORTANT: If the conversation ends with an unanswered question or a request awaiting user response (e.g., "Please run command and paste output"), you MUST preserve that exact question/request.

You MUST use this format (sections can be omitted if not applicable):

## Goal
[User goals; list multiple if session covers different tasks.]

## Constraints & Preferences
- [Constraints or requirements mentioned]

## Progress

### Done
- [x] [Completed tasks/changes]

### In Progress
- [ ] [Current work]

### Blocked
- [Issues preventing progress]

## Key Decisions
- **[Decision]**: [Brief rationale]

## Next Steps
1. [Ordered list of next actions]

## Critical Context
- [Important data, pending questions, references]

## Additional Notes
[Anything else important not covered above]

You MUST output only the structured summary; you NEVER include extra text.

Sections MUST be kept concise. You MUST preserve exact file paths, function names, error messages, and relevant tool outputs or command results. You MUST include repository state changes (branch, uncommitted changes) if mentioned.`;

export interface CompactOutcome {
  needed: boolean; // any tier fired
  prunedCount: number;
  prunedTokens: number;
  compacted: boolean; // tier 2 fired
  estBefore: number;
  estAfter: number;
  error?: string;
}

/** TIER 2 — splice a handoff summary over everything before the kept tail.
    `summarizer` is the engine's own model path (same brain, same resilience) —
    for E2E that means the mock brain serves the handoff too. */
async function compactMessages(
  messages: Msg[],
  window: number,
  summarizer: (msgs: Msg[]) => Promise<string>
): Promise<{ ok: boolean; summary?: string; estBefore: number; estAfter: number; error?: string }> {
  const estBefore = estMessages(messages);
  // the kept tail: newest ~10% of window (at least the last exchange), plus
  // the system prompt (index 0) always survives — it's the harness, not history
  const keepTokens = Math.max(1000, Math.floor(window * 0.1));
  let tailFrom = 1;
  let tailTokens = 0;
  for (let i = messages.length - 1; i >= 1; i--) {
    if (i < messages.length - 1 && tailTokens > keepTokens) break;
    tailTokens += estTokens(messages[i].content) + 4;
    tailFrom = i;
  }

  const covered = messages.slice(1, tailFrom); // never the system prompt
  if (covered.length < 2) return { ok: false, estBefore, estAfter: estBefore, error: "nothing to cover" };

  // omp: entries capped, newest matter most — keep the newest 12k chars of transcript
  const transcript = covered
    .map((m) => `${m.role === "user" ? "user" : "fotra"}: ${m.content.slice(0, 1600)}`)
    .join("\n")
    .slice(-12000);

  let summary = "";
  try {
    summary = await summarizer([{ role: "system", content: HANDOFF_PROMPT }, { role: "user", content: transcript }]);
  } catch (err) {
    return { ok: false, estBefore, estAfter: estBefore, error: err instanceof Error ? err.message : "summarizer failed" };
  }
  summary = summary.trim();
  if (!summary) return { ok: false, estBefore, estAfter: estBefore, error: "empty summary" };

  const budget = summaryBudget(window);
  if (estTokens(summary) > budget) summary = summary.slice(0, budget * 4); // their 0.8×reserve budget

  const spliced: Msg[] = [messages[0], { role: "user", content: `[handoff summary of earlier conversation]\n${summary}` }, ...messages.slice(tailFrom)];
  const estAfter = estMessages(spliced);
  if (estAfter >= estBefore * 0.95) return { ok: false, estBefore, estAfter, error: "summary didn't shrink context" };

  messages.length = 0;
  messages.push(...spliced); // in-place — the loop's reference stays valid
  return { ok: true, summary, estBefore, estAfter };
}

/** the engine hook, once per step BEFORE the model call:
    prune when bloated; compact when the window would overflow.
    Once-per-run guard on tier 2 (a second compaction inside one
    run means the window math is wrong — surface it, don't spiral). */
export async function maintainContext(
  p: { sessionId: string; runId: string; contextWindow?: number; persona: Persona; brain: string; custom: unknown; text: string; history: Turn[]; userTurnId: string; assistantTurnId: string },
  state: { messages: Msg[]; compacted: boolean },
  emit: (ev: { type: "status"; line: string } | { type: "tool"; name: string; summary: string; ok: boolean; ms?: number }) => Promise<void> | void,
  summarizer: (msgs: Msg[]) => Promise<string>
): Promise<CompactOutcome> {
  const window = resolveWindow(p);
  const est = estMessages(state.messages);
  const out: CompactOutcome = { needed: false, prunedCount: 0, prunedTokens: 0, compacted: false, estBefore: est, estAfter: est };

  // tier 1 — prune whenever bloat is worth a cache churn (≥60% of window)
  if (est > window * 0.6) {
    const pr = pruneMessages(state.messages, window);
    if (pr.prunedCount > 0) {
      out.needed = true;
      out.prunedCount = pr.prunedCount;
      out.prunedTokens = pr.tokensSaved;
      out.estAfter = estMessages(state.messages);
      await emit({ type: "tool", name: "prune", summary: `pruned ${pr.prunedCount} old tool outputs (~${Math.round(pr.tokensSaved / 100) / 10}k tokens reclaimed)`, ok: true });
      await emit({ type: "status", line: `context pruned — ${pr.prunedCount} old tool outputs elided` });
    }
  }

  // tier 2 — compact when the next request would overflow window − reserve
  const thr = window - resolveReserve(window);
  if (estMessages(state.messages) <= thr || state.compacted) return out;

  const res = await compactMessages(state.messages, window, summarizer);
  if (!res.ok) {
    out.error = res.error;
    await emit({ type: "status", line: `compaction skipped — ${res.error}` });
    return out;
  }
  state.compacted = true;
  out.needed = true;
  out.compacted = true;
  out.estAfter = res.estAfter;
  await emit({ type: "tool", name: "compact", summary: `context compacted: ~${Math.round(res.estBefore / 100) / 10}k → ~${Math.round(res.estAfter / 100) / 10}k tokens (handoff summary kept)`, ok: true });
  await emit({ type: "status", line: "context compacted — earlier steps folded into a handoff summary" });

  // persist so the NEXT run's buildMessages injects it (summaryBlock hook, engine.ts)
  await db.session
    .update({
      where: { id: p.sessionId },
      data: { summary: (res.summary ?? "").slice(0, 1500), summaryUpTo: `run:${p.runId}` },
    })
    .catch(() => undefined);
  return out;
}
