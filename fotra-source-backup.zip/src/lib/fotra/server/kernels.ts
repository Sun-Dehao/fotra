import { spawn, type ChildProcess } from "node:child_process";
import { mkdir, readdir, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { db } from "@/lib/db";
import { wsRoot } from "./workspace";
import type { EmitFn } from "./events";

/* ————————————————————————————————————————————————
   FOTRA — persistent kernels + the loopback tool bridge
   (the oh-my-pi `eval` port)
   One long-lived Python / Node kernel per session.
   State survives across cells (variables, imports,
   loaded data). From inside a cell, `tool(...)` calls
   BACK into fotra's own tool registry over a stdio
   bridge — the agent loads a CSV with ws_read from
   inside Python, searches the web mid-cell, and never
   leaves the kernel.

   omp refs: packages/coding-agent/src/eval/{py/kernel,
   py/runner.py, py/prelude.py, kernel-session-registry}.
   fd layout (omp's "dup fd1" trick, made explicit):
     0 stdin   — host → kernel: exec commands
     1 stdout  — user code prints
     2 stderr  — user code errors
     3 fd3     — kernel → host: protocol frames (result/bridge)
     4 fd4     — host → kernel: bridge results
   ———————————————————————————————————————————————— */

const CELL_TIMEOUT_MS = 20_000;
const OUT_CAP = 12_000;
const MAX_BRIDGE_CALLS = 6; // per cell — the bridge is budgeted too
const IDLE_KILL_MS = 10 * 60_000; // reap quiet kernels
const MAX_KERNELS = 4;

export interface BridgeCall {
  tool: string;
  ok: boolean;
  ms: number;
  summary?: string;
}

export interface KernelCellResult {
  ok: boolean;
  stdout: string;
  stderr: string;
  ms: number;
  bridgeCalls: BridgeCall[];
  error?: string;
  trace?: string;
  restarted: boolean; // true if a dead kernel had to be respawned fresh for this cell
  cell: number; // 1-based cell count for this kernel
}

/** the bridge executor the caller (tools.ts) injects — runs a real tool with the run's ctx */
export type BridgeFn = (name: string, args: Record<string, unknown>) => Promise<{ ok: boolean; value?: unknown; error?: string; summary?: string }>;

/* —— the runner programs (written once under ~/.fotra/kernels/) —— */

const PY_RUNNER = String.raw`
import sys, os, json, traceback

WIRE = os.fdopen(3, "w", 1)          # frames out to the host
BRIDGE = os.fdopen(4, "r")           # bridge results back in
CELL = {"__name__": "__main__"}      # persistent across cells

def _bridge_call(name, args):
    bid = os.urandom(6).hex()
    WIRE.write(json.dumps({"type": "bridge", "bid": bid, "tool": name, "args": args}) + "\n")
    WIRE.flush()
    line = BRIDGE.readline()
    if not line:
        raise RuntimeError("tool bridge closed")
    res = json.loads(line)
    if not res.get("ok"):
        raise RuntimeError("tool %s failed: %s" % (name, res.get("error") or "unknown"))
    return res.get("value")

def tool(name, **kwargs):
    """call one of fotra's own tools from inside the cell (web_search, open_link, ws_read, ws_write, memory_search, todo_write, ...)"""
    return _bridge_call(name, kwargs)

def web_search(query, num=5):
    return _bridge_call("web_search", {"query": query, "num": num})

def open_link(url):
    return _bridge_call("open_link", {"url": url})

def read_file(path):
    return _bridge_call("ws_read", {"path": path})

def write_file(path, content):
    return _bridge_call("ws_write", {"path": path, "content": content})

def search_memory(query):
    return _bridge_call("memory_search", {"query": query})

CELL.update({"tool": tool, "web_search": web_search, "open_link": open_link,
             "read_file": read_file, "write_file": write_file, "search_memory": search_memory})

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    try:
        cmd = json.loads(line)
    except Exception:
        continue
    if cmd.get("type") == "exit":
        break
    if cmd.get("type") != "exec":
        continue
    cid = cmd.get("id")
    try:
        exec(compile(cmd["code"], "<cell>", "exec"), CELL)
        WIRE.write(json.dumps({"type": "result", "id": cid, "ok": True}) + "\n")
        WIRE.flush()
    except BaseException as e:
        WIRE.write(json.dumps({"type": "result", "id": cid, "ok": False,
                               "error": "%s: %s" % (type(e).__name__, e),
                               "trace": traceback.format_exc(limit=4)[-1500:]}) + "\n")
        WIRE.flush()
`;

const JS_RUNNER = String.raw`
import fs from "node:fs";
import vm from "node:vm";
import { createRequire } from "node:module";

const wire = (s) => fs.writeSync(3, s + "\n");

// line reader on fd 4 (host → kernel bridge results)
let buf4 = "";
function readBridgeLine() {
  for (;;) {
    const nl = buf4.indexOf("\n");
    if (nl >= 0) { const line = buf4.slice(0, nl); buf4 = buf4.slice(nl + 1); return line; }
    const chunk = Buffer.alloc(4096);
    let n = 0;
    try { n = fs.readSync(4, chunk, 0, chunk.length, null); } catch { return ""; }
    if (n <= 0) return "";
    buf4 += chunk.toString("utf8", 0, n);
  }
}

let bidSeq = 0;
function bridgeCall(name, args) {
  const bid = "b" + (++bidSeq);
  wire(JSON.stringify({ type: "bridge", bid, tool: name, args: args || {} }));
  const line = readBridgeLine();
  if (!line) throw new Error("tool bridge closed");
  const res = JSON.parse(line);
  if (!res.ok) throw new Error("tool " + name + " failed: " + (res.error || "unknown"));
  return res.value;
}

const nodeRequire = createRequire(import.meta.url);
const { inspect } = nodeRequire("node:util");
const ctx = vm.createContext({
  console: {
    log: (...a) => process.stdout.write(a.map(fmt).join(" ") + "\n"),
    error: (...a) => process.stderr.write(a.map(fmt).join(" ") + "\n"),
    warn: (...a) => process.stdout.write(a.map(fmt).join(" ") + "\n"),
  },
  tool: (name, args) => bridgeCall(name, args),
  web_search: (query, num = 5) => bridgeCall("web_search", { query, num }),
  open_link: (url) => bridgeCall("open_link", { url }),
  read_file: (p) => bridgeCall("ws_read", { path: p }),
  write_file: (p, content) => bridgeCall("ws_write", { path: p, content }),
  search_memory: (q) => bridgeCall("memory_search", { query: q }),
  require: (m) => nodeRequire(m),
  fetch: (u, o) => fetch(u, o),
  setTimeout, clearTimeout, setInterval, clearInterval,
  Buffer, URL, URLSearchParams, TextEncoder, TextDecoder,
  __dirname: process.cwd(),
});
function fmt(v) { try { return typeof v === "string" ? v : inspect(v, { depth: 4 }); } catch { return String(v); } }

const chunks = [];
process.stdin.setEncoding("utf8");
process.stdin.on("data", (d) => {
  chunks.push(d);
  let buf = chunks.join("");
  for (;;) {
    const nl = buf.indexOf("\n");
    if (nl < 0) break;
    const line = buf.slice(0, nl).trim();
    buf = buf.slice(nl + 1);
    if (line) handle(line);
  }
  chunks.length = 0; chunks.push(buf);
});
process.stdin.on("end", () => process.exit(0));

function handle(line) {
  let cmd;
  try { cmd = JSON.parse(line); } catch { return; }
  if (cmd.type === "exit") return process.exit(0);
  if (cmd.type !== "exec") return;
  try {
    vm.runInContext(cmd.code, ctx, { timeout: 18_000, displayErrors: true });
    wire(JSON.stringify({ type: "result", id: cmd.id, ok: true }));
  } catch (e) {
    wire(JSON.stringify({ type: "result", id: cmd.id, ok: false, error: String(e && e.message || e), trace: String(e && e.stack || "").slice(-1500) }));
  }
}
`;

let runnersReady = false;
async function ensureRunners(): Promise<{ py: string; js: string }> {
  const dir = path.join(process.env.FOTRA_HOME?.trim() || path.join(process.env.HOME || "/tmp", ".fotra"), "kernels");
  await mkdir(dir, { recursive: true });
  const py = path.join(dir, "py-runner.py");
  const js = path.join(dir, "js-runner.mjs");
  if (!runnersReady) {
    await writeFile(py, PY_RUNNER, "utf8");
    await writeFile(js, JS_RUNNER, "utf8");
    runnersReady = true;
  }
  return { py, js };
}

/* —— the kernel registry (session-sticky, generation-checked) —— */

interface KernelProc {
  child: ChildProcess;
  lang: "js" | "python";
  sessionId: string;
  gen: number; // generation — a killed kernel never answers again
  cells: number;
  lastUsed: number;
  wireBuf: string; // fd3 line buffer
  stdoutBuf: string;
  stderrBuf: string;
  bridgeCalls: BridgeCall[]; // THIS cell's bridge traffic (reset per cell, read after — pending is nulled on resolve)
  pending: { id: string; resolve: (r: { ok: boolean; error?: string; trace?: string }) => void; bridge: BridgeFn; onStdout?: (t: string) => void } | null;
}

const globalForKernels = globalThis as unknown as { fotraKernels?: Map<string, KernelProc>; fotraKernelSweeper?: NodeJS.Timeout };
const registry: Map<string, KernelProc> = (globalForKernels.fotraKernels ??= new Map());

function key(sessionId: string, lang: "js" | "python"): string {
  return `${sessionId}:${lang}`;
}

if (!globalForKernels.fotraKernelSweeper) {
  globalForKernels.fotraKernelSweeper = setInterval(() => {
    const now = Date.now();
    for (const [k, kp] of registry) {
      if (now - kp.lastUsed > IDLE_KILL_MS) {
        try {
          kp.child.kill("SIGKILL");
        } catch {
          /* already gone */
        }
        registry.delete(k);
      }
    }
  }, 60_000);
  globalForKernels.fotraKernelSweeper.unref();
}

async function spawnKernel(lang: "js" | "python", sessionId: string): Promise<KernelProc> {
  const runners = await ensureRunners();
  const cwd = wsRoot(sessionId);
  await mkdir(cwd, { recursive: true });
  const child =
    lang === "python"
      ? spawn(process.platform === "win32" ? "python" : "python3", ["-I", "-u", runners.py], { cwd, env: { ...process.env, PYTHONIOENCODING: "utf-8" }, stdio: ["pipe", "pipe", "pipe", "pipe", "pipe"] })
      : spawn(process.execPath, [runners.js], { cwd, env: { ...process.env, NODE_ENV: "kernel" }, stdio: ["pipe", "pipe", "pipe", "pipe", "pipe"] });

  const kp: KernelProc = {
    child,
    lang,
    sessionId,
    gen: Date.now(),
    cells: 0,
    lastUsed: Date.now(),
    wireBuf: "",
    stdoutBuf: "",
    stderrBuf: "",
    bridgeCalls: [],
    pending: null,
  };

  child.stdout?.on("data", (d: Buffer) => {
    const t = d.toString("utf8");
    kp.stdoutBuf = (kp.stdoutBuf + t).slice(-OUT_CAP);
    kp.pending?.onStdout?.(t);
  });
  child.stderr?.on("data", (d: Buffer) => {
    kp.stderrBuf = (kp.stderrBuf + d.toString("utf8")).slice(-OUT_CAP);
  });

  // fd3 — the protocol wire
  const wire = child.stdio[3];
  wire?.on("data", (d: Buffer) => {
    kp.wireBuf += d.toString("utf8");
    let nl: number;
    while ((nl = kp.wireBuf.indexOf("\n")) >= 0) {
      const line = kp.wireBuf.slice(0, nl).trim();
      kp.wireBuf = kp.wireBuf.slice(nl + 1);
      if (!line) continue;
      let frame: { type?: string; id?: string; bid?: string; tool?: string; args?: Record<string, unknown>; ok?: boolean; error?: string; trace?: string };
      try {
        frame = JSON.parse(line);
      } catch {
        continue;
      }
      if (frame.type === "bridge" && kp.pending) {
        void handleBridge(kp, frame);
      } else if (frame.type === "result" && kp.pending && frame.id === kp.pending.id) {
        const p = kp.pending;
        kp.pending = null;
        p.resolve({ ok: !!frame.ok, error: frame.error, trace: frame.trace });
      }
    }
  });

  child.on("exit", () => {
    kp.pending?.resolve({ ok: false, error: "kernel exited" });
    kp.pending = null;
    registry.delete(key(sessionId, lang));
  });

  return kp;
}

async function handleBridge(
  kp: KernelProc,
  frame: { bid: string; tool: string; args?: Record<string, unknown>; }
): Promise<void> {
  const pending = kp.pending;
  if (!pending) return;
  const t0 = Date.now();
  if (kp.bridgeCalls.length >= MAX_BRIDGE_CALLS) {
    writeFd4(kp, { type: "bridgeResult", bid: frame.bid, ok: false, error: `bridge budget spent (${MAX_BRIDGE_CALLS} tool calls this cell)` });
    kp.bridgeCalls.push({ tool: frame.tool, ok: false, ms: 0, summary: "budget" });
    return;
  }
  // banned-in-kernel tools: things that re-enter execution or pause the run
  if (frame.tool === "run_js" || frame.tool === "run_python" || frame.tool === "ask_user" || frame.tool === "spawn_task" || frame.tool.startsWith("mcp_connect")) {
    writeFd4(kp, { type: "bridgeResult", bid: frame.bid, ok: false, error: `${frame.tool} is not callable from inside a cell` });
    kp.bridgeCalls.push({ tool: frame.tool, ok: false, ms: 0, summary: "blocked" });
    return;
  }
  try {
    const res = await pending.bridge(frame.tool, frame.args ?? {});
    kp.bridgeCalls.push({ tool: frame.tool, ok: res.ok, ms: Date.now() - t0, summary: res.summary });
    writeFd4(kp, { type: "bridgeResult", bid: frame.bid, ok: res.ok, value: res.value ?? null, error: res.error });
  } catch (err) {
    kp.bridgeCalls.push({ tool: frame.tool, ok: false, ms: Date.now() - t0, summary: "threw" });
    writeFd4(kp, { type: "bridgeResult", bid: frame.bid, ok: false, error: err instanceof Error ? err.message : "bridge error" });
  }
}

function writeFd4(kp: KernelProc, obj: unknown): void {
  try {
    (kp.child.stdio[4] as NodeJS.Writable | null)?.write(JSON.stringify(obj) + "\n");
  } catch {
    /* kernel died mid-bridge — the result frame will report it */
  }
}

/* —— artifact detection (files the cell left behind) —— */

async function snapshot(root: string): Promise<Map<string, number>> {
  const map = new Map<string, number>();
  const walk = async (dir: string, prefix: string) => {
    for (const e of await readdir(dir, { withFileTypes: true }).catch(() => [])) {
      const rel = prefix ? `${prefix}/${e.name}` : e.name;
      if (e.isDirectory()) await walk(path.join(dir, e.name), rel);
      else {
        const s = await stat(path.join(dir, e.name)).catch(() => null);
        if (s) map.set(rel, s.mtimeMs + s.size);
      }
    }
  };
  await walk(root, "");
  return map;
}

/* ————————————————————————————————————————————————
   THE CELL — run code in the session's persistent
   kernel; tool(...) inside it bridges back into the
   registry. State survives across calls.
   ———————————————————————————————————————————————— */
export async function runCell(
  lang: "js" | "python",
  code: string,
  ctx: { sessionId: string; runId: string; emit?: EmitFn },
  bridge: BridgeFn
): Promise<KernelCellResult & { files: string[] }> {
  const k = key(ctx.sessionId, lang);
  let kp = registry.get(k);
  let restarted = false;

  if (kp && kp.child.exitCode !== null) {
    registry.delete(k);
    kp = undefined;
  }
  // hard cap on live kernels — evict the stalest
  if (!kp && registry.size >= MAX_KERNELS) {
    let stalest: KernelProc | null = null;
    for (const v of registry.values()) if (!stalest || v.lastUsed < stalest.lastUsed) stalest = v;
    if (stalest) {
      try {
        stalest.child.kill("SIGKILL");
      } catch {
        /* gone */
      }
      registry.delete(key(stalest.sessionId, stalest.lang));
    }
  }
  if (!kp) {
    kp = await spawnKernel(lang, ctx.sessionId);
    registry.set(k, kp);
    restarted = true;
  }
  const kernel = kp;
  kernel.lastUsed = Date.now();
  kernel.cells += 1;
  const cell = kernel.cells;

  const before = await snapshot(wsRoot(ctx.sessionId));
  kernel.stdoutBuf = "";
  kernel.stderrBuf = "";
  kernel.bridgeCalls = [];

  const t0 = Date.now();
  const id = `c${cell}-${kernel.gen.toString(36)}`;

  const result = await new Promise<{ ok: boolean; error?: string; trace?: string }>((resolve) => {
    const timer = setTimeout(() => {
      // hard kill — the kernel is dead, the next cell spawns fresh
      try {
        kernel.child.kill("SIGINT");
        setTimeout(() => {
          try {
            kernel.child.kill("SIGKILL");
          } catch {
            /* gone */
          }
        }, 2000).unref();
      } catch {
        /* gone */
      }
      registry.delete(k);
      resolve({ ok: false, error: `cell killed — ${CELL_TIMEOUT_MS / 1000}s time limit (kernel state was lost; the next cell starts fresh)` });
    }, CELL_TIMEOUT_MS);

    kernel.pending = {
      id,
      bridge,
      onStdout: (t) => {
        void ctx.emit?.({ type: "status", line: `${lang === "python" ? "python" : "node"} ▸ ${t.replace(/\n+$/, "").slice(0, 80)}` });
      },
      resolve: (r) => {
        clearTimeout(timer);
        resolve(r);
      },
    };

    try {
      (kernel.child.stdin as NodeJS.Writable | null)?.write(JSON.stringify({ type: "exec", id, code }) + "\n");
    } catch {
      clearTimeout(timer);
      resolve({ ok: false, error: "kernel stdin closed" });
    }
  });

  const ms = Date.now() - t0;
  const bridgeCalls = kernel.bridgeCalls.slice(-MAX_BRIDGE_CALLS);
  // fd1 (stdout) and fd3 (result frame) are different pipes — trailing user
  // prints can land a tick after the result. Drain beat, then read.
  await new Promise((r) => setTimeout(r, 40));

  const after = await snapshot(wsRoot(ctx.sessionId));
  const files: string[] = [];
  for (const [rel, sig] of after) if (before.get(rel) !== sig) files.push(rel);
  for (const f of files) {
    const s = await stat(path.join(wsRoot(ctx.sessionId), f)).catch(() => null);
    await db.artifact
      .create({
        data: {
          sessionId: ctx.sessionId,
          runId: ctx.runId,
          kind: "code",
          name: path.basename(f),
          path: f,
          mime: guessMime(f),
          size: s?.size ?? 0,
          meta: JSON.stringify({ producer: "kernel" }),
        },
      })
      .catch(() => undefined);
  }

  return {
    ok: result.ok,
    stdout: kernel.stdoutBuf.slice(0, OUT_CAP),
    stderr: kernel.stderrBuf.slice(0, OUT_CAP),
    ms,
    bridgeCalls,
    error: result.error,
    trace: result.trace,
    restarted,
    cell,
    files,
  };
}

/** hard reset: kill the session's kernel (next cell starts fresh) */
export function resetKernel(sessionId: string, lang: "js" | "python"): boolean {
  const k = key(sessionId, lang);
  const kp = registry.get(k);
  if (!kp) return false;
  try {
    (kp.child.stdin as NodeJS.Writable | null)?.write(JSON.stringify({ type: "exit" }) + "\n");
    setTimeout(() => kp.child.kill("SIGKILL"), 500).unref();
  } catch {
    /* gone */
  }
  registry.delete(k);
  return true;
}

export function kernelStatus(): Array<{ sessionId: string; lang: string; cells: number; idleSec: number }> {
  const now = Date.now();
  return [...registry.values()].map((kp) => ({ sessionId: kp.sessionId, lang: kp.lang, cells: kp.cells, idleSec: Math.round((now - kp.lastUsed) / 1000) }));
}

function guessMime(f: string): string {
  const e = path.extname(f).toLowerCase();
  if (e === ".py") return "text/x-python";
  if (e === ".js" || e === ".mjs" || e === ".ts") return "text/javascript";
  if (e === ".json") return "application/json";
  if (e === ".md") return "text/markdown";
  if (e === ".csv") return "text/csv";
  if (e === ".png") return "image/png";
  if (e === ".html") return "text/html";
  return "text/plain";
}
