import { db } from "@/lib/db";

/* ————————————————————————————————————————————————
   FOTRA — the MCP client (BYO tools, the universal
   standard)
   Connects to Model Context Protocol servers over
   streamable HTTP (the modern transport): initialize
   handshake → tools/list → namespaced tools callable
   as mcp_<server>_<tool>. Discovered tools are stored
   and injected into the run's tool doc, so any MCP
   server's tools become fotra tools — the OpenClaw
   extensibility play without shipping 60 integrations.
   Tool results are data, not instructions.
   ———————————————————————————————————————————————— */

const CALL_TIMEOUT = 30_000;

interface JsonRpcError {
  code?: number;
  message?: string;
}

async function rpc(url: string, method: string, params?: unknown, sessionIdHeader?: string): Promise<unknown> {
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json, text/event-stream",
      ...(sessionIdHeader ? { "Mcp-Session-Id": sessionIdHeader } : {}),
    },
    body: JSON.stringify({ jsonrpc: "2.0", id: Math.floor(Math.random() * 1e9), method, params: params ?? {} }),
    signal: AbortSignal.timeout(CALL_TIMEOUT),
  });
  if (!res.ok) throw new Error(`${method} → HTTP ${res.status}`);
  const ct = res.headers.get("content-type") ?? "";
  let payload: unknown;
  if (ct.includes("text/event-stream")) {
    // streamable-http servers may answer over SSE — take the first data event
    const text = await res.text();
    const m = text.match(/^data:\s*(\{.*\})\s*$/m);
    if (!m) throw new Error(`${method} → empty SSE response`);
    payload = JSON.parse(m[1]);
  } else {
    payload = await res.json();
  }
  const obj = payload as { result?: unknown; error?: JsonRpcError };
  if (obj.error) throw new Error(`${method} → ${obj.error.message ?? "rpc error"}`);
  return obj.result;
}

export interface McpToolInfo {
  name: string;
  description?: string;
  server: string;
}

/** Connect to an MCP server: initialize, list tools, persist. */
export async function mcpConnect(name: string, urlRaw: string): Promise<{ ok: boolean; tools: McpToolInfo[]; error?: string }> {
  const url = urlRaw.trim();
  if (!/^https?:\/\//i.test(url)) return { ok: false, tools: [], error: "url must be http(s)" };
  try {
    await rpc(url, "initialize", {
      protocolVersion: "2025-03-26",
      capabilities: {},
      clientInfo: { name: "fotra", version: "0.3" },
    });
    const listed = (await rpc(url, "tools/list", {})) as { tools?: { name: string; description?: string }[] };
    const tools = (listed.tools ?? []).map((t) => ({ name: t.name, description: t.description?.slice(0, 200), server: name }));
    if (tools.length === 0) return { ok: false, tools: [], error: "server connected but exposes no tools" };
    const existing = await db.mcpServer.findFirst({ where: { OR: [{ name }, { url }] } });
    const data = { name, url, status: "connected", tools: JSON.stringify(tools), error: null };
    if (existing) await db.mcpServer.update({ where: { id: existing.id }, data });
    else await db.mcpServer.create({ data });
    return { ok: true, tools };
  } catch (err) {
    const msg = err instanceof Error ? err.message : "connect failed";
    const existing = await db.mcpServer.findFirst({ where: { OR: [{ name }, { url }] } });
    const data = { name, url, status: "error", error: msg, tools: null };
    if (existing) await db.mcpServer.update({ where: { id: existing.id }, data });
    else await db.mcpServer.create({ data });
    return { ok: false, tools: [], error: msg };
  }
}

/** All connected servers' tools, as callable descriptors. */
export async function mcpTools(): Promise<McpToolInfo[]> {
  const rows = await db.mcpServer.findMany({ where: { status: "connected" } });
  const out: McpToolInfo[] = [];
  for (const r of rows) {
    try {
      const tools = JSON.parse(r.tools ?? "[]") as McpToolInfo[];
      for (const t of tools) out.push({ name: t.name, description: t.description, server: r.name });
    } catch {
      /* skip malformed */
    }
  }
  return out;
}

export function mcpToolId(server: string, tool: string): string {
  return `mcp_${server.toLowerCase().replace(/[^a-z0-9]+/g, "")}_${tool.toLowerCase().replace(/[^a-z0-9]+/g, "")}`;
}

/** Call a namespaced mcp tool: mcp_<server>_<tool>. */
export async function mcpCall(namespaced: string, args: Record<string, unknown>): Promise<{ ok: boolean; data: unknown; summary: string }> {
  const rows = await db.mcpServer.findMany({ where: { status: "connected" } });
  for (const r of rows) {
    const prefix = `mcp_${r.name.toLowerCase().replace(/[^a-z0-9]+/g, "")}_`;
    if (!namespaced.startsWith(prefix)) continue;
    const toolName = namespaced.slice(prefix.length);
    try {
      const res = (await rpc(r.url, "tools/call", { name: toolName, arguments: args })) as { content?: { type: string; text?: string }[]; isError?: boolean };
      const text = (res.content ?? []).map((c) => c.text ?? "").join("\n").slice(0, 8000);
      if (res.isError) return { ok: false, data: { error: text || "tool reported an error" }, summary: `${toolName} errored` };
      return { ok: true, data: { text: text || "(empty result)" }, summary: `${r.name} · ${toolName}` };
    } catch (err) {
      return { ok: false, data: { error: err instanceof Error ? err.message : "call failed" }, summary: `${toolName} failed` };
    }
  }
  return { ok: false, data: { error: `no connected server owns ${namespaced}` }, summary: "no such mcp tool" };
}

export async function mcpDisconnect(id: string): Promise<void> {
  await db.mcpServer.delete({ where: { id } }).catch(() => undefined);
}
