import { spawn } from "node:child_process";
import { readdir, stat, writeFile, mkdir } from "node:fs/promises";
import path from "node:path";
import { db } from "@/lib/db";
import { wsRoot, safeJoin, listFiles } from "./workspace";

/* ————————————————————————————————————————————————
   FOTRA — the sandbox (the Muse "secure VM" idea,
   scoped honestly for v1)
   The agent writes real code and runs it in a real
   child process — Node for JS, python3 for Python —
   inside the session's workspace directory, with a
   hard wall-clock kill, output caps, and every file
   the run leaves behind recorded as an artifact.
   Honesty note: this is a timeout-bounded process on
   the host, not a gVisor jail — the README says so,
   and single-user self-hosted is the trust model.
   ———————————————————————————————————————————————— */

const HARD_TIMEOUT_MS = 20_000;
const OUT_CAP = 12_000;

export interface SandboxResult {
  ok: boolean;
  exitCode: number | null;
  stdout: string;
  stderr: string;
  ms: number;
  files: string[]; // workspace-relative paths created/changed by the run
  summary: string;
}

async function snapshot(root: string): Promise<Map<string, number>> {
  const map = new Map<string, number>();
  const walk = async (dir: string, prefix: string) => {
    for (const e of await readdir(dir, { withFileTypes: true }).catch(() => [])) {
      const rel = prefix ? `${prefix}/${e.name}` : e.name;
      if (e.isDirectory()) await walk(path.join(dir, e.name), rel);
      else {
        const s = await stat(path.join(dir, e.name)).catch(() => null);
        if (s) map.set(rel, s.mtimeMs + s.size);
      }
    }
  };
  await walk(root, "");
  return map;
}

/** Run code in the session workspace. Files the code writes are kept. */
export async function runCode(
  lang: "js" | "python",
  code: string,
  ctx: { sessionId: string; runId: string }
): Promise<SandboxResult> {
  const root = wsRoot(ctx.sessionId);
  await mkdir(root, { recursive: true });
  const before = await snapshot(root);

  const ext = lang === "python" ? "py" : "mjs";
  const file = path.join(root, `sandbox-${Date.now().toString(36)}.${ext}`);
  await writeFile(file, code, "utf8");

  const t0 = Date.now();
  const cmd = lang === "python" ? (process.platform === "win32" ? "python" : "python3") : process.execPath;
  const args = lang === "python" ? ["-I", file] : [file];

  const res = await new Promise<{ code: number | null; out: string; err: string }>((resolve) => {
    let out = "";
    let err = "";
    let killed = false;
    const child = spawn(cmd, args, { cwd: root, env: { ...process.env, NODE_ENV: "sandbox", PYTHONIOENCODING: "utf-8" }, stdio: ["ignore", "pipe", "pipe"] });
    const timer = setTimeout(() => {
      killed = true;
      child.kill("SIGKILL");
    }, HARD_TIMEOUT_MS);
    child.stdout.on("data", (d: Buffer) => {
      if (out.length < OUT_CAP) out += d.toString("utf8").slice(0, OUT_CAP - out.length);
    });
    child.stderr.on("data", (d: Buffer) => {
      if (err.length < OUT_CAP) err += d.toString("utf8").slice(0, OUT_CAP - err.length);
    });
    child.on("error", (e) => {
      clearTimeout(timer);
      resolve({ code: null, out, err: err + String(e) });
    });
    child.on("close", (c) => {
      clearTimeout(timer);
      resolve({ code: killed ? null : (c ?? 0), out, err: killed ? err + "\n(process killed — 20s time limit)" : err });
    });
  });

  const ms = Date.now() - t0;
  const after = await snapshot(root);
  const files: string[] = [];
  for (const [rel, sig] of after) if (before.get(rel) !== sig) files.push(rel);
  for (const f of files) {
    const s = await stat(safeJoin(root, f)).catch(() => null);
    await db.artifact
      .create({
        data: {
          sessionId: ctx.sessionId,
          runId: ctx.runId,
          kind: "code",
          name: path.basename(f),
          path: f,
          mime: guessMime(f),
          size: s?.size ?? 0,
          meta: JSON.stringify({ producer: "sandbox" }),
        },
      })
      .catch(() => undefined);
  }

  const exitLine = res.code === null ? "killed (timeout)" : `exit ${res.code}`;
  const summary = `${lang === "python" ? "python" : "node"} · ${exitLine} · ${(ms / 1000).toFixed(1)}s${files.length ? ` · ${files.length} file${files.length > 1 ? "s" : ""} written` : ""}`;
  return {
    ok: res.code === 0,
    exitCode: res.code,
    stdout: res.out,
    stderr: res.err,
    ms,
    files,
    summary,
  };
}

/** list the session workspace (used by ws_list and the files rail) */
export async function sandboxList(sessionId: string): Promise<string[]> {
  return listFiles(sessionId);
}

function guessMime(f: string): string {
  const e = path.extname(f).toLowerCase();
  if (e === ".py") return "text/x-python";
  if (e === ".js" || e === ".mjs" || e === ".ts") return "text/javascript";
  if (e === ".json") return "application/json";
  if (e === ".md") return "text/markdown";
  if (e === ".csv") return "text/csv";
  if (e === ".png") return "image/png";
  if (e === ".html") return "text/html";
  return "text/plain";
}
