import { chromium, type BrowserContext, type Page, type Locator } from "playwright";
import path from "node:path";
import { homedir } from "node:os";
import { db } from "@/lib/db";
import type { BrowserFrame } from "@/lib/fotra/types";
import type { ToolCtx } from "./events";

/* ————————————————————————————————————————————————
   FOTRA — the browser computer
   A server-side headless Chromium the agent drives:
   navigate, click, type, scroll, go back, extract.
   One persistent context per session (cookies survive).

   Two things make it more than "a screenshot per call":

   · IT IS WATCHABLE. Every action streams frames to
     the user's stage — where the cursor is heading and
     what it is about to do BEFORE it happens, then the
     page as it looks after. The in-between frames are
     motion (fanned live, never logged); the after-frame
     is the record.

   · THE MODEL GETS HANDLES, NOT GUESSES. Each page
     state comes back with a numbered list of what can
     be clicked or typed into. {"target": 7} hits
     exactly that element; text and selectors still
     work as fallbacks.

   Page content is data, not instructions — the prompt
   injection rule applies to everything read here.
   ———————————————————————————————————————————————— */

const FOTRA_HOME = process.env.FOTRA_HOME || path.join(homedir(), ".fotra");
const ACTION_TIMEOUT = 25_000;
const VIEW = { width: 1152, height: 720 };
const MAX_SHOTS_PER_RUN = 30;
const MAX_ELEMENTS = 48;

const PROFILE = "main";

interface Held {
  context: BrowserContext;
  page: Page;
  lastUsed: number;
  cursor: { x: number; y: number }; // normalized — where the pointer was left
}
const globalForBrowser = globalThis as unknown as {
  fotraBrowsers?: Map<string, Held>;
  fotraBrowserReaper?: NodeJS.Timeout;
  fotraShotCount?: Map<string, number>;
  fotraBrowserVisible?: boolean;
};
const browsers: Map<string, Held> = (globalForBrowser.fotraBrowsers ??= new Map());
const shotCount: Map<string, number> = (globalForBrowser.fotraShotCount ??= new Map());
globalForBrowser.fotraBrowserReaper ??= (() => {
  const t = setInterval(() => {
    const now = Date.now();
    for (const [k, h] of browsers) {
      if (now - h.lastUsed > 5 * 60_000) {
        browsers.delete(k);
        globalForBrowser.fotraBrowserVisible = false; // the next launch is quiet again
        h.context.close().catch(() => undefined);
      }
    }
  }, 60_000);
  t.unref?.();
  return t;
})();

async function held(sessionId: string): Promise<Held> {
  // one browser, one profile, for every thread: a site you signed in to stays signed in
  void sessionId;
  const key = PROFILE;
  const existing = browsers.get(key);
  if (existing && !existing.page.isClosed()) {
    existing.lastUsed = Date.now();
    return existing;
  }
  if (existing) browsers.delete(key);
  let context: BrowserContext;
  try {
    context = await chromium.launchPersistentContext(path.join(FOTRA_HOME, "browser", key), {
      headless: !globalForBrowser.fotraBrowserVisible,
      viewport: VIEW,
      javaScriptEnabled: true,
      locale: "en-US",
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (/Executable doesn't exist|playwright install/i.test(msg)) {
      throw new Error("the browser isn't installed on this machine yet — run `npx playwright install chromium` once");
    }
    throw err;
  }
  const page = context.pages()[0] ?? (await context.newPage());
  // popups and target=_blank land in the same window — one page to watch
  context.on("page", (p) => {
    const h = browsers.get(key);
    if (h && p !== h.page) {
      h.page = p;
      p.setViewportSize(VIEW).catch(() => undefined);
    }
  });
  const h: Held = { context, page, lastUsed: Date.now(), cursor: { x: 0.5, y: 0.45 } };
  browsers.set(key, h);
  return h;
}

function isWarm(sessionId: string): boolean {
  void sessionId;
  const h = browsers.get(PROFILE);
  return !!h && !h.page.isClosed();
}

export interface PageElement {
  i: number;
  role: string; // link | button | field | select | check
  name: string;
}

export interface BrowserState {
  url: string;
  title: string;
  text: string; // readable excerpt
  shot?: string; // jpeg data URL
  elements: PageElement[]; // numbered handles for the next action
  frames: number; // how many frames this action showed the user
}

export function resetShotBudget(runId: string) {
  shotCount.delete(runId);
}

async function shoot(page: Page, runId: string): Promise<string | undefined> {
  const used = shotCount.get(runId) ?? 0;
  if (used >= MAX_SHOTS_PER_RUN) return undefined;
  shotCount.set(runId, used + 1);
  try {
    const buf = await page.screenshot({ type: "jpeg", quality: 58, fullPage: false, scale: "css" });
    return `data:image/jpeg;base64,${buf.toString("base64")}`;
  } catch {
    return undefined; // a navigation raced the shot — fine
  }
}

/** number what the user could act on in the viewport, and tag each node so a handle resolves to exactly it */
async function mark(page: Page): Promise<PageElement[]> {
  try {
    return (await page.evaluate((max: number) => {
      const out: { i: number; role: string; name: string }[] = [];
      document.querySelectorAll("[data-fotra-i]").forEach((n) => n.removeAttribute("data-fotra-i"));
      const nodes = Array.from(
        document.querySelectorAll<HTMLElement>(
          "a[href],button,input:not([type=hidden]),textarea,select,[role=button],[role=link],[role=tab],[role=menuitem],[role=checkbox],[role=option],[contenteditable=true],summary"
        )
      );
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      let i = 1;
      for (const el of nodes) {
        if (out.length >= max) break;
        const r = el.getBoundingClientRect();
        if (r.width < 6 || r.height < 6) continue;
        if (r.bottom < 0 || r.top > vh || r.right < 0 || r.left > vw) continue;
        const st = getComputedStyle(el);
        if (st.visibility === "hidden" || st.display === "none" || Number(st.opacity) === 0) continue;
        const tag = el.tagName.toLowerCase();
        const input = el as HTMLInputElement;
        const type = (input.type || "").toLowerCase();
        const role =
          tag === "a" || el.getAttribute("role") === "link"
            ? "link"
            : tag === "select"
              ? "select"
              : tag === "textarea" || el.isContentEditable || (tag === "input" && !["button", "submit", "checkbox", "radio", "reset", "image"].includes(type))
                ? "field"
                : type === "checkbox" || type === "radio" || el.getAttribute("role") === "checkbox"
                  ? "check"
                  : "button";
        const name = (
          el.getAttribute("aria-label") ||
          (role === "field" ? input.placeholder || input.name || el.getAttribute("title") : "") ||
          el.innerText ||
          input.value ||
          el.getAttribute("title") ||
          (el.querySelector("img")?.getAttribute("alt") ?? "") ||
          ""
        )
          .replace(/\s+/g, " ")
          .trim()
          .slice(0, 70);
        if (!name && role !== "field") continue;
        el.setAttribute("data-fotra-i", String(i));
        out.push({ i, role, name: name || "(unlabeled field)" });
        i++;
      }
      return out;
    }, MAX_ELEMENTS)) as PageElement[];
  } catch {
    return [];
  }
}

async function capture(page: Page, runId: string, wantShot = true): Promise<Omit<BrowserState, "frames">> {
  const url = page.url();
  const title = await page.title().catch(() => "");
  let text = "";
  try {
    text = (await page.evaluate(() => (document.body?.innerText ?? "").slice(0, 4000))) as string;
  } catch {
    text = "";
  }
  const elements = await mark(page);
  const shot = wantShot ? await shoot(page, runId) : undefined;
  return { url, title, text: text.replace(/\n{3,}/g, "\n\n").trim(), shot, elements };
}

/* ————— frames: what the user watches ————— */

type FrameIn = Omit<BrowserFrame, "ts">;

/** motion — fanned to live viewers, never written to the log */
async function live(ctx: ToolCtx, frame: FrameIn): Promise<void> {
  if (!ctx.stepId) return;
  const send = ctx.emitLive ?? ctx.emit;
  await send({ type: "frame", stepId: ctx.stepId, frame }).catch(() => undefined);
}

/** the record — the page as it looks after the action; replayable */
async function settled(ctx: ToolCtx, frame: FrameIn): Promise<void> {
  if (!ctx.stepId) return;
  await ctx.emit({ type: "frame", stepId: ctx.stepId, frame }).catch(() => undefined);
}

const pause = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function center(loc: Locator): Promise<{ x: number; y: number; px: number; py: number } | null> {
  try {
    await loc.scrollIntoViewIfNeeded({ timeout: 2500 }).catch(() => undefined);
    const b = await loc.boundingBox({ timeout: 2500 });
    if (!b) return null;
    const px = b.x + b.width / 2;
    const py = b.y + b.height / 2;
    return { px, py, x: Math.min(0.98, Math.max(0.02, px / VIEW.width)), y: Math.min(0.98, Math.max(0.02, py / VIEW.height)) };
  } catch {
    return null;
  }
}

/** resolve a target — a handle number, a selector, visible text, a button/link name — to one locator */
async function resolve(page: Page, target: string | number, want: "click" | "field"): Promise<{ loc: Locator; label: string } | null> {
  const raw = String(target).trim();
  if (!raw) return null;
  if (/^#?\d{1,3}$/.test(raw)) {
    const n = raw.replace("#", "");
    const loc = page.locator(`[data-fotra-i="${n}"]`).first();
    if ((await loc.count().catch(() => 0)) > 0) {
      const label = (await loc.evaluate((el) => (el.getAttribute("aria-label") || (el as HTMLElement).innerText || (el as HTMLInputElement).placeholder || "").replace(/\s+/g, " ").trim().slice(0, 50)).catch(() => "")) || `#${n}`;
      return { loc, label };
    }
  }
  const tries: Locator[] = [];
  if (want === "field") {
    tries.push(page.getByPlaceholder(raw).first(), page.getByLabel(raw).first(), page.getByRole("textbox", { name: raw }).first(), page.getByRole("searchbox", { name: raw }).first());
  } else {
    tries.push(page.getByRole("button", { name: raw }).first(), page.getByRole("link", { name: raw }).first(), page.getByText(raw, { exact: false }).first());
  }
  // a css / xpath selector, when it looks like one
  if (/^[#.\[]|^\/\/|[>=]|^[a-z]+\[/.test(raw)) tries.unshift(page.locator(raw).first());
  for (const loc of tries) {
    if (await loc.isVisible().catch(() => false)) return { loc, label: raw.slice(0, 50) };
  }
  if (want === "field") {
    const any = page.locator("textarea:visible, input[type=search]:visible, input[type=text]:visible, input:not([type]):visible, [contenteditable=true]:visible").first();
    if (await any.isVisible().catch(() => false)) return { loc: any, label: raw.slice(0, 50) || "the field" };
  }
  return null;
}

async function settle(page: Page, ms: number): Promise<void> {
  await page.waitForLoadState("domcontentloaded", { timeout: 8000 }).catch(() => undefined);
  await page.waitForTimeout(ms).catch(() => undefined);
}

async function finish(sessionId: string, ctx: ToolCtx, frames: number, extra?: Partial<FrameIn>): Promise<BrowserState> {
  const h = await held(sessionId);
  const state = await capture(h.page, ctx.runId);
  await settled(ctx, { url: state.url, title: state.title, shot: state.shot, cursor: h.cursor, act: "read", ...extra });
  await recordShot(state, ctx);
  return { ...state, frames: frames + 1 };
}

/* ————— actions ————— */

export async function navigate(urlRaw: string, ctx: ToolCtx): Promise<BrowserState> {
  let url = urlRaw.trim();
  if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
  // the window appears the instant the agent decides to browse — a cold browser can take a few
  // seconds to start, and the user should be watching that happen, not wondering
  if (!isWarm(ctx.sessionId)) await live(ctx, { url, act: "navigate", note: "starting the browser…", cursor: { x: 0.5, y: 0.45 } });
  const h = await held(ctx.sessionId);
  await live(ctx, { url, act: "navigate", note: `opening ${hostOf(url) || url}`, cursor: h.cursor });
  await h.page.goto(url, { waitUntil: "domcontentloaded", timeout: ACTION_TIMEOUT });
  await h.page.waitForTimeout(500); // let late JS settle
  return finish(ctx.sessionId, ctx, 1, { act: "navigate" });
}

export async function click(target: string | number, ctx: ToolCtx): Promise<BrowserState> {
  const h = await held(ctx.sessionId);
  const page = h.page;
  const hit = await resolve(page, target, "click");
  if (!hit) throw new Error(`nothing clickable matches "${String(target).slice(0, 60)}" — use a number from the elements list`);
  const c = await center(hit.loc);
  if (c) {
    h.cursor = { x: c.x, y: c.y };
    await live(ctx, { url: page.url(), act: "click", note: `clicking ${quote(hit.label)}`, cursor: h.cursor });
    await page.mouse.move(c.px, c.py, { steps: 6 }).catch(() => undefined);
    await pause(420); // the watcher's cursor needs a beat to arrive before the page changes
  }
  await hit.loc.click({ timeout: 6000 });
  await settle(page, 450);
  return finish(ctx.sessionId, ctx, 1, { act: "click", note: `clicked ${quote(hit.label)}` });
}

export async function typeInto(target: string | number, text: string, submit: boolean, ctx: ToolCtx): Promise<BrowserState> {
  const h = await held(ctx.sessionId);
  const page = h.page;
  const hit = await resolve(page, target, "field");
  if (!hit) throw new Error(`no visible text field matches "${String(target).slice(0, 60)}"`);
  const c = await center(hit.loc);
  if (c) {
    h.cursor = { x: c.x, y: c.y };
    await live(ctx, { url: page.url(), act: "type", note: `typing into ${quote(hit.label)}`, typed: text.slice(0, 120), cursor: h.cursor });
    await page.mouse.move(c.px, c.py, { steps: 6 }).catch(() => undefined);
  }
  await hit.loc.click({ timeout: 4000 }).catch(() => undefined);
  await hit.loc.fill("", { timeout: 4000 }).catch(() => undefined);
  // typed, not pasted — sites with live suggestions react, and the watcher sees it land
  await hit.loc.pressSequentially(text, { delay: Math.max(8, Math.min(40, Math.round(900 / Math.max(1, text.length)))), timeout: 12_000 }).catch(async () => {
    await hit.loc.fill(text, { timeout: 6000 });
  });
  if (submit) {
    const mid = await shoot(page, ctx.runId);
    await live(ctx, { url: page.url(), act: "type", note: "pressing enter", shot: mid, typed: text.slice(0, 120), cursor: h.cursor });
    await hit.loc.press("Enter").catch(() => undefined);
  }
  await settle(page, submit ? 900 : 250);
  return finish(ctx.sessionId, ctx, submit ? 2 : 1, { act: "type", note: submit ? `searched ${quote(text.slice(0, 40))}` : `typed ${quote(text.slice(0, 40))}` });
}

export async function scrollPage(dir: "up" | "down", ctx: ToolCtx): Promise<BrowserState> {
  const h = await held(ctx.sessionId);
  await live(ctx, { url: h.page.url(), act: "scroll", note: `scrolling ${dir}`, cursor: h.cursor });
  await h.page.mouse.wheel(0, dir === "down" ? 620 : -620);
  await h.page.waitForTimeout(350);
  return finish(ctx.sessionId, ctx, 1, { act: "scroll", note: `scrolled ${dir}` });
}

export async function goBack(ctx: ToolCtx): Promise<BrowserState> {
  const h = await held(ctx.sessionId);
  await live(ctx, { url: h.page.url(), act: "back", note: "going back", cursor: h.cursor });
  await h.page.goBack({ waitUntil: "domcontentloaded", timeout: ACTION_TIMEOUT }).catch(() => undefined);
  await h.page.waitForTimeout(350);
  return finish(ctx.sessionId, ctx, 1, { act: "back" });
}

export async function extract(selector: string | undefined, ctx: ToolCtx): Promise<BrowserState> {
  const h = await held(ctx.sessionId);
  const page = h.page;
  await live(ctx, { url: page.url(), act: "read", note: selector ? `reading ${selector.slice(0, 40)}` : "reading the page", cursor: h.cursor });
  if (selector) {
    const data = await page.locator(selector).allInnerTexts().catch(() => [] as string[]);
    return { url: page.url(), title: await page.title().catch(() => ""), text: data.join("\n---\n").slice(0, 8000), elements: [], frames: 1 };
  }
  const state = await capture(page, ctx.runId, false);
  return { ...state, frames: 1 };
}

async function recordShot(state: Omit<BrowserState, "frames">, ctx: ToolCtx): Promise<void> {
  if (!state.shot) return;
  await db.artifact
    .create({
      data: {
        sessionId: ctx.sessionId,
        runId: ctx.runId,
        kind: "browser",
        name: hostOf(state.url) || "page",
        path: state.shot, // data URL (jpeg q58)
        mime: "image/jpeg",
        size: Math.round(state.shot.length * 0.75),
        meta: JSON.stringify({ url: state.url, title: state.title }),
      },
    })
    .catch(() => undefined);
}

function quote(s: string): string {
  return `“${s}”`;
}

function hostOf(u: string): string {
  try {
    return new URL(u).host.replace(/^www\./, "");
  } catch {
    return "";
  }
}

/** A person is needed (a captcha, a sign-in): reopen the same page in a REAL window on their
    screen, same profile, so what they do there — solving, logging in — carries on for the agent. */
export async function showToHuman(ctx: ToolCtx): Promise<BrowserState> {
  const prev = browsers.get(PROFILE);
  const url = prev && !prev.page.isClosed() ? prev.page.url() : "";
  if (!globalForBrowser.fotraBrowserVisible) {
    if (prev) {
      browsers.delete(PROFILE);
      await prev.context.close().catch(() => undefined);
    }
    globalForBrowser.fotraBrowserVisible = true;
  }
  const h = await held(ctx.sessionId);
  if (url && !/^about:/.test(url) && h.page.url() !== url) {
    await h.page.goto(url, { waitUntil: "domcontentloaded", timeout: ACTION_TIMEOUT }).catch(() => undefined);
  }
  await h.page.bringToFront().catch(() => undefined);
  h.lastUsed = Date.now() + 15 * 60_000; // the person gets time; the idle reaper waits
  return finish(ctx.sessionId, ctx, 1, { act: "navigate" });
}

export async function closeBrowser(sessionId: string): Promise<void> {
  void sessionId;
  const key = PROFILE;
  const h = browsers.get(key);
  if (h) {
    browsers.delete(key);
    await h.context.close().catch(() => undefined);
  }
}
