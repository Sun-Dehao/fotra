import { mkdir, readFile, readdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { db } from "@/lib/db";
import { homedir } from "node:os";

/* ————————————————————————————————————————————————
   FOTRA — the workspace
   A per-session directory the agent (and its code
   runs) can read and write. What makes tools real:
   files are objects on disk, listed in the rail,
   exportable, not text in a bubble.
   Lives under ~/.fotra/workspace/<sessionId>/ so it
   survives app updates and maps to a Docker volume.
   ———————————————————————————————————————————————— */

const FOTRA_HOME = process.env.FOTRA_HOME || path.join(homedir(), ".fotra");

export function wsRoot(sessionId: string): string {
  return path.join(FOTRA_HOME, "workspace", sessionId.replace(/[^a-zA-Z0-9_-]/g, "_"));
}

/** path-traversal guard: the resolved path must stay inside the workspace root */
export function safeJoin(root: string, rel: string): string {
  const clean = rel.replace(/^[/\\]+/, "");
  const abs = path.resolve(root, clean);
  const normRoot = path.resolve(root);
  if (abs !== normRoot && !abs.startsWith(normRoot + path.sep)) {
    throw new Error("path escapes the workspace");
  }
  return abs;
}

const MAX_FILE_BYTES = 200_000; // read/write cap per file

export async function listFiles(sessionId: string, sub = ""): Promise<string[]> {
  const root = wsRoot(sessionId);
  const dir = sub ? safeJoin(root, sub) : root;
  const out: string[] = [];
  const walk = async (d: string, prefix: string) => {
    for (const e of await readdir(d, { withFileTypes: true }).catch(() => [])) {
      const rel = prefix ? `${prefix}/${e.name}` : e.name;
      if (e.isDirectory()) await walk(path.join(d, e.name), rel);
      else out.push(rel);
    }
  };
  await walk(dir, sub ? "" : "");
  return out.sort().slice(0, 200);
}

export async function wsRead(sessionId: string, rel: string): Promise<{ ok: boolean; path?: string; content?: string; error?: string; binary?: boolean; tag?: string }> {
  try {
    const abs = safeJoin(wsRoot(sessionId), rel);
    const buf = await readFile(abs);
    if (isBinary(buf)) return { ok: true, path: rel, binary: true, content: `(binary file, ${buf.length} bytes)` };
    const content = buf.toString("utf8").slice(0, MAX_FILE_BYTES);
    const tag = recordSnapshot(sessionId, rel, content); // the hashline anchor — patches carry this
    return { ok: true, path: rel, content, tag };
  } catch {
    return { ok: false, path: rel, error: "no such file in the workspace" };
  }
}

export async function wsWrite(
  sessionId: string,
  rel: string,
  content: string,
  ctx?: { runId?: string }
): Promise<{ ok: boolean; path: string; bytes: number; error?: string }> {
  try {
    const root = wsRoot(sessionId);
    const abs = safeJoin(root, rel);
    await mkdir(path.dirname(abs), { recursive: true });
    const body = content.slice(0, MAX_FILE_BYTES);
    await writeFile(abs, body, "utf8");
    recordSnapshot(sessionId, rel, body); // writes refresh the anchor too — patch chains stay valid
    await db.artifact
      .create({
        data: {
          sessionId,
          runId: ctx?.runId ?? null,
          kind: "workspace",
          name: path.basename(rel),
          path: rel,
          mime: guessMime(rel),
          size: Buffer.byteLength(body),
          meta: JSON.stringify({ producer: "agent" }),
        },
      })
      .catch(() => undefined);
    return { ok: true, path: rel, bytes: Buffer.byteLength(body) };
  } catch (err) {
    return { ok: false, path: rel, bytes: 0, error: err instanceof Error ? err.message : "write failed" };
  }
}

export async function wsPatch(
  sessionId: string,
  rel: string,
  find: string,
  replace: string
): Promise<{ ok: boolean; path: string; count: number; error?: string }> {
  const cur = await wsRead(sessionId, rel);
  if (!cur.ok || !cur.content) return { ok: false, path: rel, count: 0, error: cur.error ?? "unreadable" };
  if (!cur.content.includes(find)) return { ok: false, path: rel, count: 0, error: "text to find is not in the file" };
  const next = cur.content.split(find).join(replace);
  const w = await wsWrite(sessionId, rel, next);
  if (!w.ok) return { ok: false, path: rel, count: 0, error: w.error };
  return { ok: true, path: rel, count: cur.content.split(find).length - 1 };
}

/* ————————————————————————————————————————————————
   HASHLINE EDITS (the oh-my-pi `edit` port)
   Every ws_read hands the model a #tag — a content
   hash of the file it just saw. Patches carry the
   tag + line ops. A stale tag (file changed since
   the read) is caught BEFORE the patch corrupts
   anything; a single-line drift is recovered by
   offset remap, anything bigger demands a fresh
   read. No old_string retyping, no whitespace
   battles, fewer tokens.
   omp ref: crates/pi-edit/src/{store.rs,modes/hashline}
   ———————————————————————————————————————————————— */

/** 4-hex content tag: sha1 of the whitespace-stripped normalized text */
export function contentTag(content: string): string {
  return createHash("sha1").update(content.replace(/\s+/g, " ").trim()).digest("hex").slice(0, 4);
}

interface EditSnapshot {
  tag: string;
  lines: string[];
  ts: number;
}
const globalForEdits = globalThis as unknown as { fotraEditStore?: Map<string, EditSnapshot> };
const editStore: Map<string, EditSnapshot> = (globalForEdits.fotraEditStore ??= new Map());

function editKey(sessionId: string, rel: string): string {
  return `${sessionId}:${rel}`;
}

/** record the snapshot a read produced (the model may anchor patches to it) */
function recordSnapshot(sessionId: string, rel: string, content: string): string {
  const tag = contentTag(content);
  editStore.set(editKey(sessionId, rel), { tag, lines: content.split("\n"), ts: Date.now() });
  return tag;
}

export interface HashlineOp {
  line?: number; // 1-based target line (replace/delete)
  after?: number; // insert AFTER this line (0 = top of file)
  insert?: string;
  replace?: string;
  delete?: boolean;
}

export async function wsPatchHashline(
  sessionId: string,
  rel: string,
  tag: string | undefined,
  ops: HashlineOp[]
): Promise<{ ok: boolean; path: string; error?: string; count?: number; remapped?: boolean }> {
  const cur = await wsRead(sessionId, rel);
  if (!cur.ok || !cur.content) return { ok: false, path: rel, error: cur.error ?? "unreadable" };
  const currentLines = cur.content.split("\n");
  const currentTag = contentTag(cur.content);
  const snap = editStore.get(editKey(sessionId, rel));

  let workLines = currentLines;
  let remapped = false;

  if (tag && tag !== currentTag) {
    // STALE — the file moved since the read. Try omp's recovery: a uniform
    // one-line drift explains most edits; remap and proceed with a note.
    if (!snap || snap.tag !== tag) {
      return { ok: false, path: rel, error: `stale tag — the file changed since your ws_read (#${currentTag} now). Read it again, then patch with the fresh tag.` };
    }
    const drift = currentLines.length - snap.lines.length;
    if (Math.abs(drift) <= 1 && snap.lines.length > 0) {
      remapped = true;
      // ops were written against snap.lines' numbering — shift them by the drift
    } else {
      return { ok: false, path: rel, error: `stale tag — the file changed by ${drift} lines since your read. Read it again and re-anchor.` };
    }
  }

  // validate + normalize ops (apply bottom-up so earlier numbers stay valid)
  const norm: Array<{ at: number; kind: "replace" | "delete" | "insert"; text?: string }> = [];
  for (const op of ops) {
    if (op.insert !== undefined && op.after !== undefined) {
      norm.push({ at: op.after, kind: "insert", text: op.insert });
    } else if (op.line !== undefined && op.delete) {
      norm.push({ at: op.line, kind: "delete" });
    } else if (op.line !== undefined && op.replace !== undefined) {
      norm.push({ at: op.line, kind: "replace", text: op.replace });
    }
  }
  if (norm.length === 0) return { ok: false, path: rel, error: "no valid ops — each op needs {line,replace} | {line,delete:true} | {after,insert}" };

  let shift = remapped ? currentLines.length - snap.lines.length : 0;
  const sorted = norm.sort((a, b) => b.at - a.at);
  let count = 0;
  for (const op of sorted) {
    let at = op.at + shift;
    if (op.kind === "insert") {
      if (at < 0 || at > workLines.length) return { ok: false, path: rel, error: `insert-after line ${op.at} is outside the file (1-${workLines.length})` };
      workLines.splice(at, 0, op.text ?? "");
      count++;
      continue;
    }
    if (at < 1 || at > workLines.length) {
      return { ok: false, path: rel, error: `line ${op.at}${remapped ? ` (after remap: ${at})` : ""} is outside the file (1-${workLines.length}) — read the file and re-anchor` };
    }
    if (op.kind === "delete") {
      workLines.splice(at - 1, 1);
      count++;
    } else {
      workLines[at - 1] = op.text ?? "";
      count++;
    }
  }
  void shift;

  const next = workLines.join("\n");
  const w = await wsWrite(sessionId, rel, next);
  if (!w.ok) return { ok: false, path: rel, error: w.error };
  recordSnapshot(sessionId, rel, next); // the fresh tag — subsequent patches anchor here
  return { ok: true, path: rel, count, remapped };
}

const BIN_EXT = new Set([".png", ".jpg", ".jpeg", ".gif", ".webp", ".pdf", ".zip", ".gz", ".mp3", ".mp4", ".wav", ".ico", ".woff", ".woff2"]);
function isBinary(buf: Buffer): boolean {
  // null byte in the first 8000 bytes → binary
  return buf.subarray(0, 8000).includes(0);
}
function guessMime(f: string): string {
  const e = path.extname(f).toLowerCase();
  if (BIN_EXT.has(e)) return "application/octet-stream";
  if (e === ".json") return "application/json";
  if (e === ".md") return "text/markdown";
  if (e === ".csv") return "text/csv";
  if (e === ".html") return "text/html";
  if (e === ".py") return "text/x-python";
  if (e === ".js" || e === ".mjs") return "text/javascript";
  return "text/plain";
}
export { BIN_EXT as binaryExtensions, MAX_FILE_BYTES };
