import { promises as fs } from "node:fs";
import path from "node:path";
import type { FotraAction, Persona, ThemeMode, UiPrefs } from "@/lib/fotra/types";
import { scrub, vaultCommit, vaultDir } from "./vault";

/* ————————————————————————————————————————————————
   FOTRA — the soul: the agent changing ITSELF
   "Be blunter." "Stop reading URLs aloud." "Go compact
   and wear the ice coat." "Always answer in Spanish."
   One tool (self_edit) covers all of it:

   · standing instructions — how it behaves from now on.
     They live in memory/SOUL.md (markdown you can read
     and edit), ride every system prompt, and every
     change is a git commit.
   · its look and voice — the persona.
   · its own app — layout, density, how much of the
     work it shows, the idle screen.

   Every edit is journaled with what it replaced, so
   "undo that" always works — by voice, or by the undo
   button on the change card.
   ———————————————————————————————————————————————— */

const MAX_INSTRUCTIONS = 24;
const MAX_JOURNAL = 40;

function soulPath(): string {
  return path.join(vaultDir(), "SOUL.md");
}
function journalPath(): string {
  return path.join(vaultDir(), "self-edits.json");
}

export interface SelfSnapshot {
  persona: Persona;
  ui: UiPrefs;
  mode: ThemeMode;
}

export interface SelfChange {
  field: string; // "name", "coat", "density", "instruction"…
  from?: string;
  to?: string;
  op: "set" | "add" | "remove";
}

interface JournalEntry {
  id: string;
  ts: number;
  why: string;
  changes: SelfChange[];
  before: { instructions: string[]; persona: Partial<Persona>; ui: Partial<UiPrefs>; mode?: ThemeMode };
  undone?: boolean;
}

export interface SelfEditInput {
  persona?: Record<string, unknown>;
  ui?: Record<string, unknown>;
  mode?: unknown;
  instructions?: { add?: unknown; remove?: unknown; clear?: unknown };
  why?: unknown;
}

export interface SelfEditResult {
  ok: boolean;
  editId?: string;
  changes: SelfChange[];
  actions: FotraAction[]; // what the client must apply (look, layout, mode)
  instructions: string[]; // the standing instructions after the edit
  error?: string;
}

/* ————— the soul file ————— */

export async function readInstructions(): Promise<string[]> {
  try {
    const raw = await fs.readFile(soulPath(), "utf8");
    return raw
      .split("\n")
      .filter((l) => /^\s*[-*]\s+/.test(l))
      .map((l) => l.replace(/^\s*[-*]\s+/, "").trim())
      .filter(Boolean)
      .slice(0, MAX_INSTRUCTIONS);
  } catch {
    return [];
  }
}

async function writeInstructions(list: string[], name: string): Promise<void> {
  await fs.mkdir(vaultDir(), { recursive: true });
  const body =
    `# soul\n\nHow ${name} behaves — standing instructions it wrote for itself when you asked it to change.\n` +
    `Edit this file by hand if you like; every line starting with "-" is one instruction.\n\n` +
    (list.length ? list.map((l) => `- ${l}`).join("\n") : "_(none yet)_") +
    "\n";
  await fs.writeFile(soulPath(), body, "utf8");
}

/** the block that rides every system prompt */
export async function soulBlock(): Promise<string> {
  const list = await readInstructions();
  if (list.length === 0) return "";
  return `\nSTANDING INSTRUCTIONS — the user asked you to change how you behave, and you wrote these for yourself. They outrank the default style rules above:\n${list.map((l) => `- ${l}`).join("\n")}\n`;
}

async function readJournal(): Promise<JournalEntry[]> {
  try {
    const j = JSON.parse(await fs.readFile(journalPath(), "utf8")) as JournalEntry[];
    return Array.isArray(j) ? j : [];
  } catch {
    return [];
  }
}

async function writeJournal(j: JournalEntry[]): Promise<void> {
  await fs.mkdir(vaultDir(), { recursive: true });
  await fs.writeFile(journalPath(), JSON.stringify(j.slice(-MAX_JOURNAL), null, 2), "utf8");
}

/* ————— validation: the model proposes, the harness decides what is a legal value ————— */

const MASCOTS = ["dot", "ghost", "star", "cat", "bot", "orb"];
const COATS = ["iris", "verdant", "ember", "ice", "rose", "mono"];
const AURAS = ["calm", "pulse", "spark"];

function str(v: unknown, max: number): string | null {
  return typeof v === "string" && v.trim() ? scrub(v.trim()).slice(0, max) : null;
}
function oneOf<T extends string>(v: unknown, set: readonly string[]): T | null {
  return typeof v === "string" && set.includes(v.toLowerCase()) ? (v.toLowerCase() as T) : null;
}
function num(v: unknown, lo: number, hi: number): number | null {
  const n = typeof v === "number" ? v : typeof v === "string" ? Number(v) : NaN;
  return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : null;
}

function cleanPersona(p: Record<string, unknown> | undefined): Partial<Persona> {
  if (!p || typeof p !== "object") return {};
  const out: Partial<Persona> = {};
  const name = str(p.name, 24);
  if (name) out.name = name;
  const tagline = str(p.tagline, 80);
  if (tagline) out.tagline = tagline;
  const mascot = oneOf<Persona["mascot"]>(p.mascot ?? p.face, MASCOTS);
  if (mascot) out.mascot = mascot;
  const coat = oneOf<Persona["coat"]>(p.coat ?? p.color ?? p.theme, COATS);
  if (coat) out.coat = coat;
  const aura = oneOf<Persona["aura"]>(p.aura ?? p.halo, AURAS);
  if (aura) out.aura = aura;
  const rate = num(p.voiceRate, 0.6, 1.4);
  if (rate !== null) out.voiceRate = rate;
  const pitch = num(p.voicePitch, 0.6, 1.4);
  if (pitch !== null) out.voicePitch = pitch;
  return out;
}

function cleanUi(u: Record<string, unknown> | undefined): Partial<UiPrefs> {
  if (!u || typeof u !== "object") return {};
  const out: Partial<UiPrefs> = {};
  const density = oneOf<UiPrefs["density"]>(u.density, ["cozy", "compact"]);
  if (density) out.density = density;
  const width = oneOf<UiPrefs["width"]>(u.width, ["narrow", "normal", "wide"]);
  if (width) out.width = width;
  const trail = oneOf<UiPrefs["trail"]>(u.trail, ["auto", "open", "quiet"]);
  if (trail) out.trail = trail;
  const stage = oneOf<UiPrefs["stage"]>(u.stage, ["pip", "wide", "off"]);
  if (stage) out.stage = stage;
  if (Array.isArray(u.suggestions)) {
    out.suggestions = u.suggestions.filter((s): s is string => typeof s === "string" && !!s.trim()).map((s) => scrub(s.trim()).slice(0, 70)).slice(0, 6);
  }
  if (typeof u.greeting === "string") out.greeting = scrub(u.greeting.trim()).slice(0, 90);
  return out;
}

function show(v: unknown): string {
  return Array.isArray(v) ? v.join(" · ") || "(default)" : String(v ?? "");
}

/* ————— the edit ————— */

export async function selfEdit(input: SelfEditInput, now: SelfSnapshot): Promise<SelfEditResult> {
  const changes: SelfChange[] = [];
  const actions: FotraAction[] = [];
  const before: JournalEntry["before"] = { instructions: await readInstructions(), persona: {}, ui: {} };

  const persona = cleanPersona(input.persona);
  const personaPatch: Partial<Persona> = {};
  for (const [k, v] of Object.entries(persona) as [keyof Persona, Persona[keyof Persona]][]) {
    if (now.persona[k] === v) continue;
    (before.persona as Record<string, unknown>)[k] = now.persona[k];
    (personaPatch as Record<string, unknown>)[k] = v;
    changes.push({ field: k === "mascot" ? "face" : k, from: show(now.persona[k]), to: show(v), op: "set" });
  }
  if (Object.keys(personaPatch).length) actions.push({ type: "persona", patch: personaPatch });

  const ui = cleanUi(input.ui);
  const uiPatch: Partial<UiPrefs> = {};
  for (const [k, v] of Object.entries(ui) as [keyof UiPrefs, UiPrefs[keyof UiPrefs]][]) {
    if (JSON.stringify(now.ui[k]) === JSON.stringify(v)) continue;
    (before.ui as Record<string, unknown>)[k] = now.ui[k];
    (uiPatch as Record<string, unknown>)[k] = v;
    changes.push({ field: k, from: show(now.ui[k]), to: show(v), op: "set" });
  }
  if (Object.keys(uiPatch).length) actions.push({ type: "ui", patch: uiPatch });

  const mode = oneOf<ThemeMode>(input.mode, ["dark", "light"]);
  if (mode && mode !== now.mode) {
    before.mode = now.mode;
    actions.push({ type: "mode", value: mode });
    changes.push({ field: "canvas", from: now.mode === "dark" ? "night" : "day", to: mode === "dark" ? "night" : "day", op: "set" });
  }

  let instructions = [...before.instructions];
  const ins = input.instructions;
  if (ins && typeof ins === "object") {
    if (ins.clear === true && instructions.length) {
      for (const l of instructions) changes.push({ field: "instruction", from: l, op: "remove" });
      instructions = [];
    }
    const removes = (Array.isArray(ins.remove) ? ins.remove : typeof ins.remove === "string" ? [ins.remove] : []).filter((r): r is string => typeof r === "string" && !!r.trim());
    for (const r of removes) {
      const needle = r.trim().toLowerCase();
      const hit = instructions.filter((l) => l.toLowerCase().includes(needle) || needle.includes(l.toLowerCase()));
      for (const l of hit) changes.push({ field: "instruction", from: l, op: "remove" });
      instructions = instructions.filter((l) => !hit.includes(l));
    }
    const adds = (Array.isArray(ins.add) ? ins.add : typeof ins.add === "string" ? [ins.add] : []).filter((a): a is string => typeof a === "string" && !!a.trim());
    for (const a of adds) {
      const line = scrub(a.trim().replace(/^[-*]\s+/, "")).slice(0, 240);
      if (!line || instructions.some((l) => l.toLowerCase() === line.toLowerCase())) continue;
      if (instructions.length >= MAX_INSTRUCTIONS) break;
      instructions.push(line);
      changes.push({ field: "instruction", to: line, op: "add" });
    }
  }

  if (changes.length === 0) {
    return { ok: false, changes, actions: [], instructions, error: "nothing to change — every value given is already the current one, or wasn't a legal value" };
  }

  const name = personaPatch.name ?? now.persona.name;
  const instructionsChanged = JSON.stringify(instructions) !== JSON.stringify(before.instructions);
  if (instructionsChanged) await writeInstructions(instructions, name);

  const why = str(input.why, 140) ?? "";
  const entry: JournalEntry = { id: `se-${Date.now().toString(36)}`, ts: Date.now(), why, changes, before };
  await writeJournal([...(await readJournal()), entry]);
  await vaultCommit(`self-edit: ${why || changes.map((c) => c.field).join(", ")}`.slice(0, 120));

  return { ok: true, editId: entry.id, changes, actions, instructions };
}

/** put back what an edit replaced — the latest one, or a specific id */
export async function undoSelfEdit(editId?: string): Promise<SelfEditResult> {
  const journal = await readJournal();
  const entry = editId ? journal.find((e) => e.id === editId) : [...journal].reverse().find((e) => !e.undone);
  const instructions = await readInstructions();
  if (!entry) return { ok: false, changes: [], actions: [], instructions, error: "no self-edit to undo" };
  if (entry.undone) return { ok: false, changes: [], actions: [], instructions, error: "that change was already undone" };

  const actions: FotraAction[] = [];
  if (Object.keys(entry.before.persona).length) actions.push({ type: "persona", patch: entry.before.persona });
  if (Object.keys(entry.before.ui).length) actions.push({ type: "ui", patch: entry.before.ui });
  if (entry.before.mode) actions.push({ type: "mode", value: entry.before.mode });
  const touchedInstructions = entry.changes.some((c) => c.field === "instruction");
  if (touchedInstructions) {
    const name = typeof entry.before.persona.name === "string" ? entry.before.persona.name : "fotra";
    await writeInstructions(entry.before.instructions, name);
  }
  entry.undone = true;
  await writeJournal(journal);
  await vaultCommit(`self-edit undone: ${entry.why || entry.id}`.slice(0, 120));

  const changes: SelfChange[] = entry.changes.map((c) =>
    c.op === "add" ? { field: c.field, from: c.to, op: "remove" as const } : c.op === "remove" ? { field: c.field, to: c.from, op: "add" as const } : { field: c.field, from: c.to, to: c.from, op: "set" as const }
  );
  return { ok: true, editId: entry.id, changes, actions, instructions: touchedInstructions ? entry.before.instructions : instructions };
}

export async function selfEditHistory(): Promise<Array<{ id: string; ts: number; why: string; changes: SelfChange[]; undone: boolean }>> {
  return (await readJournal()).map((e) => ({ id: e.id, ts: e.ts, why: e.why, changes: e.changes, undone: !!e.undone })).reverse();
}
