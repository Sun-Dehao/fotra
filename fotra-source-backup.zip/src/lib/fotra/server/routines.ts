import { db } from "@/lib/db";
import { executeRun } from "./engine";
import type { Persona } from "@/lib/fotra/types";

/* ————————————————————————————————————————————————
   FOTRA — routines (the proactive layer: Dots'
   background tasks, OpenClaw's scheduled jobs)
   "Every morning at 8, brief me." A routine is a
   stored prompt on a schedule; the in-process ticker
   fires it as a REAL run (same engine, same tools,
   same audit) and records the outcome as an assistant
   turn + lastNote. The client polls and surfaces new
   results ambiently. Honest scope: minute-level
   schedules ("every N minutes" / "daily@HH:MM"),
   no cloud push.
   ———————————————————————————————————————————————— */

const TICK_MS = 30_000;

export { parseSchedule, nextFire, describeSchedule, type ParsedSchedule } from "./schedule";
import { nextFire } from "./schedule";

export interface RoutineOutcome {
  fired: boolean;
  note: string;
}

/** Fire one routine now (ticker or run-now button). Creates the assistant
    turn placeholder, launches the run, records lastNote when it lands. */
export async function fireRoutine(routineId: string, persona: Persona, brain: "fotra" | "custom" | "provider" = "fotra"): Promise<RoutineOutcome> {
  const r = await db.routine.findUnique({ where: { id: routineId } });
  if (!r) return { fired: false, note: "routine not found" };
  const runId = `routine-${r.id}-${Date.now().toString(36)}`;
  const turnId = `t-routine-${runId}`;
  const note = `${r.name} fired — running`;
  await db.routine.update({
    where: { id: r.id },
    data: { lastRunAt: new Date(), nextRunAt: nextFire(r.schedule) ?? new Date(Date.now() + 3600_000), lastNote: note },
  });
  await db.turn.create({
    data: { id: `t-sys-${runId}`, sessionId: r.sessionId, role: "assistant", text: `routine · ${r.name}`, origin: "system" },
  }).catch(() => undefined);
  await db.turn.create({
    data: { id: turnId, sessionId: r.sessionId, role: "user", text: `[routine: ${r.name}] ${r.prompt}`, origin: "system" },
  }).catch(() => undefined);

  void executeRun({
    sessionId: r.sessionId,
    runId,
    text: `[routine: ${r.name}] ${r.prompt}`,
    userTurnId: turnId,
    history: [],
    persona,
    assistantTurnId: `t-a-${runId}`,
    brain,
    custom: { baseUrl: "", apiKey: "", model: "", temperature: 0.7 },
  })
    .then(async () => {
      const t = await db.turn.findUnique({ where: { id: `t-a-${runId}` } }).catch(() => null);
      const text = (t?.text ?? "").replace(/\s+/g, " ").slice(0, 160);
      await db.routine.update({ where: { id: r.id }, data: { lastNote: `${r.name}: ${text || "done"}` } }).catch(() => undefined);
    })
    .catch(async (err) => {
      await db.routine.update({ where: { id: r.id }, data: { lastNote: `${r.name} failed: ${err instanceof Error ? err.message.slice(0, 120) : "error"}` } }).catch(() => undefined);
    });
  return { fired: true, note };
}

/* the ticker — one per process, CAS-safe by the nextRunAt check */
const globalForTicker = globalThis as unknown as { fotraRoutineTicker?: NodeJS.Timeout; fotraRoutineFiring?: Set<string> };
const firing: Set<string> = (globalForTicker.fotraRoutineFiring ??= new Set());

export function startRoutineTicker(): void {
  if (globalForTicker.fotraRoutineTicker) return;
  globalForTicker.fotraRoutineTicker = setInterval(async () => {
    const now = new Date();
    const due = await db.routine.findMany({ where: { active: true, nextRunAt: { lte: now } }, take: 5 }).catch(() => []);
    for (const r of due) {
      if (firing.has(r.id)) continue;
      firing.add(r.id);
      // routines run with the default brain — no stored secrets involved
      const persona: Persona = { name: "fotra", tagline: "", aura: "calm", mascot: "dot", coat: "iris", voiceURI: null, voiceRate: 1, voicePitch: 1 };
      fireRoutine(r.id, persona)
        .catch(() => undefined)
        .finally(() => firing.delete(r.id));
    }
  }, TICK_MS);
  (globalForTicker.fotraRoutineTicker as NodeJS.Timeout).unref?.();
}
