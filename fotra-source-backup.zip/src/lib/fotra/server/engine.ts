import { db } from "@/lib/db";
import { zaiClient } from "./zai";
import { ProtocolParser, coerceAction, PROTOCOL_DOC } from "@/lib/fotra/protocol";
import { DEFAULT_UI, type FotraAction, type Persona, type ThemeMode, type Turn, type UiPrefs } from "@/lib/fotra/types";
import { describeStep, freshBudget, runTool, toolBudgetLeft, toolDoc, mcpToolDoc } from "./tools";
import { BrainUnavailable, builtinBrainAvailable } from "./zai";
import { selfEdit, soulBlock } from "./soul";
import type { ServerEvent, EmitFn } from "./events";
import { spawnWorkers, type WorkerSpec, type OutputSchema } from "./subagents";
import { resetShotBudget } from "./browser-computer";
import { vaultForget, vaultReadCore, vaultRemember, matchSkills } from "./vault";
import { enqueueCompact } from "./jobs";
import { resolveRole, completeRole } from "./providers";
import { StreamWatcher, TtsrCut, loadRules, type CompiledRule } from "./ttsr";
import { maintainContext } from "./compaction";
import { adviseStep, deliverNote, advisorBudget } from "./advisor";
import { authHeaders, chatUrl, explainResponse, explainThrown } from "./endpoint";

export type { ServerEvent, EmitFn } from "./events";

/* ————————————————————————————————————————————————
   FOTRA — the run engine v4 (server side)
   This is the harness:
   · an event-sourced loop — every event persisted, runs
         reattachable after reload/disconnect (the client is
         a REPLAYABLE VIEW of this loop, never the owner)
   · disconnect ≠ abort — runs continue under the
         watchdog; only an explicit stop kills one
   · ask_user / budget pauses SUSPEND the run and the
         human's answer RESUMES it — HITL on one path
   · PARALLEL TOOL BATCHES + TYPED WORKER YIELDS
   · TTSR (oh-my-pi port) — stream rules cut the model
         mid-token when it goes off-script, inject the
         rule, and retry from the same point
   · INTERRUPT-STEER — steering kicks the CURRENT model
         call, not just the next one
   · DEADLINE, NOT MICRO-STEPS — trust the model (omp's
         lesson), bound by wall clock + output budget
   · ADVISOR — a second model reviews steps inline
   · MAGIC KEYWORDS — ultrathink / orchestrate in prose
   · CHECKPOINT / REWIND — collapse explored context to
         a report, keep the run alive
   · BRAIN FALLBACK CHAINS — a dying endpoint degrades
         to the fotra brain instead of erroring the run
   · grounding — comparison screens cite only this turn's
         tool corpus
   ———————————————————————————————————————————————— */

export interface RunParams {
  sessionId: string;
  runId: string;
  text: string;
  userTurnId: string;
  history: Turn[]; // client's recent turns — upserted by id
  persona: Persona;
  assistantTurnId: string;
  brain: "fotra" | "custom" | "provider";
  custom: { baseUrl: string; apiKey: string; model: string; temperature: number };
  contextWindow?: number; // the model's window (BYO declares its own; default 128k) — compaction's input
  ui?: UiPrefs; // how the app is laid out right now — what a self-edit diffs against
  mode?: ThemeMode;
  /** reactions the user left since the last run — feedback the agent should take on board */
  feedback?: Array<{ emoji: string; note?: string; excerpt: string }>;
}

/* —— the loop state — everything a resume needs —— */
interface Msg {
  role: "system" | "user" | "assistant";
  content: string;
}

interface LoopState {
  messages: Msg[];
  outChars: number;
  assistantText: string;
  stepsTaken: number;
  stepsAllowed: number;
  usedTools: string[];
  evidence: string; // this-run tool results, lowercased — the grounding corpus
  nudges: number; // corrective retries already spent on tool-less replies
  screenComponents: Set<string>; // every screen component this run has docked
  // — v4 —
  deadlineAt: number; // wall-clock deadline (the omp lesson: bound time, not steps)
  ttsrRetries: number;
  steerKicks: number;
  advisorSpent: number;
  advisorNotes: string[]; // injections waiting for the next model call
  checkpoint: { atLen: number; label: string } | null;
  ultrathink: boolean;
  brainFallbackUsed: boolean;
  compacted: boolean; // tier-2 compaction already fired this run (omp: once, not a spiral)
  reacted?: string; // the reply tapped back on the user's message — it may be the WHOLE reply
}

interface SuspensionRecord {
  kind: "ask" | "budget";
  toolCallId: string;
  question: string;
  options?: string[];
  params: RunParams;
  state: LoopState;
}

/* —— in-memory run registry: steering, abort, live subscribers —— */
interface RunHandle {
  controller: AbortController;
  steer: string[];
  startedAt: number;
  subscribers: Set<(ev: ServerEvent) => void>;
  seq: number; // last persisted event seq
}
const globalForRuns = globalThis as unknown as { fotraRuns?: Map<string, RunHandle>; fotraPendingSubs?: Map<string, Set<(ev: ServerEvent) => void>> };
const handles: Map<string, RunHandle> = (globalForRuns.fotraRuns ??= new Map());
/** subscribers that arrived before the handle did — drained at registration */
const pendingSubs: Map<string, Set<(ev: ServerEvent) => void>> = (globalForRuns.fotraPendingSubs ??= new Map());

/* —— brain cooldowns: a dying endpoint rests, the chain walks past it —— */
const globalForCooldown = globalThis as unknown as { fotraCooldown?: Map<string, number> };
const cooldowns: Map<string, number> = (globalForCooldown.fotraCooldown ??= new Map());
function brainCooling(key: string): boolean {
  const until = cooldowns.get(key) ?? 0;
  return Date.now() < until;
}
function coolBrain(key: string, ms = 120_000): void {
  cooldowns.set(key, Date.now() + ms);
}

/** control-flow signals — never trigger brain fallback */
class SteerKick extends Error {
  constructor() {
    super("steering arrived mid-call");
  }
}

export function steerRun(runId: string, text: string): boolean {
  const h = handles.get(runId);
  if (!h) return false;
  h.steer.push(text);
  return true;
}

export function abortRun(runId: string): boolean {
  const h = handles.get(runId);
  if (!h) return false;
  h.controller.abort();
  return true;
}

export function runActive(runId: string): boolean {
  return handles.has(runId);
}

/** subscribe to a live run's events (SSE routes). Order-safe: if the handle
    isn't registered yet, the subscription waits and attaches on registration. */
export function subscribeRun(runId: string, fn: (ev: ServerEvent) => void): () => void {
  const h = handles.get(runId);
  if (h) {
    h.subscribers.add(fn);
    return () => {
      h.subscribers.delete(fn);
    };
  }
  const set = pendingSubs.get(runId) ?? new Set();
  set.add(fn);
  pendingSubs.set(runId, set);
  return () => {
    set.delete(fn);
    const live = handles.get(runId);
    live?.subscribers.delete(fn);
  };
}

/** attach any pending subscribers the moment a handle is born — no missed events, ever */
function registerHandle(runId: string, handle: RunHandle): void {
  handles.set(runId, handle);
  const pending = pendingSubs.get(runId);
  if (pending) {
    for (const fn of pending) handle.subscribers.add(fn);
    pendingSubs.delete(runId);
  }
}

export function runSeq(runId: string): number {
  return handles.get(runId)?.seq ?? 0;
}

/* —— budgets: pause, never kill —— */
const MAX_STEPS = 24; // ceiling, not a target — the deadline is the real bound (omp: trust the model)
const RESUME_STEPS = 6; // extra rounds a "continue" buys
const RUN_DEADLINE_MS = 6 * 60_000; // wall clock per run (resumes extend)
const MAX_OUTPUT_CHARS = 30_000; // per run, all steps combined
const RECENT_WINDOW = 20; // turns kept verbatim; older → compaction
const TTSR_MAX_RETRIES = 2; // per run — omp's escalation budget
const STEER_KICK_MAX = 4; // interrupts per run — steering is a scalpel, not a firehose


/* ————————————————————————————————————————————————
   EMIT — persist every event (the log), then fan out
   to live subscribers. The log is the truth; the SSE
   writers are just views.
   ———————————————————————————————————————————————— */

/** motion, not record: reaches whoever is watching right now and is never written to the log
    (the in-between frames of computer use). No seq — a replay simply doesn't have them. */
function emitLive(runId: string, ev: ServerEvent): void {
  const h = handles.get(runId);
  if (!h) return;
  for (const fn of h.subscribers) {
    try {
      fn(ev);
    } catch {
      h.subscribers.delete(fn);
    }
  }
}

async function emit(runId: string, evIn: ServerEvent): Promise<void> {
  const h = handles.get(runId);
  if (!h) return;
  h.seq += 1;
  const ev = { ...evIn, seq: h.seq } as ServerEvent; // seq rides the wire → reattach knows where to resume
  const seq = h.seq;
  await db.runEvent
    .create({ data: { runId, seq, kind: ev.type, data: JSON.stringify(ev) } })
    .catch(() => undefined);
  for (const fn of h.subscribers) {
    try {
      fn(ev);
    } catch {
      h.subscribers.delete(fn);
    }
  }
}

/* ————————————————————————————————————————————————
   THE LOOP
   ———————————————————————————————————————————————— */

export async function executeRun(p: RunParams): Promise<void> {
  const controller = new AbortController();
  const handle: RunHandle = { controller, steer: [], startedAt: Date.now(), subscribers: new Set(), seq: 0 };
  registerHandle(p.runId, handle); // order-safe: drains pending subscribers
  let state: LoopState | null = null;
  resetShotBudget(p.runId);

  // NOTE: client disconnect does NOT abort the run — runs live under the
  // watchdog and every event lands in the log. Only an explicit abort does.

  try {
    // event #1 is the session identity — logged, so a replayed run can name
    // itself (runId + assistantTurnId) to a client that reloaded
    await emit(p.runId, { type: "session", sessionId: p.sessionId, runId: p.runId, assistantTurnId: p.assistantTurnId });
    await persistHistory(p.sessionId, p.history);
    await db.turn
      .create({
        data: { id: p.userTurnId, sessionId: p.sessionId, role: "user", text: p.text, origin: "voice" },
      })
      .catch(() => undefined); // id collision on retry — ignore

    /* harness-grade memory: an explicit "remember X" never depends on the
       model choosing to emit the action — extract + persist deterministically. */
    const explicit = p.text.match(/\b(?:remember|don't forget|do not forget|keep in mind)(?:\s+that)?[:\s]+(.{3,220}?)(?:[.!?]|$)/i);
    if (explicit?.[1]?.trim()) {
      const fact = explicit[1].trim();
      const res = await vaultRemember({ sessionId: p.sessionId, fact, topic: "user-told", origin: "user-told", source: "explicit" });
      if (res.ok) {
        await emit(p.runId, { type: "action", action: { type: "remember", fact, topic: "user-told" } });
        await emit(p.runId, {
          type: "step",
          step: { id: `s-${p.runId.slice(-8)}-mem`, tool: "remember", kind: "memory", title: "Remembering", subject: fact.slice(0, 90), status: "done", summary: res.note ?? `noted: ${fact.slice(0, 60)}`, ms: 0, data: { fact, topic: "user-told" } },
        });
        await emit(p.runId, { type: "tool", name: "remember", summary: res.note ?? `noted: ${fact.slice(0, 60)}`, ok: true });
      }
    }

    // magic keywords (omp): prose-only — code spans and fences are masked out
    const prose = maskCode(p.text);
    const ultrathink = /\bultrathink\b/.test(prose);
    const orchestrate = /\borchestrate\b/.test(prose);

    const fresh: LoopState = {
      messages: await buildMessages(p, { orchestrate }),
      outChars: 0,
      assistantText: "",
      stepsTaken: 0,
      stepsAllowed: MAX_STEPS,
      usedTools: [],
      evidence: "",
      nudges: 0,
      screenComponents: new Set(),
      deadlineAt: Date.now() + RUN_DEADLINE_MS,
      ttsrRetries: 0,
      steerKicks: 0,
      advisorSpent: 0,
      advisorNotes: [],
      checkpoint: null,
      ultrathink,
      brainFallbackUsed: false,
      compacted: false,
    };
    if (ultrathink) {
      fresh.messages.push({ role: "user", content: "[harness] ultrathink requested — take the careful path: reason through the problem before answering, verify claims against tool results, prefer checking over assuming." });
      await emit(p.runId, { type: "status", line: "ultrathink — deep pass" });
    }
    state = fresh;
    await runLoop(p, fresh);
  } catch (err) {
    const msg = err instanceof Error ? err.message : "the run broke";
    if (handle.controller.signal.aborted) {
      await finalize(p, state ?? state0(), true);
    } else {
      // undrained steering is never lost, even on early failure
      if (handle.steer.length > 0) {
        await emit(p.runId, { type: "unsteered", texts: handle.steer.splice(0) });
      }
      await emit(p.runId, err instanceof BrainUnavailable ? { type: "error", message: "No model connected.", hint: msg } : { type: "error", message: "The model call failed.", hint: msg });
      await db.run.update({ where: { id: p.runId }, data: { status: "error", error: msg.slice(0, 500), endedAt: new Date() } }).catch(() => undefined);
    }
  } finally {
    const row = await db.run.findUnique({ where: { id: p.runId }, select: { status: true } }).catch(() => null);
    if (row?.status !== "waiting") handles.delete(p.runId);
  }
}

function state0(): LoopState {
  return {
    messages: [], outChars: 0, assistantText: "", stepsTaken: 0, stepsAllowed: MAX_STEPS, usedTools: [], evidence: "", nudges: 0,
    screenComponents: new Set(), deadlineAt: Date.now() + RUN_DEADLINE_MS, ttsrRetries: 0, steerKicks: 0, advisorSpent: 0,
    advisorNotes: [], checkpoint: null, ultrathink: false, brainFallbackUsed: false, compacted: false,
  };
}

/** JSON round-trip safety: Sets and Dates don't survive suspension records */
function reviveState(state: LoopState): LoopState {
  if (!(state.screenComponents instanceof Set)) state.screenComponents = new Set();
  if (typeof state.deadlineAt !== "number" || state.deadlineAt < Date.now()) state.deadlineAt = Date.now() + RUN_DEADLINE_MS;
  if (!Array.isArray(state.advisorNotes)) state.advisorNotes = [];
  if (typeof state.ttsrRetries !== "number") state.ttsrRetries = 0;
  if (typeof state.steerKicks !== "number") state.steerKicks = 0;
  if (typeof state.advisorSpent !== "number") state.advisorSpent = 0;
  if (typeof state.compacted !== "boolean") state.compacted = false;
  return state;
}

/* the shared loop — fresh runs and resumes both land here */
async function runLoop(p: RunParams, stateIn: LoopState): Promise<void> {
  const state = reviveState(stateIn);
  const handle = handles.get(p.runId);
  if (!handle) return;
  const controller = handle.controller;
  const budget = freshBudget();
  const steered: string[] = [];
  const ttsrRules: CompiledRule[] = await loadRules(); // pre-warmed — sync per-delta matching (cache refreshes per process)

  // how the agent looks right now — one object for the whole run, so a second self-edit diffs against the first
  const self = { persona: { ...p.persona }, ui: { ...DEFAULT_UI, ...(p.ui ?? {}) }, mode: (p.mode === "light" ? "light" : "dark") as ThemeMode };
  let stepSeq = 0;

  /** the tool exec context handed to every tool (progress streams back through here) */
  const makeCtx = (stepId?: string) => ({
    sessionId: p.sessionId,
    runId: p.runId,
    signal: controller.signal,
    emit: (ev: ServerEvent) => emit(p.runId, ev),
    emitLive: async (ev: ServerEvent) => emitLive(p.runId, ev),
    stepId,
    self,
    persona: { name: p.persona.name, tone: p.persona.tagline },
    brain: p.brain,
    custom: p.custom,
  });

  try {
    for (let step = state.stepsTaken; step < state.stepsAllowed; step++) {
      if (controller.signal.aborted) break;
      state.stepsTaken = step + 1;

      // deadline — the honest bound (pause-not-kill, like every budget here)
      if (Date.now() > state.deadlineAt && step > 0) {
        const question = "I've hit my time budget for this run.";
        const detail = `6 minutes of wall clock — the run is paused, not dead.`;
        await emit(p.runId, {
          type: "action",
          action: { type: "ask", id: `budget-${p.runId}`, question, detail, options: ["continue", "stop", "finish quietly"], tone: "warn", resume: { runId: p.runId, kind: "budget" } },
        });
        await suspend(p, state, { toolCallId: `budget-${p.runId}`, question: `${question} ${detail} Say continue and I'll pick up where I left off.`, options: ["continue", "stop", "finish quietly"] }, "budget");
        return;
      }

      // drain steering messages into the context (queue-and-steer) — audited on the run row.
      // The wrapper is omp's prompts/steering/user-interjection.md, verbatim: priority framing
      // so mid-run interjections override earlier instructions instead of queueing behind them.
      while (handle.steer.length > 0) {
        const msg = handle.steer.shift()!;
        state.messages.push({
          role: "user",
          content: `<system-notice>\nUser interjection during work: priority; supersedes conflicting prior instructions. Re-read; ensure current work reflects user intent.\n</system-notice>\n${msg}`,
        });
        await emit(p.runId, { type: "status", line: "steering…" });
        steered.push(msg);
      }
      if (steered.length > 0) {
        await db.run
          .update({ where: { id: p.runId }, data: { steerMsgs: JSON.stringify(steered) } })
          .catch(() => undefined);
      }

      // advisor notes collected last step inject now (omp: inline, own context)
      while (state.advisorNotes.length > 0) {
        const n = state.advisorNotes.shift()!;
        state.messages.push({ role: "user", content: n });
      }

      /* ——— CONTEXT MAINTENANCE (the omp compaction port) ———
         prune bloated old tool results, compact the prefix into a handoff
         summary when the window would overflow. Runs BEFORE the model call,
         costs nothing when the context is small (a chars/4 estimate). */
      await maintainContext(p, state, (ev) => emit(p.runId, ev as never), (msgs) => complete(p, msgs, controller.signal, () => {}));

      if (step > 0) await emit(p.runId, { type: "status", line: "thinking with the results…" });

      /* ——— the model call, wrapped in TTSR + steer-kick + fallback ——— */
      let raw = "";
      try {
        raw = await completeGuarded(p, state, handle, ttsrRules, (delta) => {
          state.outChars += delta.length;
          if (state.outChars > MAX_OUTPUT_CHARS) controller.abort(); // stop runaway generation
        });
      } catch (err) {
        if (controller.signal.aborted) throw err; // real abort — let it fly
        if (err instanceof TtsrCut) {
          /* ————— TTSR: the stream went off-script — cut, inject, retry same point ————— */
          state.ttsrRetries += 1;
          if (state.ttsrRetries > TTSR_MAX_RETRIES) {
            await emit(p.runId, { type: "ttsr", rule: err.rule.row.name, matched: err.matched.slice(0, 60) });
            await emit(p.runId, { type: "status", line: `stream rule "${err.rule.row.name}" fired twice — continuing with the reminder in context` });
            state.messages.push({ role: "user", content: `[system reminder — rule "${err.rule.row.name}"] ${err.rule.row.reminder}` });
            continue; // give the model one more shot WITH the rule in context
          }
          await emit(p.runId, { type: "ttsr", rule: err.rule.row.name, matched: err.matched.slice(0, 60) });
          await emit(p.runId, { type: "status", line: `stream rule "${err.rule.row.name}" cut the reply — regenerating` });
          state.messages.push({ role: "user", content: `[system-interrupt reason="rule_violation" rule="${err.rule.row.name}"] Your reply was cut mid-stream because it matched this rule. Start the reply over and follow the reminder:\n${err.rule.row.reminder}` });
          state.stepsTaken = step; // the retry IS this step — no budget consumed
          step--;
          continue;
        }
        if (err instanceof SteerKick) {
          state.steerKicks += 1;
          if (state.steerKicks > STEER_KICK_MAX) {
            await emit(p.runId, { type: "status", line: "steering is arriving faster than I can think — holding the rest for the next run" });
            continue; // let the normal drain handle the queue
          }
          await emit(p.runId, { type: "status", line: "steering heard — restarting this step with it" });
          state.stepsTaken = step;
          step--;
          continue;
        }
        throw err; // a real brain error — the outer catch (or fallback inside completeGuarded) handles it
      }

      // parse the protocol progressively → events + tools
      const parser = new ProtocolParser();
      const pendingTools: { name: string; args: Record<string, unknown> }[] = [];
      let sayText = "";
      let actionCount = 0; // tools + screens emitted this step — the nudge trigger

      for (const chunk of sliceForStreaming(raw)) {
        const { sayDelta, newActions } = parser.feed(chunk);
        if (sayDelta) {
          sayText += sayDelta;
          await emit(p.runId, { type: "say", text: sayDelta });
        }
        for (const rawAct of newActions) {
          const tool = asToolCall(rawAct);
          if (tool) {
            actionCount++;
            pendingTools.push(tool);
            if (tool.name === "remember") {
              const a: FotraAction = { type: "remember", fact: String(tool.args.fact ?? ""), topic: String(tool.args.topic ?? "facts") };
              await emit(p.runId, { type: "action", action: a });
            } else if (tool.name === "forget") {
              const a: FotraAction = { type: "forget", match: String(tool.args.match ?? "") };
              await emit(p.runId, { type: "action", action: a });
            }
            continue;
          }
          const action = coerceAction(rawAct);
          if (!action) continue;
          actionCount++;
          if (action.type === "react") state.reacted = action.emoji;
          // a bare persona/theme action is still a change to itself — route it through the soul so it is
          // validated, journaled and undoable like any other self-edit
          if (action.type === "persona" || action.type === "theme") {
            const patch = action.type === "theme" ? { coat: action.value } : (action.patch as Record<string, unknown>);
            const edit = await selfEdit({ persona: patch, why: "asked in passing" }, self).catch(() => null);
            if (edit?.ok) {
              for (const a of edit.actions) {
                if (a.type === "persona") self.persona = { ...self.persona, ...a.patch };
                await emit(p.runId, { type: "action", action: a });
              }
              const sid = `s-${p.runId.slice(-8)}-${state.stepsTaken}-${++stepSeq}`;
              await emit(p.runId, {
                type: "step",
                step: { id: sid, tool: "self_edit", kind: "self", title: "Changing itself", status: "done", summary: `changed ${edit.changes.length} thing${edit.changes.length === 1 ? "" : "s"} about itself`, ms: 0, data: { changes: edit.changes, editId: edit.editId } },
              });
            }
            continue;
          }
          if (action.type === "screen") state.screenComponents.add(action.component);
          const grounded = groundAction(action, state.evidence);
          if (!grounded.keep) continue;
          if (grounded.statusLine) await emit(p.runId, { type: "status", line: grounded.statusLine });
          await emit(p.runId, { type: "action", action: grounded.action });
          // client-style remember/forget ALSO persists server-side — one truth, both stores
          if (action.type === "remember") {
            pendingTools.push({ name: "remember", args: { fact: action.fact, topic: action.topic ?? "facts" } });
          } else if (action.type === "forget") {
            pendingTools.push({ name: "forget", args: { match: action.match } });
          } else if (action.type === "ask" && !action.resume) {
            pendingTools.push({ name: "ask_user", args: { question: action.question, options: action.options ?? [] } });
          }
        }
      }
      const fin = parser.finish();
      if (fin.say && parser.plainText && !sayText) {
        sayText = fin.say; // protocol-ignoring model — degrade to plain speech
        await emit(p.runId, { type: "say", text: fin.say });
      }
      state.assistantText = (state.assistantText + " " + sayText).trim();

      /* ————— context tools: checkpoint / rewind (event-log surgery, no side effects) ————— */
      const checkpointCall = pendingTools.find((c) => c.name === "checkpoint");
      const rewindCall = pendingTools.find((c) => c.name === "rewind");
      if (checkpointCall) {
        const label = String(checkpointCall.args.label ?? "").slice(0, 60) || `step ${state.stepsTaken}`;
        state.checkpoint = { atLen: state.messages.length, label };
        actionCount++;
        await emit(p.runId, { type: "checkpoint", label });
        await emit(p.runId, { type: "tool", name: "checkpoint", summary: `context checkpoint set (${label})`, ok: true });
        pendingTools.splice(pendingTools.indexOf(checkpointCall), 1);
      }
      if (rewindCall && state.checkpoint) {
        const report = String(rewindCall.args.report ?? "").slice(0, 1500) || sayText.slice(0, 800);
        const kept = state.checkpoint.atLen;
        const dropped = state.messages.length - kept;
        state.messages = [...state.messages.slice(0, kept), { role: "user", content: `[context rewind to "${state.checkpoint.label}"] The explored branch was collapsed. Report of what happened and was learned:\n${report}` }];
        state.checkpoint = null;
        actionCount++;
        await emit(p.runId, { type: "rewind", toCheckpoint: label(state), kept, dropped });
        await emit(p.runId, { type: "tool", name: "rewind", summary: `context rewound — ${dropped} messages collapsed into a report`, ok: true });
        pendingTools.splice(pendingTools.indexOf(rewindCall), 1);
      }

      /* harness nudge: the user explicitly demanded tool work or named
         artifacts (board/chart/table) but the model described instead of
         doing — correct deterministically, with escalation. This is the
         difference between a harness and a hopeful prompt: we do not ship
         an action-less reply to an action-shaped ask. */
      const expected = expectedArtifacts(p.text); // {"board","chart",…}
      const delivered = deliveredArtifacts(state, pendingTools); // what this run actually showed
      const missing = [...expected].filter((a) => !delivered.has(a));
      const demands = userDemandsTools(p.text) || expected.size > 0;
      // "Let me check…" with nothing after it is a promise, not a reply: the user should never have to say "go on"
      const announced = actionCount === 0 && announcesWork(state.assistantText);
      const needsFullNudge = actionCount === 0 && (demands || announced);
      const needsArtifactNudge = missing.length > 0 && actionCount > 0 && state.nudges < 2;
      if ((needsFullNudge || needsArtifactNudge) && state.nudges < 2 && (demands || announced)) {
        state.nudges += 1;
        state.assistantText = ""; // the retry re-speaks — don't double the transcript
        await emit(p.runId, { type: "say_reset" });
        state.messages.push({ role: "assistant", content: raw.slice(0, 4000) });
        const wanted = demandedToolName(p.text);
        state.messages.push({
          role: "user",
          content: needsFullNudge
            ? state.nudges === 1
              ? '[harness] You announced the work but emitted no actions. Emit them NOW — one or more {"type":"tool",…} tool calls and/or {"type":"screen",…} screen entries in this reply\'s "actions" array, with only a one-line say bridge before them. The named tool or screen component exists in your instructions.'
              : `[harness] FINAL CORRECTION. Your reply MUST be exactly this JSON shape — fill the real tool call (or screen component + props for what was asked) and real arguments yourself:\n{"say": "<one short line>", "actions": [{"type": "tool", "name": "${wanted ?? "web_search"}", "args": { … }}]}\nNo prose outside the JSON. The action is mandatory.`
            : `[harness] Partial delivery: the user asked for ${[...expected].join(" + ")} and you only delivered ${[...delivered].join(", ") || "none"}. Emit the MISSING artifact${missing.length > 1 ? "s" : ""} (${missing.join(", ")}) now as another entry in this reply's "actions" — one say line, then the missing screen${missing.length > 1 ? "s" : ""} only.`,
        });
        await emit(p.runId, { type: "status", line: needsFullNudge ? "no actions emitted — asking again" : `missing ${missing.join(", ")} — asking again` });
        continue; // re-loop: the model gets a corrective turn (step already consumed)
      }

      // artifact nudge spent but still missing pieces — note it honestly, ship what exists
      if (missing.length > 0 && state.nudges >= 2) {
        await emit(p.runId, { type: "status", line: `couldn't produce the ${missing.join(" / ")} — saying so` });
      }

      /* ————— the ADVISOR pass (omp: a second model watching every turn) —————
         Runs after the step's reply exists, before tool dispatch when possible —
         the note injects into the NEXT model call. Never breaks the run. */
      const toolLines = pendingTools.map((c) => `${c.name}(pending)`);
      if (state.advisorSpent < advisorBudget() && (sayText || toolLines.length > 0)) {
        state.advisorSpent += 1;
        const note = await adviseStep({ userText: p.text, reply: sayText || raw.slice(0, 800), toolLines, brain: p.brain });
        if (note) {
          const injection = await deliverNote(note, makeCtx().emit);
          state.advisorNotes.push(injection);
        }
      }

      if (pendingTools.length === 0) {
        // a blocker note with no more steps planned → force the corrective turn
        if (state.advisorNotes.length > 0 && state.stepsTaken < state.stepsAllowed && String(state.advisorNotes[0]).includes("BLOCKER")) {
          state.stepsTaken = step;
          step--;
          continue;
        }
        break; // plain answer — done
      }

      /* ————————————————————————————————————————
         EXECUTE THE TOOL BATCH — in parallel.
         Partition: ask_user (suspends last) ·
         spawn_task (grouped into parallel workers) ·
         checkpoint/rewind (already handled) ·
         everything else through the STOLEN omp
         shared/exclusive scheduler: reads run
         concurrently, writes serialize behind the
         last exclusive call, results emit in batch
         order (agent-loop.ts L3768–3794).
         ———————————————————————————————————————— */
      const askCall = pendingTools.find((c) => c.name === "ask_user");
      const spawnCalls = pendingTools.filter((c) => c.name === "spawn_task" && String(c.args.task ?? "").trim());
      const otherCalls = pendingTools.filter((c) => c.name !== "ask_user" && c.name !== "spawn_task" && c.name !== "checkpoint" && c.name !== "rewind");
      const toolMsgs: Msg[] = [];

      // omp's concurrency declarations, ported: tools that mutate shared state are EXCLUSIVE
      // (serialize behind all prior work); pure reads/queries are SHARED (concurrent with each
      // other, but still behind the last exclusive). This is what makes parallel reads +
      // serialized writes safe with zero locks.
      const EXCLUSIVE_TOOLS = new Set([
        "ws_write", "ws_patch", "run_js", "run_python", "kernel_reset", "todo_write", "learn",
        // one browser, one cursor: its actions happen in the order they were asked for
        "browser_navigate", "browser_click", "browser_type", "browser_scroll", "browser_back", "browser_extract", "browser_handoff",
        "self_edit", "routine_create", "routine_delete",
      ]);

      const execOne = async (call: { name: string; args: Record<string, unknown> }, slot: number, slots: (Msg | undefined)[]): Promise<void> => {
        const put = (m: Msg) => { slots[slot] = m; }; // in-order emission — providers require tool_use/tool_result ordering
        // atomic budget claim (sync check + increment — safe under concurrency)
        const used = budget.counts[call.name] ?? 0;
        if (toolBudgetLeft(budget, call.name) <= 0) {
          put({ role: "user", content: `TOOL RESULT for ${call.name} (refused): budget for this tool is spent this run — continue without it.` });
          return;
        }
        budget.counts[call.name] = used + 1;
        // the step opens the moment the call starts — its surface is what the user watches while it runs
        const stepId = `s-${p.runId.slice(-8)}-${state.stepsTaken}-${++stepSeq}`;
        const look = describeStep(call.name, call.args);
        await emit(p.runId, {
          type: "step",
          step: { id: stepId, tool: call.name, kind: look.kind, title: look.title, subject: look.subject, status: "running", data: stepSeed(call.name, call.args) },
        });
        const t0 = Date.now();
        const res = await runTool(call.name, call.args, makeCtx(stepId));
        const ms = res.ms ?? Date.now() - t0;
        state.usedTools.push(call.name);
        state.evidence += ` ${JSON.stringify(res.data).toLowerCase()}`;
        await emit(p.runId, { type: "step", step: { id: stepId, status: res.ok ? "done" : "error", summary: res.summary, ms, ...(res.view ? { data: res.view } : {}) } });
        await emit(p.runId, { type: "tool", name: call.name, summary: res.summary, ok: res.ok, ms });
        if (res.screen) await emit(p.runId, { type: "action", action: res.screen }); // the ui payload — the pi llm/ui split
        for (const a of res.actions ?? []) await emit(p.runId, { type: "action", action: a }); // client-side effects (a self-edit re-skinning the app)
        await db.toolCall
          .create({
            data: { runId: p.runId, name: call.name, args: JSON.stringify(call.args).slice(0, 4000), result: JSON.stringify(res.data).slice(0, 12000), ok: res.ok, ms },
          })
          .catch(() => undefined);
        put({ role: "user", content: `TOOL RESULT for ${call.name} (${res.ok ? "ok" : "failed"}):\n${JSON.stringify(res.data).slice(0, 9000)}` });
      };

      // regular tools — the omp scheduler, verbatim in spirit: exclusive calls chain through
      // lastExclusive, shared calls ride behind lastExclusive but alongside each other.
      // Execution overlaps; results land in slots so the batch order is preserved.
      if (otherCalls.length > 0) {
        if (otherCalls.length > 1) await emit(p.runId, { type: "status", line: `${otherCalls.length} tools in parallel…` });
        const slots: (Msg | undefined)[] = new Array(otherCalls.length).fill(undefined);
        let lastExclusive: Promise<void> = Promise.resolve();
        let sharedTasks: Promise<void>[] = [];
        const tasks: Promise<void>[] = [];
        for (let i = 0; i < otherCalls.length; i++) {
          const call = otherCalls[i];
          const exclusive = EXCLUSIVE_TOOLS.has(call.name);
          const start = exclusive ? Promise.all([lastExclusive, ...sharedTasks]) : lastExclusive;
          const task = start.then(() => execOne(call, i, slots));
          tasks.push(task);
          if (exclusive) {
            lastExclusive = task;
            sharedTasks = [];
          } else {
            sharedTasks.push(task);
          }
        }
        try {
          await Promise.allSettled(tasks);
        } finally {
          // whatever happened, every unfulfilled call still gets a paired result (omp's synthetic-result discipline)
          for (let i = 0; i < otherCalls.length; i++) {
            if (!slots[i]) {
              slots[i] = { role: "user", content: `TOOL RESULT for ${otherCalls[i].name} (interrupted): no result — the call was cut short; continue without it.` };
            }
          }
        }
        for (const m of slots) if (m) toolMsgs.push(m);
      }

      // sub-agents — the group runs as parallel workers (typed yields when schema given)
      if (spawnCalls.length > 0 && !controller.signal.aborted) {
        const claimable = spawnCalls.filter(() => toolBudgetLeft(budget, "spawn_task") > 0);
        for (const c of claimable) budget.counts["spawn_task"] = (budget.counts["spawn_task"] ?? 0) + 1;
        if (claimable.length > 0) {
          const specs: WorkerSpec[] = claimable.map((c, i) => ({
            name: String(c.args.name ?? `worker-${i + 1}`).slice(0, 24),
            task: String(c.args.task ?? "").slice(0, 800),
            outputSchema: parseOutputSchema(c.args.outputSchema), // the omp typed-result contract
          }));
          await emit(p.runId, { type: "status", line: claimable.length > 1 ? `spawning ${claimable.length} workers in parallel…` : "spawning a worker…" });
          const t0 = Date.now();
          const results = await spawnWorkers(specs, {
            sessionId: p.sessionId,
            parentRunId: p.runId,
            emit: makeCtx().emit,
            brain: p.brain,
            custom: p.custom,
            signal: controller.signal,
          });
          const ms = Date.now() - t0;
          for (const r of results) {
            state.usedTools.push("spawn_task");
            state.evidence += ` ${r.result.toLowerCase()} ${JSON.stringify(r.structured ?? "").toLowerCase()}`;
            await emit(p.runId, { type: "tool", name: `spawn_task:${r.name}`, summary: r.ok ? `${r.name} finished (${(r.ms / 1000).toFixed(0)}s)${r.structured ? " · yielded ✓" : ""}` : `${r.name} failed`, ok: r.ok, ms: r.ms });
            await db.toolCall
              .create({
                data: {
                  runId: p.runId,
                  name: `spawn_task:${r.name}`,
                  args: JSON.stringify({ task: specs.find((s) => s.name === r.name)?.task ?? "", outputSchema: specs.find((s) => s.name === r.name)?.outputSchema ?? null }).slice(0, 2000),
                  // structured (validated yield) FIRST — it's the machine-readable deliverable
                  result: (r.structured ? JSON.stringify(r.structured).slice(0, 4000) + "\n" : "") + r.result.slice(0, 8000),
                  ok: r.ok,
                  ms: r.ms,
                },
              })
              .catch(() => undefined);
            toolMsgs.push({
              role: "user",
              content: r.structured
                ? `WORKER RESULT from ${r.name} (VALIDATED JSON — read fields directly, cite as agent://${r.name}/<field>):\n${JSON.stringify(r.structured).slice(0, 9000)}\n(worker's one-liner: ${r.result.slice(0, 300)})`
                : `WORKER RESULT from ${r.name} (${r.ok ? "ok" : "failed"}):\n${r.result.slice(0, 9000)}`,
            });
          }
          if (results.length > 1) await emit(p.runId, { type: "status", line: `all ${results.length} workers are back` });
          void ms;
        }
      }

      // ask_user is surface-owned: it needs a HUMAN answer — suspend the run
      if (askCall && !controller.signal.aborted) {
        const question = String(askCall.args.question ?? "").trim() || "…";
        const options = (Array.isArray(askCall.args.options) ? askCall.args.options : []).filter((o): o is string => typeof o === "string");
        await db.toolCall
          .create({ data: { runId: p.runId, name: "ask_user", args: JSON.stringify({ question, options }).slice(0, 4000), result: '"suspended — waiting for the human"', ok: true, ms: 0 } })
          .catch(() => undefined);
        await suspend(p, state, { toolCallId: `ask-${p.runId}-${state.stepsTaken}`, question, options }, "ask");
        return;
      }

      if (toolMsgs.length === 0) break;

      // the model's request + results become the next context
      state.messages.push({ role: "assistant", content: raw.slice(0, 4000) });
      for (const tm of toolMsgs) state.messages.push(tm);

      if (state.outChars > MAX_OUTPUT_CHARS) {
        state.messages.push({ role: "user", content: "[budget] output cap reached — answer now with what you have, briefly." });
        break;
      }

      // step-budget guard: more work to do but the ceiling is reached → PAUSE, don't die
      if (state.stepsTaken >= state.stepsAllowed) {
        const question = "I'm at my step budget for this run.";
        const detail = `${state.stepsTaken} steps · ~${Math.round(state.outChars / 100) / 10}k chars so far — the run is paused, not dead.`;
        await emit(p.runId, {
          type: "action",
          action: { type: "ask", id: `budget-${p.runId}`, question, detail, options: ["continue", "stop", "finish quietly"], tone: "warn", resume: { runId: p.runId, kind: "budget" } },
        });
        await suspend(
          p,
          state,
          { toolCallId: `budget-${p.runId}`, question: `${question} ${detail} Say continue and I'll pick up where I left off.`, options: ["continue", "stop", "finish quietly"] },
          "budget"
        );
        return;
      }
    }

    const interrupted = controller.signal.aborted;
    await finalize(p, state, interrupted);
  } catch (err) {
    if (controller.signal.aborted) {
      await finalize(p, state, true);
    } else {
      const msg = err instanceof Error ? err.message : "the run broke";
      // undrained steering is never lost, even on failure
      if (handle.steer.length > 0) {
        await emit(p.runId, { type: "unsteered", texts: handle.steer.splice(0) });
      }
      await emit(p.runId, err instanceof BrainUnavailable ? { type: "error", message: "No model connected.", hint: msg } : { type: "error", message: "The model call failed.", hint: msg });
      await db.run.update({ where: { id: p.runId }, data: { status: "error", error: msg.slice(0, 500), endedAt: new Date() } }).catch(() => undefined);
    }
  } finally {
    // a finished run leaves the registry; a suspended/waiting one STAYS registered
    // until resumed or reaped — check the DB status to know which.
    const row = await db.run.findUnique({ where: { id: p.runId }, select: { status: true } }).catch(() => null);
    if (row?.status !== "waiting") handles.delete(p.runId);
  }
}

/** what a step can show before its tool has answered — the query being typed, the code about to run */
function stepSeed(name: string, args: Record<string, unknown>): Record<string, unknown> | undefined {
  if (name === "web_search") return { query: String(args.query ?? args.q ?? args.search ?? args.text ?? "").slice(0, 200) };
  if (name === "run_js" || name === "run_python") return { lang: name === "run_js" ? "js" : "python", code: String(args.code ?? "").slice(0, 2400) };
  if (name === "open_link") return { url: String(args.url ?? "").slice(0, 300) };
  if (name === "ws_write") return { path: String(args.path ?? ""), preview: String(args.content ?? "").slice(0, 600), wrote: true };
  if (name === "remember") return { fact: String(args.fact ?? "").slice(0, 200), topic: String(args.topic ?? "") };
  return undefined;
}

/** label helper for the rewind event */
function label(state: LoopState): string {
  return state.checkpoint?.label ?? "(inline)";
}

/* ————————————————————————————————————————————————
   THE GUARDED MODEL CALL — TTSR watcher + steer kick
   + brain fallback chain, one surface
   ———————————————————————————————————————————————— */
async function completeGuarded(
  p: RunParams,
  state: LoopState,
  handle: RunHandle,
  rules: CompiledRule[],
  onChars: (delta: string) => void
): Promise<string> {
  const order: Array<"fotra" | "custom" | "provider"> = [];
  const builtin = builtinBrainAvailable();
  const providerReady = !!resolveRole("chat");
  const primaryCooling = p.brain === "custom" ? brainCooling(`custom:${p.custom.baseUrl}`) : p.brain === "provider" ? brainCooling(`provider`) : false;
  if (!primaryCooling && (p.brain !== "fotra" || builtin)) order.push(p.brain);
  // the fallback chain: whatever else is actually wired on this machine
  if (p.brain !== "provider" && providerReady && !brainCooling("provider")) order.push("provider");
  if (p.brain !== "fotra" && builtin) order.push("fotra");
  if (order.length === 0) {
    throw new BrainUnavailable(
      p.brain === "fotra"
        ? "No model is connected yet. Open settings → brain and add any OpenAI-compatible endpoint, or switch to the demo brain."
        : "That model is cooling off after an error and there is no fallback wired — try again in a minute."
    );
  }

  let lastErr: unknown = null;
  for (let attempt = 0; attempt < order.length; attempt++) {
    const brain = order[attempt];
    const watcher = new StreamWatcher();
    let sawKick = false;
    try {
      const text = await complete(
        { ...p, brain },
        state.messages,
        handle.controller.signal,
        (delta) => {
          onChars(delta);
          // TTSR — SYNCHRONOUS per-delta matching: a throw from inside the
          // provider's chunk loop aborts the stream mid-token (BYO) or the
          // handoff (SDK) — before anything is emitted to the run
          watcher.feedAndCheck(delta, rules);
          // interrupt-steer: a queued steering message kicks the CURRENT call
          if (handle.steer.length > 0 && state.steerKicks < STEER_KICK_MAX) {
            sawKick = true;
          }
        }
      );
      if (sawKick) throw new SteerKick();
      if (attempt > 0) state.brainFallbackUsed = true;
      return text;
    } catch (err) {
      if (err instanceof TtsrCut || err instanceof SteerKick) throw err; // control flow — never falls back
      if (handle.controller.signal.aborted) throw err; // user abort — let it fly
      lastErr = err;
      // a real brain failure — cool the endpoint and walk the chain
      if (brain === "custom") coolBrain(`custom:${p.custom.baseUrl}`);
      if (brain === "provider") coolBrain("provider");
      if (attempt < order.length - 1) {
        await emit(p.runId, { type: "status", line: brain === p.brain ? `that model failed (${err instanceof Error ? err.message.slice(0, 60) : "error"}) — trying the fallback` : "retrying on the fallback brain" });
        continue;
      }
      throw err;
    }
  }
  throw lastErr ?? new Error("no brain answered");
}

/* ————————————————————————————————————————————————
   FINALIZE
   ———————————————————————————————————————————————— */

async function finalize(p: RunParams, state: LoopState, interrupted: boolean): Promise<void> {
  await db.turn
    .create({
      data: { id: p.assistantTurnId, sessionId: p.sessionId, role: "assistant", text: state.assistantText || (state.reacted ? `(reacted ${state.reacted} — no words needed)` : "(silent)"), interrupted },
    })
    .catch(() => undefined);
  await db.session.update({ where: { id: p.sessionId }, data: { lastAt: new Date() } }).catch(() => undefined);
  await db.run
    .update({ where: { id: p.runId }, data: { status: interrupted ? "interrupted" : "done", steps: state.stepsTaken, tokens: Math.round(state.outChars / 4), endedAt: new Date() } })
    .catch(() => undefined);
  // steering that never drained (the run ended first) is NOT lost — the client
  // restores these to its visible queue and they get their own run (§6.2)
  const h = handles.get(p.runId);
  if (h && h.steer.length > 0) {
    await emit(p.runId, { type: "unsteered", texts: h.steer.splice(0) });
  }
  await emit(p.runId, { type: "done", interrupted, usedTools: state.usedTools });
  enqueueCompact(p.sessionId, p.brain); // nap compression — fire and forget, never blocks the reply
}

/* ————————————————————————————————————————————————
   SUSPEND + RESUME — human-in-the-loop on one path
   for touch and voice (§6.2: surface-owned tools end
   the run; the surface resumes it with the answer)
   ———————————————————————————————————————————————— */

async function suspend(p: RunParams, state: LoopState, s: { toolCallId: string; question: string; options: string[] }, kind: "ask" | "budget"): Promise<void> {
  const rec: SuspensionRecord = { kind, toolCallId: s.toolCallId, question: s.question, options: s.options, params: p, state };
  await db.run.update({
    where: { id: p.runId },
    data: { status: "waiting", suspension: JSON.stringify(rec) },
  }).catch(() => undefined);
  await emit(p.runId, { type: "waiting", reason: kind });
  enqueueCompact(p.sessionId, p.brain);
}

/** resume a waiting run with the human's answer. Errors if the run moved on.
    `seed` subscribers are attached to the handle at claim time — no event
    can slip between resume and subscribe. */
export async function resumeRun(runId: string, answerRaw: string, seed?: Set<(ev: ServerEvent) => void>): Promise<{ ok: false; error: string } | { ok: true }> {
  const run = await db.run.findUnique({ where: { id: runId } });
  if (!run) return { ok: false, error: "run not found" };
  if (run.status !== "waiting") return { ok: false, error: `run is ${run.status}, not waiting` };
  let rec: SuspensionRecord;
  try {
    rec = JSON.parse(run.suspension ?? "{}") as SuspensionRecord;
  } catch {
    return { ok: false, error: "suspension record corrupt" };
  }
  const answer = answerRaw.trim().slice(0, 2000);
  if (!answer) return { ok: false, error: "answer required" };

  const p = rec.params;
  const state = reviveState(rec.state);
  const controller = new AbortController();
  const handle: RunHandle = { controller, steer: [], startedAt: Date.now(), subscribers: seed ?? new Set(), seq: runSeq(runId) };
  registerHandle(runId, handle); // order-safe: drains pending subscribers
  resetShotBudget(runId);

  // claim it — idempotent: a second resume sees "running"
  const claim = await db.run.updateMany({ where: { id: runId, status: "waiting" }, data: { status: "running", suspension: null } });
  if (claim.count === 0) {
    handles.delete(runId);
    return { ok: false, error: "run is no longer waiting" };
  }

  const norm = answer.toLowerCase();
  if (rec.kind === "budget") {
    if (/\bstop\b|abort|cancel/.test(norm)) {
      controller.abort();
      await finalize(p, state, true);
      handles.delete(runId);
      return { ok: true };
    }
    if (/finish|wrap|quiet/.test(norm)) {
      state.stepsAllowed = state.stepsTaken + 1;
      state.deadlineAt = Date.now() + 60_000; // one minute to wrap up
      state.messages.push({ role: "user", content: "[budget] user chose: finish quietly — wrap up now, briefly, with what you have." });
    } else {
      state.stepsAllowed = state.stepsTaken + RESUME_STEPS;
      state.deadlineAt = Date.now() + RUN_DEADLINE_MS; // continue buys fresh wall clock
      state.messages.push({ role: "user", content: "[budget] user chose: continue — pick up exactly where you left off." });
    }
  } else {
    // ask_user: the answer routes through the same path as a card click.
    // Voice consent is allow_once by design — nothing here grants standing permission.
    state.messages.push({ role: "user", content: `[answer to your question "${rec.question}"] ${answer}` });
    state.stepsAllowed = state.stepsTaken + 3;
  }
  await db.turn
    .create({ data: { id: `${runId}-ans-${Date.now().toString(36)}`, sessionId: p.sessionId, role: "user", text: answer, origin: "action" } })
    .catch(() => undefined);

  void runLoop(p, state); // continues under the same event log
  return { ok: true };
}

/* ————————————————————————————————————————————————
   GROUNDING — comparison screens may only cite
   evidence recorded THIS turn (the JEV lesson)
   ———————————————————————————————————————————————— */

function normText(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim();
}

function groundAction(action: FotraAction, evidence: string): { keep: boolean; action: FotraAction; statusLine?: string } {
  if (action.type !== "screen") return { keep: true, action };
  if (action.component !== "table" && action.component !== "hotel") return { keep: true, action };

  const corpus = normText(evidence);
  const cited = (v: unknown): boolean => {
    const t = normText(String(v ?? ""));
    return t.length < 5 || corpus.includes(t.slice(0, 60));
  };

  if (action.component === "table") {
    const rows = Array.isArray(action.props.rows) ? (action.props.rows as unknown[][]) : [];
    if (rows.length === 0) return { keep: true, action };
    if (!corpus) {
      return {
        keep: true,
        action: { ...action, component: "card", props: { title: String(action.props.title ?? "comparison"), body: "I built this from what I already knew — nothing from the live web this turn.", items: [] } },
        statusLine: "grounding: no web evidence this turn — showing a plain card instead",
      };
    }
    const kept = rows.filter((row) => Array.isArray(row) && row.some((cell) => cited(cell)));
    const dropped = rows.length - kept.length;
    if (dropped === 0) return { keep: true, action };
    if (kept.length === 0) {
      return {
        keep: true,
        action: { ...action, component: "card", props: { ...action.props, rows: undefined, body: "None of these rows traced back to this turn's sources." } },
        statusLine: "grounding: dropped every row — none traced to this turn's sources",
      };
    }
    return {
      keep: true,
      action: { ...action, props: { ...action.props, rows: kept } },
      statusLine: `grounding: dropped ${dropped} row${dropped > 1 ? "s" : ""} with no source this turn`,
    };
  }

  // hotel — each option must trace to the corpus (name or area)
  const options = Array.isArray(action.props.options) ? (action.props.options as Record<string, unknown>[]) : [];
  if (options.length === 0 || !corpus) return { keep: true, action };
  const kept = options.filter((o) => cited(o.name) || cited(o.area));
  const dropped = options.length - kept.length;
  if (dropped === 0) return { keep: true, action };
  if (kept.length === 0) return { keep: true, action, statusLine: "grounding: no option traced to this turn's sources — kept as-is, say so honestly" };
  return {
    keep: true,
    action: { ...action, props: { ...action.props, options: kept } },
    statusLine: `grounding: dropped ${dropped} option${dropped > 1 ? "s" : ""} with no source this turn`,
  };
}

/* ————————————————————————————————————————————————
   MESSAGE BUILDING — core memory block + skills +
   compaction + tools doc
   ———————————————————————————————————————————————— */

async function buildMessages(p: RunParams, opts?: { orchestrate?: boolean }) {
  const session = await db.session.findUnique({
    where: { id: p.sessionId },
    include: { memories: { orderBy: { ts: "desc" }, take: 30 } },
  });

  // the core block: what fotra knows, vault-sourced, capped (§6.5)
  const core = await vaultReadCore(p.sessionId);
  // learned skills fire on trigger — the omp `learn` loop, injected not hoped for
  const skills = await matchSkills(p.text);
  const skillsBlock = skills.length > 0 ? `\nLEARNED SKILLS (applies to this ask):\n${skills.map((s) => s.body).join("\n---\n").slice(0, 3000)}\n` : "";
  // the soul: standing instructions the agent wrote for itself when the user asked it to change
  const soul = await soulBlock();
  const look = `\nYOU RIGHT NOW: name "${p.persona.name}", face ${p.persona.mascot}, coat ${p.persona.coat}, aura ${p.persona.aura}, canvas ${p.mode === "light" ? "day" : "night"}; app density ${p.ui?.density ?? "cozy"}, width ${p.ui?.width ?? "normal"}, trail ${p.ui?.trail ?? "auto"}.\n`;
  const summaryBlock = session?.summary ? `\nCompacted memory of older conversation (before the recent window):\n${session.summary}\n` : "";
  const now = new Date();
  const datetime = now.toLocaleString("en-US", { weekday: "short", year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });

  const tools = toolDoc(await mcpToolDoc());

  const system =
    PROTOCOL_DOC.replace("{{PERSONA_NAME}}", p.persona.name)
      .replace("{{PERSONA_TAGLINE}}", p.persona.tagline || "a voice-first personal agent")
      .replace("{{MEMORY}}", core)
      .replace("{{HISTORY}}", "(see conversation below)") +
    `

Current date & time: ${datetime}
${look}${soul}${summaryBlock}${skillsBlock}
TOOLS — fotra is a full harness: you can search the web, read pages, run real code in persistent kernels, drive a real browser the user watches live, edit workspace files by content-hash anchors, spawn parallel worker agents with typed yields, keep a visible task board, schedule routines that run while the user is away, change yourself, checkpoint/rewind your own context, and use the user's MCP tools. Call them inside "actions" with a short spoken bridge ("let me check that…"), then STOP — you'll be called again with the results:
${tools}

Tool doctrine:
- CODE IS FOR DETERMINISM, KERNELS ARE FOR STATE: anything numeric, algorithmic, or data-shaped → run_js / run_python. Kernels PERSIST across calls (variables survive) and can call your own tools from inside a cell: tool("web_search", query="…"), web_search("…"), read_file("…"), write_file("…"). Files land in the user's workspace.
- THE BROWSER IS FOR DOING THINGS ON REAL SITES: booking, checking live prices or availability, filling a form, anything a search snippet can't settle. Also reach for it — without being asked — when the user points at a specific site or account ("what did X post", "check their page", a URL), when the answer is minutes old, or when web_search fails or comes back thin: browser_navigate straight to the page instead of searching again or giving up. If a page puts a CAPTCHA, a human check or a sign-in wall in the way, do not fight it and do not give up: call browser_handoff — a real window opens on the user's screen, they do that one step, say "done", and you carry on signed in. The user watches a live window with your cursor in it. Work in small steps: browser_navigate → read the returned \`elements\` list → browser_type / browser_click BY NUMBER → read the new list → repeat. One browser action per reply (each needs the page state from the last). Stop and ask_user before anything that spends money, submits personal details, or can't be undone — then hand off with open_link.
- CHANGING YOURSELF IS A TOOL: when the user tells you to behave, look, sound or be laid out differently ("be blunter", "stop using emoji", "go compact", "wear the ice coat", "call yourself Nova", "always answer in Spanish") call self_edit — never just promise to. Behavior goes in instructions.add as a short imperative you will read in every future prompt. "Undo that" → self_edit {"undo":true}.
- ROUTINES ARE FOR "EVERY…": anything recurring or "keep an eye on" → routine_create; it runs as a full agent run on schedule and the answer lands in the thread.
- WORKERS ARE FOR PARALLELISM + TYPED RESULTS: multiple independent subtasks → several spawn_task calls in ONE reply. Give outputSchema ({"required":["field"],"properties":{"field":"string"}}) and the worker's yield comes back as validated JSON you cite as agent://<name>/<field>.
- FILES ARE FOR DURABLE OUTPUT: ws_write deliverables; ws_read returns a #tag — ws_patch with {"path","tag","ops":[{line,replace}|{line,delete:true}|{after,insert}]} anchors to exactly what you read; a stale tag is caught before corruption.
- THE BOARD IS FOR MULTI-STEP WORK: 3+ steps → todo_write first, update as you go.
- MEMORY: remember facts when told; recall for scored retrieval; learn {"lesson"} captures a reusable skill that auto-fires on matching future asks.
- CHECKPOINT BEFORE EXPLORING: for long tool chains, checkpoint {} first; when the exploration paid off, rewind {"report":"…"} collapses the detour into a report and frees context.
- ASK WHEN BLOCKED: genuinely need the user's choice → ask_user — the run pauses and their answer resumes it.
- One tool batch per reply. After results arrive, ANSWER the user (more tool calls only if truly needed — multi-step browser work is the exception: keep going until the task is actually done).
- Never invent current facts. If a tool fails or is budgeted out, say so plainly and answer with what you have.
- COMPARISON TABLES AND HOTEL CARDS ARE GROUNDED: rows/options that don't trace back to this turn's tool results get dropped.
- Prefer tools over guessing anything time-sensitive (news, prices, scores, "today", "latest").${
      opts?.orchestrate
        ? `\n\n[orchestrate] This ask wants orchestration: break it into independent subtasks, fan them out as parallel spawn_task workers (with typed outputSchema when the results are structured), then synthesize. Verify each phase before relying on it.`
        : ""
    }`;

  const msgs: Msg[] = [{ role: "system", content: system }];
  for (const t of p.history.slice(-RECENT_WINDOW)) {
    if (!t.text?.trim() || t.origin === "system" || t.origin === "voice-call") continue;
    msgs.push({ role: t.role === "user" ? "user" : "assistant", content: t.text });
  }
  // reactions are feedback: the user tapped an emoji on something you said since the last run
  const fb = (p.feedback ?? []).filter((f) => f && typeof f.emoji === "string").slice(-4);
  const fbBlock =
    fb.length > 0
      ? `<system-notice>\nSince your last reply the user reacted to your messages:\n${fb
          .map((f) => `- ${f.emoji}${f.note ? ` ("${String(f.note).slice(0, 80)}")` : ""} on: "${String(f.excerpt).replace(/\s+/g, " ").slice(0, 140)}"`)
          .join("\n")}\nTake it on board without making a speech about it. If a negative reaction points at a habit (too long, wrong tone, wrong format), fix the habit — and if it is clearly a lasting preference, record it with self_edit instructions.add.\n</system-notice>\n`
      : "";
  msgs.push({ role: "user", content: fbBlock + p.text });
  return msgs;
}

/** the omp outputSchema contract, parsed defensively from model args */
function parseOutputSchema(v: unknown): OutputSchema | undefined {
  if (!v || typeof v !== "object") return undefined;
  const o = v as { required?: unknown; properties?: unknown };
  const properties: Record<string, "string" | "number" | "boolean" | "object" | "array"> = {};
  if (o.properties && typeof o.properties === "object") {
    for (const [k, t] of Object.entries(o.properties as Record<string, unknown>)) {
      if (t === "string" || t === "number" || t === "boolean" || t === "object" || t === "array") properties[k] = t;
    }
  }
  const required = Array.isArray(o.required) ? o.required.filter((r): r is string => typeof r === "string") : Object.keys(properties);
  if (Object.keys(properties).length === 0) return undefined;
  return { required, properties };
}

/** mask code spans/fences so magic keywords only fire in prose (omp rule) */
function maskCode(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/`[^`\n]*`/g, " ");
}

/* upsert the client's recent turns by id — no duplicates, no divergence */
async function persistHistory(sessionId: string, history: Turn[]) {
  for (const t of history.slice(-RECENT_WINDOW)) {
    if (!t.id || !t.text?.trim()) continue;
    await db.turn
      .upsert({
        where: { id: t.id },
        create: { id: t.id, sessionId, role: t.role, text: t.text.slice(0, 8000), origin: t.origin ?? null, interrupted: t.interrupted ?? false },
        update: { text: t.text.slice(0, 8000), interrupted: t.interrupted ?? false },
      })
      .catch(() => undefined);
  }
}

/* ————————————————————————————————————————————————
   BRAINS — three adapters, one contract
   (ultrathink enables thinking on the sdk brain)
   ———————————————————————————————————————————————— */

async function complete(
  p: RunParams,
  messages: Msg[],
  signal: AbortSignal,
  onChunk: (delta: string) => void
): Promise<string> {
  if (p.brain === "fotra") {
    // 429-resilient SDK call: exponential backoff (2s/5s/10s) — transient
    // rate limits get absorbed instead of erroring the run. There is no
    // fallback below the sdk brain, so the backoff IS the resilience.
    const BACKOFFS = [2000, 5000, 10000];
    let lastErr: unknown = null;
    for (let attempt = 0; attempt <= BACKOFFS.length; attempt++) {
      if (signal.aborted) throw new Error("aborted");
      try {
        const aborted = new Promise<never>((_, rej) => {
          signal.addEventListener("abort", () => rej(new Error("aborted")), { once: true });
        });
        const timeout = new Promise<never>((_, rej) => {
          setTimeout(() => rej(new Error("the brain didn't answer in time (90s)")), 90_000);
        });
        const res = await Promise.race([
          (await zaiClient()).chat.completions.create({
            messages: messages as never,
            // ultrathink (omp magic keyword): the highest supported thinking effort
            thinking: p.text && /\bultrathink\b/.test(maskCode(p.text)) ? { type: "enabled" } : { type: "disabled" },
          }),
          aborted,
          timeout,
        ]);
        const text = res.choices[0]?.message?.content ?? "";
        if (!text.trim() && !signal.aborted) throw new Error("empty reply from the brain");
        onChunk(text);
        return text;
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        lastErr = err;
        const rateish = /429|too many requests|rate limit/i.test(msg);
        if (rateish && attempt < BACKOFFS.length && !signal.aborted) {
          await new Promise((r) => setTimeout(r, BACKOFFS[attempt]));
          continue;
        }
        throw err;
      }
    }
    throw lastErr ?? new Error("the brain didn't answer");
  }
  if (p.brain === "provider") {
    const role = resolveRole("chat");
    if (!role) throw new Error("providers.json has no resolvable chat role — set roles.chat and its key in .env.local");
    const aborted = new Promise<never>((_, rej) => {
      signal.addEventListener("abort", () => rej(new Error("aborted")), { once: true });
    });
    const res = await Promise.race([
      completeRole(role, messages),
      aborted,
      new Promise<never>((_, rej) => setTimeout(() => rej(new Error("provider didn't answer in time (60s)")), 60_000)),
    ]);
    if (!res.trim() && !signal.aborted) throw new Error("empty reply from the provider");
    onChunk(res);
    return res;
  }
  return byoCompleteStream(p.custom, messages, signal, onChunk);
}

async function byoCompleteStream(
  custom: RunParams["custom"],
  messages: Msg[],
  signal: AbortSignal,
  onChunk: (delta: string) => void
): Promise<string> {
  if (!custom.baseUrl.trim() || !custom.model.trim()) {
    throw new Error("no endpoint configured — Settings → brain");
  }
  const url = chatUrl(custom.baseUrl);
  const headers: Record<string, string> = { "Content-Type": "application/json", ...authHeaders(custom.baseUrl, custom.apiKey) };

  let res: Response;
  try {
    res = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify({ model: custom.model, messages, temperature: custom.temperature ?? 0.7, stream: true }),
      signal: AbortSignal.any([signal, AbortSignal.timeout(120_000)]),
    });
  } catch (err) {
    if (signal.aborted) throw err;
    // say what is wrong and what to do, not "fetch failed"
    const f = explainThrown(err, custom.baseUrl);
    throw new Error(`${f.message} ${f.hint}`);
  }
  if (!res.ok || !res.body) {
    const f = await explainResponse(res, custom.baseUrl, { hadKey: !!custom.apiKey?.trim() });
    throw new Error(f.kind === "other" ? f.raw : `${f.message} ${f.hint} (${f.raw.slice(0, 160)})`);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let full = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data:")) continue;
      const payload = trimmed.slice(5).trim();
      if (!payload || payload === "[DONE]") continue;
      try {
        const obj = JSON.parse(payload) as { choices?: { delta?: { content?: string }; text?: string }[] };
        const t = obj.choices?.[0]?.delta?.content ?? obj.choices?.[0]?.text ?? "";
        // NOTE: onChunk runs OUTSIDE any try — a TtsrCut thrown by the stream
        // watcher must propagate (mid-token abort), never be swallowed as a
        // "malformed line"
        if (t) {
          full += t;
          onChunk(t);
        }
      } catch (err) {
        if (err instanceof TtsrCut || err instanceof SteerKick) throw err; // control flow — never "malformed"
        /* skip malformed line */
      }
    }
  }
  return full;
}

/* ————— utils ————— */

/** does this user message explicitly demand tool work? (nudge trigger —
    conservative: only fires on unmistakable tool intent) */
const TOOL_WORDS = /\b(spawn_task|run_js|run_python|browser_navigate|browser_click|browser_type|browser_extract|ws_write|ws_read|ws_list|ws_patch|web_search|todo_write|mcp_connect|recall|reflect|learn|checkpoint|rewind)\b/;
function userDemandsTools(text: string): boolean {
  const t = text.toLowerCase();
  if (/\b(use|call|run|spawn|open|browse|write|create|make)\b.*\b(tool|worker|workers|parallel)\b/.test(t)) return true;
  if (TOOL_WORDS.test(t)) return true;
  if (/\b(in parallel|both workers|two workers|several workers)\b/.test(t)) return true;
  return false;
}

/** the tool name the user explicitly named, if any */
function demandedToolName(text: string): string | null {
  const m = text.toLowerCase().match(TOOL_WORDS);
  return m ? m[1] : null;
}

/** distinct artifact nouns the user asked for, normalized to component keys */
function expectedArtifacts(text: string): Set<string> {
  const out = new Set<string>();
  const t = text.toLowerCase();
  if (/\bboard\b/.test(t)) out.add("board");
  if (/\bchart\b|\bgraph\b|\bplot\b/.test(t)) out.add("chart");
  if (/\btable\b/.test(t)) out.add("table");
  if (/\bchecklist\b/.test(t)) out.add("checklist");
  return out;
}

/** which asked-for artifacts the run has actually delivered so far */
function deliveredArtifacts(state: LoopState, pendingTools: { name: string }[]): Set<string> {
  const out = new Set<string>();
  if (state.screenComponents.has("todo") || pendingTools.some((t) => t.name === "todo_write")) out.add("board");
  if (state.screenComponents.has("chart")) out.add("chart");
  if (state.screenComponents.has("table")) out.add("table");
  if (state.screenComponents.has("checklist")) out.add("checklist");
  return out;
}

function normalizeUrl(base: string): string {
  let u = base.trim().replace(/\s+/g, "");
  if (!u) return "";
  if (!/^https?:\/\//i.test(u)) u = `https://${u}`;
  u = u.replace(/\/*$/, "");
  if (/\/chat\/completions$/.test(u)) return u;
  if (/\/(v\d+\w*|openai)$/.test(u)) return `${u}/chat/completions`;
  return `${u}/v1/chat/completions`;
}

function asToolCall(raw: unknown): { name: string; args: Record<string, unknown> } | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  if (o.type !== "tool") return null;
  if (typeof o.name !== "string") return null;
  return { name: o.name, args: (o.args && typeof o.args === "object" ? o.args : {}) as Record<string, unknown> };
}

/** slice text into small chunks so the client sees progressive rendering */
function sliceForStreaming(text: string): string[] {
  if (!text) return [];
  const chunks: string[] = [];
  const size = 48;
  for (let i = 0; i < text.length; i += size) chunks.push(text.slice(i, i + size));
  return chunks;
}

/** a reply that only promises work ("Let me check…", "I'll look that up") and then stops */
function announcesWork(say: string): boolean {
  const s = say.trim();
  if (!s || s.length > 260 || /\?\s*$/.test(s)) return false; // a question back to the user is a real reply
  return /\b(let me|lemme|i'?ll|i will|i'?m going to|going to|one sec|hang on|hold on|give me a (?:sec|moment|minute))\b[^.?!]{0,80}\b(check|look|search|find|dig|dive|pull|grab|fetch|see|try|fix|run|open|browse|scan|verify|get)\b/i.test(s);
}