import { readFileSync, statSync } from "node:fs";
import path from "node:path";

/* ————————————————————————————————————————————————
   FOTRA — providers.json (the BYO model layer, §6.6)
   The tracked file holds env-var NAMES and base URLs —
   never values. Keys live in .env.local (untracked).
   Boot validation names every error; a pasted sk- value
   in the tracked file hard-fails production (refuses to
   run half-configured) and loudly degrades in dev.
   ———————————————————————————————————————————————— */

export interface ProviderSpec {
  baseUrl: string;
  apiKeyEnv: string | null;
  defaultModel?: string;
}

export interface ProvidersFile {
  providers: Record<string, ProviderSpec>;
  roles: { chat?: string; small?: string };
}

export interface ResolvedProvider {
  id: string;
  baseUrl: string;
  apiKey: string; // resolved from env — "" for keyless-local
  model: string;
  keyless: boolean; // baseUrl set, no key needed (local servers)
}

const FILE = path.join(process.cwd(), "providers.json");

let cache: { mtime: number; parsed: ProvidersFile } | null = null;

export function loadProviders(): { ok: true; file: ProvidersFile } | { ok: false; error: string } {
  try {
    const mtime = statSync(FILE).mtimeMs;
    if (cache && cache.mtime === mtime) return { ok: true, file: cache.parsed };
    const raw = readFileSync(FILE, "utf8");
    const parsed = JSON.parse(raw) as ProvidersFile;

    if (!parsed || typeof parsed !== "object" || typeof parsed.providers !== "object" || !parsed.providers) {
      return { ok: false, error: "providers.json: missing \"providers\" object" };
    }
    // key hygiene — the whole point: no key-shaped values in the tracked file
    if (/\bsk-[A-Za-z0-9_\-]{8,}\b/.test(raw)) {
      return { ok: false, error: 'providers.json contains a pasted key (sk-…). Keys belong in .env.local — the tracked file holds env-var NAMES only. Refusing to run half-configured.' };
    }
    for (const [id, p] of Object.entries(parsed.providers)) {
      if (!p || typeof p.baseUrl !== "string" || !/^https?:\/\//.test(p.baseUrl)) {
        return { ok: false, error: `providers.json: provider "${id}" needs an http(s) baseUrl` };
      }
      if (p.apiKeyEnv !== null && typeof p.apiKeyEnv !== "string") {
        return { ok: false, error: `providers.json: provider "${id}" apiKeyEnv must be an env-var name or null` };
      }
    }
    for (const [role, ref] of Object.entries(parsed.roles ?? {})) {
      if (ref === null || ref === undefined) continue; // unset role — fine
      if (typeof ref !== "string" || !ref.includes("/")) {
        return { ok: false, error: `providers.json: role "${role}" must look like "provider/model"` };
      }
      const [pid] = ref.split("/");
      if (!parsed.providers[pid]) {
        return { ok: false, error: `providers.json: role "${role}" points at unknown provider "${pid}"` };
      }
    }
    cache = { mtime, parsed };
    return { ok: true, file: parsed };
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === "ENOENT") {
      return { ok: false, error: "providers.json not found — copy providers.example.json to start" };
    }
    return { ok: false, error: `providers.json invalid: ${err instanceof Error ? err.message : "parse error"}` };
  }
}

export function providersValid(): boolean {
  return loadProviders().ok;
}

/** status lights for the settings screen: which providers resolve, which roles are wired */
export function providersStatus() {
  const r = loadProviders();
  if (!r.ok) return { valid: false, error: r.error, providers: [], roles: {} as Record<string, string | null> };
  const file = r.file;
  const providers = Object.entries(file.providers).map(([id, p]) => {
    const key = p.apiKeyEnv ? (process.env[p.apiKeyEnv] ?? "").trim() : "";
    return {
      id,
      baseUrl: p.baseUrl,
      defaultModel: p.defaultModel ?? "",
      hasKey: !!key || p.apiKeyEnv === null, // null apiKeyEnv = keyless local
      keyless: p.apiKeyEnv === null,
      keyEnv: p.apiKeyEnv,
    };
  });
  const roles: Record<string, string | null> = {};
  for (const role of ["chat", "small"] as const) {
    const ref = file.roles?.[role];
    if (!ref) {
      roles[role] = null;
    } else {
      const [pid, model] = ref.split("/");
      const p = file.providers[pid];
      const key = p?.apiKeyEnv ? (process.env[p.apiKeyEnv] ?? "").trim() : "";
      roles[role] = p && (p.apiKeyEnv === null || key) ? `${pid}/${model ?? p.defaultModel}` : null;
    }
  }
  return { valid: true, error: "", providers, roles };
}

/** resolve a providers.json role to a concrete endpoint */
export function resolveRole(role: "chat" | "small"): ResolvedProvider | null {
  const r = loadProviders();
  if (!r.ok) return null;
  const ref = r.file.roles?.[role];
  if (!ref) return null;
  const [pid, model] = ref.split("/");
  const p = r.file.providers[pid];
  if (!p) return null;
  const apiKey = p.apiKeyEnv ? (process.env[p.apiKeyEnv] ?? "").trim() : "";
  if (p.apiKeyEnv && !apiKey) return null; // role set but key missing — not resolvable
  return { id: pid, baseUrl: p.baseUrl, apiKey, model: model || p.defaultModel || "", keyless: p.apiKeyEnv === null };
}

function normalizeUrl(base: string): string {
  let u = base.trim().replace(/\s+/g, "");
  if (!u) return "";
  u = u.replace(/\/*$/, "");
  if (/\/chat\/completions$/.test(u)) return u;
  if (/\/(v\d+\w*|openai)$/.test(u)) return `${u}/chat/completions`;
  return `${u}/v1/chat/completions`;
}

/** non-streaming completion against a providers.json role (memory/compaction/small work) */
export async function completeRole(
  p: ResolvedProvider,
  messages: { role: string; content: string }[]
): Promise<string> {
  if (!p.baseUrl.trim() || !p.model.trim()) throw new Error("provider role incomplete");
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (p.apiKey) headers.Authorization = `Bearer ${p.apiKey}`;
  const res = await fetch(normalizeUrl(p.baseUrl), {
    method: "POST",
    headers,
    body: JSON.stringify({ model: p.model, messages, temperature: 0.4, stream: false }),
    signal: AbortSignal.timeout(60_000),
  });
  if (!res.ok) throw new Error(`provider ${p.id} → ${res.status}`);
  const j = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  return j.choices?.[0]?.message?.content ?? "";
}

/** the "prove it" test call — a real 16-token run before you trust it */
export async function proveProvider(p: ResolvedProvider): Promise<{ ok: boolean; detail: string }> {
  try {
    const text = await completeRole(p, [
      { role: "system", content: "Reply with the single word: awake" },
      { role: "user", content: "status?" },
    ]);
    return { ok: !!text.trim(), detail: text.trim().slice(0, 80) || "empty reply" };
  } catch (err) {
    return { ok: false, detail: err instanceof Error ? err.message : "unreachable" };
  }
}
