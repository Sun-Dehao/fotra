import { existsSync } from "node:fs";
import path from "node:path";
import { homedir } from "node:os";
import ZAI from "z-ai-web-dev-sdk";

/* ————————————————————————————————————————————————
   The built-in brain (the z.ai SDK) only exists where
   its config file does. Everywhere else — any normal
   self-host — it is simply absent, and the harness has
   to know that up front instead of failing mid-run with
   a stack trace. One client, one honest availability
   check, shared by every module that used to build its own.
   ———————————————————————————————————————————————— */

export class BrainUnavailable extends Error {
  constructor(message = "no model is connected") {
    super(message);
    this.name = "BrainUnavailable";
  }
}

type Client = Awaited<ReturnType<typeof ZAI.create>>;
let client: Client | null = null;

export function builtinBrainAvailable(): boolean {
  if (process.env.FOTRA_DISABLE_BUILTIN === "1") return false;
  return [path.join(process.cwd(), ".z-ai-config"), path.join(homedir(), ".z-ai-config"), "/etc/.z-ai-config"].some((p) => {
    try {
      return existsSync(p);
    } catch {
      return false;
    }
  });
}

export async function zaiClient(): Promise<Client> {
  if (client) return client;
  if (!builtinBrainAvailable()) {
    throw new BrainUnavailable("the built-in brain isn't available on this machine — connect a model in settings → brain");
  }
  client = await ZAI.create();
  return client;
}
