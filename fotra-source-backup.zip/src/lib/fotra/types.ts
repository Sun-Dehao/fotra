/* ————————————————————————————————————————————————
   FOTRA — shared types
   The wire format is the product: the model says things
   and docks screens. Everything else serves that.
   ———————————————————————————————————————————————— */

export type Phase =
  | "idle"
  | "listening"
  | "thinking"
  | "speaking"
  | "working"
  | "error";

export type ThemeName = "verdant" | "ember"; // DEPRECATED as a setting — the wire value of the legacy "theme" action, now mapped onto the coat
export type ThemeMode = "dark" | "light"; // the canvas the accent rides on (next-themes drives data-mode)
export type Aura = "calm" | "pulse" | "spark"; // the halo — the mascot's ambient ring
export type MascotSkin = "dot" | "ghost" | "star" | "cat" | "bot" | "orb"; // the five faces: Dots-style plush, Muse-style capy-blob, oh-my-pi's π mark, a Grok-ish bot, and the pure orb
export type MascotCoat = "iris" | "verdant" | "ember" | "ice" | "rose" | "mono"; // the coat — THE skin: drives the app accent, orb mesh and face palette together
export type EngineMode = "fotra" | "custom" | "demo" | "provider";
export type VoiceMode = "browser" | "realtime";

export interface Persona {
  name: string;
  tagline: string;
  aura: Aura;
  mascot: MascotSkin; // the face it wears (settings can change it)
  coat: MascotCoat; // the coat it wears — explicit re-skin (orb mesh + face palette)
  voiceURI: string | null;
  voiceRate: number; // 0.6 – 1.4
  voicePitch: number; // 0.6 – 1.4
}

export interface Settings {
  mode: ThemeMode; // dark (default) | light — synced with next-themes (storageKey fotra.mode)
  engine: EngineMode;
  sessionId?: string; // server harness session (created on first server run)
  lastRunId?: string; // for reattach after reload
  lastSeq?: number; // last event seq seen for that run
  voiceMode: VoiceMode; // browser (Web Speech) | realtime (WebRTC, needs a server key)
  realtimeVoice: string; // provider voice name for realtime calls
  custom: {
    baseUrl: string;
    apiKey: string;
    model: string;
    temperature: number;
  };
  handsFree: boolean;
  voiceOutput: boolean;
  ui: UiPrefs;
}

export interface CustomProviderConfig {
  baseUrl: string;
  apiKey: string;
  model: string;
  temperature: number;
}

/* —— steps: one per tool call. A step is LIVE while its tool runs (its surface
   animates on the stage) and settles into a one-line receipt when it lands. —— */

export type StepKind =
  | "search" // web_search — the query types itself, sources fly in
  | "read" // open_link — a page being skimmed
  | "browser" // computer use — the live window with the ghost cursor
  | "code" // run_js / run_python — code in, output out
  | "memory" // remember / recall / reflect / learn / forget
  | "file" // workspace reads and writes
  | "worker" // spawn_task — a parallel sub-agent
  | "plan" // todo_write / checkpoint / rewind
  | "self" // self_edit — the agent changing itself
  | "schedule" // routines
  | "connect" // mcp
  | "other";

export type StepStatus = "running" | "done" | "error";

export interface Step {
  id: string;
  tool: string; // the tool's wire name ("web_search")
  kind: StepKind;
  title: string; // present tense while live ("Searching the web")
  subject?: string; // the query / url / file / target
  status: StepStatus;
  summary?: string; // the one-line receipt
  ms?: number;
  /** kind-specific payload the surface renders (results, code, output, diff…) */
  data?: Record<string, unknown>;
  ts: number;
}

/** one frame of computer use — what the agent's browser shows right now */
export interface BrowserFrame {
  url: string;
  title?: string;
  shot?: string; // image data URL
  /** where the agent is pointing, normalized 0..1 of the frame */
  cursor?: { x: number; y: number };
  act?: "navigate" | "click" | "type" | "scroll" | "read" | "back";
  note?: string; // "clicking “Search”"
  typed?: string; // text going into a field
  ts: number;
}

/** the live computer-use window — exists only while there is something to watch */
export interface BrowserStage {
  stepId: string | null;
  turnId: string | null;
  live: boolean; // an action is in flight
  demo?: boolean;
  frames: BrowserFrame[]; // capped history — the scrubber
  open: boolean; // the popup is on screen
  size: "pip" | "wide";
}

/* —— the timeline: an assistant turn is a sequence of blocks, in the order
   things actually happened — words, then work, then more words, then a screen —— */
export type TurnBlock =
  | { kind: "text"; text: string }
  | { kind: "steps"; ids: string[] }
  | { kind: "screen"; id: string };

export interface Reaction {
  emoji: string;
  by: "user" | "agent";
  note?: string; // "too long" — what was off, when the user says
  sent?: boolean; // already delivered to the agent as feedback
  ts: number;
}

export interface Turn {
  id: string;
  role: "user" | "assistant";
  text: string;
  origin?: "voice" | "text" | "action" | "system" | "voice-call";
  streaming?: boolean;
  interrupted?: boolean;
  ts: number;
  screenIds?: string[];
  note?: string; // e.g. "queued"
  blocks?: TurnBlock[]; // assistant turns: the interleaved timeline
  steps?: Record<string, Step>;
  reactions?: Reaction[];
  ms?: number; // how long the run took
  /** the whole reply was a tapback on your message — no words, so no bubble */
  tapOnly?: boolean;
}

/** how the app arranges itself — the agent can change these when asked ("make yourself compact") */
export interface UiPrefs {
  density: "cozy" | "compact";
  width: "narrow" | "normal" | "wide";
  trail: "auto" | "open" | "quiet"; // how much of the work it shows: live then folded · always open · receipts only
  stage: "pip" | "wide" | "off"; // the computer-use window
  suggestions: string[]; // the idle chips — empty = the built-in set
  greeting: string; // the idle line — empty = the built-in one
}

export const DEFAULT_UI: UiPrefs = {
  density: "cozy",
  width: "normal",
  trail: "auto",
  stage: "pip",
  suggestions: [],
  greeting: "",
};

export type ScreenKind =
  | "card"
  | "stat"
  | "table"
  | "checklist"
  | "hotel"
  | "ask"
  | "code" // sandbox run: lang, code, stdout, stderr, exit, ms, files
  | "browser" // browser computer frame: url, title, shot (data URL), text
  | "worker" // sub-agent card: name, task, phase (working|done|error), note
  | "todo" // the task board: items[{text,status}]
  | "files" // workspace file list: files[], highlight?
  | "chart" // data-ink chart: title, kind(bar|line), labels[], series[{name,values[]}]
  | "doc" // long-form: title, markdown — when the answer is more than a few spoken lines
  | "sources"; // what an answer stands on: items[{title,url,host,snippet}]

export type ScreenStatus = "streaming" | "live" | "retired" | "interrupted";

export interface ScreenInstance {
  id: string;
  component: ScreenKind;
  props: Record<string, unknown>;
  status: ScreenStatus;
  pinned: boolean;
  expanded: boolean;
  resolved?: string | null; // chosen option for ask screens
  building?: boolean; // progressive render in progress
  turnId?: string;
  demoData?: boolean;
  ts: number;
}

export type WidgetKind = "note" | "clock" | "todo" | "timer";

export interface WidgetInstance {
  id: string;
  kind: WidgetKind;
  props: Record<string, unknown>;
  ts: number;
}

export interface MemoryFact {
  id: string;
  fact: string;
  topic: string;
  origin: "user-told" | "agent-observed";
  ts: number;
}

export interface QueuedMessage {
  id: string;
  text: string;
  origin: "voice" | "text";
  ts: number;
  steered?: boolean; // already injected mid-run server-side
}

/* —— actions: what a model (or the demo brain) can do —— */

export type FotraAction =
  | { type: "screen"; id: string; component: ScreenKind; props: Record<string, unknown>; demoData?: boolean; building?: boolean }
  | { type: "screen-delta"; id: string; props: Record<string, unknown> }
  | { type: "persona"; patch: Partial<Persona> }
  | { type: "theme"; value: ThemeName }
  | { type: "remember"; fact: string; topic?: string }
  | { type: "forget"; match: string }
  | { type: "widget"; id: string; kind: WidgetKind; props: Record<string, unknown> }
  | { type: "unwidget"; id: string }
  | { type: "pin"; id?: string }
  | { type: "open_link"; url: string; label?: string }
  | { type: "react"; emoji: string } // a tapback on the user's message
  | { type: "ui"; patch: Partial<UiPrefs> } // the agent rearranging its own app
  | { type: "mode"; value: ThemeMode } // night / day
  | {
      type: "ask";
      id: string;
      question: string;
      detail?: string;
      options?: string[];
      tone?: "info" | "warn";
      /** when set, this ask suspends a server run — the answer resumes it (HITL) */
      resume?: { runId: string; kind: "ask" | "budget" };
    };

/* —— event stream between adapter and the loop —— */

export type AgentEvent =
  | { type: "say"; text: string }
  | { type: "status"; line: string }
  | { type: "action"; action: FotraAction }
  | { type: "tool"; name: string; summary: string; ok: boolean; ms?: number }
  | { type: "step"; step: StepPatch }
  | { type: "frame"; stepId: string; frame: Omit<BrowserFrame, "ts">; demo?: boolean }
  | { type: "latency"; ms: number }
  | { type: "done"; interrupted?: boolean }
  | { type: "error"; message: string; hint?: string };

/** a step as it travels the wire: the id plus whatever changed */
export type StepPatch = Partial<Omit<Step, "id" | "ts">> & { id: string };

/** one entry in the activity feed (the harness telemetry rail) */
export interface ToolActivity {
  id: string;
  name: string;
  summary: string;
  ok: boolean;
  ms?: number;
  ts: number;
}

export interface RunContext {
  text: string;
  userTurnId?: string;
  history: Turn[];
  persona: Persona;
  memory: MemoryFact[];
  settings: Settings;
  interruptedAt?: string | null;
  activeScreens: ScreenInstance[];
  signal: AbortSignal;
}

export interface ModelAdapter {
  id: string;
  label: string;
  respond(ctx: RunContext): AsyncGenerator<AgentEvent>;
}

export const DEFAULT_PERSONA: Persona = {
  name: "Fotra",
  tagline: "always awake, never bored",
  aura: "calm",
  mascot: "dot",
  coat: "verdant", // the signature phosphor green — the coat is the theme now
  voiceURI: null,
  voiceRate: 1.04,
  voicePitch: 1,
};

export const DEFAULT_SETTINGS: Settings = {
  mode: "dark",
  engine: "fotra",
  sessionId: "",
  lastRunId: "",
  lastSeq: 0,
  voiceMode: "browser",
  realtimeVoice: "alloy",
  custom: { baseUrl: "", apiKey: "", model: "", temperature: 0.7 },
  handsFree: false, // the mic opens when you ask it to — never on its own after a reply
  voiceOutput: true,
  ui: DEFAULT_UI,
};

export function uid(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}
