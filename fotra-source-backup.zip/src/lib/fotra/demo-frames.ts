"use client";

/* ————————————————————————————————————————————————
   DEMO FRAMES — pages for the demo brain's browser.
   The demo brain has no network, so when it "uses the
   computer" it drives a stand-in site drawn here as
   SVG (and the window is badged DEMO). The frames are
   real pictures with real coordinates: the cursor
   targets below are where those things actually are,
   so the choreography reads exactly like a live run.
   With a real model connected, none of this is used —
   the frames are screenshots of a real Chromium.
   ———————————————————————————————————————————————— */

export const FRAME_W = 1152;
export const FRAME_H = 720;

export interface DemoStay {
  name: string;
  area: string;
  price: number;
  rating: number;
  perks: string[];
}

interface Palette {
  paper: string;
  paper2: string;
  paper3: string;
  rule: string;
  ink: string;
  ink2: string;
  dim: string;
  glow: string;
  glowInk: string;
}

/** the site wears the app's current coat — read the live tokens */
function palette(): Palette {
  const fallback: Palette = {
    paper: "oklch(97% 0.004 152)",
    paper2: "oklch(94% 0.006 152)",
    paper3: "oklch(90% 0.01 152)",
    rule: "oklch(86% 0.01 152)",
    ink: "oklch(20% 0.01 152)",
    ink2: "oklch(34% 0.01 152)",
    dim: "oklch(52% 0.01 152)",
    glow: "oklch(56% 0.15 152)",
    glowInk: "oklch(98% 0.01 152)",
  };
  if (typeof document === "undefined") return fallback;
  const hue = getComputedStyle(document.documentElement).getPropertyValue("--f-hue").trim() || "152";
  // websites are bright: a light page in the coat's hue, whatever canvas the app is on
  return {
    paper: `oklch(98% 0.004 ${hue})`,
    paper2: `oklch(95.5% 0.008 ${hue})`,
    paper3: `oklch(92% 0.012 ${hue})`,
    rule: `oklch(87% 0.012 ${hue})`,
    ink: `oklch(22% 0.015 ${hue})`,
    ink2: `oklch(38% 0.015 ${hue})`,
    dim: `oklch(55% 0.012 ${hue})`,
    glow: `oklch(55% 0.16 ${hue})`,
    glowInk: `oklch(98.5% 0.01 ${hue})`,
  };
}

function esc(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function toUrl(svg: string): string {
  const b64 = typeof btoa !== "undefined" ? btoa(unescape(encodeURIComponent(svg))) : "";
  return `data:image/svg+xml;base64,${b64}`;
}

const FONT = `font-family="Inter, 'Segoe UI', system-ui, sans-serif"`;

function shell(p: Palette, body: string): string {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${FRAME_W}" height="${FRAME_H}" viewBox="0 0 ${FRAME_W} ${FRAME_H}">
<rect width="${FRAME_W}" height="${FRAME_H}" fill="${p.paper}"/>
<rect width="${FRAME_W}" height="64" fill="${p.paper}"/>
<line x1="0" y1="64" x2="${FRAME_W}" y2="64" stroke="${p.rule}"/>
<circle cx="52" cy="32" r="11" fill="${p.glow}"/>
<text x="72" y="39" ${FONT} font-size="20" font-weight="700" fill="${p.ink}">stays</text>
<text x="832" y="38" ${FONT} font-size="14" fill="${p.ink2}">Deals</text>
<text x="900" y="38" ${FONT} font-size="14" fill="${p.ink2}">Trips</text>
<text x="966" y="38" ${FONT} font-size="14" fill="${p.ink2}">Help</text>
<rect x="1030" y="18" width="84" height="30" rx="15" fill="none" stroke="${p.rule}"/>
<text x="1072" y="38" ${FONT} font-size="13" text-anchor="middle" fill="${p.ink}">Sign in</text>
${body}
<text x="${FRAME_W / 2}" y="702" ${FONT} font-size="11" text-anchor="middle" fill="${p.dim}">stand-in site drawn by the demo brain — connect a model and this window shows the real web</text>
</svg>`;
}

/* —— targets: where the cursor should go, normalized —— */
export const TARGET = {
  where: { x: 400 / FRAME_W, y: 331 / FRAME_H },
  search: { x: 862 / FRAME_W, y: 331 / FRAME_H },
  sortRating: { x: 388 / FRAME_W, y: 157 / FRAME_H },
  row: (i: number) => ({ x: 960 / FRAME_W, y: (258 + i * 140) / FRAME_H }),
  hold: { x: 878 / FRAME_W, y: 430 / FRAME_H },
} as const;

/** the landing page: a search box waiting for a city */
export function homeFrame(typedCity = ""): string {
  const p = palette();
  return toUrl(
    shell(
      p,
      `<text x="${FRAME_W / 2}" y="210" ${FONT} font-size="44" font-weight="700" text-anchor="middle" fill="${p.ink}">Find somewhere good to stay</text>
<text x="${FRAME_W / 2}" y="248" ${FONT} font-size="17" text-anchor="middle" fill="${p.dim}">Hotels, ryokans and pods — rated by people who slept there.</text>
<rect x="216" y="296" width="720" height="70" rx="35" fill="${p.paper}" stroke="${typedCity ? p.glow : p.rule}" stroke-width="${typedCity ? 2 : 1.5}"/>
<text x="252" y="322" ${FONT} font-size="11" letter-spacing="1.2" fill="${p.dim}">WHERE</text>
<text x="252" y="346" ${FONT} font-size="18" fill="${typedCity ? p.ink : p.dim}">${typedCity ? esc(typedCity) : "City or neighbourhood"}</text>
<line x1="560" y1="312" x2="560" y2="350" stroke="${p.rule}"/>
<text x="584" y="322" ${FONT} font-size="11" letter-spacing="1.2" fill="${p.dim}">WHEN</text>
<text x="584" y="346" ${FONT} font-size="18" fill="${p.ink2}">This weekend · 3 nights</text>
<rect x="800" y="306" width="124" height="50" rx="25" fill="${p.glow}"/>
<text x="862" y="337" ${FONT} font-size="16" font-weight="600" text-anchor="middle" fill="${p.glowInk}">Search</text>
${["Tokyo", "Lisbon", "Kyoto", "Paris", "Bali"]
  .map(
    (c, i) =>
      `<rect x="${306 + i * 112}" y="404" width="98" height="34" rx="17" fill="${p.paper2}"/><text x="${355 + i * 112}" y="426" ${FONT} font-size="14" text-anchor="middle" fill="${p.ink2}">${c}</text>`
  )
  .join("")}
${[0, 1, 2]
  .map(
    (i) =>
      `<rect x="${96 + i * 330}" y="490" width="300" height="160" rx="16" fill="${p.paper2}"/><rect x="${96 + i * 330}" y="490" width="300" height="96" rx="16" fill="${p.paper3}"/><rect x="${116 + i * 330}" y="606" width="150" height="10" rx="5" fill="${p.rule}"/><rect x="${116 + i * 330}" y="626" width="90" height="8" rx="4" fill="${p.rule}"/>`
  )
  .join("")}`
    )
  );
}

/** the results list — three stays, optionally sorted, one optionally highlighted */
export function resultsFrame(city: string, stays: DemoStay[], opts?: { sorted?: boolean; highlight?: number }): string {
  const p = palette();
  const rows = stays
    .slice(0, 3)
    .map((s, i) => {
      const y = 196 + i * 140;
      const hot = opts?.highlight === i;
      return `<rect x="56" y="${y}" width="1040" height="124" rx="16" fill="${hot ? p.paper2 : p.paper}" stroke="${hot ? p.glow : p.rule}" stroke-width="${hot ? 2 : 1}"/>
<rect x="72" y="${y + 14}" width="150" height="96" rx="10" fill="${p.paper3}"/>
<path d="M92 ${y + 92}l34-36 26 24 18-16 34 28z" fill="${p.rule}"/>
<circle cx="190" cy="${y + 40}" r="9" fill="${p.rule}"/>
<text x="246" y="${y + 44}" ${FONT} font-size="21" font-weight="700" fill="${p.ink}">${esc(s.name)}</text>
<text x="246" y="${y + 68}" ${FONT} font-size="14" fill="${p.dim}">${esc(s.area)} · ${esc(s.perks.slice(0, 2).join(" · "))}</text>
<rect x="246" y="${y + 82}" width="62" height="24" rx="12" fill="${p.glow}"/>
<text x="277" y="${y + 99}" ${FONT} font-size="13" font-weight="600" text-anchor="middle" fill="${p.glowInk}">${s.rating.toFixed(1)}</text>
<text x="320" y="${y + 99}" ${FONT} font-size="13" fill="${p.ink2}">${s.rating >= 4.7 ? "Exceptional" : s.rating >= 4.5 ? "Excellent" : "Very good"}</text>
<text x="850" y="${y + 50}" ${FONT} font-size="26" font-weight="700" text-anchor="end" fill="${p.ink}">$${s.price}</text>
<text x="850" y="${y + 72}" ${FONT} font-size="12" text-anchor="end" fill="${p.dim}">per night</text>
<rect x="882" y="${y + 40}" width="156" height="44" rx="22" fill="${hot ? p.glow : p.paper}" stroke="${hot ? p.glow : p.ink2}" stroke-width="1.5"/>
<text x="960" y="${y + 67}" ${FONT} font-size="15" font-weight="600" text-anchor="middle" fill="${hot ? p.glowInk : p.ink}">View stay</text>`;
    })
    .join("");
  return toUrl(
    shell(
      p,
      `<text x="56" y="112" ${FONT} font-size="26" font-weight="700" fill="${p.ink}">Stays in ${esc(city)}</text>
<text x="56" y="136" ${FONT} font-size="14" fill="${p.dim}">This weekend · 3 nights · ${stays.length} matches</text>
<text x="56" y="162" ${FONT} font-size="13" fill="${p.dim}">Sort by</text>
<rect x="116" y="140" width="112" height="34" rx="17" fill="${opts?.sorted ? p.paper : p.ink}" stroke="${p.rule}"/>
<text x="172" y="162" ${FONT} font-size="13" text-anchor="middle" fill="${opts?.sorted ? p.ink2 : p.paper}">Recommended</text>
<rect x="238" y="140" width="92" height="34" rx="17" fill="${p.paper}" stroke="${p.rule}"/>
<text x="284" y="162" ${FONT} font-size="13" text-anchor="middle" fill="${p.ink2}">Price</text>
<rect x="340" y="140" width="96" height="34" rx="17" fill="${opts?.sorted ? p.ink : p.paper}" stroke="${p.rule}"/>
<text x="388" y="162" ${FONT} font-size="13" text-anchor="middle" fill="${opts?.sorted ? p.paper : p.ink2}">Rating</text>
${rows}`
    )
  );
}

/** one stay's page — what it looks like right before a hold */
export function stayFrame(city: string, s: DemoStay, held = false): string {
  const p = palette();
  return toUrl(
    shell(
      p,
      `<text x="56" y="104" ${FONT} font-size="13" fill="${p.dim}">Stays · ${esc(city)} · ${esc(s.area)}</text>
<rect x="56" y="124" width="620" height="330" rx="18" fill="${p.paper3}"/>
<path d="M96 414l150-170 110 104 76-66 204 132z" fill="${p.rule}"/>
<circle cx="568" cy="198" r="30" fill="${p.rule}"/>
<rect x="56" y="470" width="198" height="120" rx="12" fill="${p.paper2}"/>
<rect x="267" y="470" width="198" height="120" rx="12" fill="${p.paper2}"/>
<rect x="478" y="470" width="198" height="120" rx="12" fill="${p.paper2}"/>
<rect x="716" y="124" width="380" height="466" rx="18" fill="${p.paper}" stroke="${p.rule}"/>
<text x="744" y="174" ${FONT} font-size="28" font-weight="700" fill="${p.ink}">${esc(s.name)}</text>
<text x="744" y="202" ${FONT} font-size="15" fill="${p.dim}">${esc(s.area)}, ${esc(city)}</text>
<rect x="744" y="222" width="62" height="26" rx="13" fill="${p.glow}"/>
<text x="775" y="240" ${FONT} font-size="13" font-weight="600" text-anchor="middle" fill="${p.glowInk}">${s.rating.toFixed(1)}</text>
${s.perks
  .slice(0, 3)
  .map((perk, i) => `<circle cx="750" cy="${284 + i * 30}" r="4" fill="${p.glow}"/><text x="766" y="${289 + i * 30}" ${FONT} font-size="15" fill="${p.ink2}">${esc(perk)}</text>`)
  .join("")}
<line x1="744" y1="372" x2="1068" y2="372" stroke="${p.rule}"/>
<text x="744" y="352" ${FONT} font-size="14" fill="${p.dim}">3 nights · this weekend</text>
<text x="1068" y="352" ${FONT} font-size="20" font-weight="700" text-anchor="end" fill="${p.ink}">$${s.price * 3}</text>
<rect x="744" y="402" width="268" height="56" rx="28" fill="${held ? p.paper2 : p.glow}" stroke="${held ? p.glow : "none"}" stroke-width="2"/>
<text x="878" y="437" ${FONT} font-size="17" font-weight="600" text-anchor="middle" fill="${held ? p.glow : p.glowInk}">${held ? "Held for you" : "Hold this room"}</text>
<text x="744" y="492" ${FONT} font-size="13" fill="${p.dim}">Free to hold · no card needed · cancel any time</text>`
    )
  );
}

/** a plain article page for the generic "use the browser" demo */
export function articleFrame(title: string, host: string): string {
  const p = palette();
  return toUrl(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${FRAME_W}" height="${FRAME_H}" viewBox="0 0 ${FRAME_W} ${FRAME_H}">
<rect width="${FRAME_W}" height="${FRAME_H}" fill="${p.paper}"/>
<text x="176" y="70" ${FONT} font-size="15" font-weight="700" fill="${p.ink}">${esc(host)}</text>
<line x1="0" y1="96" x2="${FRAME_W}" y2="96" stroke="${p.rule}"/>
<text x="176" y="186" font-family="Georgia, serif" font-size="46" font-weight="700" fill="${p.ink}">${esc(title)}</text>
<text x="176" y="228" ${FONT} font-size="15" fill="${p.dim}">A stand-in page — the demo brain has no network.</text>
${[0, 1, 2, 3, 4, 5, 6, 7]
  .map((i) => `<rect x="176" y="${272 + i * 30}" width="${i % 4 === 3 ? 520 : 800 - (i % 3) * 46}" height="12" rx="6" fill="${p.paper3}"/>`)
  .join("")}
<rect x="176" y="536" width="168" height="46" rx="23" fill="${p.glow}"/>
<text x="260" y="565" ${FONT} font-size="15" font-weight="600" text-anchor="middle" fill="${p.glowInk}">More information</text>
<text x="${FRAME_W / 2}" y="702" ${FONT} font-size="11" text-anchor="middle" fill="${p.dim}">stand-in site drawn by the demo brain — connect a model and this window shows the real web</text>
</svg>`
  );
}
export const ARTICLE_TARGET = { more: { x: 260 / FRAME_W, y: 559 / FRAME_H } } as const;
