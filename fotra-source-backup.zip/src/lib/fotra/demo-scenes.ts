"use client";

/* ————————————————————————————————————————————————
   DEMO SCENES — the demo brain doing "work".
   A scene is the same stream of step + frame events
   the real harness emits, on a script: the search
   types and its sources land, the browser window pops
   up and the cursor goes where the buttons are. It
   exists so the whole interface can be felt with zero
   keys — every result it shows is labelled demo.
   ———————————————————————————————————————————————— */

import type { AgentEvent, BrowserFrame, StepKind, StepPatch } from "./types";
import { ARTICLE_TARGET, TARGET, articleFrame, homeFrame, resultsFrame, stayFrame, type DemoStay } from "./demo-frames";

export type Scene = (signal: AbortSignal) => AsyncGenerator<AgentEvent>;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
let n = 0;
const sid = (p: string) => `demo-${p}-${Date.now().toString(36)}-${++n}`;

function open(id: string, tool: string, kind: StepKind, title: string, subject?: string, data?: Record<string, unknown>): AgentEvent {
  return { type: "step", step: { id, tool, kind, title, subject, status: "running", data } };
}
function close(id: string, summary: string, ms: number, data?: Record<string, unknown>, ok = true): AgentEvent {
  const step: StepPatch = { id, status: ok ? "done" : "error", summary, ms, ...(data ? { data } : {}) };
  return { type: "step", step };
}
function frame(stepId: string, f: Omit<BrowserFrame, "ts">): AgentEvent {
  return { type: "frame", stepId, frame: f, demo: true };
}

/* —— a web search: the query types, the sources fly in —— */
export async function* searchBeat(
  signal: AbortSignal,
  query: string,
  results: Array<{ title: string; host: string; snippet: string }>,
  ms = 1500
): AsyncGenerator<AgentEvent> {
  const id = sid("search");
  yield open(id, "web_search", "search", "Searching the web", query, { query });
  await sleep(ms);
  if (signal.aborted) return;
  yield close(id, `${results.length} results for “${query.slice(0, 48)}”`, ms, {
    query,
    results: results.map((r) => ({ ...r, url: `https://${r.host}/` })),
  });
  await sleep(650);
}

/* —— the hotel run, act one: search, then go look on a booking site —— */
export function hotelSearchScene(city: string, stays: DemoStay[]): Scene {
  return async function* (signal) {
    yield* searchBeat(signal, `best places to stay in ${city} this weekend`, [
      { title: `Where to stay in ${city}: a neighbourhood guide`, host: "stays.demo", snippet: `Three areas worth your nights in ${city}, and who each one suits.` },
      { title: `${city} hotels ranked by people who slept there`, host: "roomnotes.demo", snippet: `${stays[0].name} keeps topping the list — here's why.` },
      { title: `${city} on a budget: pods, hostels, small hotels`, host: "citybeds.demo", snippet: `From $${Math.min(...stays.map((s) => s.price))} a night without the regret.` },
    ]);
    if (signal.aborted) return;

    const url = "https://stays.demo/";
    const nav = sid("nav");
    yield open(nav, "browser_navigate", "browser", "Opening", "stays.demo");
    yield frame(nav, { url, act: "navigate", note: "opening stays.demo", cursor: { x: 0.5, y: 0.45 } });
    await sleep(900);
    if (signal.aborted) return;
    yield frame(nav, { url, title: "stays — find somewhere good", shot: homeFrame(), act: "read", cursor: { x: 0.5, y: 0.45 } });
    yield close(nav, "opened stays.demo", 900, { url, host: "stays.demo", title: "stays — find somewhere good" });
    await sleep(500);

    const type = sid("type");
    yield open(type, "browser_type", "browser", "Typing", city);
    yield frame(type, { url, act: "type", note: "typing into “Where”", typed: city, cursor: TARGET.where });
    await sleep(1300);
    if (signal.aborted) return;
    yield frame(type, { url, shot: homeFrame(city), act: "type", note: "typing into “Where”", typed: city, cursor: TARGET.where });
    await sleep(350);
    yield close(type, `typed “${city}”`, 1650);

    const go = sid("click");
    yield open(go, "browser_click", "browser", "Clicking", "Search");
    yield frame(go, { url, act: "click", note: "clicking “Search”", cursor: TARGET.search });
    await sleep(1000);
    if (signal.aborted) return;
    const results = `https://stays.demo/search?q=${encodeURIComponent(city.toLowerCase())}`;
    yield frame(go, { url: results, title: `Stays in ${city}`, shot: resultsFrame(city, stays), act: "click", note: `${stays.length} stays in ${city}`, cursor: TARGET.search });
    yield close(go, `clicked → Stays in ${city}`, 1000, { url: results, host: "stays.demo", title: `Stays in ${city}` });
    await sleep(700);

    const sort = sid("click");
    yield open(sort, "browser_click", "browser", "Clicking", "Rating");
    yield frame(sort, { url: results, act: "click", note: "sorting by rating", cursor: TARGET.sortRating });
    await sleep(950);
    if (signal.aborted) return;
    const sorted = [...stays].sort((a, b) => b.rating - a.rating);
    yield frame(sort, { url: results, shot: resultsFrame(city, sorted, { sorted: true }), act: "click", note: "sorted by rating — reading the top three", cursor: TARGET.sortRating });
    yield close(sort, "sorted by rating", 950);
    await sleep(600);
  };
}

/* —— act two: open the chosen stay —— */
export function hotelPickScene(city: string, stays: DemoStay[], chosen: DemoStay): Scene {
  return async function* (signal) {
    const sorted = [...stays].sort((a, b) => b.rating - a.rating);
    const i = Math.max(0, sorted.findIndex((s) => s.name === chosen.name));
    const list = `https://stays.demo/search?q=${encodeURIComponent(city.toLowerCase())}`;
    const id = sid("click");
    yield open(id, "browser_click", "browser", "Clicking", chosen.name);
    yield frame(id, { url: list, shot: resultsFrame(city, sorted, { sorted: true, highlight: i }), act: "click", note: `opening ${chosen.name}`, cursor: TARGET.row(i) });
    await sleep(1100);
    if (signal.aborted) return;
    const url = `https://stays.demo/stay/${chosen.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
    yield frame(id, { url, title: chosen.name, shot: stayFrame(city, chosen), act: "click", note: `${chosen.name} — checking the room`, cursor: TARGET.row(i) });
    yield close(id, `clicked → ${chosen.name}`, 1100, { url, host: "stays.demo", title: chosen.name });
    await sleep(500);
  };
}

/* —— act three: hold it (the demo's stand-in for the payment boundary) —— */
export function hotelHoldScene(city: string, chosen: DemoStay): Scene {
  return async function* (signal) {
    const url = `https://stays.demo/stay/${chosen.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
    const id = sid("click");
    yield open(id, "browser_click", "browser", "Clicking", "Hold this room");
    yield frame(id, { url, shot: stayFrame(city, chosen), act: "click", note: "clicking “Hold this room”", cursor: TARGET.hold });
    await sleep(1100);
    if (signal.aborted) return;
    yield frame(id, { url, title: `${chosen.name} — held`, shot: stayFrame(city, chosen, true), act: "click", note: "held — no card, no charge", cursor: TARGET.hold });
    yield close(id, "held the room", 1100, { url, host: "stays.demo", title: `${chosen.name} — held` });
    await sleep(400);
  };
}

/* —— a generic page visit —— */
export function browseScene(host: string, title: string): Scene {
  return async function* (signal) {
    const url = `https://${host}/`;
    const nav = sid("nav");
    yield open(nav, "browser_navigate", "browser", "Opening", host);
    yield frame(nav, { url, act: "navigate", note: `opening ${host}`, cursor: { x: 0.5, y: 0.4 } });
    await sleep(1000);
    if (signal.aborted) return;
    yield frame(nav, { url, title, shot: articleFrame(title, host), act: "read", note: "reading the page", cursor: { x: 0.5, y: 0.4 } });
    yield close(nav, `opened ${host}`, 1000, { url, host, title });
    await sleep(700);
    const id = sid("click");
    yield open(id, "browser_click", "browser", "Clicking", "More information");
    yield frame(id, { url, act: "click", note: "clicking “More information”", cursor: ARTICLE_TARGET.more });
    await sleep(1100);
    if (signal.aborted) return;
    yield frame(id, { url: `${url}more`, title: `${title} — more`, shot: articleFrame(`${title}, continued`, host), act: "click", note: "read the follow-up page", cursor: ARTICLE_TARGET.more });
    yield close(id, "clicked → more information", 1100);
    await sleep(400);
  };
}

/* —— code: it runs, it prints —— */
export function codeScene(cells: Array<{ lang: "python" | "js"; code: string; stdout: string; ms: number; cell?: number; bridge?: Array<{ tool: string; ok: boolean }> }>): Scene {
  return async function* (signal) {
    for (const c of cells) {
      const id = sid("code");
      const data = { lang: c.lang, code: c.code, ...(c.cell ? { cell: c.cell, kernel: true } : {}) };
      yield open(id, c.lang === "python" ? "run_python" : "run_js", "code", c.lang === "python" ? "Running Python" : "Running JavaScript", undefined, data);
      await sleep(Math.max(700, c.ms));
      if (signal.aborted) return;
      yield close(id, `${c.lang === "python" ? "python" : "node"} · ok · ${(c.ms / 1000).toFixed(1)}s`, c.ms, { ...data, stdout: c.stdout, exit: 0, ms: c.ms, bridge: c.bridge ?? [] });
      await sleep(450);
    }
  };
}

/* —— workers: two at once, each reporting in —— */
export function workersScene(workers: Array<{ name: string; task: string; log: string[]; result: string }>): Scene {
  return async function* (signal) {
    const ids = workers.map((w) => sid(`w-${w.name}`));
    for (let i = 0; i < workers.length; i++) {
      const w = workers[i];
      yield { type: "step", step: { id: ids[i], tool: "spawn_task", kind: "worker", title: w.name, subject: w.task, status: "running", data: { name: w.name, task: w.task, log: [] } } };
      await sleep(160);
    }
    const rounds = Math.max(...workers.map((w) => w.log.length));
    for (let r = 0; r < rounds; r++) {
      await sleep(820);
      if (signal.aborted) return;
      for (let i = 0; i < workers.length; i++) {
        const w = workers[i];
        if (r < w.log.length) yield { type: "step", step: { id: ids[i], data: { log: w.log.slice(0, r + 1) } } };
      }
    }
    for (let i = 0; i < workers.length; i++) {
      await sleep(520);
      if (signal.aborted) return;
      yield close(ids[i], workers[i].result, 1800 + i * 520, { phase: "done" });
    }
    await sleep(400);
  };
}

/* —— one-beat steps: a file written, a fact kept, a routine set, a change to itself —— */
export function beat(tool: string, kind: StepKind, title: string, subject: string, summary: string, data: Record<string, unknown>, ms = 700): Scene {
  return async function* (signal) {
    const id = sid(kind);
    yield open(id, tool, kind, title, subject, kind === "self" ? undefined : data);
    await sleep(ms);
    if (signal.aborted) return;
    yield close(id, summary, ms, data);
    await sleep(380);
  };
}

export function chain(...scenes: Scene[]): Scene {
  return async function* (signal) {
    for (const s of scenes) {
      if (signal.aborted) return;
      yield* s(signal);
    }
  };
}
