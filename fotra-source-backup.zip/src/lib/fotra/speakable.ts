/* ————————————————————————————————————————————————
   SPEAKABLE — stolen from oh-my-pi
   packages/coding-agent/src/tts/speakable.ts (MIT)
   The streaming markdown→speech segmenter, constants
   and all: fence-swallowing, URL→host, path→basename,
   FIRST_SEGMENT_MIN / SOFT_CLAUSE_LEN / MAX_SEGMENT
   tuned against a real TTS engine. Adapted for the
   browser (no Node imports), same numbers.
   ———————————————————————————————————————————————— */

/** the first chunk may be short — speech starts fast, latency feels like a human */
export const FIRST_SEGMENT_MIN = 12;
/** past this length, split at clause boundaries (, ; :) */
export const SOFT_CLAUSE_LEN = 160;
/** hard ceiling — split at a word boundary, no matter what */
export const MAX_SEGMENT = 280;

const SENTENCE_RE = /^[\s\S]*?[.!?…]["')\]]?(\s|$)/;

/** index of the last soft clause boundary (", " · "; " · " — ") in text, or -1 */
function lastClause(text: string): number {
  return Math.max(text.lastIndexOf(", "), text.lastIndexOf("; "), text.lastIndexOf(" — "));
}

/** fence-swallow + markdown strip + speakable rewrites — applied to text BEFORE segmenting */
export function sanitizeForSpeech(text: string): string {
  let out = "";
  let inFence = false;
  for (const line of text.split("\n")) {
    // a fence marker anywhere in the line toggles fence state (indented + mid-line both count)
    const fence = /^(\s*)(```|~~~)/.test(line) || line.includes("```");
    if (fence) {
      inFence = !inFence;
      if (inFence) out += " [code] ";
      continue;
    }
    if (inFence) continue; // swallow fenced content — never read code aloud
    out += line + "\n";
  }
  if (inFence) out += " [code] "; // unterminated fence — close the marker
  return out
    .replace(/```[\s\S]*?```/g, " [code] ") // inline fences too
    .replace(/~~~[\s\S]*?~~~/g, " [code] ")
    .replace(/`([^`]+)`/g, "$1") // inline code → the text itself
    .replace(/!\[[^\]]*\]\(([^)]+)\)/g, " image ") // images
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, "$1") // links → label only
    .replace(/https?:\/\/(?:www\.)?([^\/\s)\]]+)[^\s)\]]*/g, "$1") // URL → host (omp: never read query strings aloud)
    .replace(/(?:\/[\w.-]+){3,}/g, (m) => { // long paths → basename (omp: /a/b/c.txt → c.txt)
      const base = m.split("/").filter(Boolean).pop() ?? m;
      return base.length > 0 && base.length < m.length ? base : m;
    })
    .replace(/[*_~]{1,3}([^*_~]+)[*_~]{1,3}/g, "$1") // emphasis → plain
    .replace(/^\s*#{1,6}\s+/gm, "") // headings
    .replace(/^\s*[-*+]\s+/gm, "") // list markers
    .replace(/^\s*>\s?/gm, "") // quotes
    .replace(/\|/g, " ") // table pipes
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Segment a chunk of assistant text into speakable pieces (batch mode).
 * Sentences ship whole; once a run passes SOFT_CLAUSE_LEN the next clause
 * boundary cuts; MAX_SEGMENT is the hard word-boundary ceiling.
 */
export function segmentSpeech(text: string, opts?: { first?: boolean }): string[] {
  const clean = sanitizeForSpeech(text);
  if (!clean) return [];
  const out: string[] = [];
  let rest = clean;
  let first = opts?.first !== false;

  while (rest.length > 0) {
    // sentence boundaries ship whole — the first segment may be as short as 12 (speech starts fast)
    const m = rest.match(SENTENCE_RE);
    if (m && m[0].trim().length >= (first ? FIRST_SEGMENT_MIN : 1)) {
      out.push(m[0].trim());
      rest = rest.slice(m[0].length);
      first = false;
      continue;
    }
    // hard ceiling — split at the best boundary inside the window
    if (rest.length > MAX_SEGMENT) {
      const window = rest.slice(0, MAX_SEGMENT);
      const cut = Math.max(window.lastIndexOf(". "), window.lastIndexOf("! "), window.lastIndexOf("? "), lastClause(window));
      if (cut + 2 >= FIRST_SEGMENT_MIN) {
        out.push(rest.slice(0, cut + 1).trim());
        rest = rest.slice(cut + 1);
      } else {
        const sp = window.lastIndexOf(" ");
        out.push(rest.slice(0, sp > 0 ? sp : MAX_SEGMENT).trim());
        rest = rest.slice(sp > 0 ? sp + 1 : MAX_SEGMENT);
      }
      first = false;
      continue;
    }
    // no sentence end yet — short tail ships whole, long tail cuts at a clause
    if (rest.length <= SOFT_CLAUSE_LEN) {
      out.push(rest.trim());
      break;
    }
    const soft = lastClause(rest);
    if (soft + 2 >= FIRST_SEGMENT_MIN) {
      out.push(rest.slice(0, soft + 1).trim());
      rest = rest.slice(soft + 1);
      first = false;
      continue;
    }
    // no boundary at all — take it all
    out.push(rest.trim());
    break;
  }
  return out.filter((s) => s.length > 0);
}

/**
 * Streaming take: how much of the growing buffer can be SPOKEN right now.
 * Returns [speakable, remainder]. The first take fires at any boundary past
 * FIRST_SEGMENT_MIN (speech starts while the model is still generating);
 * later takes hold for full sentences, cutting at clauses only once the
 * buffer passes SOFT_CLAUSE_LEN, and never holding past MAX_SEGMENT.
 */
export function takeSpeakable(buffer: string, isFinal: boolean, firstTake: boolean): [string, string] {
  if (isFinal) {
    const rest = buffer.trim();
    return rest ? [rest, ""] : ["", ""];
  }
  if (buffer.length < FIRST_SEGMENT_MIN) return ["", buffer];
  // a complete sentence ships (any length once we're past the first; ≥12 for the first — anti-chop)
  const m = buffer.match(SENTENCE_RE);
  if (m && m[0].trim().length >= (firstTake ? FIRST_SEGMENT_MIN : 1)) {
    return [m[0], buffer.slice(m[0].length)];
  }
  // no sentence end: the first take may cut at a clause ≥12 (start speaking early);
  // later takes cut at a clause only once past SOFT_CLAUSE_LEN — never holding past MAX
  if (buffer.length > SOFT_CLAUSE_LEN || (firstTake && m === null)) {
    const soft = lastClause(buffer);
    if (soft + 2 >= FIRST_SEGMENT_MIN) return [buffer.slice(0, soft + 1), buffer.slice(soft + 1)];
    if (buffer.length > MAX_SEGMENT) {
      const sp = buffer.lastIndexOf(" ");
      if (sp > 0) return [buffer.slice(0, sp), buffer.slice(sp + 1)];
    }
  }
  return ["", buffer];
}
