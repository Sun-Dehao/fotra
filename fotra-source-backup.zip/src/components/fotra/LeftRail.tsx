"use client";

/* ————————————————————————————————————————————————
   THE LEFT RAIL — the harness surfaces + sessions
   The agent doesn't just talk: it keeps FILES, runs
   ROUTINES on schedules, connects MCP tools, and
   holds MEMORY — and every conversation ever had is
   a recorded SESSION you can jump back into (the
   oh-my-pi sessions story, one click). Icons on the
   strip; click opens the panel.
   ———————————————————————————————————————————————— */

import { useCallback, useEffect, useState } from "react";
import {
  CalendarClock,
  FileText,
  History,
  MessageSquarePlus,
  Plug,
  RefreshCw,
  Settings2,
  Trash2,
  X,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { loadThreads, useFotra, type SavedThread } from "@/lib/fotra/store";
import { refreshWsFiles } from "@/lib/fotra/agent";

type Panel = null | "sessions" | "files" | "routines" | "mcp" | "memory";

interface RoutineRow {
  id: string;
  name: string;
  prompt: string;
  schedule: string;
  active: boolean;
  nextRunAt: string;
  lastNote: string | null;
  valid: boolean;
}
interface McpRow {
  id: string;
  name: string;
  url: string;
  status: string;
  error: string | null;
  tools: { name: string; id: string; description?: string }[];
}
interface SessionRow {
  id: string;
  title: string;
  turnCount: number;
  runCount: number;
  createdAt: string;
  lastAt: string;
}

export function LeftRail({ mobile = false, onClose }: { mobile?: boolean; onClose?: () => void }) {
  const [panel, setPanel] = useState<Panel>(mobile ? "sessions" : null); // in the drawer it opens on your threads
  const setMemoryOpen = useFotra((s) => s.setMemoryOpen);
  const setSettingsOpen = useFotra((s) => s.setSettingsOpen);

  const pick = (p: Panel) => {
    if (p === "memory") {
      setMemoryOpen(true);
      setPanel(null);
      if (onClose) onClose();
      return;
    }
    setPanel((cur) => (cur === p ? null : p));
  };

  // the palette (and anything else) can aim the rail at a surface
  useEffect(() => {
    const onEvt = (e: Event) => {
      const detail = (e as CustomEvent).detail as Panel;
      if (detail) setPanel(detail);
    };
    window.addEventListener("fotra:rail-panel", onEvt);
    return () => window.removeEventListener("fotra:rail-panel", onEvt);
  }, []);

  return (
    <div className="flex h-full w-full">
      {/* the icon strip */}
      <nav
        className="flex w-[52px] shrink-0 flex-col items-center gap-1.5 border-r border-rule bg-paper-2/60 py-3"
        aria-label="Harness surfaces"
      >
        <RailButton icon={<History size={16} />} label="Sessions" active={panel === "sessions"} onClick={() => pick("sessions")} />
        <RailButton icon={<FileText size={16} />} label="Workspace files" active={panel === "files"} onClick={() => pick("files")} />
        <RailButton icon={<CalendarClock size={16} />} label="Routines" active={panel === "routines"} onClick={() => pick("routines")} />
        <RailButton icon={<Plug size={16} />} label="MCP tools" active={panel === "mcp"} onClick={() => pick("mcp")} />
        <RailButton icon={<Zap size={16} />} label="Memory" onClick={() => pick("memory")} />
        <div className="mt-auto">
          <RailButton icon={<Settings2 size={16} />} label="Settings" onClick={() => { setSettingsOpen(true); if (onClose) onClose(); }} />
        </div>
      </nav>

      {/* the flyout */}
      {panel && (
        <div className={`f-fade f-scroll min-h-0 overflow-y-auto overflow-x-hidden bg-paper-2/40 ${mobile ? "min-w-0 flex-1" : "w-[240px] shrink-0 border-r border-rule"}`}>
          {panel === "sessions" && <SessionsPanel />}
          {panel === "files" && <FilesPanel />}
          {panel === "routines" && <RoutinesPanel />}
          {panel === "mcp" && <McpPanel />}
        </div>
      )}
    </div>
  );
}

function RailButton({ icon, label, active, onClick }: { icon: React.ReactNode; label: string; active?: boolean; onClick: () => void }) {
  return (
    <Button
      type="button"
      variant="ghost"
      size="icon"
      aria-label={label}
      title={label}
      aria-pressed={active ?? undefined}
      onClick={onClick}
      className={`grid h-10 w-10 rounded-md ${
        active ? "bg-glow/15 text-glow hover:bg-glow/20 hover:text-glow" : "text-dim hover:bg-paper-3 hover:text-ink"
      }`}
    >
      {icon}
    </Button>
  );
}

/* —— SESSIONS — every conversation ever, one click away —— */

function SessionsPanel() {
  const sessionId = useFotra((s) => s.settings.sessionId);
  const threadId = useFotra((s) => s.threadId);
  const turnCount = useFotra((s) => s.turns.length);
  const switchSession = useFotra((s) => s.switchSession);
  const openThread = useFotra((s) => s.openThread);
  const deleteThread = useFotra((s) => s.deleteThread);
  const newSession = useFotra((s) => s.newSession);
  const readOnly = useFotra((s) => s.readOnly);
  const [server, setServer] = useState<SessionRow[]>([]);
  const [local, setLocal] = useState<SavedThread[]>([]);

  const load = useCallback(async () => {
    setLocal(loadThreads());
    try {
      const res = await fetch("/api/sessions");
      if (!res.ok) return;
      const j = (await res.json()) as { sessions: SessionRow[] };
      setServer(j.sessions ?? []);
    } catch {
      /* the browser's own copies still list */
    }
  }, []);

  useEffect(() => {
    void load();
    const onThreads = () => setLocal(loadThreads());
    window.addEventListener("fotra:threads", onThreads);
    return () => window.removeEventListener("fotra:threads", onThreads);
  }, [load, sessionId, threadId, turnCount]);

  function when(ts: number): string {
    const days = Math.floor((Date.now() - ts) / 86_400_000);
    if (days <= 0) return "today";
    if (days === 1) return "yesterday";
    if (days < 7) return `${days}d ago`;
    return new Date(ts).toLocaleDateString();
  }

  // one list: threads kept in this browser (steps and screens intact), then any the server
  // recorded that this browser has no copy of
  const known = new Set(local.map((t) => t.sessionId).filter(Boolean));
  const rows = [
    ...local.map((t) => ({ key: t.id, title: t.title, ts: t.updatedAt, turns: t.turns.length, current: t.id === threadId, open: () => openThread(t.id), remove: () => deleteThread(t.id) })),
    ...server
      .filter((s) => !known.has(s.id) && s.turnCount > 0)
      .map((s) => ({ key: s.id, title: s.title, ts: new Date(s.lastAt).getTime(), turns: s.turnCount, current: s.id === sessionId && turnCount > 0, open: () => void switchSession(s.id), remove: null as null | (() => void) })),
  ].sort((a, b) => b.ts - a.ts);

  return (
    <div className="flex flex-col gap-2 p-3">
      <PanelHead label="threads" count={rows.length} onRefresh={() => void load()} />
      <Button
        variant="outline"
        size="sm"
        disabled={readOnly || turnCount === 0}
        onClick={() => newSession()}
        className="w-full justify-start gap-2 border-glow/40 text-glow hover:bg-glow/10 hover:text-glow"
      >
        <MessageSquarePlus size={13} /> new thread
      </Button>
      {rows.length === 0 && <p className="px-1 text-xs leading-relaxed text-dim">nothing yet — every conversation is kept here once you say something</p>}
      <ul className="space-y-0.5">
        {rows.map((r) => (
          <li key={r.key} className="group/row relative">
            <button
              type="button"
              disabled={readOnly}
              onClick={r.open}
              className={`w-full rounded-md px-2.5 py-2 text-left transition-colors ${r.current ? "bg-glow/10" : "hover:bg-paper-3"} ${readOnly ? "cursor-not-allowed opacity-50" : ""}`}
              aria-current={r.current ? "true" : undefined}
            >
              <span className={`block truncate pr-6 text-[13px] leading-snug ${r.current ? "text-ink" : "text-ink-2"}`}>{r.title}</span>
              <span className="f-label mt-0.5 block !opacity-45">
                {when(r.ts)} · {r.turns} turns
              </span>
            </button>
            {r.remove && !readOnly && (
              <button
                type="button"
                aria-label={`Delete thread: ${r.title}`}
                title="delete"
                onClick={r.remove}
                className="absolute right-1.5 top-1.5 grid h-7 w-7 place-items-center rounded-md text-dim opacity-0 transition-opacity hover:bg-paper-3 hover:text-danger focus-visible:opacity-100 group-hover/row:opacity-100"
              >
                <Trash2 size={12} />
              </button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
/* —— FILES —— */

function FilesPanel() {
  const files = useFotra((s) => s.wsFiles);
  const sessionId = useFotra((s) => s.settings.sessionId);
  const [open, setOpen] = useState<string | null>(null);
  const [content, setContent] = useState<string>("");
  const [busy, setBusy] = useState(false);

  const read = async (f: string) => {
    if (open === f) {
      setOpen(null);
      return;
    }
    setOpen(f);
    setContent("");
    setBusy(true);
    try {
      const res = await fetch(`/api/workspace?sessionId=${encodeURIComponent(sessionId ?? "")}&path=${encodeURIComponent(f)}`);
      const j = (await res.json()) as { content?: string; error?: string };
      setContent(j.content ?? j.error ?? "(empty)");
    } catch {
      setContent("(couldn't read)");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex flex-col gap-2 p-3">
      <PanelHead label="workspace" count={files.length} onRefresh={() => void refreshWsFiles()} />
      {files.length === 0 && (
        <p className="px-1 text-xs leading-relaxed text-dim">
          no files yet — ask fotra to write one, or to run some code that leaves results behind
        </p>
      )}
      <ul className="space-y-0.5">
        {files.map((f) => (
          <li key={f}>
            <button
              type="button"
              onClick={() => void read(f)}
              className="f-mono w-full truncate rounded px-2 py-1.5 text-left text-xs text-ink-2 transition-colors hover:bg-paper-3 hover:text-ink"
            >
              {f}
            </button>
            {open === f && (
              <div className="f-fade mt-1 rounded-md border border-rule bg-paper-2 p-2">
                {busy ? (
                  <div className="f-shimmer h-3 w-2/3" />
                ) : (
                  <pre className="f-mono f-scroll max-h-48 overflow-y-auto whitespace-pre-wrap text-[11px] leading-relaxed text-ink-2">{content}</pre>
                )}
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

function PanelHead({ label, count, onRefresh }: { label: string; count?: number; onRefresh?: () => void }) {
  return (
    <div className="flex items-center justify-between px-1">
      <span className="f-label !opacity-60">
        {label} {typeof count === "number" ? `· ${count}` : ""}
      </span>
      {onRefresh && (
        <Button type="button" variant="ghost" size="icon" aria-label="Refresh" onClick={onRefresh} className="h-7 w-7 text-dim hover:text-ink">
          <RefreshCw size={12} />
        </Button>
      )}
    </div>
  );
}

/* —— ROUTINES —— */

function RoutinesPanel() {
  const sessionId = useFotra((s) => s.settings.sessionId);
  const [rows, setRows] = useState<RoutineRow[]>([]);
  const [name, setName] = useState("");
  const [schedule, setSchedule] = useState("daily at 08:00");
  const [prompt, setPrompt] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    if (!sessionId) return;
    try {
      const res = await fetch(`/api/routines?sessionId=${encodeURIComponent(sessionId)}`);
      if (!res.ok) return;
      const j = (await res.json()) as { routines: RoutineRow[] };
      setRows(j.routines ?? []);
    } catch {
      /* stale */
    }
  }, [sessionId]);

  useEffect(() => {
    void load();
    const t = setInterval(() => void load(), 30_000);
    return () => clearInterval(t);
  }, [load]);

  const create = async () => {
    setErr("");
    setBusy(true);
    try {
      const res = await fetch("/api/routines", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId, name, prompt, schedule }),
      });
      const j = (await res.json()) as { error?: string };
      if (!res.ok) {
        setErr(j.error ?? "couldn't create");
        return;
      }
      toast.success("routine scheduled", { description: `${name} · ${schedule}` });
      setName("");
      setPrompt("");
      await load();
    } finally {
      setBusy(false);
    }
  };

  const act = async (id: string, action: "toggle" | "run") => {
    await fetch("/api/routines", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, action }) }).catch(() => undefined);
    await load();
  };
  const del = async (id: string) => {
    await fetch(`/api/routines?id=${encodeURIComponent(id)}`, { method: "DELETE" }).catch(() => undefined);
    await load();
  };

  return (
    <div className="flex flex-col gap-3 p-3">
      <PanelHead label="routines" count={rows.length} onRefresh={() => void load()} />
      {rows.length === 0 && (
        <p className="px-1 text-xs leading-relaxed text-dim">
          nothing scheduled — a routine is a goal you hand off: "every morning, brief me on…". Set it once, it never forgets, and ⚡ runs it on demand.
        </p>
      )}
      <ul className="space-y-2">
        {rows.map((r) => (
          <li key={r.id} className="rounded-md border border-rule p-2.5">
            <div className="flex items-center justify-between gap-2">
              <span className={`truncate text-sm font-medium ${r.active ? "text-ink" : "text-dim line-through"}`}>{r.name}</span>
              <div className="flex items-center gap-1">
                <Button type="button" variant="ghost" size="icon" aria-label="Run now" title="Run now" onClick={() => void act(r.id, "run")} className="h-7 w-7 text-dim hover:bg-paper-3 hover:text-glow">
                  <Zap size={12} />
                </Button>
                <Button type="button" variant="ghost" size="icon" aria-label={r.active ? "Pause" : "Resume"} title={r.active ? "Pause" : "Resume"} onClick={() => void act(r.id, "toggle")} className="h-7 w-7 text-dim hover:bg-paper-3 hover:text-ink">
                  <span className={`h-2 w-2 rounded-full ${r.active ? "bg-glow" : "border border-rule"}`} />
                </Button>
                <Button type="button" variant="ghost" size="icon" aria-label="Delete routine" onClick={() => void del(r.id)} className="h-7 w-7 text-dim hover:bg-paper-3 hover:text-danger">
                  <Trash2 size={12} />
                </Button>
              </div>
            </div>
            <div className="f-label !opacity-50 mt-0.5">{r.schedule}</div>
            {r.lastNote && <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-ink-2">{r.lastNote}</p>}
          </li>
        ))}
      </ul>

      {/* create */}
      <div className="space-y-1.5 border-t border-rule pt-3">
        <div className="f-label !opacity-50 px-1">new routine</div>
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="name — morning brief" className="h-8 border-rule bg-paper text-xs" />
        <Input value={schedule} onChange={(e) => setSchedule(e.target.value)} placeholder="every 30 minutes / daily at 08:00" className="f-mono h-8 border-rule bg-paper text-[11px]" />
        <Textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="what fotra should do when it fires — search the news, write a file, brief me…" rows={3} className="border-rule bg-paper text-xs" />
        {err && <p className="text-xs text-danger">{err}</p>}
        <Button
          type="button"
          variant="outline"
          disabled={busy || !name.trim() || !prompt.trim()}
          onClick={() => void create()}
          className="w-full border-glow/50 bg-glow/10 text-glow hover:bg-glow/20 hover:text-glow"
        >
          schedule it
        </Button>
      </div>
    </div>
  );
}

/* —— MCP —— */

function McpPanel() {
  const [rows, setRows] = useState<McpRow[]>([]);
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/mcp");
      if (!res.ok) return;
      const j = (await res.json()) as { servers: McpRow[] };
      setRows(j.servers ?? []);
    } catch {
      /* stale */
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const connect = async () => {
    setErr("");
    setBusy(true);
    try {
      const res = await fetch("/api/mcp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, url }),
      });
      const j = (await res.json()) as { error?: string };
      if (!res.ok) {
        setErr(j.error ?? "connect failed");
        return;
      }
      toast.success(`${name} connected`, { description: "its tools join the belt on the next run" });
      setName("");
      setUrl("");
      await load();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex flex-col gap-3 p-3">
      <PanelHead label="mcp · byo tools" count={rows.length} onRefresh={() => void load()} />
      {rows.length === 0 && (
        <p className="px-1 text-xs leading-relaxed text-dim">
          connect any Model Context Protocol server (streamable HTTP url) — its tools become fotra tools
        </p>
      )}
      <ul className="space-y-2">
        {rows.map((r) => (
          <li key={r.id} className="rounded-md border border-rule p-2.5">
            <div className="flex items-center justify-between gap-2">
              <div className="flex min-w-0 items-center gap-2">
                <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${r.status === "connected" ? "bg-glow" : "bg-danger"}`} />
                <span className="truncate text-sm font-medium text-ink">{r.name}</span>
                <span className="f-label !opacity-50 shrink-0">{r.tools.length} tools</span>
              </div>
              <Button type="button" variant="ghost" size="icon" aria-label="Disconnect" onClick={async () => { await fetch(`/api/mcp?id=${encodeURIComponent(r.id)}`, { method: "DELETE" }).catch(() => undefined); await load(); }} className="h-7 w-7 text-dim hover:bg-paper-3 hover:text-danger">
                <X size={12} />
              </Button>
            </div>
            {r.error && <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-danger">{r.error}</p>}
            {r.tools.length > 0 && (
              <ul className="mt-1.5 space-y-0.5">
                {r.tools.slice(0, 8).map((t) => (
                  <li key={t.id} className="f-mono truncate text-[11px] text-ink-2" title={t.description ?? t.name}>
                    {t.name}
                  </li>
                ))}
                {r.tools.length > 8 && <li className="f-label !opacity-40">+{r.tools.length - 8} more</li>}
              </ul>
            )}
          </li>
        ))}
      </ul>

      <div className="space-y-1.5 border-t border-rule pt-3">
        <div className="f-label !opacity-50 px-1">connect a server</div>
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="name — weather" className="h-8 border-rule bg-paper text-xs" />
        <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://example.com/mcp" className="f-mono h-8 border-rule bg-paper text-[11px]" />
        {err && <p className="text-xs text-danger">{err}</p>}
        <Button
          type="button"
          variant="outline"
          disabled={busy || !name.trim() || !url.trim()}
          onClick={() => void connect()}
          className="w-full border-glow/50 bg-glow/10 text-glow hover:bg-glow/20 hover:text-glow"
        >
          connect
        </Button>
        <p className="px-1 text-[11px] leading-relaxed text-dim">fotra calls its tools as mcp_{"<server>"}_{"<tool>"} — the agent discovers them on the next run</p>
      </div>
    </div>
  );
}
