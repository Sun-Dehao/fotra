"use client";

/* ————————————————————————————————————————————————
   REACTIONS — the row under a reply.
   Hover a reply (or focus into it) and six tapbacks
   appear beside a copy button. Pick one and it stays as
   a chip; tap it again to take it back. A thumbs-down
   asks, in one line, what was off — the answer rides
   into the next run with the reaction.
   ———————————————————————————————————————————————— */

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Copy } from "lucide-react";
import { useFotra } from "@/lib/fotra/store";
import { REACTIONS, WHY_CHIPS } from "@/lib/fotra/reactions";
import type { Turn } from "@/lib/fotra/types";

export function ReplyTools({ turn, last = false }: { turn: Turn; last?: boolean }) {
  const react = useFotra((s) => s.react);
  const mine = turn.reactions?.find((r) => r.by === "user");
  const [copied, setCopied] = useState(false);
  const [askWhy, setAskWhy] = useState(false);

  function pick(emoji: string, asksWhy?: boolean) {
    const removing = mine?.emoji === emoji;
    react(turn.id, emoji, "user");
    setAskWhy(!removing && !!asksWhy);
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(turn.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    } catch {
      /* clipboard blocked — nothing to say about it */
    }
  }

  return (
    <div className="f-reply-tools" data-held={!!mine || askWhy} data-last={last}>
      <div className="flex items-center gap-0.5">
        {mine && (
          <motion.button
            type="button"
            key={mine.emoji}
            initial={{ scale: 0.4, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 520, damping: 22 }}
            onClick={() => pick(mine.emoji)}
            className="f-react-chip"
            aria-label={`You reacted ${mine.emoji} — remove`}
            title={mine.note ? `${mine.note} · tap to remove` : "tap to remove"}
          >
            <span className="f-emoji">{mine.emoji}</span>
            {mine.note && <span className="text-[11px] text-ink-2">{mine.note}</span>}
          </motion.button>
        )}
        <div className="f-react-bar" role="group" aria-label="React to this reply">
          {REACTIONS.filter((r) => r.emoji !== mine?.emoji).map((r) => (
            <button key={r.emoji} type="button" onClick={() => pick(r.emoji, r.asksWhy)} className="f-react-btn" aria-label={`React: ${r.label}`} title={r.label}>
              <span className="f-emoji">{r.emoji}</span>
            </button>
          ))}
          <span className="mx-1 h-3.5 w-px bg-rule" aria-hidden="true" />
          <button type="button" onClick={() => void copy()} className="f-react-btn text-dim hover:text-ink" aria-label="Copy this reply" title="copy">
            {copied ? <Check size={13} className="text-glow" /> : <Copy size={13} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {askWhy && mine && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="flex flex-wrap items-center gap-1.5 pt-1.5">
              <span className="f-label !opacity-50">what was off?</span>
              {WHY_CHIPS.map((w) => (
                <button
                  key={w}
                  type="button"
                  onClick={() => {
                    react(turn.id, mine.emoji, "user", w);
                    setAskWhy(false);
                  }}
                  className="rounded-full border border-rule px-2.5 py-0.5 text-xs text-ink-2 transition-colors hover:border-glow/60 hover:text-ink"
                >
                  {w}
                </button>
              ))}
              <button type="button" onClick={() => setAskWhy(false)} className="f-label px-1 !opacity-45 hover:!opacity-90">
                skip
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/** the agent's tapback on something you said — it pops onto the corner of your bubble */
export function Tapback({ turn }: { turn: Turn }) {
  const r = turn.reactions?.find((x) => x.by === "agent");
  return (
    <AnimatePresence>
      {r && (
        <motion.span
          key={r.emoji}
          className="f-tapback"
          initial={{ scale: 0, rotate: -24, opacity: 0 }}
          animate={{ scale: 1, rotate: 0, opacity: 1 }}
          exit={{ scale: 0, opacity: 0 }}
          transition={{ type: "spring", stiffness: 460, damping: 17, delay: 0.15 }}
          role="img"
          aria-label={`reacted ${r.emoji}`}
        >
          <span className="f-emoji">{r.emoji}</span>
        </motion.span>
      )}
    </AnimatePresence>
  );
}
