"use client";

/* ————————————————————————————————————————————————
   THE WIDGET DOCK — things fotra puts on your screen
   "Add a clock." "Leave a note." The agent spawns them,
   they persist, you can clear them. Its screen, your
   stuff on it.
   ———————————————————————————————————————————————— */

import { useEffect, useState } from "react";
import { Check, Pause, Play, RotateCcw, StickyNote, Timer as TimerIcon, X } from "lucide-react";
import { useFotra } from "@/lib/fotra/store";
import type { WidgetInstance } from "@/lib/fotra/types";

export function WidgetDock() {
  const widgets = useFotra((s) => s.widgets);
  if (widgets.length === 0) return null;

  return (
    <div className="flex w-max gap-2 lg:w-full lg:grid lg:grid-cols-2">
      {widgets.map((w) => (
        <WidgetTile key={w.id} widget={w} />
      ))}
    </div>
  );
}

function WidgetTile({ widget }: { widget: WidgetInstance }) {
  const removeWidget = useFotra((s) => s.removeWidget);
  const [hover, setHover] = useState(false);

  return (
    <div
      className="f-rise f-theme-swap group relative rounded-md border border-rule bg-paper-2 p-3"
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      <button
        type="button"
        aria-label={`Remove ${widget.kind} widget`}
        onClick={() => removeWidget(widget.id)}
        className={`absolute right-1.5 top-1.5 rounded p-1 text-dim hover:text-ink hover:bg-paper-3 transition-opacity min-w-[28px] min-h-[28px] grid place-items-center ${
          hover ? "opacity-100" : "opacity-0"
        }`}
      >
        <X size={12} />
      </button>
      {widget.kind === "clock" && <ClockWidget />}
      {widget.kind === "note" && <NoteWidget widget={widget} />}
      {widget.kind === "todo" && <TodoWidget widget={widget} />}
      {widget.kind === "timer" && <TimerWidget widget={widget} />}
    </div>
  );
}

/* —— clock: live, seconds and all —— */

function ClockWidget() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="pr-4">
      <div className="f-label !opacity-50 mb-1">clock</div>
      <div className="f-data text-xl text-ink tabular-nums">
        {now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
      </div>
      <div className="text-xs text-dim mt-0.5">
        {now.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" })}
      </div>
    </div>
  );
}

/* —— note: it stays until cleared —— */

function NoteWidget({ widget }: { widget: WidgetInstance }) {
  const text = typeof widget.props.text === "string" ? widget.props.text : "";
  return (
    <div className="pr-4">
      <div className="mb-1.5 flex items-center gap-1.5">
        <StickyNote size={12} className="text-glow" aria-hidden="true" />
        <span className="f-label !opacity-50">note</span>
      </div>
      <p className="text-sm text-ink-2 leading-relaxed break-words">{text}</p>
    </div>
  );
}

/* —— todo: mini checklist, local-only —— */

interface TodoItem { text: string; done: boolean }

function TodoWidget({ widget }: { widget: WidgetInstance }) {
  const patchWidget = useFotra((s) => s.patchWidget);
  const items: TodoItem[] = Array.isArray(widget.props.items)
    ? (widget.props.items as unknown[]).map((x) => x as TodoItem).filter((x) => x && typeof x.text === "string")
    : [];
  const done = items.filter((i) => i.done).length;

  function toggle(i: number) {
    patchWidget(widget.id, {
      items: items.map((it, idx) => (idx === i ? { ...it, done: !it.done } : it)),
    });
  }

  return (
    <div className="pr-4">
      <div className="f-label !opacity-50 mb-1.5 flex items-baseline justify-between gap-2">
        <span>{typeof widget.props.title === "string" ? widget.props.title : "list"}</span>
        <span>{done}/{items.length}</span>
      </div>
      <ul className="space-y-1">
        {items.map((it, i) => (
          <li key={i}>
            <button
              type="button"
              onClick={() => toggle(i)}
              aria-pressed={it.done}
              className="flex w-full items-start gap-2 text-left"
            >
              <span
                className={`mt-[3px] grid h-3.5 w-3.5 shrink-0 place-items-center rounded border ${
                  it.done ? "border-glow bg-glow text-glow-ink" : "border-rule text-transparent"
                }`}
              >
                <Check size={9} strokeWidth={3.5} />
              </span>
              <span className={`text-xs leading-relaxed ${it.done ? "text-dim line-through" : "text-ink-2"}`}>{it.text}</span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* —— timer: five minutes, ready in the dock —— */

function TimerWidget({ widget }: { widget: WidgetInstance }) {
  const patchWidget = useFotra((s) => s.patchWidget);
  const total = typeof widget.props.total === "number" ? widget.props.total : 300;
  const running = widget.props.running === true;
  const [rem, setRem] = useState(() =>
    typeof widget.props.remaining === "number" ? (widget.props.remaining as number) : total
  );

  useEffect(() => {
    if (!running) return;
    const t = setInterval(() => {
      setRem((r) => {
        const next = Math.max(0, r - 1);
        if (next <= 0) patchWidget(widget.id, { remaining: 0, running: false });
        return next;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [running, widget.id, patchWidget]);

  const mm = Math.floor(rem / 60).toString().padStart(2, "0");
  const ss = (rem % 60).toString().padStart(2, "0");
  const pct = total > 0 ? (rem / total) * 100 : 0;

  return (
    <div className="pr-4">
      <div className="mb-1.5 flex items-center gap-1.5">
        <TimerIcon size={12} className="text-glow" aria-hidden="true" />
        <span className="f-label !opacity-50">timer</span>
      </div>
      <div className={`f-data text-xl tabular-nums ${rem === 0 ? "text-glow" : "text-ink"}`}>
        {mm}:{ss}
      </div>
      <div className="mt-2 h-1 rounded-full bg-paper-3 overflow-hidden">
        <div className="h-full rounded-full bg-glow transition-all duration-1000 ease-linear" style={{ width: `${pct}%` }} />
      </div>
      <div className="mt-2 flex gap-1.5">
        {rem === 0 ? (
          <button
            type="button"
            aria-label="Reset timer"
            onClick={() => {
              setRem(total);
              patchWidget(widget.id, { remaining: total, running: false });
            }}
            className="rounded p-1.5 text-dim hover:text-ink hover:bg-paper-3 min-w-[32px] min-h-[32px] grid place-items-center"
          >
            <RotateCcw size={13} />
          </button>
        ) : (
          <>
            <button
              type="button"
              aria-label={running ? "Pause timer" : "Start timer"}
              onClick={() => patchWidget(widget.id, { running: !running, remaining: rem })}
              className="rounded p-1.5 text-dim hover:text-glow hover:bg-paper-3 min-w-[32px] min-h-[32px] grid place-items-center"
            >
              {running ? <Pause size={13} /> : <Play size={13} />}
            </button>
            <button
              type="button"
              aria-label="Reset timer"
              onClick={() => {
                setRem(total);
                patchWidget(widget.id, { remaining: total, running: false });
              }}
              className="rounded p-1.5 text-dim hover:text-ink hover:bg-paper-3 min-w-[32px] min-h-[32px] grid place-items-center"
            >
              <RotateCcw size={13} />
            </button>
          </>
        )}
      </div>
    </div>
  );
}
