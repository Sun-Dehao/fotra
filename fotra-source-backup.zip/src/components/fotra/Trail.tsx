"use client";

/* ————————————————————————————————————————————————
   THE TRAIL — the agent's work, in the flow of the
   conversation. The rule the whole app follows:

     show what is happening while it happens,
     then get out of the way.

   While a tool runs its surface is live — you watch
   the search, the page, the code. A beat after the
   work lands, the group folds into one quiet line
   ("searched the web · read 2 pages · 6s"). Click it
   and everything is still there, step by step.
   ———————————————————————————————————————————————— */

import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  BookOpenText,
  Brain,
  CalendarClock,
  ChevronRight,
  FileText,
  ListChecks,
  MousePointer2,
  Plug,
  Search,
  Sparkles,
  SquareTerminal,
  Users,
  Wrench,
} from "lucide-react";
import { useFotra } from "@/lib/fotra/store";
import type { Step, StepKind, Turn } from "@/lib/fotra/types";
import {
  BrowserSurface,
  CodeSurface,
  FileSurface,
  MemorySurface,
  PlainSurface,
  ReadSurface,
  ScheduleSurface,
  SearchSurface,
  SelfSurface,
  WorkerSurface,
} from "./Surfaces";

const EASE = [0.16, 1, 0.3, 1] as const;
const LINGER_MS = 1700; // how long a finished surface stays open before the group folds

const KIND_ICON: Record<StepKind, typeof Search> = {
  search: Search,
  read: BookOpenText,
  browser: MousePointer2,
  code: SquareTerminal,
  memory: Brain,
  file: FileText,
  worker: Users,
  plan: ListChecks,
  self: Sparkles,
  schedule: CalendarClock,
  connect: Plug,
  other: Wrench,
};

/** an item in the group: one step, or a run of browser steps read as one session */
type Item = { key: string; kind: StepKind; steps: Step[] };

function toItems(steps: Step[]): Item[] {
  const out: Item[] = [];
  for (const s of steps) {
    const last = out[out.length - 1];
    if (s.kind === "browser" && last?.kind === "browser") last.steps.push(s);
    else out.push({ key: s.id, kind: s.kind, steps: [s] });
  }
  return out;
}

function plural(n: number, one: string, many: string): string {
  return n === 1 ? one : many.replace("#", String(n));
}

/** the folded line: what happened, in plain words */
function summarize(steps: Step[]): string {
  const by = new Map<StepKind, Step[]>();
  for (const s of steps) by.set(s.kind, [...(by.get(s.kind) ?? []), s]);
  const parts: string[] = [];
  for (const [kind, list] of by) {
    const n = list.length;
    switch (kind) {
      case "search":
        parts.push(plural(n, "searched the web", "ran # searches"));
        break;
      case "read":
        parts.push(plural(n, `read ${list[0].subject || "a page"}`, "read # pages"));
        break;
      case "browser":
        parts.push(plural(n, "used the browser", "used the browser · # actions"));
        break;
      case "code":
        parts.push(plural(n, "ran code", "ran # cells"));
        break;
      case "memory": {
        const wrote = list.filter((s) => s.tool === "remember" || s.tool === "learn").length;
        parts.push(wrote === n ? plural(n, "noted it", "noted # things") : wrote === 0 ? "checked memory" : "used memory");
        break;
      }
      case "file": {
        const wrote = list.filter((s) => s.tool === "ws_write" || s.tool === "ws_patch");
        parts.push(wrote.length === 1 ? `wrote ${wrote[0].subject || "a file"}` : wrote.length > 1 ? `wrote ${wrote.length} files` : plural(n, `read ${list[0].subject || "a file"}`, "read # files"));
        break;
      }
      case "worker":
        parts.push(plural(n, `${list[0].title} worked on it`, "# workers in parallel"));
        break;
      case "plan":
        parts.push("updated the plan");
        break;
      case "self":
        parts.push(list.some((s) => s.data?.undone) ? "undid a change to itself" : "changed itself");
        break;
      case "schedule":
        parts.push(list[0].tool === "routine_create" ? "scheduled a routine" : list[0].tool === "routine_delete" ? "cancelled a routine" : "checked the schedule");
        break;
      case "connect":
        parts.push(plural(n, `used ${list[0].subject || "a connected tool"}`, "used # connected tools"));
        break;
      default:
        parts.push(plural(n, list[0].title.toLowerCase(), "# other steps"));
    }
  }
  const text = parts.join(" · ");
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function totalMs(steps: Step[]): number {
  if (steps.length === 0) return 0;
  const start = Math.min(...steps.map((s) => s.ts));
  const end = Math.max(...steps.map((s) => s.ts + (s.ms ?? 0)));
  return Math.max(end - start, Math.max(...steps.map((s) => s.ms ?? 0)));
}

function fmtMs(ms: number): string {
  if (ms < 950) return `${Math.max(1, Math.round(ms / 10) * 10)}ms`;
  if (ms < 60_000) return `${(ms / 1000).toFixed(ms < 10_000 ? 1 : 0)}s`;
  return `${Math.floor(ms / 60_000)}m ${Math.round((ms % 60_000) / 1000)}s`;
}

function Surface({ item, turnId, live }: { item: Item; turnId: string; live: boolean }) {
  const step = item.steps[item.steps.length - 1];
  switch (item.kind) {
    case "search":
      return <SearchSurface step={step} live={live} />;
    case "read":
      return <ReadSurface step={step} />;
    case "browser":
      return <BrowserSurface steps={item.steps} turnId={turnId} />;
    case "code":
      return <CodeSurface step={step} />;
    case "memory":
      return <MemorySurface step={step} />;
    case "file":
      return <FileSurface step={step} />;
    case "worker":
      return <WorkerSurface step={step} />;
    case "self":
      return <SelfSurface step={step} />;
    case "schedule":
      return <ScheduleSurface step={step} />;
    default:
      return <PlainSurface step={step} />;
  }
}

/** one settled step in the opened list — a line that opens to its surface */
function Receipt({ item, turnId }: { item: Item; turnId: string }) {
  const [open, setOpen] = useState(false);
  const step = item.steps[item.steps.length - 1];
  const Icon = KIND_ICON[item.kind];
  const failed = item.steps.some((s) => s.status === "error");
  const ms = item.steps.reduce((a, s) => a + (s.ms ?? 0), 0);
  const line = item.kind === "browser" && item.steps.length > 1 ? `Used the browser · ${item.steps.length} actions` : step.summary || `${step.title}${step.subject ? ` ${step.subject}` : ""}`;
  return (
    <li>
      <button type="button" onClick={() => setOpen((o) => !o)} aria-expanded={open} className="f-receipt group">
        <Icon size={13} className={`shrink-0 ${failed ? "text-danger" : "text-dim"}`} aria-hidden="true" />
        <span className={`min-w-0 flex-1 truncate text-left ${failed ? "text-danger" : "text-ink-2"}`}>{line}</span>
        {ms > 0 && <span className="f-data shrink-0 text-[11px] text-dim">{fmtMs(ms)}</span>}
        <ChevronRight size={13} className={`shrink-0 text-dim transition-transform ${open ? "rotate-90" : ""}`} aria-hidden="true" />
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.26, ease: EASE }}
            className="overflow-hidden"
          >
            <div className="pb-1.5 pl-[22px] pt-1">
              <Surface item={item} turnId={turnId} live={false} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </li>
  );
}

export function StepGroup({ turn, ids }: { turn: Turn; ids: string[] }) {
  const pref = useFotra((s) => s.settings.ui?.trail ?? "auto");
  const steps = useMemo(() => ids.map((id) => turn.steps?.[id]).filter((s): s is Step => !!s), [ids, turn.steps]);
  const items = useMemo(() => toItems(steps), [steps]);
  const running = steps.some((s) => s.status === "running");
  const actionable = steps.some((s) => s.kind === "self" || s.kind === "schedule");

  // live = the group is showing its surfaces. It starts live only if work is actually in flight
  // (a reloaded thread opens folded), stays a beat after the last step lands, then folds.
  const [lingering, setLingering] = useState(false);
  const [userOpen, setUserOpen] = useState<boolean | null>(null);
  const hovering = useRef(false);
  const wasRunning = useRef(running);

  useEffect(() => {
    if (running) {
      wasRunning.current = true;
      setLingering(false);
      return;
    }
    if (!wasRunning.current) return;
    wasRunning.current = false;
    setLingering(true);
    let t: ReturnType<typeof setTimeout>;
    const fold = () => {
      // never fold something out from under the pointer
      if (hovering.current) t = setTimeout(fold, 900);
      else setLingering(false);
    };
    // a change to itself (with its undo) or a new routine is something to read, not just watch
    t = setTimeout(fold, actionable ? LINGER_MS * 5 : LINGER_MS);
    return () => clearTimeout(t);
  }, [running, actionable]);

  if (steps.length === 0) return null;

  const live = pref === "open" || (pref !== "quiet" && (running || lingering));
  const open = userOpen ?? false;
  const failed = steps.some((s) => s.status === "error");
  const kinds = [...new Set(steps.map((s) => s.kind))].slice(0, 4);
  const runningStep = [...steps].reverse().find((s) => s.status === "running");

  return (
    <div
      className="f-trail"
      data-live={live}
      onMouseEnter={() => (hovering.current = true)}
      onMouseLeave={() => (hovering.current = false)}
    >
      <AnimatePresence initial={false}>
        {live ? (
          <motion.div
            key="live"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0, transition: { duration: 0.34, ease: EASE } }}
            transition={{ duration: 0.3, ease: EASE }}
            className="space-y-2 overflow-hidden"
          >
            {items.map((item, i) => {
              const itemRunning = item.steps.some((s) => s.status === "running");
              const isLast = i === items.length - 1;
              // while work is in flight only what is moving (and what just landed) gets a full surface;
              // earlier steps shrink to a line so a long chain doesn't push the page around
              if (pref !== "open" && !itemRunning && !isLast) {
                const Icon = KIND_ICON[item.kind];
                const st = item.steps[item.steps.length - 1];
                return (
                  <div key={item.key} className="f-receipt !cursor-default">
                    <Icon size={13} className={`shrink-0 ${st.status === "error" ? "text-danger" : "text-dim"}`} aria-hidden="true" />
                    <span className={`min-w-0 flex-1 truncate ${st.status === "error" ? "text-danger" : "text-dim"}`}>{st.summary || st.title}</span>
                  </div>
                );
              }
              return (
                <motion.div key={item.key} layout="position" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.32, ease: EASE }}>
                  <div className="mb-1 flex items-center gap-2 pl-0.5">
                    {(() => {
                      const Icon = KIND_ICON[item.kind];
                      return <Icon size={12} className={itemRunning ? "text-glow" : "text-dim"} aria-hidden="true" />;
                    })()}
                    <span className={`text-xs ${itemRunning ? "f-work-intent" : "text-dim"}`}>
                      {item.kind === "browser" ? (itemRunning ? "Using the browser" : "Used the browser") : item.steps[0].title}
                      {item.kind !== "browser" && item.kind !== "search" && item.steps[0].subject ? ` · ${item.steps[0].subject}` : ""}
                    </span>
                  </div>
                  <Surface item={item} turnId={turn.id} live />
                </motion.div>
              );
            })}
          </motion.div>
        ) : (
          <motion.div key="folded" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.22 }}>
            <button type="button" onClick={() => setUserOpen(!open)} aria-expanded={open} className="f-trail-fold group">
              <span className="flex shrink-0 items-center -space-x-1">
                {kinds.map((k) => {
                  const Icon = KIND_ICON[k];
                  return (
                    <span key={k} className="f-trail-ico">
                      <Icon size={11} aria-hidden="true" />
                    </span>
                  );
                })}
              </span>
              <span className={`min-w-0 flex-1 truncate text-left text-[13px] ${running ? "f-work-intent" : failed ? "text-ink-2" : "text-dim group-hover:text-ink-2"}`}>
                {running && runningStep ? `${runningStep.title}${runningStep.subject ? ` · ${runningStep.subject}` : ""}…` : summarize(steps)}
              </span>
              {failed && !running && <span className="f-label shrink-0 text-danger !opacity-90">{steps.filter((s) => s.status === "error").length} failed</span>}
              {!running && <span className="f-data shrink-0 text-[11px] text-dim">{fmtMs(totalMs(steps))}</span>}
              <ChevronRight size={13} className={`shrink-0 text-dim transition-transform ${open ? "rotate-90" : ""}`} aria-hidden="true" />
            </button>
            <AnimatePresence initial={false}>
              {open && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.26, ease: EASE }}
                  className="overflow-hidden"
                >
                  <ul className="space-y-0.5 pl-1.5 pt-1">
                    {items.map((item) => (
                      <Receipt key={item.key} item={item} turnId={turn.id} />
                    ))}
                  </ul>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
