"use client";

/* ————————————————————————————————————————————————
   THE BROWSER STAGE — watching it use the computer.
   When the agent drives its browser, a window pops up
   and you see what it sees: the page, its cursor (with
   its name on it) gliding to what it is about to click,
   the ripple when it clicks, the words as it types.

   It appears on its own when there is something to
   watch and tucks back into the thread a few seconds
   after the work is done — where the receipt keeps the
   last frame and a way to replay every step.

   Picture-in-picture by default (drag it anywhere),
   wide when you want to really look.
   ———————————————————————————————————————————————— */

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useDragControls } from "framer-motion";
import { ChevronsDown, ChevronsUp, Lock, Maximize2, Minimize2, Square, X } from "lucide-react";
import { useFotra } from "@/lib/fotra/store";
import { stopEverything } from "@/lib/fotra/agent";
import { useTyped } from "./Surfaces";

const EASE = [0.16, 1, 0.3, 1] as const;
const TUCK_MS = 5200; // after the run ends, how long the window stays before folding into the thread

function splitUrl(u: string): { host: string; path: string; secure: boolean } {
  try {
    const url = new URL(u);
    return { host: url.host.replace(/^www\./, ""), path: (url.pathname + url.search).replace(/\/$/, ""), secure: url.protocol === "https:" };
  } catch {
    return { host: u.replace(/^https?:\/\//, ""), path: "", secure: u.startsWith("https") };
  }
}

export function BrowserStage() {
  const stage = useFotra((s) => s.stage);
  const setStage = useFotra((s) => s.setStage);
  const phase = useFotra((s) => s.phase);
  const name = useFotra((s) => s.persona.name);
  const boundsRef = useRef<HTMLDivElement>(null);
  const drag = useDragControls();
  const hovering = useRef(false);
  const [held, setHeld] = useState(false); // the user touched it — it stays until they close it
  const [scrub, setScrub] = useState<number | null>(null); // looking back at an earlier frame

  const frames = stage.frames;
  const running = phase === "working" || phase === "thinking" || phase === "speaking";
  const live = stage.live && running;
  const idx = scrub !== null && scrub < frames.length ? scrub : frames.length - 1;
  const frame = frames[idx];
  const wide = stage.size === "wide";

  // new frames pull the view back to the present
  useEffect(() => {
    setScrub(null);
  }, [frames.length]);

  // a fresh session forgets that the last one was held open
  useEffect(() => {
    setHeld(false);
  }, [stage.turnId]);

  // the work is done: linger, then tuck back into the thread — unless the user is looking at it
  useEffect(() => {
    if (!stage.open || running || held || wide) return;
    let t: ReturnType<typeof setTimeout>;
    const tuck = () => {
      if (hovering.current) t = setTimeout(tuck, 1500);
      else setStage({ open: false });
    };
    t = setTimeout(tuck, TUCK_MS);
    return () => clearTimeout(t);
  }, [stage.open, running, held, wide, setStage]);

  const show = stage.open && !!frame;
  const { host, path, secure } = splitUrl(frame?.url ?? "");
  const typed = useTyped(frame?.typed ?? "", !!frame?.typed && frame.act === "type" && idx === frames.length - 1, 38);
  const cx = frame?.cursor?.x ?? 0.5;
  const cy = frame?.cursor?.y ?? 0.45;
  const loading = live && frame?.act === "navigate" && idx === frames.length - 1;
  const badge = stage.demo ? "demo" : live ? "live" : running ? "watching" : "replay";

  return (
    <div ref={boundsRef} className="pointer-events-none fixed inset-0 z-40" aria-hidden={!show}>
      <AnimatePresence>
        {show && wide && (
          <motion.div
            key="dim"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="f-stage-dim pointer-events-auto absolute inset-0"
            onClick={() => setStage({ size: "pip" })}
          />
        )}
        {show && (
          <motion.section
            key={wide ? "wide" : "pip"}
            role="dialog"
            aria-label={`${name}'s browser`}
            drag={!wide}
            dragControls={drag}
            dragListener={false}
            dragMomentum={false}
            dragElastic={0.08}
            dragConstraints={boundsRef}
            initial={{ opacity: 0, scale: 0.9, y: 28 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 22, transition: { duration: 0.2 } }}
            transition={{ duration: 0.42, ease: EASE }}
            className={`f-stage pointer-events-auto ${wide ? "is-wide" : "is-pip"}`}
            data-live={live}
            onMouseEnter={() => (hovering.current = true)}
            onMouseLeave={() => (hovering.current = false)}
          >
            {/* the chrome — grab it to move the window */}
            <header
              className="f-stage-bar"
              onPointerDown={(e) => {
                if (!wide && !(e.target as HTMLElement).closest("button")) {
                  drag.start(e);
                  setHeld(true);
                }
              }}
            >
              <span className="flex shrink-0 items-center gap-1.5" aria-hidden="true">
                <i className="f-stage-dot" />
                <i className="f-stage-dot" />
                <i className="f-stage-dot" />
              </span>
              <span className="f-stage-url">
                {secure && <Lock size={10} className="shrink-0 opacity-60" aria-hidden="true" />}
                <span className="truncate">
                  <span className="text-ink">{host || "about:blank"}</span>
                  <span className="text-dim">{path.length > 1 ? path.slice(0, 60) : ""}</span>
                </span>
              </span>
              <span className={`f-stage-badge ${live ? "is-live" : ""}`}>
                {live && <span className="f-live-dot" aria-hidden="true" />}
                {badge}
              </span>
              <button
                type="button"
                className="f-stage-btn"
                aria-label={wide ? "Shrink the browser window" : "Expand the browser window"}
                onClick={() => {
                  setHeld(true);
                  setStage({ size: wide ? "pip" : "wide" });
                }}
              >
                {wide ? <Minimize2 size={13} /> : <Maximize2 size={13} />}
              </button>
              <button type="button" className="f-stage-btn" aria-label="Close the browser window" onClick={() => setStage({ open: false })}>
                <X size={14} />
              </button>
            </header>

            {/* the page */}
            <div className="f-stage-view">
              {loading && <div className="f-stage-load" aria-hidden="true" />}
              <AnimatePresence initial={false}>
                {frame.shot ? (
                  <motion.img
                    key={frame.shot.length + ":" + frame.shot.slice(-24)}
                    src={frame.shot}
                    alt={frame.title ? `the page: ${frame.title}` : "the page the agent is on"}
                    draggable={false}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 1, transition: { duration: 0.34 } }}
                    transition={{ duration: 0.3 }}
                    className="f-stage-shot"
                  />
                ) : (
                  <motion.div key="blank" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="f-stage-blank">
                    <span className="f-shimmer h-4 w-2/5" />
                    <span className="f-shimmer h-3 w-4/5" />
                    <span className="f-shimmer h-3 w-3/5" />
                    <span className="f-shimmer mt-3 h-24 w-full" />
                  </motion.div>
                )}
              </AnimatePresence>

              {/* scrolling — a nudge in the direction of travel */}
              {live && frame.act === "scroll" && (
                <span className="f-stage-scroll" aria-hidden="true">
                  {/up/.test(frame.note ?? "") ? <ChevronsUp size={18} /> : <ChevronsDown size={18} />}
                </span>
              )}

              {/* the cursor — it wears the agent's name, like a collaborator's */}
              {frame.shot && (
                <motion.div
                  className="f-stage-cursor"
                  initial={false}
                  animate={{ left: `${cx * 100}%`, top: `${cy * 100}%` }}
                  transition={{ type: "spring", stiffness: 170, damping: 24, mass: 0.9 }}
                >
                  {frame.act === "click" && <span key={frame.ts} className="f-stage-ripple" aria-hidden="true" />}
                  <svg width="20" height="22" viewBox="0 0 20 22" aria-hidden="true">
                    <path d="M2.5 1.8 17 9.6l-6.3 1.7-2.6 6.6z" className="f-stage-arrow" />
                  </svg>
                  <span className="f-stage-tag">{name.toLowerCase()}</span>
                  {frame.act === "type" && frame.typed && (
                    <span className="f-stage-typed">
                      {typed}
                      <span className="f-caret" aria-hidden="true" />
                    </span>
                  )}
                </motion.div>
              )}
            </div>

            {/* what it is doing, and the reel of what it did */}
            <footer className="f-stage-foot">
              <span className={`min-w-0 flex-1 truncate text-xs ${live ? "f-work-intent" : "text-dim"}`} aria-live="polite">
                {frame.note || frame.title || host}
              </span>
              {frames.length > 1 && (
                <span className="flex shrink-0 items-center gap-[3px]" role="group" aria-label="Steps so far">
                  {frames.slice(-14).map((f, i, list) => {
                    const real = frames.length - list.length + i;
                    return (
                      <button
                        key={f.ts + ":" + real}
                        type="button"
                        aria-label={`Step ${real + 1}${f.note ? ` — ${f.note}` : ""}`}
                        aria-pressed={real === idx}
                        title={f.note || f.title || ""}
                        onClick={() => {
                          setHeld(true);
                          setScrub(real === frames.length - 1 ? null : real);
                        }}
                        className={`f-stage-pip ${real === idx ? "is-on" : ""}`}
                      />
                    );
                  })}
                </span>
              )}
              {live && (
                <button type="button" className="f-stage-stop" onClick={() => stopEverything()} aria-label="Stop the agent">
                  <Square size={8} fill="currentColor" aria-hidden="true" />
                  stop
                </button>
              )}
            </footer>
          </motion.section>
        )}
      </AnimatePresence>
    </div>
  );
}
