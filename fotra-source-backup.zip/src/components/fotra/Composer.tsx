"use client";

/* ————————————————————————————————————————————————
   THE COMPOSER — text as the equal path
   One floating bar: the mascot (it is the mic), the
   input, send. While a run is live the bar grows a
   line that says what it is doing, how long it has
   been, and how to stop it — and enter STEERS the run
   instead of queueing behind it. Space is push-to-talk
   whenever the input isn't focused.
   ———————————————————————————————————————————————— */

import { useEffect, useRef, useState, type KeyboardEvent as ReactKeyboardEvent } from "react";
import { ArrowUp, CornerUpRight, Mic, MicOff, Phone, Pin, Square, Volume2, VolumeX, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useFotra } from "@/lib/fotra/store";
import { submitInput, stopEverything, runState } from "@/lib/fotra/agent";
import { voiceInput } from "@/lib/fotra/voice";
import { callState, endCall, startCall, subscribeCalls, toggleMute, toggleSpeaker } from "@/lib/fotra/voice-realtime";
import { MascotButton } from "./mascot/StageMascot";

export function Composer({ hero = false }: { hero?: boolean }) {
  const [draft, setDraft] = useState("");
  const taRef = useRef<HTMLTextAreaElement>(null);
  const queue = useFotra((s) => s.queue);
  const removeQueued = useFotra((s) => s.removeQueued);
  const phase = useFotra((s) => s.phase);
  const screens = useFotra((s) => s.screens);
  const screenOrder = useFotra((s) => s.screenOrder);
  const setExpanded = useFotra((s) => s.setExpanded);
  const readOnly = useFotra((s) => s.readOnly);
  const voiceMode = useFotra((s) => s.settings.voiceMode);

  const [call, setCall] = useState(callState());
  useEffect(() => subscribeCalls(() => setCall(callState())), []);

  const running = phase === "thinking" || phase === "working" || phase === "speaking";
  const statusLine = useFotra((s) => s.statusLine);
  const waiting = runState().waiting;
  const pinnedScreens = screenOrder
    .map((id) => screens[id])
    .filter((sc) => sc?.pinned && sc.status !== "retired");

  function send() {
    const text = draft.trim();
    if (!text) return;
    setDraft("");
    submitInput(text, "text");
  }

  // the textarea grows with the message — one line to five, then it scrolls
  useEffect(() => {
    const el = taRef.current;
    if (!el) return;
    el.style.height = "0px";
    el.style.height = `${Math.min(el.scrollHeight, 148)}px`;
  }, [draft]);

  function onKeyDown(e: ReactKeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
    e.stopPropagation(); // keep space typing spaces, not toggling the mic
  }

  const onCall = call.status === "active" || call.status === "connecting";

  const startedAt = useFotra((s) => s.runStartedAt);
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!running) return;
    setNow(Date.now());
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [running]);
  const secs = startedAt ? Math.max(0, Math.floor((now - startedAt) / 1000)) : 0;

  // the first thing on screen is the place to type
  useEffect(() => {
    if (window.matchMedia("(pointer: fine)").matches) taRef.current?.focus();
  }, []);

  return (
    <div>
      {/* pinned chips */}
      {pinnedScreens.length > 0 && (
        <div className="f-scroll mb-2 flex gap-2 overflow-x-auto">
          {pinnedScreens.map((sc) => (
            <button
              key={sc.id}
              type="button"
              onClick={() => setExpanded(sc.id, true)}
              className="f-fade inline-flex min-h-[30px] shrink-0 items-center gap-1.5 rounded-full border border-glow/40 bg-glow/5 px-3 text-xs text-ink-2 transition-colors hover:border-glow hover:text-ink"
              aria-label={`Pinned ${sc.component} screen — open`}
            >
              <Pin size={11} className="text-glow" />
              <span className="f-label !opacity-80">{String(sc.props.title ?? sc.component).slice(0, 40)}</span>
            </button>
          ))}
        </div>
      )}

      {/* the call bar — live realtime call */}
      {onCall && <CallBar call={call} />}

      <div className="f-composer" data-running={running} data-listening={phase === "listening"}>
        {/* what it is doing right now — one honest line, with the clock and the way out */}
        {running && (
          <div className="f-now" role="status">
            <span className="f-live-dot" aria-hidden="true" />
            <span className="f-data shrink-0 text-[11px] text-dim" title="elapsed">
              {Math.floor(secs / 60)}:{(secs % 60).toString().padStart(2, "0")}
            </span>
            <span className="f-work-intent min-w-0 flex-1 truncate text-xs">
              {statusLine || (phase === "speaking" ? "speaking…" : phase === "thinking" ? "thinking…" : "working…")}
            </span>
            <button type="button" onClick={() => stopEverything()} className="f-now-stop" aria-label="Stop the current run">
              <Square size={8} fill="currentColor" aria-hidden="true" />
              stop
              <kbd>esc</kbd>
            </button>
          </div>
        )}

        {/* the visible queue */}
        {queue.length > 0 && (
          <div className="space-y-1 px-3 pt-2.5">
            {queue.map((q) => (
              <div key={q.id} className={`f-fade flex items-center justify-between gap-3 rounded-xl border px-3 py-1.5 ${q.steered ? "border-glow/30 bg-glow/5" : "border-rule bg-paper-3/40"}`}>
                <p className="min-w-0 truncate text-sm text-ink-2">
                  <span className="f-label mr-2 !opacity-60">{q.steered ? "steered in" : "queued"}</span>
                  {q.text}
                </p>
                <button type="button" aria-label="Remove queued message" onClick={() => removeQueued(q.id)} className="grid h-7 w-7 shrink-0 place-items-center rounded-full text-dim hover:bg-paper-3 hover:text-ink">
                  <X size={13} />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="flex items-end gap-2 p-2 pl-2.5">
          {/* the mascot is the mic: tap to talk, tap to interrupt */}
          {/* on the idle screen the big one above already is — no need for two */}
          {!hero && (
            <div className="shrink-0 pb-0.5">
              <MascotButton size={38} />
            </div>
          )}
          <textarea
            ref={taRef}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={onKeyDown}
            disabled={readOnly}
            rows={1}
            placeholder={
              onCall
                ? "on a call — or type here"
                : readOnly
                  ? "read-only — another tab owns the conversation"
                  : waiting
                    ? "answer the question…"
                    : phase === "listening"
                      ? "listening… or type"
                      : running
                        ? "steer it — type and press enter, no need to stop"
                        : "Ask anything"
            }
            aria-label="Message"
            className={`max-h-[148px] min-h-[40px] min-w-0 flex-1 resize-none bg-transparent py-2 ${hero ? "pl-3 pr-1.5" : "px-1.5"} text-[15px] leading-relaxed text-ink outline-none placeholder:text-dim disabled:opacity-50`}
          />
          {onCall ? (
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => void endCall()}
                  aria-label="End the call"
                  className="h-10 w-10 shrink-0 rounded-full border-danger/60 text-danger hover:bg-danger/10 hover:text-danger"
                >
                  <Phone size={15} />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="top">end the call</TooltipContent>
            </Tooltip>
          ) : (
            <>
              {/* the send button — send when idle, STEER when a run is live */}
              {(running || voiceMode !== "realtime" || draft.trim()) && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      type="button"
                      size="icon"
                      onClick={send}
                      disabled={!draft.trim() || readOnly}
                      aria-label={running ? "Steer the current run" : "Send message"}
                      className={`h-10 w-10 shrink-0 rounded-full transition-all ${
                        draft.trim() && !readOnly ? "bg-glow text-glow-ink hover:brightness-110" : "bg-paper-3 text-dim hover:bg-paper-3"
                      }`}
                    >
                      {running ? <CornerUpRight size={16} strokeWidth={2.5} /> : <ArrowUp size={16} strokeWidth={2.5} />}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="top">{running ? "steer — it lands mid-run" : "send · enter"}</TooltipContent>
                </Tooltip>
              )}
              {/* idle + realtime mode: the call button */}
              {!running && voiceMode === "realtime" && !draft.trim() && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      type="button"
                      size="icon"
                      onClick={() => void startCall()}
                      aria-label="Start a voice call"
                      className="h-10 w-10 shrink-0 rounded-full bg-glow text-glow-ink hover:brightness-110"
                    >
                      <Phone size={15} />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="top">realtime call · webrtc</TooltipContent>
                </Tooltip>
              )}
            </>
          )}
        </div>
      </div>
      {call.error && <p className="f-label mt-1.5 px-3 text-danger !opacity-80">{call.error}</p>}
    </div>
  );
}
function CallBar({ call }: { call: ReturnType<typeof callState> }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const secs = call.startedAt ? Math.max(0, Math.floor((now - call.startedAt) / 1000)) : 0;
  const mm = Math.floor(secs / 60);
  const ss = secs % 60;
  const danger = secs >= 14 * 60 + 30;

  return (
    <div className="f-fade mb-2 flex items-center justify-between gap-3 rounded-2xl border border-glow/40 bg-glow/5 px-3.5 py-2">
      <div className="flex min-w-0 items-center gap-2.5">
        <span className="f-live-dot" aria-hidden="true" />
        <span className={`f-data text-sm ${danger ? "text-danger" : "text-ink"}`}>
          {call.status === "connecting" ? "connecting…" : `${mm}:${ss.toString().padStart(2, "0")}`}
        </span>
        {call.phase === "thinking" && <span className="f-label !opacity-60">thinking…</span>}
        {call.phase === "speaking" && <span className="f-label !opacity-60">speaking</span>}
        {call.phase === "listening" && !call.caption && <span className="f-label !opacity-60">listening</span>}
        {call.caption && <span className="f-label !opacity-70 max-w-[280px] truncate">{call.caption}</span>}
      </div>
      <div className="flex shrink-0 items-center gap-1.5">
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={toggleMute}
          aria-label={call.muted ? "Unmute mic" : "Mute mic"}
          className={`h-9 w-9 rounded-md ${call.muted ? "border-danger/60 bg-transparent text-danger hover:bg-danger/10 hover:text-danger" : "border-rule bg-transparent text-ink-2 hover:bg-paper-3 hover:text-ink"}`}
        >
          {call.muted ? <MicOff size={14} /> : <Mic size={14} />}
        </Button>
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={toggleSpeaker}
          aria-label={call.speakerMuted ? "Unmute speaker" : "Mute speaker"}
          className={`h-9 w-9 rounded-md ${call.speakerMuted ? "border-danger/60 bg-transparent text-danger hover:bg-danger/10 hover:text-danger" : "border-rule bg-transparent text-ink-2 hover:bg-paper-3 hover:text-ink"}`}
        >
          {call.speakerMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
        </Button>
      </div>
    </div>
  );
}

/** app-level space push-to-talk (input not focused) */
export function handleGlobalKeydown(e: KeyboardEvent) {
  const target = e.target as HTMLElement | null;
  const typing = target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable);
  if (typing) return;
  if (e.code === "Space" && !e.repeat) {
    e.preventDefault();
    if (!voiceInput.listening) void voiceInput.start();
  }
}

export function handleGlobalKeyup(e: KeyboardEvent) {
  const target = e.target as HTMLElement | null;
  const typing = target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable);
  if (typing) return;
  if (e.code === "Space") {
    e.preventDefault();
    if (voiceInput.listening) voiceInput.stop(true);
  }
}
