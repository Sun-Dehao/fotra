"use client";

/* ————————————————————————————————————————————————
   GENERATIVE SCREENS — the component registry
   Typed components for RESULTS (the work itself shows
   in the trail). They dock in the thread where they
   were made, build while fotra speaks, and pin when
   you want to keep them above the composer.
   ———————————————————————————————————————————————— */

import { useMemo, useState } from "react";
import {
  Check,
  Maximize2,
  Minimize2,
  Pin,
  PinOff,
  Star,
  X,
} from "lucide-react";
import { useFotra } from "@/lib/fotra/store";
import { submitInput } from "@/lib/fotra/agent";
import type { ScreenInstance } from "@/lib/fotra/types";
import { Markdown } from "./Markdown";
import { HostTile } from "./Surfaces";

/* —— ScreenCard: lifecycle chrome around any component —— */

export function ScreenCard({ screen }: { screen: ScreenInstance }) {
  const togglePin = useFotra((s) => s.togglePin);
  const setExpanded = useFotra((s) => s.setExpanded);
  const dismissScreen = useFotra((s) => s.dismissScreen);
  const retired = screen.status === "interrupted";
  const label = SCREEN_LABEL[screen.component] ?? screen.component;

  if (screen.expanded) {
    return <ExpandedScreen screen={screen} />;
  }

  return (
    <div
      className={`f-screen f-rise f-theme-swap group/screen my-3 overflow-hidden ${screen.component === "doc" || screen.component === "table" || screen.component === "chart" ? "max-w-none" : "max-w-[580px]"} ${
        retired ? "opacity-50" : ""
      }`}
    >
      <div className="f-screen-head">
        <div className="flex items-center gap-2">
          <span className="f-label !opacity-60">{label}</span>
          {screen.building && (
            <span className="f-label !opacity-100 text-glow">building…</span>
          )}
          {screen.demoData && !screen.building && (
            <span className="f-label !opacity-45">demo data</span>
          )}
          {screen.pinned && (
            <span className="f-label !opacity-45 text-glow">pinned</span>
          )}
          {screen.status === "interrupted" && (
            <span className="f-label !opacity-45">interrupted</span>
          )}
        </div>
        {/* the chrome stays out of the way until you reach for it */}
        <div className="f-screen-tools">
          <button type="button" aria-label={screen.pinned ? "Unpin screen" : "Pin screen"} onClick={() => togglePin(screen.id)} className="f-screen-btn">
            {screen.pinned ? <PinOff size={13} /> : <Pin size={13} />}
          </button>
          <button type="button" aria-label="Expand screen" onClick={() => setExpanded(screen.id, true)} className="f-screen-btn">
            <Maximize2 size={13} />
          </button>
          <button type="button" aria-label="Dismiss screen" onClick={() => dismissScreen(screen.id)} className="f-screen-btn">
            <X size={13} />
          </button>
        </div>
      </div>
      <div className="px-4 pb-4 pt-1">
        <ScreenBody screen={screen} />
      </div>
    </div>
  );
}

const SCREEN_LABEL: Record<string, string> = {
  card: "note",
  stat: "figure",
  table: "comparison",
  checklist: "checklist",
  hotel: "stays",
  ask: "question",
  todo: "plan",
  chart: "chart",
  doc: "write-up",
  sources: "sources",
  code: "code",
  browser: "browser",
  worker: "worker",
  files: "files",
};

function ExpandedScreen({ screen }: { screen: ScreenInstance }) {
  const setExpanded = useFotra((s) => s.setExpanded);
  return (
    <div className="f-stage-dim fixed inset-0 z-50 grid place-items-center p-4 f-fade" role="dialog" aria-modal="true" aria-label="Expanded screen" onClick={() => setExpanded(screen.id, false)}>
      <div className="f-surface f-scroll max-h-[88vh] w-full max-w-3xl overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-rule px-4 py-2">
          <span className="f-label !opacity-70">{screen.component}</span>
          <button
            type="button"
            aria-label="Close expanded screen"
            onClick={() => setExpanded(screen.id, false)}
            className="rounded p-2 text-dim hover:bg-paper-3 hover:text-ink min-w-[36px] min-h-[36px] grid place-items-center"
          >
            <Minimize2 size={15} />
          </button>
        </div>
        <div className="p-6 text-lg">
          <ScreenBody screen={screen} large />
        </div>
      </div>
    </div>
  );
}

function ScreenBody({ screen, large = false }: { screen: ScreenInstance; large?: boolean }) {
  const p = screen.props;
  switch (screen.component) {
    case "card":
      return <CardBody p={p} large={large} />;
    case "stat":
      return <StatBody p={p} large={large} />;
    case "table":
      return <TableBody p={p} large={large} />;
    case "checklist":
      return <ChecklistBody screen={screen} large={large} />;
    case "hotel":
      return <HotelBody screen={screen} large={large} />;
    case "ask":
      return <AskBody screen={screen} large={large} />;
    case "code":
      return <CodeBody p={p} large={large} />;
    case "browser":
      return <BrowserBody p={p} large={large} />;
    case "worker":
      return <WorkerBody p={p} large={large} />;
    case "todo":
      return <TodoBody p={p} large={large} />;
    case "files":
      return <FilesBody p={p} large={large} />;
    case "chart":
      return <ChartBody p={p} large={large} />;
    case "doc":
      return <DocBody p={p} large={large} />;
    case "sources":
      return <SourcesBody p={p} />;
    default:
      return null;
  }
}

/* —— helpers —— */

const Skeleton = ({ w = "100%", h = "0.9em" }: { w?: string; h?: string }) => (
  <div className="f-shimmer inline-block align-middle" style={{ width: w, height: h }} />
);

const FadeIn = ({ children }: { children: React.ReactNode }) => (
  <span className="f-fade">{children}</span>
);

function asString(v: unknown): string | null {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function asNum(v: unknown): number | null {
  return typeof v === "number" ? v : null;
}

/* —— DOC — the long-form answer: when it's more than a few spoken lines —— */

function DocBody({ p, large }: { p: Record<string, unknown>; large?: boolean }) {
  const title = asString(p.title);
  const md = asString(p.markdown) ?? asString(p.body) ?? "";
  return (
    <div className="space-y-2">
      {title && <h3 className={`font-display font-semibold text-ink ${large ? "text-2xl" : "text-lg"}`}>{title}</h3>}
      {md ? <Markdown text={md} className={large ? "text-base" : ""} /> : <Skeleton w="92%" h="5em" />}
    </div>
  );
}

/* —— SOURCES — what a researched answer stands on —— */

function SourcesBody({ p }: { p: Record<string, unknown> }) {
  const items = (Array.isArray(p.items) ? (p.items as unknown[]) : [])
    .map((x) => (x ?? {}) as { title?: unknown; url?: unknown; host?: unknown })
    .filter((x) => typeof x.url === "string" && /^https?:\/\//i.test(x.url as string));
  if (items.length === 0) return <Skeleton w="70%" h="1.6em" />;
  return (
    <ul className="flex flex-wrap gap-2">
      {items.map((it, i) => {
        const url = it.url as string;
        let host = typeof it.host === "string" ? it.host : "";
        if (!host) {
          try {
            host = new URL(url).host.replace(/^www\./, "");
          } catch {
            host = url;
          }
        }
        return (
          <li key={`${url}-${i}`}>
            <a href={url} target="_blank" rel="noopener noreferrer" className="f-source" title={typeof it.title === "string" ? it.title : url}>
              <HostTile host={host} size={18} />
              <span className="min-w-0 truncate">{typeof it.title === "string" && it.title ? it.title : host}</span>
              <span className="shrink-0 text-dim">{host}</span>
            </a>
          </li>
        );
      })}
    </ul>
  );
}

/* —— CARD —— */

function CardBody({ p, large }: { p: Record<string, unknown>; large?: boolean }) {
  const title = asString(p.title);
  const body = asString(p.body);
  const items = Array.isArray(p.items) ? (p.items as unknown[]).filter((x): x is string => typeof x === "string") : [];
  return (
    <div className="space-y-3">
      {title ? (
        <h3 className={`font-display font-semibold text-ink ${large ? "text-2xl" : "text-base"}`}>{title}</h3>
      ) : (
        <Skeleton w="40%" h="1.2em" />
      )}
      {body && <p className="text-ink-2 leading-relaxed">{body}</p>}
      {items.length > 0 && (
        <ul className="space-y-1.5">
          {items.map((it, i) => (
            <li key={i} className="flex gap-2.5 text-ink-2 leading-relaxed">
              <span className="mt-[0.7em] h-1 w-1 shrink-0 rounded-full bg-glow" aria-hidden="true" />
              <span><FadeIn>{it}</FadeIn></span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* —— STAT —— */

function StatBody({ p, large }: { p: Record<string, unknown>; large?: boolean }) {
  const label = asString(p.label);
  const value = asString(p.value);
  const delta = asString(p.delta);
  const hint = asString(p.hint);
  return (
    <div className="space-y-2">
      {label ? <div className="f-label">{label}</div> : <Skeleton w="35%" h="0.8em" />}
      {value ? (
        <div className={`font-display font-semibold text-glow ${large ? "text-6xl" : "text-5xl"} f-data`}>{value}</div>
      ) : (
        <Skeleton w="45%" h="2.4em" />
      )}
      <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
        {delta && <span className="f-data text-sm text-ink-2">{delta}</span>}
        {hint && <span className="text-sm text-dim">{hint}</span>}
        {!delta && !hint && screenBuilding(p) && <Skeleton w="55%" h="0.8em" />}
      </div>
    </div>
  );
}

function screenBuilding(p: Record<string, unknown>): boolean {
  return Object.keys(p).length < 2;
}

/* —— TABLE —— */

function TableBody({ p, large }: { p: Record<string, unknown>; large?: boolean }) {
  const title = asString(p.title);
  const columns = Array.isArray(p.columns) ? (p.columns as unknown[]).filter((x): x is string => typeof x === "string") : [];
  const rows = Array.isArray(p.rows)
    ? (p.rows as unknown[]).map((r) => (Array.isArray(r) ? (r as unknown[]).map((c) => String(c)) : null)).filter((r): r is string[] => r !== null)
    : [];
  return (
    <div className="space-y-3">
      {title && <h3 className={`font-display font-semibold text-ink ${large ? "text-2xl" : "text-base"}`}>{title}</h3>}
      {columns.length > 0 ? (
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr>
              {columns.map((c, i) => (
                <th key={i} className="f-label !opacity-70 text-left border-b border-rule pb-2 pr-4 font-normal">
                  {c}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} className="border-b border-rule/50 last:border-0">
                {r.map((c, j) => (
                  <td key={j} className={`py-2.5 pr-4 align-top ${j === 0 ? "text-dim" : "text-ink-2 f-data"}`}>
                    <FadeIn>{c}</FadeIn>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <Skeleton w="90%" h="6em" />
      )}
    </div>
  );
}

/* —— CHECKLIST —— */

interface ChecklistItem { text: string; done: boolean }

function ChecklistBody({ screen, large }: { screen: ScreenInstance; large?: boolean }) {
  const patchScreen = useFotra((s) => s.patchScreen);
  const title = asString(screen.props.title);
  const rawItems = Array.isArray(screen.props.items)
    ? (screen.props.items as unknown[]).map((x) => (typeof x === "string" ? { text: x, done: false } : x as ChecklistItem)).filter((x) => x && typeof x.text === "string")
    : [];
  const done = rawItems.filter((i) => i.done).length;

  function toggle(i: number) {
    // local-only update — the satisfying part needs no model
    const next = rawItems.map((it, idx) => (idx === i ? { ...it, done: !it.done } : it));
    patchScreen(screen.id, { items: next });
  }

  return (
    <div className="space-y-3">
      <div className="flex items-baseline justify-between gap-3">
        {title ? (
          <h3 className={`font-display font-semibold text-ink ${large ? "text-2xl" : "text-base"}`}>{title}</h3>
        ) : (
          <Skeleton w="45%" h="1.2em" />
        )}
        {rawItems.length > 0 && (
          <span className="f-label shrink-0">{done}/{rawItems.length}</span>
        )}
      </div>
      {rawItems.length === 0 ? (
        <div className="space-y-2">
          <Skeleton w="80%" />
          <Skeleton w="65%" />
          <Skeleton w="72%" />
        </div>
      ) : (
        <ul className="space-y-0.5">
          {rawItems.map((it, i) => (
            <li key={i}>
              <button
                type="button"
                onClick={() => toggle(i)}
                className="group flex w-full items-start gap-3 rounded-md px-2 py-2 -mx-2 text-left hover:bg-paper-3 min-h-[40px]"
                aria-pressed={it.done}
              >
                <span
                  className={`mt-0.5 grid h-[18px] w-[18px] shrink-0 place-items-center rounded border transition-colors ${
                    it.done ? "border-glow bg-glow text-glow-ink" : "border-rule text-transparent group-hover:border-dim"
                  }`}
                >
                  <Check size={12} strokeWidth={3} />
                </span>
                <span className={`leading-relaxed ${it.done ? "text-dim line-through" : "text-ink-2"}`}>{it.text}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* —— HOTEL — the party trick —— */

interface HotelOption { name: string; area: string; price: number; rating: number; perks: string[] }

function HotelBody({ screen, large }: { screen: ScreenInstance; large?: boolean }) {
  const p = screen.props;
  const title = asString(p.title);
  const selected = asString(p.selected);
  const booked = p.booked === true;

  // during progressive build the options come as optionN* fields
  const options = useMemo(() => {
    const arr = Array.isArray(p.options) ? (p.options as unknown[]).filter((x): x is HotelOption => !!x && typeof (x as HotelOption).name === "string") : [];
    if (arr.length > 0) return arr;
    const built: HotelOption[] = [];
    for (let i = 0; i < 3; i++) {
      const name = asString(p[`option${i}Name`]);
      if (!name) continue;
      built.push({
        name,
        area: asString(p[`option${i}Area`]) ?? "",
        price: asNum(p[`option${i}Price`]) ?? 0,
        rating: asNum(p[`option${i}Rating`]) ?? 0,
        perks: Array.isArray(p[`option${i}Perks`]) ? (p[`option${i}Perks`] as unknown[]).filter((x): x is string => typeof x === "string") : [],
      });
    }
    return built;
  }, [p]);

  // local slider state; follows the brain when it re-cuts the budget (voice: "under 120")
  const propBudget = typeof p.budget === "number" ? (p.budget as number) : 400;
  const [localBudget, setLocalBudget] = useState<number | null>(null);
  const [seenProp, setSeenProp] = useState(propBudget);
  if (seenProp !== propBudget) {
    setSeenProp(propBudget);
    setLocalBudget(null); // brain moved it — follow
  }
  const budget = localBudget ?? propBudget;
  const visible = options.filter((o) => o.price <= budget);

  return (
    <div className="space-y-4">
      <div className="flex items-baseline justify-between gap-3">
        {title ? (
          <h3 className={`font-display font-semibold text-ink ${large ? "text-2xl" : "text-base"}`}>{title}</h3>
        ) : (
          <Skeleton w="50%" h="1.2em" />
        )}
        <span className="f-label shrink-0">{visible.length} in range</span>
      </div>

      {typeof p.budget === "number" && (
        <div className="flex items-center gap-3">
          <input
            type="range"
            className="f-range flex-1"
            min={50}
            max={400}
            step={10}
            value={budget}
            aria-label="Budget per night"
            onChange={(e) => setLocalBudget(Number(e.target.value))}
          />
          <span className="f-data text-sm text-glow w-14 text-right">${budget}</span>
        </div>
      )}

      {options.length === 0 ? (
        <div className="space-y-3">
          <Skeleton w="100%" h="4.4em" />
          <Skeleton w="100%" h="4.4em" />
        </div>
      ) : (
        <ul className="space-y-2">
          {visible.map((o) => {
            const isSelected = selected === o.name;
            return (
              <li
                key={o.name}
                className={`f-fade rounded-md border px-3.5 py-3 transition-colors ${
                  isSelected ? "border-glow/60 bg-glow/5" : "border-rule hover:border-dim/60"
                } ${booked && isSelected ? "border-glow" : ""}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-display font-semibold text-ink">{o.name}</span>
                      {o.rating > 0 && (
                        <span className="f-data inline-flex items-center gap-1 text-xs text-dim">
                          <Star size={11} className="text-glow" fill="currentColor" /> {o.rating}
                        </span>
                      )}
                    </div>
                    <div className="text-sm text-dim mt-0.5">{o.area}</div>
                    {o.perks.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {o.perks.map((perk) => (
                          <span key={perk} className="f-label !opacity-60 rounded-full border border-rule px-2 py-0.5 !normal-case tracking-normal">
                            {perk}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="shrink-0 text-right">
                    <div className="f-data text-ink font-semibold">${o.price}</div>
                    <div className="f-label !opacity-50">/night</div>
                  </div>
                </div>
                {!booked && (
                  <button
                    type="button"
                    onClick={() => submitInput(`Go with ${o.name}`, "action")}
                    className={`mt-3 rounded-md px-3 py-1.5 text-sm font-medium transition-colors min-h-[36px] ${
                      isSelected ? "bg-glow text-glow-ink" : "border border-rule text-ink-2 hover:border-glow/60 hover:text-ink"
                    }`}
                  >
                    {isSelected ? "selected" : "go with this"}
                  </button>
                )}
                {booked && isSelected && (
                  <div className="mt-3 inline-flex items-center gap-2 rounded-md bg-glow/10 border border-glow/40 px-3 py-1.5 text-sm text-glow">
                    <Check size={14} /> held — demo booking
                  </div>
                )}
              </li>
            );
          })}
          {visible.length === 0 && (
            <li className="text-dim text-sm py-2">Nothing under ${budget} — slide up.</li>
          )}
        </ul>
      )}
    </div>
  );
}

/* —— ASK — fotra needs an answer (and may be holding a run open for it) —— */

function AskBody({ screen, large }: { screen: ScreenInstance; large?: boolean }) {
  const resolveAsk = useFotra((s) => s.resolveAsk);
  const q = asString(screen.props.question) ?? "";
  const detail = asString(screen.props.detail);
  const options = Array.isArray(screen.props.options)
    ? (screen.props.options as unknown[]).filter((x): x is string => typeof x === "string")
    : ["Yes", "No"];
  const resolved = screen.resolved ?? null;
  const resume =
    screen.props.resume && typeof screen.props.resume === "object"
      ? (screen.props.resume as { runId?: string; kind?: string })
      : null;

  return (
    <div className="space-y-3">
      <div className="flex items-start gap-2.5">
        <span className="f-label mt-1.5 shrink-0 text-glow">ask</span>
        <div>
          <p className={`font-display font-semibold text-ink ${large ? "text-2xl" : "text-base"}`}>{q}</p>
          {detail && <p className="mt-1 text-sm text-dim leading-relaxed">{detail}</p>}
        </div>
      </div>
      <div className="flex flex-wrap gap-2 pl-8">
        {resolved ? (
          <span className="f-fade inline-flex items-center gap-2 rounded-md border border-glow/40 bg-glow/10 px-3 py-1.5 text-sm text-glow">
            <Check size={14} /> {resolved}
          </span>
        ) : (
          options.map((opt) => (
            <button
              key={opt}
              type="button"
              onClick={() => {
                resolveAsk(screen.id, opt);
                if (resume?.runId) {
                  // the card's answer resumes the suspended run — one path for touch and voice
                  import("@/lib/fotra/agent").then((m) => m.answerSuspended(opt));
                } else {
                  submitInput(opt, "action");
                }
              }}
              className="rounded-md border border-rule px-3.5 py-2 text-sm font-medium text-ink-2 transition-colors hover:border-glow/60 hover:text-ink hover:bg-paper-3 min-h-[40px]"
            >
              {opt}
            </button>
          ))
        )}
      </div>
      {resume?.kind === "budget" && !resolved && (
        <p className="f-label !opacity-50 pl-8">the run is paused, not dead — or just say “continue”</p>
      )}
    </div>
  );
}

/* —— CODE (sandbox run: what ran, what came out) —— */

function CodeBody({ p, large }: { p: Record<string, unknown>; large?: boolean }) {
  const lang = asString(p.lang) ?? "js";
  const code = asString(p.code) ?? "";
  const stdout = asString(p.stdout);
  const stderr = asString(p.stderr);
  const exit = asNum(p.exit);
  const ms = asNum(p.ms);
  const files = Array.isArray(p.files) ? (p.files as unknown[]).filter((x): x is string => typeof x === "string") : [];
  const cell = asNum(p.cell);
  const kernel = p.kernel === true;
  const bridge = Array.isArray(p.bridge)
    ? (p.bridge as Array<Record<string, unknown>>).filter((b) => b && typeof b === "object")
    : [];
  const failed = exit !== null && exit !== 0;
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
        <span className="f-label text-glow">{lang === "python" ? "python" : "node"}</span>
        {kernel && (
          <span className="f-label rounded border border-glow/40 px-1.5 py-0.5 text-glow" title="a persistent kernel — variables survive across calls">
            kernel{cell !== null ? ` · cell ${cell}` : ""}
          </span>
        )}
        {exit !== null && (
          <span className={`f-data f-label !opacity-80 ${failed ? "text-danger" : ""}`}>
            exit {exit}
          </span>
        )}
        {ms !== null && <span className="f-data f-label !opacity-50">{(ms / 1000).toFixed(1)}s</span>}
        {files.length > 0 && (
          <span className="f-label !opacity-50">
            wrote {files.length} file{files.length > 1 ? "s" : ""}
          </span>
        )}
        {!code && <Skeleton w="30%" h="0.8em" />}
      </div>
      {bridge.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="f-label !opacity-50">bridge →</span>
          {bridge.map((b, i) => (
            <span
              key={i}
              className={`f-label rounded border px-1.5 py-0.5 ${b.ok ? "border-rule text-dim" : "border-danger/40 text-danger"}`}
              title={`the cell called fotra's own ${String(b.tool)} tool${b.summary ? ` — ${String(b.summary)}` : ""}`}
            >
              {String(b.tool)}
              {b.ok ? "✓" : "✗"}
            </span>
          ))}
        </div>
      )}
      {code && (
        <pre className={`f-mono overflow-x-auto rounded-md border border-rule bg-paper-2 p-3 ${large ? "text-sm" : "text-xs"} leading-relaxed`}>
          <code>{code}</code>
        </pre>
      )}
      {stdout && (
        <div className="rounded-md border border-rule bg-paper-2 p-3">
          <div className="f-label !opacity-50 mb-1.5">stdout</div>
          <pre className={`f-mono whitespace-pre-wrap ${large ? "text-sm" : "text-xs"} leading-relaxed text-ink-2`}>{stdout}</pre>
        </div>
      )}
      {stderr && (
        <div className="rounded-md border border-danger/30 bg-danger/5 p-3">
          <div className="f-label !opacity-50 mb-1.5 text-danger">stderr</div>
          <pre className={`f-mono whitespace-pre-wrap ${large ? "text-sm" : "text-xs"} leading-relaxed text-ink-2`}>{stderr}</pre>
        </div>
      )}
    </div>
  );
}

/* —— BROWSER (the agent's headless browser — what it sees, you see) —— */

function BrowserBody({ p, large }: { p: Record<string, unknown>; large?: boolean }) {
  const url = asString(p.url);
  const title = asString(p.title);
  const shot = asString(p.shot);
  const text = asString(p.text);
  return (
    <div className="space-y-2.5">
      <div className="flex items-center gap-2 min-w-0">
        <span className="f-label text-glow shrink-0">browser</span>
        {url ? (
          <span className="f-mono truncate text-xs text-dim">{url.replace(/^https?:\/\//, "")}</span>
        ) : (
          <Skeleton w="45%" h="0.8em" />
        )}
      </div>
      {title && <div className="text-sm font-medium text-ink leading-snug">{title}</div>}
      {shot ? (
        <div className="overflow-hidden rounded-md border border-rule">
          { }
          <img src={shot} alt={title ? `screenshot of ${title}` : "browser screenshot"} className="block w-full" />
        </div>
      ) : url ? (
        <div className="rounded-md border border-rule bg-paper-2 p-3">
          <Skeleton w="100%" h="2em" />
        </div>
      ) : null}
      {text && <p className="text-sm text-dim leading-relaxed line-clamp-3">{text}</p>}
    </div>
  );
}

/* —— WORKER (sub-agent card: live progress of a parallel run) —— */

function WorkerBody({ p, large }: { p: Record<string, unknown>; large?: boolean }) {
  const name = asString(p.name) ?? "worker";
  const task = asString(p.task) ?? "";
  const phase = asString(p.phase) ?? "working";
  const note = asString(p.note);
  const done = phase === "done";
  const errored = phase === "error";
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2.5">
        <span className={`f-label shrink-0 ${done ? "text-glow" : errored ? "text-danger" : "text-ink-2"}`}>
          {done ? "done" : errored ? "error" : "working"}
        </span>
        <span className="font-display font-semibold text-ink text-sm">{name}</span>
        <span className="f-label !opacity-50 truncate">sub-agent</span>
      </div>
      {task && <p className="text-sm text-ink-2 leading-relaxed">{task}</p>}
      {note ? (
        <p className={`text-sm leading-relaxed ${errored ? "text-danger" : done ? "text-ink-2" : "text-dim"} f-fade`}>{note}</p>
      ) : (
        !done && <Skeleton w="60%" h="0.8em" />
      )}
      {!done && !errored && <div className="f-progress w-full" />}
    </div>
  );
}

/* —— TODO (the agent's task board) —— */

function TodoBody({ p, large }: { p: Record<string, unknown>; large?: boolean }) {
  const raw = Array.isArray(p.items) ? p.items : [];
  const items = raw
    .map((i) => {
      const o = (i ?? {}) as { text?: unknown; status?: unknown };
      return { text: typeof o.text === "string" ? o.text : "", status: o.status === "doing" || o.status === "done" ? o.status : "todo" };
    })
    .filter((i) => i.text);
  const doneCount = items.filter((i) => i.status === "done").length;
  return (
    <div className="space-y-2.5">
      <div className="flex items-center gap-2.5">
        <span className="f-label text-glow">board</span>
        <span className="f-data f-label !opacity-50">{doneCount}/{items.length}</span>
        {items.length === 0 && <Skeleton w="40%" h="0.8em" />}
      </div>
      {items.length > 0 && (
        <ol className="space-y-1.5">
          {items.map((it, i) => (
            <li key={i} className="flex items-center gap-2.5 leading-relaxed">
              <span
                aria-hidden="true"
                className={`grid h-4 w-4 shrink-0 place-items-center rounded-full border ${
                  it.status === "done" ? "border-glow bg-glow/20" : it.status === "doing" ? "border-glow" : "border-rule"
                }`}
              >
                {it.status === "done" && <Check size={10} className="text-glow" />}
              </span>
              <span className={`text-sm ${it.status === "done" ? "text-dim line-through" : it.status === "doing" ? "text-ink font-medium" : "text-ink-2"}`}>
                {it.text}
              </span>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

/* —— FILES (workspace listing) —— */

function FilesBody({ p, large }: { p: Record<string, unknown>; large?: boolean }) {
  const files = Array.isArray(p.files) ? (p.files as unknown[]).filter((x): x is string => typeof x === "string") : [];
  const highlight = asString(p.highlight);
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2.5">
        <span className="f-label text-glow">workspace</span>
        <span className="f-data f-label !opacity-50">{files.length} file{files.length === 1 ? "" : "s"}</span>
        {files.length === 0 && <Skeleton w="30%" h="0.8em" />}
      </div>
      {files.length > 0 && (
        <ul className="space-y-1">
          {files.slice(0, large ? 100 : 12).map((f) => (
            <li key={f} className="flex items-center gap-2">
              <span className={`f-mono text-xs truncate ${f === highlight ? "text-glow" : "text-ink-2"}`}>{f}</span>
              {f === highlight && <span className="f-label !opacity-50">new</span>}
            </li>
          ))}
          {files.length > (large ? 100 : 12) && <li className="f-label !opacity-40">+{files.length - (large ? 100 : 12)} more</li>}
        </ul>
      )}
    </div>
  );
}

/* —— CHART (data-ink: the accent at lightness steps, nothing else) —— */

function ChartBody({ p, large }: { p: Record<string, unknown>; large?: boolean }) {
  const title = asString(p.title);
  const kind = asString(p.kind) === "line" ? "line" : "bar";
  const labels = Array.isArray(p.labels) ? (p.labels as unknown[]).filter((x): x is string => typeof x === "string") : [];
  const seriesRaw = Array.isArray(p.series) ? (p.series as unknown[]) : [];
  const series = seriesRaw
    .map((s) => {
      const o = (s ?? {}) as { name?: unknown; values?: unknown };
      return {
        name: typeof o.name === "string" ? o.name : "",
        values: Array.isArray(o.values) ? (o.values as unknown[]).map((v) => (typeof v === "number" ? v : Number(v) || 0)) : [],
      };
    })
    .filter((s) => s.values.length > 0);
  const chart = <ChartSvg kind={kind} labels={labels} series={series} large={large} />;
  if (!series.length) return <div className="space-y-2"><div className="f-label !opacity-50">chart</div><Skeleton w="100%" h="8em" /></div>;
  return (
    <div className="space-y-2.5">
      {title && <div className="text-sm font-medium text-ink">{title}</div>}
      {chart}
      {series.length > 1 && (
        <div className="flex flex-wrap gap-3">
          {series.map((s, i) => (
            <span key={i} className="f-label !opacity-70 flex items-center gap-1.5">
              <span aria-hidden className="h-2 w-2 rounded-[3px]" style={{ background: `var(--chart-${i + 1}, var(--glow))` }} />
              {s.name || `series ${i + 1}`}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

function ChartSvg({ kind, labels, series, large }: { kind: "bar" | "line"; labels: string[]; series: { name: string; values: number[] }[]; large?: boolean }) {
  const w = large ? 640 : 480;
  const h = large ? 340 : 210;
  const padL = 38;
  const padB = 22;
  const padT = 10;
  const all = series.flatMap((s) => s.values);
  const max = Math.max(...all, 1);
  const min = Math.min(...all, 0);
  const range = max - min || 1;
  const n = Math.max(...series.map((s) => s.values.length), 1);
  const innerW = w - padL - 8;
  const innerH = h - padB - padT;
  const x = (i: number) => padL + (n === 1 ? innerW / 2 : (i / (n - 1)) * innerW);
  const y = (v: number) => padT + innerH - ((v - min) / range) * innerH;
  const ticks = [0, 0.5, 1];
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" role="img" aria-label={`${kind} chart`}>
      {ticks.map((t) => {
        const v = min + t * range;
        return (
          <g key={t}>
            <line x1={padL} x2={w - 8} y1={y(v)} y2={y(v)} stroke="var(--rule)" strokeWidth="1" opacity="0.6" />
            <text x={padL - 6} y={y(v) + 3} textAnchor="end" fontSize="9" fill="var(--dim)" className="f-data">{fmtNum(v)}</text>
          </g>
        );
      })}
      {labels.slice(0, n).map((l, i) => (
        <text key={i} x={x(i)} y={h - 6} textAnchor="middle" fontSize="9" fill="var(--dim)">{l.slice(0, 8)}</text>
      ))}
      {series.map((s, si) => {
        const color = `var(--chart-${si + 1}, var(--glow))`;
        if (kind === "line") {
          const d = s.values.map((v, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");
          return <path key={si} d={d} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />;
        }
        const bw = Math.max(4, (innerW / n) * 0.6 / series.length);
        return (
          <g key={si}>
            {s.values.map((v, i) => {
              const bx = x(i) - (bw * series.length) / 2 + si * bw;
              const by = y(v);
              const bh = padT + innerH - by;
              return <rect key={i} x={bx} y={by} width={bw} height={Math.max(bh, 0)} rx="2" fill={color} />;
            })}
          </g>
        );
      })}
    </svg>
  );
}

function fmtNum(v: number): string {
  if (Math.abs(v) >= 1000) return `${Math.round(v / 1000)}k`;
  if (Math.abs(v) >= 10) return String(Math.round(v));
  return v.toFixed(1);
}
