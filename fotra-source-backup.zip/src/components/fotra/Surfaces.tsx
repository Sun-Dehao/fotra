"use client";

/* ————————————————————————————————————————————————
   SURFACES — what a tool call looks like while it runs.
   Each kind of work brings its own: a search types its
   query and its sources fly in; a page gets skimmed;
   code runs and prints; a memory lands; a worker reports;
   a self-edit shows exactly what changed, with an undo.
   The same component renders the settled state when you
   open a finished step — nothing here is a mock of the
   work, it is the work's own data.
   ———————————————————————————————————————————————— */

import { useEffect, useState } from "react";
import { ArrowUpRight, Check, CornerDownRight, FileText, Minus, MonitorPlay, Plus, Search, Undo2 } from "lucide-react";
import { toast } from "sonner";
import { useFotra } from "@/lib/fotra/store";
import { applySelfActions } from "@/lib/fotra/agent";
import type { BrowserFrame, FotraAction, Step } from "@/lib/fotra/types";

/* —— small shared pieces —— */

function str(v: unknown): string {
  return typeof v === "string" ? v : "";
}
function arr<T = Record<string, unknown>>(v: unknown): T[] {
  return Array.isArray(v) ? (v as T[]) : [];
}

/** text that types itself while `active`; whole when not */
export function useTyped(text: string, active: boolean, cps = 46): string {
  const [n, setN] = useState(active ? 0 : text.length);
  useEffect(() => {
    if (!active) {
      setN(text.length);
      return;
    }
    setN(0);
    const started = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const next = Math.min(text.length, Math.floor(((now - started) / 1000) * cps));
      setN(next);
      if (next < text.length) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // the query is fixed for a step's life — retyping on every status patch would stutter
     
  }, [text]);
  return text.slice(0, n);
}

/** a site's mark without asking a third party for its favicon: the host's initial on a hue of its own */
export function HostTile({ host, size = 22 }: { host: string; size?: number }) {
  const h = host.replace(/^www\./, "");
  let hash = 0;
  for (let i = 0; i < h.length; i++) hash = (hash * 31 + h.charCodeAt(i)) >>> 0;
  return (
    <span
      className="f-host-tile"
      style={{ width: size, height: size, fontSize: Math.round(size * 0.5), background: `oklch(58% 0.09 ${hash % 360})` }}
      aria-hidden="true"
    >
      {(h[0] ?? "·").toUpperCase()}
    </span>
  );
}

function Spinner() {
  return <span className="f-spin" aria-hidden="true" />;
}

/* ————————————————————————————————————————————————
   SEARCH — the query types itself, the sources fly in
   ———————————————————————————————————————————————— */

interface Hit {
  title?: string;
  url?: string;
  host?: string;
  snippet?: string;
  date?: string;
}

export function SearchSurface({ step, live }: { step: Step; live: boolean }) {
  const query = str(step.data?.query) || step.subject || "";
  const running = step.status === "running";
  const typed = useTyped(query, live && running);
  const hits = arr<Hit>(step.data?.results).filter((h) => h && (h.title || h.url));

  return (
    <div className="f-surf">
      <div className="f-search-bar" data-live={running}>
        <Search size={14} className="shrink-0 text-dim" aria-hidden="true" />
        <span className="min-w-0 flex-1 truncate text-sm text-ink">
          {typed}
          {running && <span className="f-caret" aria-hidden="true" />}
        </span>
        {running ? (
          <Spinner />
        ) : (
          <span className="f-label shrink-0 !opacity-60">
            {step.status === "error" ? "failed" : `${hits.length} source${hits.length === 1 ? "" : "s"}`}
          </span>
        )}
      </div>

      {running && hits.length === 0 && (
        <ul className="mt-2 space-y-2" aria-hidden="true">
          {[72, 58, 66].map((w, i) => (
            <li key={i} className="flex items-center gap-2.5 px-1">
              <span className="f-shimmer h-[22px] w-[22px] shrink-0 !rounded-md" />
              <span className="f-shimmer h-3" style={{ width: `${w}%`, animationDelay: `${i * 140}ms` }} />
            </li>
          ))}
        </ul>
      )}

      {hits.length > 0 && (
        <ul className="mt-1.5">
          {hits.map((h, i) => (
            <li key={`${h.url}-${i}`} className="f-result" style={{ animationDelay: live ? `${i * 70}ms` : "0ms" }}>
              <a href={h.url} target="_blank" rel="noopener noreferrer" className="group flex items-start gap-2.5 rounded-lg px-1 py-1.5 transition-colors hover:bg-paper-3/60">
                <span className="mt-0.5">
                  <HostTile host={str(h.host) || str(h.url)} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-baseline gap-2">
                    <span className="truncate text-sm text-ink">{h.title || h.url}</span>
                    <ArrowUpRight size={12} className="shrink-0 text-dim opacity-0 transition-opacity group-hover:opacity-100" aria-hidden="true" />
                  </span>
                  <span className="mt-0.5 line-clamp-1 block text-xs text-dim">
                    <span className="text-ink-2">{h.host}</span>
                    {h.snippet ? ` — ${h.snippet}` : ""}
                  </span>
                </span>
              </a>
            </li>
          ))}
        </ul>
      )}

      {!running && hits.length === 0 && <p className="mt-2 px-1 text-xs text-dim">{step.summary || "nothing came back"}</p>}
    </div>
  );
}

/* ————————————————————————————————————————————————
   READ — a page being skimmed
   ———————————————————————————————————————————————— */

export function ReadSurface({ step }: { step: Step }) {
  const running = step.status === "running";
  const host = str(step.data?.host) || step.subject || "";
  const title = str(step.data?.title);
  const excerpt = str(step.data?.excerpt);
  const url = str(step.data?.url);
  const chars = typeof step.data?.chars === "number" ? (step.data.chars as number) : 0;
  return (
    <div className="f-surf">
      <div className="flex items-center gap-2.5">
        <HostTile host={host} />
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm text-ink">{title || host}</div>
          <div className="truncate text-xs text-dim">{title ? host : url.replace(/^https?:\/\//, "")}</div>
        </div>
        {running ? <Spinner /> : chars > 0 ? <span className="f-label shrink-0 !opacity-55">{Math.max(1, Math.round(chars / 1000))}k chars</span> : null}
      </div>
      {running ? (
        <div className="f-skim mt-3" aria-hidden="true">
          {[94, 100, 82, 97, 60].map((w, i) => (
            <span key={i} style={{ width: `${w}%` }} />
          ))}
        </div>
      ) : excerpt ? (
        <p className="mt-2.5 line-clamp-3 text-xs leading-relaxed text-dim">{excerpt}</p>
      ) : (
        step.status === "error" && <p className="mt-2 text-xs text-danger">{step.summary}</p>
      )}
    </div>
  );
}

/* ————————————————————————————————————————————————
   CODE — what ran, what came out
   ———————————————————————————————————————————————— */

export function CodeSurface({ step }: { step: Step }) {
  const d = step.data ?? {};
  const running = step.status === "running";
  const lang = str(d.lang) === "python" ? "python" : "node";
  const code = str(d.code);
  const stdout = str(d.stdout);
  const stderr = str(d.stderr);
  const cell = typeof d.cell === "number" ? (d.cell as number) : null;
  const files = arr<string>(d.files).filter((f) => typeof f === "string");
  const bridge = arr<{ tool?: string; ok?: boolean }>(d.bridge);
  const failed = step.status === "error";
  return (
    <div className="f-surf !p-0 overflow-hidden">
      <div className="flex items-center gap-2.5 border-b border-rule px-3 py-2">
        <span className="f-label !opacity-90 text-glow">{lang}</span>
        {cell !== null && <span className="f-label !opacity-50">cell {cell}</span>}
        {bridge.map((b, i) => (
          <span key={i} className={`f-label !opacity-70 rounded border px-1.5 ${b.ok ? "border-rule" : "border-danger/50 text-danger"}`}>
            {String(b.tool)}
          </span>
        ))}
        <span className="ml-auto flex items-center gap-2">
          {running ? (
            <>
              <span className="f-label !opacity-60">running</span>
              <Spinner />
            </>
          ) : (
            <span className={`f-label !opacity-70 ${failed ? "text-danger" : ""}`}>
              {failed ? "error" : "ok"}
              {typeof step.ms === "number" ? ` · ${(step.ms / 1000).toFixed(1)}s` : ""}
            </span>
          )}
        </span>
      </div>
      {code && (
        <pre className="f-mono f-scroll max-h-52 overflow-auto px-3 py-2.5 text-xs leading-relaxed text-ink-2">
          <code>{code}</code>
        </pre>
      )}
      {running && <div className="f-progress" />}
      {(stdout || stderr) && (
        <div className="border-t border-rule bg-paper/60 px-3 py-2.5">
          {stdout && <pre className="f-mono f-scroll max-h-44 overflow-auto whitespace-pre-wrap text-xs leading-relaxed text-ink">{stdout}</pre>}
          {stderr && <pre className="f-mono f-scroll mt-1 max-h-32 overflow-auto whitespace-pre-wrap text-xs leading-relaxed text-danger">{stderr}</pre>}
        </div>
      )}
      {files.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5 border-t border-rule px-3 py-2">
          <span className="f-label !opacity-50">wrote</span>
          {files.map((f) => (
            <span key={f} className="f-mono rounded border border-rule px-1.5 py-0.5 text-[11px] text-ink-2">
              {f}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

/* ————————————————————————————————————————————————
   BROWSER — the receipt of a computer-use session.
   The live show happens in the stage window; this is
   its place in the thread: the last frame, the steps
   it took, and a way back in.
   ———————————————————————————————————————————————— */

export function BrowserSurface({ steps, turnId }: { steps: Step[]; turnId: string }) {
  const stage = useFotra((s) => s.stage);
  const setStage = useFotra((s) => s.setStage);
  const mine = stage.turnId === turnId;
  const frames: BrowserFrame[] = mine ? stage.frames : [];
  const last = frames[frames.length - 1];
  const running = steps.some((s) => s.status === "running");
  const lastStep = steps[steps.length - 1];
  const host = str(lastStep?.data?.host) || (last ? hostOf(last.url) : "") || steps.find((s) => s.subject)?.subject || "";

  return (
    <div className="f-surf">
      <div className="flex items-stretch gap-3">
        <button
          type="button"
          onClick={() => setStage({ open: true })}
          disabled={!mine || frames.length === 0}
          className="f-browser-thumb group"
          aria-label="Open the browser window"
        >
          {last?.shot ? (
             
            <img src={last.shot} alt="" />
          ) : (
            <span className="grid h-full w-full place-items-center">
              <MonitorPlay size={18} className="text-dim" aria-hidden="true" />
            </span>
          )}
          {running && <span className="f-browser-thumb-live" aria-hidden="true" />}
        </button>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="truncate text-sm text-ink">{host || "browser"}</span>
            {running ? <Spinner /> : null}
            {mine && frames.length > 0 && !stage.open && (
              <button type="button" onClick={() => setStage({ open: true })} className="f-label ml-auto shrink-0 rounded-full border border-rule px-2 py-0.5 !opacity-80 transition-colors hover:border-glow/60 hover:text-glow">
                {running ? "watch" : "replay"}
              </button>
            )}
          </div>
          <ol className="mt-1.5 space-y-0.5">
            {steps.slice(-5).map((s) => (
              <li key={s.id} className="flex items-baseline gap-1.5 text-xs">
                <CornerDownRight size={10} className={`shrink-0 translate-y-[1px] ${s.status === "error" ? "text-danger" : s.status === "running" ? "text-glow" : "text-dim"}`} aria-hidden="true" />
                <span className={`min-w-0 truncate ${s.status === "running" ? "f-work-intent" : s.status === "error" ? "text-danger" : "text-dim"}`}>
                  {s.status === "running" ? `${s.title}${s.subject ? ` ${s.subject}` : ""}…` : s.summary || s.title}
                </span>
              </li>
            ))}
          </ol>
          {steps.length > 5 && <p className="f-label mt-1 !opacity-40">+{steps.length - 5} earlier actions</p>}
        </div>
      </div>
    </div>
  );
}

function hostOf(u: string): string {
  try {
    return new URL(u).host.replace(/^www\./, "");
  } catch {
    return "";
  }
}

/* ————————————————————————————————————————————————
   MEMORY — a fact landing, or a few coming back
   ———————————————————————————————————————————————— */

export function MemorySurface({ step }: { step: Step }) {
  const fact = str(step.data?.fact);
  const topic = str(step.data?.topic);
  const memories = arr<{ fact?: string; topic?: string }>(step.data?.memories);
  const running = step.status === "running";
  if (memories.length > 0) {
    return (
      <div className="f-surf">
        <ul className="space-y-1.5">
          {memories.map((m, i) => (
            <li key={i} className="f-result flex gap-2 text-sm text-ink-2" style={{ animationDelay: `${i * 60}ms` }}>
              <span className="mt-[0.6em] h-1 w-1 shrink-0 rounded-full bg-glow" aria-hidden="true" />
              <span className="min-w-0">
                {m.fact}
                {m.topic ? <span className="f-label ml-2 !opacity-45">{m.topic}</span> : null}
              </span>
            </li>
          ))}
        </ul>
      </div>
    );
  }
  return (
    <div className="f-surf">
      <div className="flex items-start gap-2.5">
        <span className={`f-memory-pin ${running ? "" : "is-set"}`} aria-hidden="true">
          <Check size={11} strokeWidth={3} />
        </span>
        <div className="min-w-0">
          <p className="text-sm text-ink">{fact || step.subject || step.summary}</p>
          {topic && <p className="f-label mt-1 !opacity-45">{topic}</p>}
        </div>
      </div>
    </div>
  );
}

/* ————————————————————————————————————————————————
   FILE — what was read or written
   ———————————————————————————————————————————————— */

export function FileSurface({ step }: { step: Step }) {
  const path = str(step.data?.path) || step.subject || "";
  const preview = str(step.data?.preview);
  const files = arr<string>(step.data?.files).filter((f) => typeof f === "string");
  const lines = typeof step.data?.lines === "number" ? (step.data.lines as number) : 0;
  return (
    <div className="f-surf !p-0 overflow-hidden">
      <div className="flex items-center gap-2 border-b border-rule px-3 py-2">
        <FileText size={13} className="shrink-0 text-dim" aria-hidden="true" />
        <span className="f-mono min-w-0 truncate text-xs text-ink">{path || "workspace"}</span>
        {step.status === "running" ? (
          <span className="ml-auto">
            <Spinner />
          </span>
        ) : lines > 0 ? (
          <span className="f-label ml-auto shrink-0 !opacity-50">{lines} lines</span>
        ) : null}
      </div>
      {preview && <pre className="f-mono f-scroll max-h-40 overflow-auto whitespace-pre-wrap px-3 py-2.5 text-xs leading-relaxed text-ink-2">{preview}</pre>}
      {files.length > 0 && (
        <ul className="px-3 py-2.5">
          {files.slice(0, 14).map((f) => (
            <li key={f} className="f-mono truncate text-xs leading-relaxed text-ink-2">
              {f}
            </li>
          ))}
        </ul>
      )}
      {!preview && files.length === 0 && step.summary && <p className="px-3 py-2.5 text-xs text-dim">{step.summary}</p>}
    </div>
  );
}

/* ————————————————————————————————————————————————
   WORKER — a parallel sub-agent reporting in
   ———————————————————————————————————————————————— */

export function WorkerSurface({ step }: { step: Step }) {
  const d = step.data ?? {};
  const running = step.status === "running";
  const log = arr<string>(d.log).filter((l) => typeof l === "string");
  return (
    <div className="f-surf">
      <div className="flex items-center gap-2">
        <span className={`f-worker-orb ${running ? "is-live" : step.status === "error" ? "is-err" : ""}`} aria-hidden="true" />
        <span className="font-display text-sm font-semibold text-ink">{str(d.name) || step.title}</span>
        <span className="f-label !opacity-45">worker</span>
        {typeof step.ms === "number" && !running && <span className="f-label ml-auto !opacity-50">{(step.ms / 1000).toFixed(0)}s</span>}
      </div>
      <p className="mt-1.5 text-xs leading-relaxed text-dim">{str(d.task) || step.subject}</p>
      {log.length > 0 && (
        <ol className="mt-2 space-y-0.5">
          {log.map((l, i) => (
            <li key={i} className="flex items-baseline gap-1.5 text-xs text-dim">
              <CornerDownRight size={10} className="shrink-0 translate-y-[1px]" aria-hidden="true" />
              <span className="min-w-0 truncate">{l}</span>
            </li>
          ))}
        </ol>
      )}
      {running ? <div className="f-progress mt-2.5" /> : step.summary ? <p className={`mt-2 text-sm leading-relaxed ${step.status === "error" ? "text-danger" : "text-ink-2"}`}>{step.summary}</p> : null}
    </div>
  );
}

/* ————————————————————————————————————————————————
   SELF — the agent changed itself: exactly what, and
   an undo that always works
   ———————————————————————————————————————————————— */

interface Change {
  field?: string;
  from?: string;
  to?: string;
  op?: "set" | "add" | "remove";
}

export function SelfSurface({ step }: { step: Step }) {
  const changes = arr<Change>(step.data?.changes);
  const editId = str(step.data?.editId);
  const wasUndo = step.data?.undone === true;
  const [undone, setUndone] = useState(false);
  const [busy, setBusy] = useState(false);

  async function undo() {
    if (!editId || busy) return;
    setBusy(true);
    try {
      const res = await fetch("/api/self", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ editId }) });
      const j = (await res.json()) as { ok?: boolean; actions?: FotraAction[]; error?: string };
      if (!j.ok) {
        toast.error("couldn't undo that", { description: j.error });
        return;
      }
      applySelfActions(j.actions ?? []);
      setUndone(true);
      toast.success("put back the way it was");
    } catch {
      toast.error("couldn't undo that", { description: "network error" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="f-surf">
      {changes.length === 0 ? (
        <p className="text-sm text-dim">{step.status === "running" ? "working out the change…" : step.summary}</p>
      ) : (
        <ul className={`space-y-1.5 ${undone ? "opacity-45" : ""}`}>
          {changes.map((c, i) => (
            <li key={i} className="f-result flex items-start gap-2.5 text-sm" style={{ animationDelay: `${i * 70}ms` }}>
              <span className={`f-diff-mark ${c.op === "remove" ? "is-minus" : c.op === "add" ? "is-plus" : ""}`} aria-hidden="true">
                {c.op === "remove" ? <Minus size={10} strokeWidth={3} /> : c.op === "add" ? <Plus size={10} strokeWidth={3} /> : <Check size={10} strokeWidth={3} />}
              </span>
              {c.field === "instruction" ? (
                <span className={`min-w-0 leading-snug ${c.op === "remove" ? "text-dim line-through" : "text-ink"}`}>
                  {c.op === "remove" ? c.from : c.to}
                  <span className="f-label ml-2 !opacity-45">{c.op === "remove" ? "dropped" : "from now on"}</span>
                </span>
              ) : (
                <span className="min-w-0 leading-snug">
                  <span className="f-label mr-2 !opacity-60">{c.field}</span>
                  {c.from ? <span className="text-dim line-through">{c.from}</span> : null}
                  {c.from ? <span className="mx-1.5 text-dim">→</span> : null}
                  <span className="text-ink">{c.to}</span>
                </span>
              )}
            </li>
          ))}
        </ul>
      )}
      {editId && !wasUndo && step.status === "done" && (
        <div className="mt-2.5 flex items-center gap-2">
          <button
            type="button"
            onClick={() => void undo()}
            disabled={undone || busy}
            className="inline-flex min-h-[30px] items-center gap-1.5 rounded-full border border-rule px-2.5 text-xs text-ink-2 transition-colors hover:border-dim/70 hover:text-ink disabled:opacity-50"
          >
            <Undo2 size={12} aria-hidden="true" />
            {undone ? "undone" : "undo"}
          </button>
          <span className="f-label !opacity-40">journaled — it can always be put back</span>
        </div>
      )}
    </div>
  );
}

/* ————————————————————————————————————————————————
   SCHEDULE — a routine set to run on its own
   ———————————————————————————————————————————————— */

export function ScheduleSurface({ step }: { step: Step }) {
  const d = step.data ?? {};
  const routines = arr<{ name?: string; schedule?: string; next?: string }>(d.routines);
  const cancelled = arr<string>(d.cancelled);
  const fmt = (iso: string) => {
    const t = new Date(iso);
    return Number.isNaN(t.getTime()) ? "" : t.toLocaleString([], { weekday: "short", hour: "numeric", minute: "2-digit" });
  };
  if (routines.length > 0) {
    return (
      <div className="f-surf">
        <ul className="space-y-1.5">
          {routines.map((r, i) => (
            <li key={i} className="flex items-baseline justify-between gap-3 text-sm">
              <span className="min-w-0 truncate text-ink">{r.name}</span>
              <span className="f-label shrink-0 !opacity-60">
                {r.schedule}
                {r.next ? ` · next ${fmt(r.next)}` : ""}
              </span>
            </li>
          ))}
        </ul>
      </div>
    );
  }
  if (cancelled.length > 0) {
    return (
      <div className="f-surf">
        <p className="text-sm text-dim">cancelled {cancelled.join(", ")}</p>
      </div>
    );
  }
  return (
    <div className="f-surf">
      <div className="flex items-baseline justify-between gap-3">
        <span className="font-display min-w-0 truncate text-sm font-semibold text-ink">{str(d.name) || step.subject}</span>
        <span className="f-label shrink-0 text-glow !opacity-100">{str(d.schedule)}</span>
      </div>
      {str(d.prompt) && <p className="mt-1.5 text-xs leading-relaxed text-dim">{str(d.prompt)}</p>}
      {str(d.next) && <p className="f-label mt-2 !opacity-50">first run {fmt(str(d.next))} — it runs on its own, the answer lands here</p>}
      {step.status === "error" && <p className="mt-1.5 text-xs text-danger">{step.summary}</p>}
    </div>
  );
}

/* —— anything else: the one-line truth —— */
export function PlainSurface({ step }: { step: Step }) {
  return (
    <div className="f-surf">
      <p className={`text-sm ${step.status === "error" ? "text-danger" : "text-ink-2"}`}>
        {step.status === "running" ? `${step.title}${step.subject ? ` · ${step.subject}` : ""}…` : step.summary || step.title}
      </p>
      {step.status === "running" && <div className="f-progress mt-2.5" />}
    </div>
  );
}
