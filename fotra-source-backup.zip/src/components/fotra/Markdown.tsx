"use client";

/* ————————————————————————————————————————————————
   MARKDOWN — how the agent's words render.
   Speech is short and plain, but a bring-your-own model
   will bold a word or drop a list, and a doc screen is
   long-form by design. One renderer for both, styled
   from the token system (.f-md in globals.css).
   Links open in a new tab; raw HTML is never rendered.
   ———————————————————————————————————————————————— */

import { memo } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

export const Markdown = memo(function Markdown({ text, className = "" }: { text: string; className?: string }) {
  return (
    <div className={`f-md ${className}`}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          a: ({ href, children }) => (
            <a href={href} target="_blank" rel="noopener noreferrer">
              {children}
            </a>
          ),
          table: ({ children }) => (
            <div className="f-md-table f-scroll">
              <table>{children}</table>
            </div>
          ),
        }}
      >
        {text}
      </ReactMarkdown>
    </div>
  );
});
