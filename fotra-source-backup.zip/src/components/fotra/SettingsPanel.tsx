"use client";

/* ————————————————————————————————————————————————
   SETTINGS — everything, honestly, in one slide-over
   — tabbed: appearance / persona / voice / brain /
   rules / memory / data / about. One section at a
   time gets the whole pane — no endless scroll, no
   cramped grids. Rail on desktop (ArrowUp/Down),
   chip strip on mobile (ArrowLeft/Right), last
   section remembered. shadcn-built: Sheet shell,
   Select, Slider, Switch, Input, Button. No dark
   patterns.
   ———————————————————————————————————————————————— */

import { useEffect, useRef, useState } from "react";
import {
  AudioLines, Brain, Check, Database, Download, HardDrive, Info, Moon, Palette, Pencil,
  Scissors, Search, Sparkles, Sun, Trash2, UserRound, X, Zap,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { useFotra } from "@/lib/fotra/store";
import { speechOut, ttsSupported } from "@/lib/fotra/voice";
import { applySelfActions } from "@/lib/fotra/agent";
import type { Aura, FotraAction, MascotSkin, Persona, ThemeMode, UiPrefs } from "@/lib/fotra/types";
import { Mascot, MASCOT_SKINS, MASCOT_COATS } from "./mascot/Mascot";

const TABS = [
  { id: "appearance", label: "appearance", icon: Palette, blurb: "Night or day, its body, its color, and what glows around it." },
  { id: "persona", label: "persona", icon: UserRound, blurb: "What it is called and how it sounds." },
  { id: "itself", label: "itself", icon: Sparkles, blurb: "The rules it wrote for itself, its layout, and every change it made — each one undoable." },
  { id: "voice", label: "voice", icon: AudioLines, blurb: "How you talk to it out loud." },
  { id: "brain", label: "brain", icon: Brain, blurb: "Which model does the thinking." },
  { id: "rules", label: "rules", icon: Scissors, blurb: "Patterns that stop a reply mid-sentence and make it try again." },
  { id: "memory", label: "memory", icon: Database, blurb: "What it knows about you. Every line is yours to edit or delete." },
  { id: "data", label: "data", icon: HardDrive, blurb: "Export, search, or clear the conversation." },
  { id: "about", label: "about", icon: Info, blurb: "What it can do, and what it can't yet." },
] as const;

type TabId = (typeof TABS)[number]["id"];
const TAB_IDS: readonly TabId[] = TABS.map((t) => t.id);
const TAB_STORAGE = "fotra.settings.tab";

export function SettingsPanel() {
  const open = useFotra((s) => s.settingsOpen);
  const setOpen = useFotra((s) => s.setSettingsOpen);
  const [tab, setTab] = useState<TabId>("appearance");
  const listRef = useRef<HTMLDivElement>(null);

  // restore the last-visited section on open (client-only, guarded)
  useEffect(() => {
    if (!open) return;
    try {
      const saved = localStorage.getItem(TAB_STORAGE);
      if (saved && (TAB_IDS as readonly string[]).includes(saved)) setTab(saved as TabId);
    } catch {
      /* private mode etc. — stay on appearance */
    }
  }, [open]);

  function pick(id: TabId) {
    setTab(id);
    try {
      localStorage.setItem(TAB_STORAGE, id);
    } catch {
      /* non-fatal */
    }
    listRef.current
      ?.querySelector<HTMLButtonElement>(`[data-tab="${id}"]`)
      ?.scrollIntoView({ block: "nearest", inline: "nearest" });
  }

  // arrow keys follow the visual orientation: chip strip on mobile, rail on desktop
  function onListKeyDown(e: React.KeyboardEvent) {
    const vertical = window.matchMedia("(min-width: 640px)").matches;
    const dir = vertical
      ? e.key === "ArrowDown"
        ? 1
        : e.key === "ArrowUp"
          ? -1
          : 0
      : e.key === "ArrowRight"
        ? 1
        : e.key === "ArrowLeft"
          ? -1
          : 0;
    if (!dir) return;
    e.preventDefault();
    const i = TAB_IDS.indexOf(tab);
    const next = TAB_IDS[(i + dir + TAB_IDS.length) % TAB_IDS.length];
    pick(next);
    listRef.current?.querySelector<HTMLButtonElement>(`[data-tab="${next}"]`)?.focus();
  }

  const current = TABS.find((t) => t.id === tab) ?? TABS[0];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent
        showCloseButton={false}
        className="f-theme-swap flex h-dvh w-full max-w-none flex-col gap-0 overflow-hidden rounded-none border-rule bg-paper-2 p-0 shadow-2xl sm:h-[min(88dvh,720px)] sm:w-[min(94vw,880px)] sm:max-w-none sm:flex-row sm:rounded-2xl"
      >
        <DialogDescription className="sr-only">
          Appearance, persona, voice, brain, rules, memory, data and about — one section at a time
        </DialogDescription>

        {/* the sections — a rail on desktop, a chip strip on a phone */}
        <div
          ref={listRef}
          role="tablist"
          aria-label="Settings sections"
          onKeyDown={onListKeyDown}
          className="f-settings-tabs flex shrink-0 gap-1 overflow-x-auto border-b border-rule bg-paper/50 p-2 sm:w-[188px] sm:flex-col sm:gap-0.5 sm:overflow-x-hidden sm:overflow-y-auto sm:border-b-0 sm:border-r sm:p-3"
        >
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                id={`tab-${t.id}`}
                data-tab={t.id}
                type="button"
                role="tab"
                aria-selected={active}
                tabIndex={active ? 0 : -1}
                onClick={() => pick(t.id)}
                className={`flex items-center gap-2.5 whitespace-nowrap rounded-lg px-3 py-2 text-left text-sm transition-colors ${
                  active ? "bg-glow/10 font-medium text-ink" : "text-dim hover:bg-paper-3/60 hover:text-ink-2"
                }`}
              >
                <Icon size={15} className={`shrink-0 ${active ? "text-glow" : ""}`} />
                {t.label}
              </button>
            );
          })}
        </div>

        {/* the one section on screen — its name is the only heading */}
        <div role="tabpanel" aria-labelledby={`tab-${tab}`} className="flex min-h-0 min-w-0 flex-1 flex-col">
          <div className="flex shrink-0 items-start justify-between gap-4 px-6 pb-3 pt-5">
            <div className="min-w-0">
              <DialogTitle className="font-display text-xl font-semibold capitalize leading-tight tracking-tight text-ink">{current.label}</DialogTitle>
              <p className="mt-1 text-[13px] leading-snug text-dim">{current.blurb}</p>
            </div>
            <DialogClose asChild>
              <button type="button" aria-label="Close settings" className="-mr-2 -mt-1 grid h-9 w-9 shrink-0 place-items-center rounded-full text-dim transition-colors hover:bg-paper-3 hover:text-ink">
                <X size={16} />
              </button>
            </DialogClose>
          </div>
          <div key={tab} className="f-fade min-h-0 min-w-0 flex-1 overflow-y-auto overflow-x-hidden pb-6">
            {tab === "appearance" && <AppearanceSection />}
            {tab === "persona" && <PersonaSection />}
            {tab === "itself" && <SelfSection />}
            {tab === "voice" && <VoiceSection />}
            {tab === "brain" && (
              <>
                <BrainSection />
                <SearchSection />
              </>
            )}
            {tab === "rules" && <RulesSection />}
            {tab === "memory" && <MemorySection />}
            {tab === "data" && <DataSection />}
            {tab === "about" && (
              <>
                <CapabilitySection />
                <footer className="px-6 py-4">
                  <p className="text-xs leading-relaxed text-dim">
                    Everything lives on your machine — threads in this browser and in SQLite, memory as
                    git-markdown under <code className="f-data">~/.fotra</code>. Zero phone-home. Your API
                    key is kept in this browser and sent only to the endpoint you named, straight from
                    this computer.
                  </p>
                </footer>
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* —— section chrome —— */

function Section({ label, children }: { label?: string; children: React.ReactNode }) {
  return (
    <section className="min-w-0 px-6 py-3">
      {label ? <h3 className="f-label mb-3 mt-2 !opacity-60">{label}</h3> : null}
      <div className="min-w-0 space-y-4">{children}</div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm text-ink-2">{label}</span>
      {children}
    </label>
  );
}

const inputCls = "w-full border-rule bg-paper text-sm text-ink placeholder:text-dim/60 focus-visible:ring-glow/40";

/* —— APPEARANCE —— */

function AppearanceSection() {
  const mode = useFotra((s) => s.settings.mode);
  const aura = useFotra((s) => s.persona.aura);
  const mascot = useFotra((s) => s.persona.mascot);
  const coat = useFotra((s) => s.persona.coat);
  const name = useFotra((s) => s.persona.name);
  const setMode = useFotra((s) => s.setMode);
  const setCoat = useFotra((s) => s.setCoat);
  const patchPersona = useFotra((s) => s.patchPersona);

  return (
    <Section>
      <Field label="canvas — night or day">
        <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label="Mode">
          {(["dark", "light"] as ThemeMode[]).map((m) => (
            <button
              key={m}
              type="button"
              role="radio"
              aria-checked={mode === m}
              onClick={() => setMode(m)}
              className={`flex items-center gap-3 rounded-md border px-3 py-2.5 text-left transition-colors ${
                mode === m ? "border-glow/70 bg-glow/5" : "border-rule hover:border-dim/60"
              }`}
            >
              {m === "dark" ? <Moon size={15} className="shrink-0 text-dim" /> : <Sun size={15} className="shrink-0 text-dim" />}
              <span>
                <span className="block text-sm font-medium text-ink">{m === "dark" ? "night" : "day"}</span>
                <span className="block text-xs text-dim">{m === "dark" ? "the native canvas" : "ink on paper"}</span>
              </span>
            </button>
          ))}
        </div>
      </Field>

      <Field label="body">
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-6" role="radiogroup" aria-label="Mascot body">
          {MASCOT_SKINS.map((sk) => (
            <button
              key={sk.id}
              type="button"
              role="radio"
              aria-checked={mascot === sk.id}
              title={sk.note}
              onClick={() => patchPersona({ mascot: sk.id })}
              className={`flex flex-col items-center gap-1.5 rounded-md border px-1 py-3 transition-colors ${
                mascot === sk.id ? "border-glow/70 bg-glow/5" : "border-rule hover:border-dim/60"
              }`}
            >
              <Mascot size={50} skin={sk.id} coat={coat} name={name} phase="idle" showHalo={false} decorative />
              <span className={`text-xs ${mascot === sk.id ? "text-ink" : "text-dim"}`}>
                {sk.label}
              </span>
            </button>
          ))}
        </div>
        <p className="text-xs leading-relaxed text-dim">
          Its eyes follow your pointer, and its face shows what it is doing — listening, thinking,
          working, speaking.
        </p>
      </Field>

      <Field label="coat — recolors the whole app">
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-6" role="radiogroup" aria-label="Mascot coat">
          {MASCOT_COATS.map((c) => (
            <button
              key={c.id}
              type="button"
              role="radio"
              aria-checked={coat === c.id}
              title={`the ${c.label} coat`}
              onClick={() => setCoat(c.id)}
              className={`flex flex-col items-center gap-1.5 rounded-md border px-1 py-2.5 transition-colors ${
                coat === c.id ? "border-glow/70 bg-glow/5" : "border-rule hover:border-dim/60"
              }`}
            >
              <Mascot size={34} skin="orb" coat={c.id} showFace={false} showHalo={false} phase="idle" decorative />
              <span className={`text-xs ${coat === c.id ? "text-ink" : "text-dim"}`}>{c.label}</span>
            </button>
          ))}
        </div>
        <p className="text-xs leading-relaxed text-dim">
          One choice: the accent, the canvas tint and the mascot change together.
        </p>
      </Field>

      <Field label="aura — what surrounds it">
        <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label="Aura">
          {(["calm", "pulse", "spark"] as Aura[]).map((a) => (
            <button
              key={a}
              type="button"
              role="radio"
              aria-checked={aura === a}
              onClick={() => patchPersona({ aura: a })}
              className={`flex flex-col items-center gap-1 overflow-hidden rounded-md border px-2 pb-2.5 pt-7 text-sm transition-colors ${
                aura === a ? "border-glow/70 bg-glow/5 text-ink" : "border-rule text-ink-2 hover:border-dim/60"
              }`}
            >
              <Mascot size={54} skin={mascot} coat={coat} aura={a} phase="idle" decorative />
              <span className="mt-5">{a}</span>
              <span className="text-xs text-dim">{a === "calm" ? "a soft glow" : a === "pulse" ? "sonar rings" : "twinkling sparks"}</span>
            </button>
          ))}
        </div>
        <p className="text-xs leading-relaxed text-dim">
          Whatever the aura, a thin arc circles it while it thinks or works.
        </p>
      </Field>
    </Section>
  );
}

/* —— PERSONA —— */

function PersonaSection() {
  const persona = useFotra((s) => s.persona);
  const patchPersona = useFotra((s) => s.patchPersona);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    if (!ttsSupported()) return;
    const load = () => setVoices(window.speechSynthesis.getVoices().filter((v) => /^en/i.test(v.lang)));
    load();
    window.speechSynthesis.addEventListener?.("voiceschanged", load);
    const t = setTimeout(load, 600);
    return () => {
      window.speechSynthesis.removeEventListener?.("voiceschanged", load);
      clearTimeout(t);
    };
  }, []);

  function set(p: Partial<Persona>) {
    patchPersona(p);
  }

  return (
    <Section>
      <div className="grid grid-cols-2 gap-3">
        <Field label="its name">
          <Input
            className={inputCls}
            value={persona.name}
            maxLength={24}
            onChange={(e) => set({ name: e.target.value })}
            aria-label="Assistant name"
          />
        </Field>
        <Field label="tagline">
          <Input
            className={inputCls}
            value={persona.tagline}
            maxLength={80}
            onChange={(e) => set({ tagline: e.target.value })}
            aria-label="Assistant tagline"
          />
        </Field>
      </div>

      {ttsSupported() && voices.length > 0 && (
        <Field label="voice">
          <Select
            value={persona.voiceURI ?? ""}
            onValueChange={(v) => set({ voiceURI: v || null })}
          >
            <SelectTrigger className={`${inputCls} w-full`} aria-label="Voice">
              <SelectValue placeholder="auto (best available)" />
            </SelectTrigger>
            <SelectContent className="border-rule bg-paper-2">
              <SelectItem value="auto">auto (best available)</SelectItem>
              {voices.map((v) => (
                <SelectItem key={v.voiceURI} value={v.voiceURI}>
                  {v.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
      )}

      <div className="grid grid-cols-2 gap-4">
        <Field label={`rate · ${persona.voiceRate.toFixed(2)}`}>
          <Slider
            min={0.6}
            max={1.4}
            step={0.02}
            value={[persona.voiceRate]}
            onValueChange={([v]) => set({ voiceRate: v })}
            aria-label="Voice rate"
          />
        </Field>
        <Field label={`pitch · ${persona.voicePitch.toFixed(2)}`}>
          <Slider
            min={0.6}
            max={1.4}
            step={0.02}
            value={[persona.voicePitch]}
            onValueChange={([v]) => set({ voicePitch: v })}
            aria-label="Voice pitch"
          />
        </Field>
      </div>

      <Button
        type="button"
        variant="outline"
        onClick={() => speechOut.speak(`${persona.name} here — ${persona.tagline}. Sound check.`, persona)}
        className="min-h-[40px] border-rule text-ink-2 hover:border-glow/60 hover:bg-paper-3 hover:text-ink"
      >
        <Zap size={14} className="text-glow" /> test the voice
      </Button>
    </Section>
  );
}

/* —— VOICE — browser or realtime —— */

function VoiceSection() {
  const voiceMode = useFotra((s) => s.settings.voiceMode);
  const realtimeVoice = useFotra((s) => s.settings.realtimeVoice);
  const update = useFotra((s) => s.updateSettings);
  const [keyState, setKeyState] = useState<string>("checking…");

  useEffect(() => {
    void fetch("/api/providers")
      .then((r) => r.json())
      .then((j: { providers?: Array<{ id: string; hasKey: boolean }> }) => {
        const openai = j.providers?.find((p) => p.id === "openai");
        setKeyState(openai?.hasKey ? "key found — realtime ready" : "no server key — needs OPENAI_API_KEY in .env.local");
      })
      .catch(() => setKeyState("can't reach the server"));
  }, []);

  return (
    <Section>
      <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label="Voice mode">
        <button
          type="button"
          role="radio"
          aria-checked={voiceMode === "browser"}
          onClick={() => update({ voiceMode: "browser" })}
          className={`rounded-md border px-3 py-2.5 text-left transition-colors ${
            voiceMode === "browser" ? "border-glow/70 bg-glow/5" : "border-rule hover:border-dim/60"
          }`}
        >
          <span className="block text-sm font-medium text-ink">browser voice</span>
          <span className="block text-xs text-dim">zero keys · hold space to talk</span>
        </button>
        <button
          type="button"
          role="radio"
          aria-checked={voiceMode === "realtime"}
          onClick={() => update({ voiceMode: "realtime" })}
          className={`rounded-md border px-3 py-2.5 text-left transition-colors ${
            voiceMode === "realtime" ? "border-glow/70 bg-glow/5" : "border-rule hover:border-dim/60"
          }`}
        >
          <span className="block text-sm font-medium text-ink">realtime call</span>
          <span className="block text-xs text-dim">webrtc · semantic-vad barge-in · needs a server key</span>
        </button>
      </div>
      {voiceMode === "realtime" && (
        <div className="f-fade space-y-3">
          <Field label="provider voice">
            <Select value={realtimeVoice} onValueChange={(v) => update({ realtimeVoice: v })}>
              <SelectTrigger className={`${inputCls} w-full`} aria-label="Realtime voice">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="border-rule bg-paper-2">
                {["alloy", "echo", "shimmer", "verse", "sage"].map((v) => (
                  <SelectItem key={v} value={v}>
                    {v}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <p className={`f-label !opacity-70 ${keyState.includes("ready") ? "text-glow" : ""}`} role="status">
            {keyState}
          </p>
        </div>
      )}
    </Section>
  );
}

/* —— ITSELF — what it has changed about itself, and its own app's layout —— */

interface SelfHistoryRow {
  id: string;
  ts: number;
  why: string;
  undone: boolean;
  changes: Array<{ field: string; from?: string; to?: string; op: string }>;
}

function SelfSection() {
  const ui = useFotra((s) => s.settings.ui);
  const patchUi = useFotra((s) => s.patchUi);
  const name = useFotra((s) => s.persona.name);
  const [data, setData] = useState<{ instructions: string[]; history: SelfHistoryRow[] } | null>(null);

  const load = () =>
    fetch("/api/self")
      .then((r) => r.json())
      .then(setData)
      .catch(() => setData({ instructions: [], history: [] }));
  useEffect(() => {
    void load();
  }, []);

  async function undo(id: string) {
    const res = await fetch("/api/self", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ editId: id }) });
    const j = (await res.json()) as { ok?: boolean; actions?: FotraAction[]; error?: string };
    if (!j.ok) {
      toast.error("couldn't undo that", { description: j.error });
      return;
    }
    applySelfActions(j.actions ?? []);
    toast.success("put back the way it was");
    void load();
  }

  const seg = <K extends keyof UiPrefs>(key: K, options: Array<[UiPrefs[K], string]>, label: string) => (
    <Field label={label}>
      <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label={label}>
        {options.map(([value, text]) => (
          <button
            key={String(value)}
            type="button"
            role="radio"
            aria-checked={ui?.[key] === value}
            onClick={() => patchUi({ [key]: value } as Partial<UiPrefs>)}
            className={`min-h-[34px] rounded-full border px-3 text-xs transition-colors ${
              ui?.[key] === value ? "border-glow/70 bg-glow/10 text-ink" : "border-rule text-ink-2 hover:border-dim/60"
            }`}
          >
            {text}
          </button>
        ))}
      </div>
    </Field>
  );

  return (
    <>
      <Section label="standing instructions">
        <p className="text-xs leading-relaxed text-dim">
          Tell {name} to change how it behaves — “be blunter”, “always answer in Spanish”, “stop reading links aloud” — and it writes
          the rule here and reads it before every reply. The file is <span className="f-mono text-ink-2">~/.fotra/memory/SOUL.md</span>; every edit is a git commit.
        </p>
        {data && data.instructions.length > 0 ? (
          <ul className="space-y-1.5">
            {data.instructions.map((line) => (
              <li key={line} className="flex gap-2.5 text-sm leading-relaxed text-ink">
                <span className="mt-[0.65em] h-1 w-1 shrink-0 rounded-full bg-glow" aria-hidden="true" />
                {line}
              </li>
            ))}
          </ul>
        ) : (
          <p className="f-label !opacity-50">{data ? "none yet — just ask it to change" : "loading…"}</p>
        )}
      </Section>

      <Section label="its layout">
        <p className="text-xs leading-relaxed text-dim">It can change these itself when you ask (“go compact”, “hide your work”) — or set them here.</p>
        {seg("density", [["cozy", "cozy"], ["compact", "compact"]], "density")}
        {seg("width", [["narrow", "narrow"], ["normal", "normal"], ["wide", "wide"]], "thread width")}
        {seg("trail", [["auto", "live, then folded"], ["open", "always open"], ["quiet", "one line only"]], "how much of its work it shows")}
        {seg("stage", [["pip", "pops up beside the thread"], ["wide", "opens large"], ["off", "stays in the thread"]], "the browser window")}
      </Section>

      <Section label="changes it made to itself">
        {data && data.history.length > 0 ? (
          <ul className="space-y-2">
            {data.history.slice(0, 12).map((h) => (
              <li key={h.id} className={`flex items-start justify-between gap-3 rounded-md border border-rule px-3 py-2 ${h.undone ? "opacity-50" : ""}`}>
                <div className="min-w-0">
                  <p className="text-sm leading-snug text-ink">
                    {h.changes
                      .map((c) => (c.field === "instruction" ? (c.op === "remove" ? `dropped “${c.from}”` : `“${c.to}”`) : `${c.field} → ${c.to}`))
                      .join(" · ")}
                  </p>
                  <p className="f-label mt-1 !opacity-45">
                    {new Date(h.ts).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                    {h.undone ? " · undone" : ""}
                  </p>
                </div>
                {!h.undone && (
                  <Button type="button" variant="outline" size="sm" onClick={() => void undo(h.id)} className="h-8 shrink-0 border-rule text-ink-2 hover:border-dim/70 hover:text-ink">
                    undo
                  </Button>
                )}
              </li>
            ))}
          </ul>
        ) : (
          <p className="f-label !opacity-50">{data ? "nothing yet" : "loading…"}</p>
        )}
      </Section>
    </>
  );
}

/* —— BRAIN — connect a model in three moves: pick, paste, connect —— */

interface BrainPreset {
  label: string;
  baseUrl: string;
  model: string;
  /** where its keys are made */
  keyUrl?: string;
  local?: boolean;
  note?: string;
}

const BRAIN_PRESETS: BrainPreset[] = [
  { label: "Anthropic", baseUrl: "https://api.anthropic.com/v1", model: "claude-sonnet-5-5", keyUrl: "https://console.anthropic.com/settings/keys" },
  { label: "OpenAI", baseUrl: "https://api.openai.com/v1", model: "gpt-4o", keyUrl: "https://platform.openai.com/api-keys" },
  { label: "Google Gemini", baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai", model: "gemini-2.5-flash", keyUrl: "https://aistudio.google.com/apikey" },
  { label: "OpenRouter", baseUrl: "https://openrouter.ai/api/v1", model: "anthropic/claude-sonnet-4.5", keyUrl: "https://openrouter.ai/keys", note: "one key, most models" },
  { label: "DeepSeek", baseUrl: "https://api.deepseek.com/v1", model: "deepseek-chat", keyUrl: "https://platform.deepseek.com/api_keys" },
  { label: "Moonshot", baseUrl: "https://api.moonshot.ai/v1", model: "kimi-k2-turbo-preview", keyUrl: "https://platform.moonshot.ai/console/api-keys" },
  { label: "xAI", baseUrl: "https://api.x.ai/v1", model: "grok-4", keyUrl: "https://console.x.ai" },
  { label: "Groq", baseUrl: "https://api.groq.com/openai/v1", model: "llama-3.3-70b-versatile", keyUrl: "https://console.groq.com/keys" },
  { label: "Mistral", baseUrl: "https://api.mistral.ai/v1", model: "mistral-large-latest", keyUrl: "https://console.mistral.ai/api-keys" },
  { label: "Ollama", baseUrl: "http://127.0.0.1:11434/v1", model: "qwen2.5:14b", local: true },
  { label: "LM Studio", baseUrl: "http://127.0.0.1:1234/v1", model: "local-model", local: true },
];

interface ReachRow {
  url: string;
  state: "ok" | "blocked" | "down";
  ms: number;
  note: string;
}
interface ConnectFailure {
  kind: string;
  message: string;
  hint: string;
  raw: string;
}
type ConnectState =
  | { state: "idle" }
  | { state: "running" }
  | { state: "ok"; msg: string }
  | { state: "fail"; failure: ConnectFailure };

function BrainSection() {
  const settings = useFotra((s) => s.settings);
  const update = useFotra((s) => s.updateSettings);
  const custom = settings.custom;
  const [conn, setConn] = useState<ConnectState>({ state: "idle" });
  const [models, setModels] = useState<string[]>([]);
  const [reach, setReach] = useState<Record<string, ReachRow> | null>(null);
  const [proxy, setProxy] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);
  const [providers, setProviders] = useState<{
    valid: boolean;
    error?: string;
    providers?: Array<{ id: string; hasKey: boolean; keyless: boolean; defaultModel: string }>;
    roles?: Record<string, string | null>;
  } | null>(null);
  const [provTest, setProvTest] = useState<{ state: "idle" | "running" | "ok" | "fail"; msg: string }>({ state: "idle", msg: "" });
  const [builtin, setBuiltin] = useState(false);

  const preset = BRAIN_PRESETS.find((p) => p.baseUrl === custom.baseUrl) ?? null;
  const live = settings.engine === "custom" && !!custom.baseUrl && !!custom.model;

  const checkReach = () => {
    setChecking(true);
    void fetch("/api/brain/reach", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ urls: BRAIN_PRESETS.map((p) => p.baseUrl) }),
    })
      .then((r) => r.json())
      .then((j: { reach?: ReachRow[]; proxy?: string | null }) => {
        setReach(Object.fromEntries((j.reach ?? []).map((r) => [r.url, r])));
        setProxy(j.proxy ?? null);
      })
      .catch(() => setReach({}))
      .finally(() => setChecking(false));
  };

  useEffect(() => {
    checkReach();
    void fetch("/api/providers")
      .then((r) => r.json())
      .then(setProviders)
      .catch(() => setProviders(null));
    void fetch("/api/brain")
      .then((r) => r.json())
      .then((b: { builtin?: boolean }) => setBuiltin(!!b.builtin))
      .catch(() => setBuiltin(false));
  }, []);

  function choose(p: BrainPreset) {
    // a different provider means a different key — never carry one provider's key to another
    update({ custom: { ...custom, baseUrl: p.baseUrl, model: p.model, apiKey: p.baseUrl === custom.baseUrl ? custom.apiKey : "" } });
    setModels([]);
    setConn({ state: "idle" });
  }

  async function connect() {
    setConn({ state: "running" });
    try {
      const res = await fetch("/api/test-model", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ baseUrl: custom.baseUrl, apiKey: custom.apiKey, model: custom.model }),
      });
      const data = (await res.json()) as { ok: boolean; error?: string; failure?: ConnectFailure; latencyMs?: number; models?: string[]; model?: string };
      if (data.models?.length) setModels(data.models);
      if (data.ok) {
        const model = data.model || custom.model;
        update({ engine: "custom", custom: { ...useFotra.getState().settings.custom, model } });
        setConn({ state: "ok", msg: `connected to ${model} · answered in ${data.latencyMs ?? "?"}ms` });
        toast.success("model connected", { description: `${model} is answering now` });
      } else {
        // the list came back but the model name was wrong: keep what the account does have on offer
        if (data.model && data.failure?.kind !== "model") update({ custom: { ...useFotra.getState().settings.custom, model: data.model } });
        setConn({ state: "fail", failure: data.failure ?? { kind: "other", message: data.error ?? "That didn't work.", hint: "", raw: "" } });
      }
    } catch (err) {
      setConn({ state: "fail", failure: { kind: "network", message: "Couldn't reach this app's own server.", hint: "Is the app still running?", raw: err instanceof Error ? err.message : "" } });
    }
  }

  async function proveProvider() {
    setProvTest({ state: "running", msg: "calling…" });
    try {
      const res = await fetch("/api/providers/test", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ providerId: "openai" }) });
      const data = (await res.json()) as { ok?: boolean; detail?: string; error?: string };
      setProvTest(data.ok ? { state: "ok", msg: data.detail ?? "awake" } : { state: "fail", msg: data.detail ?? data.error ?? "failed" });
    } catch (err) {
      setProvTest({ state: "fail", msg: err instanceof Error ? err.message : "network error" });
    }
  }

  const served = reach ? BRAIN_PRESETS.filter((p) => !p.local && reach[p.baseUrl]?.state === "ok").length : 0;
  const cloud = BRAIN_PRESETS.filter((p) => !p.local).length;
  const here = reach?.[custom.baseUrl];
  const needsKey = !!custom.baseUrl && !(preset?.local ?? /127\.0\.0\.1|localhost/.test(custom.baseUrl));
  const canConnect = !!custom.baseUrl && (!needsKey || !!custom.apiKey.trim()) && conn.state !== "running";

  const otherBtn = (id: "fotra" | "provider" | "demo", title: string, sub: React.ReactNode) => (
    <button
      type="button"
      role="radio"
      aria-checked={settings.engine === id}
      onClick={() => update({ engine: id })}
      className={`w-full rounded-lg border px-3 py-2.5 text-left transition-colors ${settings.engine === id ? "border-glow/70 bg-glow/5" : "border-rule hover:border-dim/60"}`}
    >
      <span className="block text-sm font-medium text-ink">{title}</span>
      <span className="block text-xs leading-relaxed text-dim">{sub}</span>
    </button>
  );

  return (
    <Section>
      {/* what is answering right now */}
      <div className={`flex items-center gap-3 rounded-xl border px-3.5 py-3 ${live ? "border-glow/40 bg-glow/5" : "border-rule bg-paper"}`} role="status">
        <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${live ? "bg-glow" : settings.engine === "demo" ? "bg-dim/50" : "bg-glow/70"}`} aria-hidden="true" />
        <p className="min-w-0 text-sm leading-snug text-ink">
          {live ? (
            <>
              <span className="font-medium">{custom.model}</span> <span className="text-dim">is answering · {preset?.label ?? hostLabel(custom.baseUrl)}</span>
            </>
          ) : settings.engine === "demo" ? (
            <>
              The demo brain is answering. <span className="text-dim">It is scripted — connect a model below for the real thing.</span>
            </>
          ) : settings.engine === "provider" ? (
            <>
              providers.json is answering. <span className="text-dim">{providers?.roles?.chat ?? "no chat role set"}</span>
            </>
          ) : (
            <>The built-in brain is answering.</>
          )}
        </p>
      </div>

      {/* 1 — pick */}
      <div>
        <div className="mb-2 flex items-baseline justify-between gap-3">
          <span className="text-sm text-ink-2">1 · pick a provider</span>
          <button type="button" onClick={checkReach} disabled={checking} className="f-label !opacity-60 transition-opacity hover:!opacity-100 disabled:!opacity-30">
            {checking ? "checking…" : "check again"}
          </button>
        </div>
        <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3" role="radiogroup" aria-label="Provider">
          {BRAIN_PRESETS.map((p) => {
            const r = reach?.[p.baseUrl];
            const on = custom.baseUrl === p.baseUrl;
            const dot = !r ? "bg-dim/30" : r.state === "ok" ? "bg-glow" : r.state === "blocked" ? "bg-danger" : p.local ? "bg-dim/40" : "bg-danger";
            const sub = !r ? "checking…" : r.state === "ok" ? (p.local ? "running here" : p.note ?? `reachable · ${r.ms}ms`) : r.state === "blocked" ? "not served here" : p.local ? "not running" : "no answer here";
            return (
              <button
                key={p.label}
                type="button"
                role="radio"
                aria-checked={on}
                onClick={() => choose(p)}
                title={r?.note ?? p.baseUrl}
                className={`flex min-w-0 items-center gap-2.5 rounded-lg border px-3 py-2 text-left transition-colors ${on ? "border-glow/70 bg-glow/5" : "border-rule hover:border-dim/60"}`}
              >
                <span className={`h-2 w-2 shrink-0 rounded-full ${dot}`} aria-hidden="true" />
                <span className="min-w-0">
                  <span className="block truncate text-sm font-medium text-ink">{p.label}</span>
                  <span className={`block truncate text-[11px] ${r && r.state !== "ok" && !p.local ? "text-danger" : "text-dim"}`}>{sub}</span>
                </span>
              </button>
            );
          })}
        </div>
        <p className="mt-2 text-xs leading-relaxed text-dim">
          Calls go straight from this computer to the provider{proxy ? <> through your proxy (<span className="f-mono">{proxy}</span>)</> : null} — no server of
          ours sits in between, so the only region that matters is yours.{" "}
          {reach && (
            <span className={served === cloud ? "text-ink-2" : "text-ink"}>
              {served === cloud ? "Every provider here answers from your network." : `${served} of ${cloud} answer from your network; the red ones would fail, so pick a green one.`}
            </span>
          )}
        </p>
      </div>

      {/* 2 — paste */}
      {custom.baseUrl && (
        <div className="f-fade space-y-3">
          {needsKey ? (
            <div>
              <div className="mb-1.5 flex items-baseline justify-between gap-3">
                <label htmlFor="brain-key" className="text-sm text-ink-2">
                  2 · paste your {preset?.label ?? ""} key
                </label>
                {preset?.keyUrl && (
                  <a href={preset.keyUrl} target="_blank" rel="noreferrer noopener" className="text-xs text-glow underline-offset-2 hover:underline">
                    get a key ↗
                  </a>
                )}
              </div>
              <Input
                id="brain-key"
                className={`${inputCls} f-mono`}
                type="password"
                placeholder="sk-…"
                value={custom.apiKey}
                onChange={(e) => {
                  update({ custom: { ...custom, apiKey: e.target.value.trim() } });
                  if (conn.state !== "idle") setConn({ state: "idle" });
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && canConnect) void connect();
                  e.stopPropagation();
                }}
                autoComplete="off"
                spellCheck={false}
              />
              <p className="mt-1.5 text-xs text-dim">Kept in this browser only. Sent to {hostLabel(custom.baseUrl)} and nowhere else.</p>
            </div>
          ) : (
            <p className="text-sm text-ink-2">
              2 · no key needed <span className="text-dim">— it runs on this machine. Start {preset?.label ?? "the server"} and load a model first.</span>
            </p>
          )}

          {/* 3 — connect */}
          <div className="flex flex-wrap items-end gap-2">
            <div className="min-w-[180px] flex-1">
              <label htmlFor="brain-model" className="mb-1.5 block text-sm text-ink-2">
                3 · model{models.length > 0 ? <span className="text-dim"> · {models.length} on your account</span> : null}
              </label>
              <Input
                id="brain-model"
                list="brain-models"
                className={`${inputCls} f-mono`}
                placeholder="model name"
                value={custom.model}
                onChange={(e) => update({ custom: { ...custom, model: e.target.value.trim() } })}
                onKeyDown={(e) => e.stopPropagation()}
                spellCheck={false}
              />
              <datalist id="brain-models">
                {models.map((m) => (
                  <option key={m} value={m} />
                ))}
              </datalist>
            </div>
            <Button type="button" onClick={() => void connect()} disabled={!canConnect} className="h-10 min-w-[120px] bg-glow font-medium text-glow-ink hover:brightness-110 disabled:opacity-40">
              {conn.state === "running" ? "connecting…" : live && conn.state === "ok" ? "connected" : "connect"}
            </Button>
          </div>

          {here && here.state !== "ok" && conn.state === "idle" && !preset?.local && (
            <p className="rounded-lg border border-danger/40 bg-danger/5 px-3 py-2 text-xs leading-relaxed text-ink-2">
              {hostLabel(custom.baseUrl)} {here.state === "blocked" ? "refuses requests from your network's location" : "isn't answering from your network"}. A key won't fix that —
              pick a green provider (OpenRouter carries most models), or turn on a VPN or system proxy and restart the app.
            </p>
          )}
          {conn.state === "ok" && (
            <p className="f-fade flex items-center gap-1.5 text-sm text-glow" role="status">
              <Check size={14} /> {conn.msg}
            </p>
          )}
          {conn.state === "fail" && (
            <div className="f-fade rounded-lg border border-danger/40 bg-danger/5 px-3 py-2.5" role="alert">
              <p className="text-sm font-medium leading-snug text-ink">{conn.failure.message}</p>
              {conn.failure.hint && <p className="mt-1 text-xs leading-relaxed text-ink-2">{conn.failure.hint}</p>}
              {conn.failure.raw && <p className="f-mono mt-1.5 break-words text-[11px] leading-relaxed text-dim">{conn.failure.raw}</p>}
            </div>
          )}
        </div>
      )}

      {/* everything else, out of the way */}
      <details className="group rounded-lg border border-rule">
        <summary className="flex cursor-pointer list-none items-center justify-between px-3 py-2.5 text-sm text-ink-2 hover:text-ink">
          a different endpoint, tuning, other brains
          <span className="text-dim transition-transform group-open:rotate-90" aria-hidden="true">›</span>
        </summary>
        <div className="space-y-4 border-t border-rule px-3 py-3">
          <Field label="endpoint — any OpenAI-compatible base URL">
            <Input
              className={`${inputCls} f-mono`}
              placeholder="https://your-host/v1"
              value={custom.baseUrl}
              onChange={(e) => update({ custom: { ...custom, baseUrl: e.target.value.trim() } })}
              onKeyDown={(e) => e.stopPropagation()}
              aria-label="Endpoint base URL"
              spellCheck={false}
            />
          </Field>
          <Field label={`temperature · ${custom.temperature.toFixed(2)}`}>
            <Slider min={0} max={1.5} step={0.05} value={[custom.temperature]} onValueChange={([v]) => update({ custom: { ...custom, temperature: v } })} aria-label="Temperature" className="w-full max-w-xs" />
          </Field>
          <div className="space-y-2" role="radiogroup" aria-label="Other brains">
            {builtin && otherBtn("fotra", "built-in brain", "the host platform's model · zero keys")}
            {otherBtn(
              "provider",
              "providers.json",
              `keys on the server (env vars), for routines that run while this tab is closed · ${providers?.roles?.chat ? `chat → ${providers.roles.chat}` : "no chat role set yet"}`
            )}
            {otherBtn("demo", "demo brain", "offline and scripted — shows the whole interface with zero keys, but it isn't thinking")}
          </div>
          {settings.engine === "provider" && (
            <div className="f-fade space-y-2.5">
              {providers?.valid ? (
                <ul className="space-y-1.5">
                  {providers.providers?.map((p) => (
                    <li key={p.id} className="flex items-center justify-between gap-3 text-sm">
                      <span className="text-ink-2">
                        {p.id}
                        {p.defaultModel ? ` · ${p.defaultModel}` : ""}
                      </span>
                      <span className={`f-label !opacity-80 ${p.hasKey || p.keyless ? "text-glow" : "text-danger"}`}>{p.keyless ? "local · no key needed" : p.hasKey ? "key found" : "no key"}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-xs leading-relaxed text-danger">{providers?.error ?? "checking providers.json…"}</p>
              )}
              <div className="flex items-center gap-2">
                <Button type="button" variant="outline" onClick={proveProvider} disabled={!providers?.roles?.chat || provTest.state === "running"} className="min-h-[40px] border-rule text-ink-2 hover:border-glow/60 hover:bg-paper-3 hover:text-ink">
                  <Zap size={14} className="text-glow" /> test the chat role
                </Button>
                {provTest.state !== "idle" && (
                  <span className={`text-xs ${provTest.state === "ok" ? "text-glow" : provTest.state === "fail" ? "text-danger" : "text-dim"}`} role="status">
                    {provTest.msg}
                  </span>
                )}
              </div>
              <p className="text-xs leading-relaxed text-dim">Edit providers.json at the project root; keys go in .env.local.</p>
            </div>
          )}
        </div>
      </details>
    </Section>
  );
}

/* —— WEB SEARCH — Google through its official API, or the keyless engines —— */

function SearchSection() {
  const [on, setOn] = useState<boolean | null>(null);
  const [key, setKey] = useState("");
  const [cx, setCx] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void fetch("/api/search-config")
      .then((r) => r.json())
      .then((j: { google?: boolean; cx?: string }) => {
        setOn(!!j.google);
        setCx(j.cx ?? "");
      })
      .catch(() => setOn(false));
  }, []);

  async function save() {
    setBusy(true);
    setMsg(null);
    try {
      const res = await fetch("/api/search-config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ googleKey: key, googleCx: cx }) });
      const j = (await res.json()) as { ok?: boolean; error?: string; results?: number };
      if (j.ok) {
        setOn(true);
        setKey("");
        setMsg({ ok: true, text: `Google answered with ${j.results} results — it is the search engine now.` });
      } else setMsg({ ok: false, text: j.error ?? "That didn't work." });
    } catch {
      setMsg({ ok: false, text: "Couldn't reach this app's own server." });
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    await fetch("/api/search-config", { method: "DELETE" }).catch(() => undefined);
    setOn(false);
    setMsg(null);
  }

  return (
    <Section label="web search">
      <div className={`flex items-center justify-between gap-3 rounded-xl border px-3.5 py-3 ${on ? "border-glow/40 bg-glow/5" : "border-rule bg-paper"}`} role="status">
        <p className="min-w-0 text-sm leading-snug text-ink">
          {on === null ? "checking…" : on ? (
            <>
              <span className="font-medium">Google</span> <span className="text-dim">is searching · your key, 100 free searches a day</span>
            </>
          ) : (
            <>
              Keyless search <span className="text-dim">(DuckDuckGo, then Bing) — works with no setup, but gets rate-limited</span>
            </>
          )}
        </p>
        {on && (
          <button type="button" onClick={() => void remove()} className="f-label shrink-0 !opacity-60 hover:!opacity-100">
            remove
          </button>
        )}
      </div>
      {!on && on !== null && (
        <div className="space-y-3">
          <p className="text-xs leading-relaxed text-dim">
            To search with Google, make two things (both free):{" "}
            <a href="https://developers.google.com/custom-search/v1/introduction" target="_blank" rel="noreferrer noopener" className="text-glow underline-offset-2 hover:underline">
              an API key ↗
            </a>{" "}
            and{" "}
            <a href="https://programmablesearchengine.google.com/controlpanel/create" target="_blank" rel="noreferrer noopener" className="text-glow underline-offset-2 hover:underline">
              a search engine set to “search the entire web” ↗
            </a>
            , then paste them here.
          </p>
          <div className="grid gap-2 sm:grid-cols-2">
            <Input className={`${inputCls} f-mono`} type="password" placeholder="API key" value={key} onChange={(e) => setKey(e.target.value.trim())} onKeyDown={(e) => e.stopPropagation()} autoComplete="off" spellCheck={false} aria-label="Google API key" />
            <Input className={`${inputCls} f-mono`} placeholder="search engine ID (cx)" value={cx} onChange={(e) => setCx(e.target.value.trim())} onKeyDown={(e) => e.stopPropagation()} spellCheck={false} aria-label="Google search engine ID" />
          </div>
          <Button type="button" variant="outline" onClick={() => void save()} disabled={busy || !key || !cx} className="min-h-[40px] border-rule text-ink-2 hover:border-glow/60 hover:bg-paper-3 hover:text-ink">
            {busy ? "testing…" : "test and use Google"}
          </Button>
          <p className="text-xs text-dim">Saved on this computer in <span className="f-mono">~/.fotra/search.json</span>; sent only to Google.</p>
        </div>
      )}
      {msg && <p className={`text-sm ${msg.ok ? "text-glow" : "text-danger"}`} role="status">{msg.text}</p>}
    </Section>
  );
}

function hostLabel(base: string): string {
  try {
    return new URL(/^https?:\/\//.test(base) ? base : `https://${base}`).host;
  } catch {
    return base;
  }
}

/* —— STREAM RULES (TTSR — cut the model mid-stream when it goes off-script) —— */

interface RuleRow {
  id: string;
  name: string;
  pattern: string;
  reminder: string;
  enabled: boolean;
  hits: number;
}

function RulesSection() {
  const [rules, setRules] = useState<RuleRow[] | null>(null);
  const [test, setTest] = useState("");
  const [testHits, setTestHits] = useState<Array<{ name: string; matched: string }> | null>(null);
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState({ name: "", pattern: "", reminder: "" });
  const [error, setError] = useState("");

  const load = () => {
    void fetch("/api/rules")
      .then((r) => r.json())
      .then((j: { rules?: RuleRow[] }) => setRules(j.rules ?? []))
      .catch(() => setRules([]));
  };
  useEffect(load, []);

  const toggle = (r: RuleRow) => {
    setRules((prev) => prev?.map((x) => (x.id === r.id ? { ...x, enabled: !x.enabled } : x)) ?? null);
    void fetch("/api/rules", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: r.id, enabled: !r.enabled }),
    });
  };
  const remove = (r: RuleRow) => {
    setRules((prev) => prev?.filter((x) => x.id !== r.id) ?? null);
    void fetch(`/api/rules?id=${r.id}`, { method: "DELETE" }).then(load);
  };
  const create = () => {
    setError("");
    void fetch("/api/rules", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(draft),
    })
      .then((r) => r.json())
      .then((j: { error?: string }) => {
        if (j.error) {
          setError(j.error);
          return;
        }
        toast.success("rule armed", { description: `/${draft.pattern}/ watches the live reply now` });
        setAdding(false);
        setDraft({ name: "", pattern: "", reminder: "" });
        load();
      });
  };
  const runTest = () => {
    setTestHits(null);
    void fetch("/api/rules", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ test }),
    })
      .then((r) => r.json())
      .then((j: { hits?: Array<{ name: string; matched: string }> }) => setTestHits(j.hits ?? []));
  };

  return (
    <Section>
      <p className="text-xs leading-relaxed text-dim">
        A rule watches the reply as it is written. When its pattern matches, the reply stops, the
        reminder is handed to the model, and it carries on from the same point.
      </p>
      {rules === null && <p className="text-xs text-dim">loading…</p>}
      {rules?.map((r) => (
        <div key={r.id} className="min-w-0 rounded-lg border border-rule bg-paper p-3">
          <div className="flex items-center justify-between gap-2">
            <span className="flex min-w-0 items-center gap-2.5">
              <Switch
                checked={r.enabled}
                onCheckedChange={() => toggle(r)}
                aria-label={r.enabled ? `Disarm rule ${r.name}` : `Arm rule ${r.name}`}
              />
              <span className="f-label truncate text-ink">{r.name}</span>
            </span>
            <div className="flex shrink-0 items-center gap-2">
              <span className="f-data f-label !opacity-50" title="times this rule has cut a stream">{r.hits}×</span>
              <Button type="button" variant="ghost" size="icon" aria-label={`Delete rule ${r.name}`} onClick={() => remove(r)} className="h-8 w-8 text-dim hover:bg-paper-3 hover:text-danger">
                <Trash2 size={14} />
              </Button>
            </div>
          </div>
          <div className="f-mono mt-2 truncate text-xs text-dim" title={r.pattern}>
            /{r.pattern}/
          </div>
          <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-ink-2" title={r.reminder}>
            {r.reminder}
          </p>
        </div>
      ))}
      {adding ? (
        <div className="space-y-2 rounded-md border border-glow/40 bg-paper-2 p-3">
          <Input
            className={inputCls}
            placeholder="rule name (e.g. no-markdown-in-speech)"
            value={draft.name}
            onChange={(e) => setDraft({ ...draft, name: e.target.value })}
          />
          <Input
            className={`${inputCls} f-mono`}
            placeholder="regex pattern (e.g. as requested|in conclusion)"
            value={draft.pattern}
            onChange={(e) => setDraft({ ...draft, pattern: e.target.value })}
          />
          <Textarea
            className={inputCls}
            rows={3}
            placeholder="the reminder injected when it fires — what should the model do differently?"
            value={draft.reminder}
            onChange={(e) => setDraft({ ...draft, reminder: e.target.value })}
          />
          {error && <p className="text-xs text-danger">{error}</p>}
          <div className="flex gap-2">
            <Button type="button" onClick={create} className="flex-1 bg-glow text-glow-ink hover:brightness-110">
              save rule
            </Button>
            <Button type="button" variant="outline" onClick={() => setAdding(false)} className="flex-1 border-rule text-ink-2 hover:bg-paper-3 hover:text-ink">
              cancel
            </Button>
          </div>
        </div>
      ) : (
        <Button type="button" variant="outline" onClick={() => setAdding(true)} className="w-full border-rule text-ink-2 hover:border-dim/60 hover:bg-paper-3 hover:text-ink">
          + add a rule
        </Button>
      )}
      <Field label="try text against the armed rules">
        <div className="flex gap-2">
          <Input
            className={inputCls}
            placeholder="paste model output to see which rules would cut it"
            value={test}
            onChange={(e) => setTest(e.target.value)}
          />
          <Button type="button" variant="outline" onClick={runTest} className="shrink-0 border-rule text-ink-2 hover:bg-paper-3 hover:text-ink">
            test
          </Button>
        </div>
      </Field>
      {testHits && (
        <div className={testHits.length ? "rounded-md border border-danger/40 bg-danger/5 p-3" : "rounded-md border border-rule bg-paper-2 p-3"}>
          {testHits.length === 0 ? (
            <p className="text-xs text-dim">no rule matches — the stream would pass through</p>
          ) : (
            testHits.map((h, i) => (
              <p key={i} className="text-xs text-danger">
                <span className="f-label">{h.name}</span> would cut on “{h.matched}”
              </p>
            ))
          )}
        </div>
      )}
    </Section>
  );
}

/* —— MEMORY — server-backed when a session exists (git vault under the hood) —— */

interface ServerMemory {
  id: string;
  fact: string;
  topic: string;
  origin: string;
  source?: string | null;
  ts: string;
}

function MemorySection() {
  const localMemory = useFotra((s) => s.memory);
  const remember = useFotra((s) => s.remember);
  const removeFact = useFotra((s) => s.removeFact);
  const sessionId = useFotra((s) => s.settings.sessionId);
  const [draft, setDraft] = useState("");
  const [server, setServer] = useState<ServerMemory[] | null>(null);
  const [editing, setEditing] = useState<string | null>(null);
  const [editText, setEditText] = useState("");

  const load = () => {
    if (!sessionId) return;
    void fetch(`/api/memory?sessionId=${sessionId}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((j: { memories?: ServerMemory[] } | null) => setServer(j?.memories ?? []))
      .catch(() => setServer(null));
  };
  useEffect(load, [sessionId]);

  async function serverDelete(id: string) {
    await fetch("/api/memory", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId, id }),
    }).catch(() => undefined);
    load();
  }
  async function serverEdit(id: string) {
    if (!editText.trim()) return;
    await fetch("/api/memory", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId, id, fact: editText }),
    }).catch(() => undefined);
    setEditing(null);
    load();
  }

  const list: Array<{ id: string; fact: string; topic: string; origin: string; source?: string | null; ts: string }> = server ?? localMemory.map((m) => ({ ...m, ts: new Date(m.ts).toISOString() }));

  function exportMemory() {
    const md = list.map((m) => `- ${m.fact} · _${m.topic}_ · ${new Date(m.ts).toLocaleDateString()}`).join("\n");
    const blob = new Blob([`# What fotra remembers\n\n${md || "(nothing yet)"}\n`], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "fotra-memory.md";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <Section>
      {sessionId && (
        <p className="f-label !opacity-50 leading-relaxed">
          server-side · every edit is a git commit in ~/.fotra/memory — the history is the trust story
        </p>
      )}
      {list.length === 0 ? (
        <p className="text-sm leading-relaxed text-dim">
          Nothing yet. Say “remember that …” in the thread, or add a note here. Every line is
          editable and deletable — it&apos;s your data, not its.
        </p>
      ) : (
        <ul className="space-y-2">
          {list.map((m) => (
            <li key={m.id} className="f-fade rounded-md border border-rule bg-paper-2 px-3 py-2.5">
              {editing === m.id ? (
                <div className="flex items-start gap-2">
                  <Input
                    className={inputCls}
                    value={editText}
                    onChange={(e) => setEditText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") void serverEdit(m.id);
                      e.stopPropagation();
                    }}
                    aria-label="Edit memory fact"
                    autoFocus
                  />
                  <Button type="button" variant="ghost" size="icon" onClick={() => void serverEdit(m.id)} aria-label="Save edit" className="h-9 w-9 shrink-0 text-glow hover:bg-paper-3">
                    <Check size={14} />
                  </Button>
                  <Button type="button" variant="ghost" size="icon" onClick={() => setEditing(null)} aria-label="Cancel edit" className="h-9 w-9 shrink-0 text-dim hover:bg-paper-3">
                    <X size={14} />
                  </Button>
                </div>
              ) : (
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="break-words text-sm leading-snug text-ink-2">{m.fact}</p>
                    <p className="f-label !opacity-45 mt-1">
                      {m.topic} · {m.origin === "user-told" ? "you said" : "it noticed"} · {new Date(m.ts).toLocaleDateString()}
                      {m.source ? ` · via ${m.source}` : ""}
                    </p>
                  </div>
                  <div className="flex shrink-0">
                    {sessionId ? (
                      <>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          aria-label="Edit memory"
                          onClick={() => {
                            setEditing(m.id);
                            setEditText(m.fact);
                          }}
                          className="h-8 w-8 text-dim hover:bg-paper-3 hover:text-ink"
                        >
                          <Pencil size={13} />
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          aria-label="Forget this"
                          onClick={() => void serverDelete(m.id)}
                          className="h-8 w-8 text-dim hover:bg-paper-3 hover:text-danger"
                        >
                          <Trash2 size={13} />
                        </Button>
                      </>
                    ) : (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        aria-label="Forget this"
                        onClick={() => removeFact(m.id)}
                        className="h-8 w-8 text-dim hover:bg-paper-3 hover:text-danger"
                      >
                        <Trash2 size={13} />
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}

      <div className="flex gap-2">
        <Input
          className={inputCls}
          placeholder="add a fact…"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && draft.trim()) {
              remember(draft.trim(), "facts", "user-told");
              setDraft("");
            }
            e.stopPropagation();
          }}
          aria-label="Add memory fact"
        />
        {list.length > 0 && (
          <Button
            type="button"
            variant="outline"
            aria-label="Export memory as markdown"
            onClick={exportMemory}
            className="h-11 w-11 shrink-0 border-rule text-dim hover:border-dim/60 hover:bg-paper-3 hover:text-ink"
          >
            <Download size={15} />
          </Button>
        )}
      </div>
    </Section>
  );
}

/* —— DATA — export + search the append-only log —— */

function DataSection() {
  const turns = useFotra((s) => s.turns);
  const resetThread = useFotra((s) => s.resetThread);
  const sessionId = useFotra((s) => s.settings.sessionId);
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<Array<{ id: string; role: string; text: string; ts: string }> | null>(null);

  function exportLocal() {
    const md = turns
      .map((t) => `${t.role === "user" ? "**you**" : `**${useFotra.getState().persona.name}**`}: ${t.text}`)
      .join("\n\n");
    const blob = new Blob([`# fotra thread\n\n${md || "(empty)"}\n`], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "fotra-thread.md";
    a.click();
    URL.revokeObjectURL(url);
  }

  function exportServer() {
    if (!sessionId) return;
    window.open(`/api/session?id=${sessionId}&export=md`, "_blank", "noopener");
  }

  async function search() {
    const q = query.trim();
    if (!q || !sessionId) return;
    const res = await fetch(`/api/session?id=${sessionId}&q=${encodeURIComponent(q)}`).catch(() => null);
    if (!res || !res.ok) return setHits([]);
    const j = (await res.json()) as { hits?: Array<{ id: string; role: string; text: string; ts: string }> };
    setHits(j.hits ?? []);
  }

  return (
    <Section>
      <div className="flex flex-wrap gap-2">
        <Button
          type="button"
          variant="outline"
          onClick={sessionId ? exportServer : exportLocal}
          disabled={turns.length === 0 && !sessionId}
          className="min-h-[40px] border-rule text-ink-2 hover:border-glow/60 hover:bg-paper-3 hover:text-ink"
        >
          <Download size={14} /> export thread{sessionId ? " · server log" : ""}
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={() => {
            if (confirm("Clear the thread? Memory and settings stay.")) resetThread();
          }}
          disabled={turns.length === 0}
          className="min-h-[40px] border-rule text-ink-2 hover:border-danger hover:bg-transparent hover:text-danger"
        >
          <Trash2 size={14} /> clear thread
        </Button>
      </div>

      {sessionId && (
        <div className="space-y-2">
          <div className="flex gap-2">
            <Input
              className={inputCls}
              placeholder="search every turn ever — the log is greppable"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") void search();
                e.stopPropagation();
              }}
              aria-label="Search the thread"
            />
            <Button
              type="button"
              variant="outline"
              onClick={() => void search()}
              disabled={!query.trim()}
              aria-label="Search"
              className="h-11 w-11 shrink-0 border-rule text-dim hover:border-dim/60 hover:bg-paper-3 hover:text-ink"
            >
              <Search size={15} />
            </Button>
          </div>
          {hits && (
            <ul className="space-y-1.5">
              {hits.length === 0 && <li className="f-label !opacity-60">nothing matched</li>}
              {hits.slice(0, 8).map((h) => (
                <li key={h.id} className="f-fade rounded-md border border-rule bg-paper-2 px-3 py-2">
                  <span className="f-label !opacity-45">{h.role} · {new Date(h.ts).toLocaleString()}</span>
                  <p className="line-clamp-2 text-sm leading-snug text-ink-2">{h.text}</p>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </Section>
  );
}

/* —— CAPABILITIES (the honest matrix) —— */

function CapabilitySection() {
  const rows: [string, string][] = [
    ["your model", "any openai-compatible endpoint runs the full harness: 31 tools, recorded runs, a fallback chain to providers.json when one is wired"],
    ["the trail", "every tool call is a live step in the thread — the search types and its sources land, code runs and prints — then the group folds to one line you can reopen"],
    ["tapbacks", "when a message needs no words back, the whole reply is a reaction on your bubble · your own reactions ride into the next run as feedback"],
    ["itself", "self_edit — behavior (standing instructions in SOUL.md), look, voice and its own layout · every change journaled and undoable, by voice or button"],
    ["providers.json", "server-side roles · keys in .env.local, never in the tracked file"],
    ["demo brain", "fully offline and scripted — plays the same step and browser-frame events so the interface can be felt with zero keys; everything it shows is labelled demo"],
    ["kernels", "run_js / run_python run in PERSISTENT kernels — state survives across calls, and cells call fotra's own tools from inside (tool(\"web_search\",…)) · 20s/cell · files land in the workspace (the oh-my-pi eval port; timeouts, not a VM jail)"],
    ["browser computer", "a real headless chromium you watch live: its cursor glides to what it clicks, text types in · the model acts on numbered element handles, not guessed selectors · it asks before anything that spends money"],
    ["sub-agents", "spawn_task — parallel workers, own runs + budgets + event streams · outputSchema → the worker yields VALIDATED JSON the parent cites as agent://<name>/<field>"],
    ["workspace", "read/write/patch in ~/.fotra/workspace · hashline edits anchor to the #tag a read handed out — stale tags caught before corruption · artifacts recorded"],
    ["web + memory", "web_search · open_link · remember/forget · recall (scored: relevance × recency) · reflect (synthesize over memory) · learn (skills that auto-fire on trigger) · git-markdown vault · daily consolidation"],
    ["stream rules", "TTSR (oh-my-pi port) — regex rules watch the live reply; a match cuts the stream mid-token, injects the reminder, regenerates from the same point · edit them below"],
    ["advisor", "a second model reviews steps inline — aside / concern / blocker — and the agent course-corrects (≤2 passes/run)"],
    ["context ops", "checkpoint {} marks the context · rewind {report} collapses the detour into a report · ultrathink / orchestrate magic keywords (prose only)"],
    ["board + charts", "todo_write task board · chart screens (data-ink ramp) · grounded tables"],
    ["routines", "scheduled autonomous runs — it can create them itself when you say “every morning…” · fire on demand · answers land in the thread"],
    ["web search", "the host platform's search when present, otherwise a keyless duckduckgo fallback — a bring-your-own-model install can still search"],
    ["mcp", "connect any streamable-http MCP server — its tools become mcp_<server>_<tool>"],
    ["sessions", "every conversation is a recorded session — the rail's sessions panel and ⌘K jump between them; switching replays the server log"],
    ["long context", "older turns compact into a rolling summary as a background job · reattach after reload"],
    ["runs", "event-sourced · parallel tool batches · interrupt-steering (kicks the current call) · deadline-bounded (6 min, pause-not-kill) · nudge-guarded tool use"],
    ["realtime voice", "webrtc call w/ semantic-vad barge-in (needs a server openai key) · ask_fotra delegates to this harness"],
    ["browser voice", "web speech · zero keys · hold space to talk"],
    ["firefox / safari", "typing + screens (no web speech) — said plainly, never silent"],
    ["not yet (honest)", "webrtc realtime needs your server key to exercise · code runs timeout-bounded, not vm-isolated · recall is scored keyword + recency, no embeddings · routines need a server-side brain (providers.json) since a browser-held key can't fire while you're away · the browser is headless: no logins it can't type, no captchas"],
  ];
  return (
    <Section>
      <dl className="space-y-2.5">
        {rows.map(([k, v]) => (
          <div key={k} className="flex gap-3 text-sm">
            <dt className="f-label !opacity-60 w-36 shrink-0 pt-0.5">{k}</dt>
            <dd className="leading-relaxed text-ink-2">{v}</dd>
          </div>
        ))}
      </dl>
    </Section>
  );
}
