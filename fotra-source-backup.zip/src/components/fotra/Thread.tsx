"use client";

/* ————————————————————————————————————————————————
   THE THREAD — one conversation, in the order things
   happened. Your words sit right; its reply is a
   timeline on the left: what it said, the work it did
   (live while it runs, folded when done), the screens
   it built, what it said next. System lines (memory
   consolidation, routines) and voice-call receipts are
   quiet hairlines — never toasts.
   ———————————————————————————————————————————————— */

import { useEffect, useRef, useState } from "react";
import { ChevronDown, Phone } from "lucide-react";
import { useFotra } from "@/lib/fotra/store";
import type { Turn, TurnBlock } from "@/lib/fotra/types";
import { ScreenCard } from "./Screens";
import { Mascot } from "./mascot/Mascot";
import { Markdown } from "./Markdown";
import { StepGroup } from "./Trail";
import { ReplyTools, Tapback } from "./Reactions";

const WIDTH = { narrow: "max-w-[600px]", normal: "max-w-[736px]", wide: "max-w-[940px]" } as const;

export function Thread() {
  const turns = useFotra((s) => s.turns);
  const screens = useFotra((s) => s.screens);
  const phase = useFotra((s) => s.phase);
  const statusLine = useFotra((s) => s.statusLine);
  const liveCaption = useFotra((s) => s.liveCaption);
  const ui = useFotra((s) => s.settings.ui);
  const scrollRef = useRef<HTMLDivElement>(null);
  const pinned = useRef(true);

  // autoscroll when near the bottom; never yank the user mid-read
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      pinned.current = el.scrollHeight - el.scrollTop - el.clientHeight < 140;
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  // a new turn always brings you to it — you just said something, or it just started answering
  const turnCount = turns.length;
  useEffect(() => {
    pinned.current = true;
    const el = scrollRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [turnCount]);

  useEffect(() => {
    const el = scrollRef.current;
    if (el && pinned.current) el.scrollTop = el.scrollHeight;
  }, [turns, screens, liveCaption, phase, statusLine]);

  // surfaces grow and fold on their own clock — keep the bottom in view while they do
  useEffect(() => {
    const el = scrollRef.current;
    const inner = el?.firstElementChild;
    if (!el || !inner || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => {
      if (pinned.current) el.scrollTop = el.scrollHeight;
    });
    ro.observe(inner);
    return () => ro.disconnect();
  }, []);

  const compact = ui?.density === "compact";
  const lastId = turns[turns.length - 1]?.id;

  return (
    <div ref={scrollRef} className="f-scroll h-full overflow-y-auto px-4 sm:px-6" data-density={compact ? "compact" : "cozy"}>
      <div className={`mx-auto ${WIDTH[ui?.width ?? "normal"]} ${compact ? "py-4" : "py-7"}`}>
        {turns.map((t) =>
          t.origin === "system" ? (
            <div key={t.id} className="f-fade my-5 flex items-center gap-3" aria-live="polite">
              <span className="h-px flex-1 bg-rule" aria-hidden="true" />
              <span className="f-label !opacity-40">{t.text}</span>
              <span className="h-px flex-1 bg-rule" aria-hidden="true" />
            </div>
          ) : t.origin === "voice-call" ? (
            <VoiceReceipt key={t.id} text={t.text} />
          ) : t.tapOnly ? null : t.role === "user" ? (
            <UserTurn key={t.id} turn={t} compact={compact} />
          ) : (
            <AssistantTurn key={t.id} turn={t} compact={compact} last={t.id === lastId} thinking={t.id === lastId && t.streaming === true && phase === "thinking"} />
          )
        )}

        {/* live caption while listening */}
        {(phase === "listening" || (liveCaption && phase !== "idle")) && (
          <div className="mt-5 flex justify-end" aria-live="polite">
            <div className="f-bubble f-bubble-live">
              {liveCaption || <span className="f-label !opacity-70">listening…</span>}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function UserTurn({ turn, compact }: { turn: Turn; compact: boolean }) {
  return (
    <div className={`f-rise flex justify-end ${compact ? "mt-4" : "mt-7"}`}>
      <div className="relative max-w-[82%]">
        <div className="f-bubble whitespace-pre-wrap">{turn.text}</div>
        <Tapback turn={turn} />
        {(turn.origin === "voice" || turn.note) && (
          <span className="f-label mt-1 block text-right !opacity-35">{turn.origin === "voice" ? "voice" : turn.note}</span>
        )}
      </div>
    </div>
  );
}

function AssistantTurn({ turn, compact, thinking, last }: { turn: Turn; compact: boolean; thinking: boolean; last: boolean }) {
  const screens = useFotra((s) => s.screens);
  // turns from before the timeline existed (or replayed from the server log) have only text + screens
  const blocks: TurnBlock[] =
    turn.blocks && turn.blocks.length > 0
      ? turn.blocks
      : [...(turn.text ? [{ kind: "text" as const, text: turn.text }] : []), ...(turn.screenIds ?? []).map((id) => ({ kind: "screen" as const, id }))];
  const lastTextIdx = blocks.map((b) => b.kind).lastIndexOf("text");
  const empty = blocks.length === 0;

  return (
    <div className={`group/turn flex gap-3 ${compact ? "mt-3" : "mt-5"}`}>
      <span className="mt-0.5 hidden shrink-0 sm:block" aria-hidden="true">
        <Mascot size={26} decorative showHalo={false} phase={turn.streaming ? "working" : "idle"} />
      </span>
      <div className="min-w-0 flex-1">
        {empty && turn.streaming && (
          <div className="flex h-[26px] items-center gap-2" aria-live="polite">
            <span className="f-think" aria-hidden="true">
              <i />
              <i />
              <i />
            </span>
            <span className="sr-only">thinking</span>
          </div>
        )}
        {blocks.map((b, i) => {
          if (b.kind === "text") {
            const tail = i === lastTextIdx;
            return (
              <div key={`t${i}`} className={i > 0 ? "mt-3" : ""}>
                <Markdown text={b.text} className={turn.streaming && tail && i === blocks.length - 1 ? "is-streaming" : ""} />
                {turn.interrupted && tail && b.text && <span className="f-label !opacity-55">— cut off</span>}
              </div>
            );
          }
          if (b.kind === "steps") {
            return (
              <div key={`s${b.ids[0]}`} className={i > 0 ? "mt-3" : ""}>
                <StepGroup turn={turn} ids={b.ids} />
              </div>
            );
          }
          const sc = screens[b.id];
          if (!sc || sc.expanded || sc.status === "retired") return null;
          return <ScreenCard key={`c${b.id}`} screen={sc} />;
        })}
        {/* between tool rounds: it is reading the results, about to speak */}
        {thinking && !empty && blocks[blocks.length - 1]?.kind !== "text" && (
          <div className="mt-3 flex h-5 items-center" aria-hidden="true">
            <span className="f-think">
              <i />
              <i />
              <i />
            </span>
          </div>
        )}
        {!turn.streaming && turn.text && <ReplyTools turn={turn} last={last} />}
      </div>
    </div>
  );
}

/* voice receipts — compact chips on a hairline; the transcript stays in the log */
function VoiceReceipt({ text }: { text: string }) {
  const [open, setOpen] = useState(false);
  if (!text.startsWith("voice call")) return null; // transcript bodies stay hidden
  return (
    <div className="f-fade my-4">
      <div className="flex items-center gap-2">
        <span className="h-px flex-1 bg-rule" aria-hidden="true" />
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          className="inline-flex items-center gap-1.5 rounded-full border border-rule px-2.5 py-1 text-xs text-dim transition-colors hover:border-dim/60 hover:text-ink"
          aria-expanded={open}
        >
          <Phone size={10} className="text-glow" aria-hidden="true" />
          <span className="f-label !opacity-80">{text}</span>
          <ChevronDown size={11} className={`transition-transform ${open ? "rotate-180" : ""}`} aria-hidden="true" />
        </button>
        <span className="h-px flex-1 bg-rule" aria-hidden="true" />
      </div>
      {open && <p className="f-label mt-2 text-center !opacity-50">the full transcript is in the exported thread — this chip is the receipt</p>}
    </div>
  );
}
