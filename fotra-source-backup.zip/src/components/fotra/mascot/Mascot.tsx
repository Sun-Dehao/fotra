"use client";

/* ————————————————————————————————————————————————
   THE MASCOT, v3 — a character, not a face on a ball

   Six bodies, each its own silhouette, drawn as one
   crisp SVG: sprout, ghost, star, cat, bot — and the
   orb, the faceless living mesh (openbot's AgentOrb,
   MIT). The coat colors the body; the aura is what
   surrounds it, and the three auras look nothing
   alike: a glow, sonar rings, a scatter of sparks.

   It is alive in small ways: it floats, blinks, and
   its eyes follow your pointer. It leans in when it
   listens, looks up when it thinks, narrows its eyes
   when it works, and its mouth moves when it speaks.

   One mascot, many sizes: the hero, the header chip,
   the avatar beside each reply. Press the hero to talk.
   ———————————————————————————————————————————————— */

import { useEffect, useId } from "react";
import { type MotionValue, useAnimationFrame, useMotionValue } from "framer-motion";
import { useFotra } from "@/lib/fotra/store";
import { voiceInput } from "@/lib/fotra/voice";
import type { Aura, MascotCoat, MascotSkin, Phase } from "@/lib/fotra/types";
import AgentOrb from "./agent-orb";
import { type AIState, getAIStateMotion } from "./ai-core";

/* —— phase → AIState: fotra's six phases map 1:1 —— */
export function phaseToAIState(phase: Phase): AIState {
  switch (phase) {
    case "listening":
      return "listening";
    case "thinking":
      return "thinking";
    case "speaking":
      return "streaming";
    case "working":
      return "working";
    case "error":
      return "error";
    default:
      return "idle";
  }
}

/* —— the six coats: orb mesh palette (the character's own palette lives in globals.css as --m-*) —— */
export const MASCOT_COATS: {
  id: MascotCoat;
  label: string;
  colors: { bg: string; c1: string; c2: string; c3: string; c4: string };
}[] = [
  {
    id: "iris",
    label: "iris",
    colors: { bg: "oklch(92% 0.03 300)", c1: "oklch(68% 0.21 350)", c2: "oklch(70% 0.18 210)", c3: "oklch(66% 0.2 285)", c4: "oklch(72% 0.19 325)" },
  },
  {
    id: "verdant",
    label: "verdant",
    colors: { bg: "oklch(93% 0.03 160)", c1: "oklch(74% 0.17 150)", c2: "oklch(68% 0.14 180)", c3: "oklch(60% 0.15 140)", c4: "oklch(78% 0.15 165)" },
  },
  {
    id: "ember",
    label: "ember",
    colors: { bg: "oklch(93% 0.025 60)", c1: "oklch(70% 0.18 30)", c2: "oklch(66% 0.16 55)", c3: "oklch(60% 0.17 15)", c4: "oklch(74% 0.15 45)" },
  },
  {
    id: "ice",
    label: "ice",
    colors: { bg: "oklch(93% 0.025 230)", c1: "oklch(72% 0.15 220)", c2: "oklch(68% 0.13 200)", c3: "oklch(64% 0.14 250)", c4: "oklch(76% 0.12 230)" },
  },
  {
    id: "rose",
    label: "rose",
    colors: { bg: "oklch(93% 0.025 350)", c1: "oklch(72% 0.18 350)", c2: "oklch(68% 0.16 320)", c3: "oklch(64% 0.15 5)", c4: "oklch(76% 0.14 340)" },
  },
  {
    id: "mono",
    label: "mono",
    colors: { bg: "oklch(92% 0.01 270)", c1: "oklch(70% 0.012 270)", c2: "oklch(60% 0.01 270)", c3: "oklch(52% 0.008 270)", c4: "oklch(78% 0.015 270)" },
  },
];

export function coatColors(coat: MascotCoat) {
  return (MASCOT_COATS.find((c) => c.id === coat) ?? MASCOT_COATS[0]).colors;
}

/* —— amplitude for the orb ————————————————————————————————
   listening → the real mic (voice.ts feeds us its level). speaking /
   working → a simulated speech envelope (three detuned sines). else 0. */
export function useMascotAmplitude(phase: Phase): MotionValue<number> {
  const amplitude = useMotionValue(0);

  useEffect(() => {
    if (phase !== "listening") return;
    voiceInput.onLevel((level) => amplitude.set(level));
    return () => {
      voiceInput.onLevel(null);
      amplitude.set(0);
    };
  }, [phase, amplitude]);

  const motion = getAIStateMotion(phaseToAIState(phase));
  const simActive = phase === "speaking" || phase === "working";

  useAnimationFrame((time) => {
    if (!simActive) return;
    const t = time / 1000;
    const envelope =
      0.5 +
      0.3 * Math.sin(t * 2.1 * motion.speed) +
      0.14 * Math.sin(t * 5.3 * motion.speed + 1.7) +
      0.06 * Math.sin(t * 11.7 * motion.speed + 0.4);
    amplitude.set(Math.min(1, Math.max(0, envelope * motion.intensity)));
  });

  return amplitude;
}

export const MASCOT_SKINS: { id: MascotSkin; label: string; note: string }[] = [
  { id: "dot", label: "sprout", note: "round, with a leaf" },
  { id: "ghost", label: "ghost", note: "soft, with a wavy hem" },
  { id: "star", label: "star", note: "a four-point spark" },
  { id: "cat", label: "cat", note: "ears and whiskers" },
  { id: "bot", label: "bot", note: "a visor and an antenna" },
  { id: "orb", label: "orb", note: "no face — pure energy" },
];

/* —— the eyes follow the pointer: one listener for every mascot on the page —— */
let lookers = 0;
let lookRaf = 0;
function onPointer(e: PointerEvent) {
  if (lookRaf) return;
  lookRaf = requestAnimationFrame(() => {
    lookRaf = 0;
    const x = (e.clientX / window.innerWidth) * 2 - 1;
    const y = (e.clientY / window.innerHeight) * 2 - 1;
    const root = document.documentElement.style;
    root.setProperty("--f-look-x", x.toFixed(3));
    root.setProperty("--f-look-y", y.toFixed(3));
  });
}
function useLook() {
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    if (lookers++ === 0) window.addEventListener("pointermove", onPointer, { passive: true });
    return () => {
      if (--lookers === 0) window.removeEventListener("pointermove", onPointer);
    };
  }, []);
}

/* —— the mascot ———————————————————————————————————————————————— */
export function Mascot({
  phase = "idle",
  skin,
  coat,
  aura,
  name,
  size = 64,
  decorative = false,
  showHalo = true,
  className = "",
}: {
  phase?: Phase;
  skin?: MascotSkin;
  coat?: MascotCoat;
  aura?: Aura;
  name?: string;
  size?: number;
  decorative?: boolean;
  /** kept for older callers — the character reads at any size now, so it is always drawn */
  showFace?: boolean;
  /** false where the aura would crowd (chips, avatars, tiny previews) */
  showHalo?: boolean;
  className?: string;
}) {
  const persona = useFotra((s) => s.persona);
  const sk = skin ?? persona.mascot;
  const ct = coat ?? persona.coat;
  const au = aura ?? persona.aura;
  const nm = name ?? persona.name;
  const uid = useId().replace(/[^a-zA-Z0-9]/g, "");
  const withAura = showHalo && size >= 40;
  useLook();

  return (
    <span
      className={`f-mascot ${className}`}
      data-state={phase}
      data-skin={sk}
      data-coat={ct}
      data-aura={au}
      data-small={size < 40 ? "" : undefined}
      style={{ width: size, height: size, "--m-size": `${size}px` } as React.CSSProperties}
      role={decorative ? "presentation" : "img"}
      aria-label={decorative ? undefined : `${nm} is ${phase}`}
    >
      {withAura && <AuraLayer />}
      {sk === "orb" ? <OrbBody size={size} phase={phase} coat={ct} /> : <Character skin={sk} uid={uid} small={size < 40} />}
    </span>
  );
}

/* the aura — every piece is in the DOM; data-aura on the mascot decides which ones show */
function AuraLayer() {
  return (
    <span className="f-m-aura" aria-hidden="true">
      <i className="f-a-glow" />
      <i className="f-a-ring" />
      <i className="f-a-ring" />
      <i className="f-a-ring" />
      {[0, 1, 2, 3, 4, 5, 6].map((i) => (
        <i key={i} className="f-a-spark" />
      ))}
      <i className="f-a-busy" />
    </span>
  );
}

/* the orb — the one faceless body: the liquid mesh, coat-colored, audio-reactive */
function OrbBody({ size, phase, coat }: { size: number; phase: Phase; coat: MascotCoat }) {
  const amplitude = useMascotAmplitude(phase);
  return (
    <span className="f-m-orbbody" aria-hidden="true">
      <AgentOrb size={`${size}px`} state={phaseToAIState(phase)} amplitude={amplitude} colors={coatColors(coat)} animationDuration={22} />
    </span>
  );
}

type Body = Exclude<MascotSkin, "orb">;

/* —— silhouettes (viewBox 0 0 100 100) —— */
const BODY: Record<Body, string> = {
  dot: "M50 16C73 16 89 32 89 54C89 76 73 91 50 91C27 91 11 76 11 54C11 32 27 16 50 16Z",
  ghost:
    "M14 50C14 27 29 10 50 10C71 10 86 27 86 50V84Q86 91 80 86L75 82Q68 77 62 82L56 86Q50 91 44 86L38 82Q32 77 25 82L20 86Q14 91 14 84Z",
  star: "M50 9C56 28 72 44 91 50C72 56 56 72 50 91C44 72 28 56 9 50C28 44 44 28 50 9Z",
  cat: "M15 58C15 49 17 42 20 36L17 13Q17 9 21 11L41 22Q45 21 50 21Q55 21 59 22L79 11Q83 9 83 13L80 36C83 42 85 49 85 58C85 77 70 90 50 90C30 90 15 77 15 58Z",
  bot: "M32 24H68C79 24 87 32 87 43V68C87 79 79 87 68 87H32C21 87 13 79 13 68V43C13 32 21 24 32 24Z",
};

/* where the face sits on each body: [dx, dy, scale] around the center */
const FACE: Record<Body, [number, number, number]> = {
  dot: [0, 5, 1],
  ghost: [0, -3, 0.96],
  star: [0, 0, 0.56],
  cat: [0, 9, 0.94],
  bot: [0, 6, 0.9],
};

function Character({ skin, uid, small }: { skin: Body; uid: string; small: boolean }) {
  const d = BODY[skin];
  const [dx, dy, sc] = FACE[skin];
  const bot = skin === "bot";
  const eyeFill = bot ? "var(--m-sheen)" : "var(--m-feature)";
  return (
    <span className="f-m-char" aria-hidden="true">
      <svg viewBox="0 0 100 100" focusable="false">
        <defs>
          <radialGradient id={`b${uid}`} cx="34%" cy="26%" r="88%">
            <stop offset="0%" stopColor="var(--m-sheen)" />
            <stop offset="38%" stopColor="var(--m-core)" />
            <stop offset="100%" stopColor="var(--m-deep)" />
          </radialGradient>
          <radialGradient id={`h${uid}`} cx="32%" cy="20%" r="46%">
            <stop offset="0%" stopColor="white" stopOpacity="0.55" />
            <stop offset="100%" stopColor="white" stopOpacity="0" />
          </radialGradient>
          <linearGradient id={`s${uid}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="55%" stopColor="var(--m-deep)" stopOpacity="0" />
            <stop offset="100%" stopColor="var(--m-deep)" stopOpacity="0.55" />
          </linearGradient>
        </defs>

        <g className="f-m-body">
          {/* what grows out of it, behind the body */}
          {skin === "dot" && (
            <g className="f-m-leaf">
              <path d="M50 18Q49 10 52 5" fill="none" stroke="var(--m-deep)" strokeWidth="3" strokeLinecap="round" />
              <path d="M52 6C58 -2 70 0 72 4C68 12 58 12 52 6Z" fill="var(--m-core)" stroke="var(--m-deep)" strokeWidth="1.5" strokeLinejoin="round" />
            </g>
          )}
          {bot && (
            <>
              <line x1="50" y1="25" x2="50" y2="12" stroke="var(--m-deep)" strokeWidth="3.5" strokeLinecap="round" />
              <circle className="f-m-bulb" cx="50" cy="10" r="5" fill="var(--m-mark-a)" />
              <rect x="6" y="46" width="9" height="20" rx="4.5" fill="var(--m-deep)" />
              <rect x="85" y="46" width="9" height="20" rx="4.5" fill="var(--m-deep)" />
            </>
          )}

          {/* the body: color, then weight at the bottom, then a soft highlight */}
          <path d={d} fill={`url(#b${uid})`} stroke={skin === "star" ? "var(--m-core)" : undefined} strokeWidth={skin === "star" ? 7 : undefined} strokeLinejoin="round" />
          <path d={d} fill={`url(#s${uid})`} />
          <path d={d} fill={`url(#h${uid})`} />

          {skin === "cat" && (
            <>
              <path d="M22 17L24 31L34 22Z" fill="var(--m-mark-a)" opacity="0.55" />
              <path d="M78 17L76 31L66 22Z" fill="var(--m-mark-a)" opacity="0.55" />
            </>
          )}
          {bot && <rect x="22" y="38" width="56" height="34" rx="15" fill="var(--m-feature)" />}

          {/* the face */}
          <g transform={`translate(${50 + dx} ${50 + dy}) scale(${sc}) translate(-50 -50)`}>
            {!small && !bot && (
              <>
                <ellipse cx="25" cy="60" rx="6.5" ry="4" fill="var(--m-mark-a)" opacity="0.4" />
                <ellipse cx="75" cy="60" rx="6.5" ry="4" fill="var(--m-mark-a)" opacity="0.4" />
              </>
            )}
            <g className="f-m-eyes">
              <g className="f-m-eye">
                <ellipse cx="36" cy="48" rx={small ? 6.5 : 5.6} ry={small ? 9 : 8.4} fill={eyeFill} />
                {!small && !bot && <circle cx="38" cy="44.4" r="2.1" fill="white" />}
              </g>
              <g className="f-m-eye">
                <ellipse cx="64" cy="48" rx={small ? 6.5 : 5.6} ry={small ? 9 : 8.4} fill={eyeFill} />
                {!small && !bot && <circle cx="66" cy="44.4" r="2.1" fill="white" />}
              </g>
            </g>
            {!small && !bot && (
              <g className="f-m-mouth">
                {skin === "cat" ? (
                  <>
                    <path className="f-m-smile" d="M44 61Q47 65 50 61Q53 65 56 61" fill="none" stroke="var(--m-feature)" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M48 57.5H52L50 60Z" fill="var(--m-feature)" stroke="var(--m-feature)" strokeWidth="1.4" strokeLinejoin="round" />
                    <path d="M20 54L8 51M20 59L8 61M80 54L92 51M80 59L92 61" stroke="var(--m-feature)" strokeWidth="1.5" strokeLinecap="round" opacity="0.45" />
                  </>
                ) : (
                  <path className="f-m-smile" d="M43.5 60Q50 67 56.5 60" fill="none" stroke="var(--m-feature)" strokeWidth="3" strokeLinecap="round" />
                )}
                <ellipse className="f-m-talk" cx="50" cy="63" rx="5" ry="4.6" fill="var(--m-feature)" />
              </g>
            )}
            {!small && bot && <rect className="f-m-talk f-m-led" x="43" y="60" width="14" height="3" rx="1.5" fill="var(--m-sheen)" />}
          </g>
        </g>
      </svg>
    </span>
  );
}
