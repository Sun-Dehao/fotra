"use client";

/* ————————————————————————————————————————————————
   STAGE MASCOT — the hero control
   The mascot IS the mic button (fotra's own): press
   it to talk, press it to interrupt, tap it to
   dismiss an error. The waveform strip underneath
   (ElevenLabs' mirrored bars, stolen via openbot)
   shows the live mic while listening.
   ———————————————————————————————————————————————— */

import { useEffect, useState } from "react";
import { Mic, MicOff } from "lucide-react";
import { useFotra } from "@/lib/fotra/store";
import { voiceInput, speechInputSupported } from "@/lib/fotra/voice";
import { interruptAndListen } from "@/lib/fotra/agent";
import { Mascot } from "./Mascot";
import { LiveWaveform } from "./live-waveform";

/* the press behavior shared by the stage hero and the composer's mini control */
function useMascotPress() {
  const phase = useFotra((s) => s.phase);
  const persona = useFotra((s) => s.persona);
  const nm = persona.name.toLowerCase();
  const errored = phase === "error";
  const label =
    phase === "listening"
      ? `${nm} is listening — tap to send`
      : phase === "speaking"
        ? `${nm} is speaking — tap to interrupt`
        : phase === "thinking"
          ? `${nm} is thinking — tap to interrupt`
          : phase === "working"
            ? `${nm} is working — tap to interrupt`
            : errored
              ? `${nm} hit an error — tap to dismiss`
              : `${nm} — hold or tap to talk`;

  function onPress() {
    const s = useFotra.getState();
    if (phase === "listening") {
      voiceInput.stop(true); // stop & send what was said
      return;
    }
    if (phase === "speaking" || phase === "thinking" || phase === "working") {
      interruptAndListen(); // barge-in: cut it off, open the mic
      return;
    }
    if (phase === "error") {
      s.clearError();
      return;
    }
    if (!speechInputSupported()) {
      s.setError(
        "No speech recognition in this browser.",
        "Chrome or Edge have it. Typing works everywhere — that's the equal path."
      );
      return;
    }
    void voiceInput.start();
  }

  return { phase, onPress, label, errored };
}

/** the interactive mascot as a button — any size, no waveform (composer mini, etc.) */
export function MascotButton({ size = 44 }: { size?: number }) {
  const { phase, onPress, label } = useMascotPress();
  const bloom = useFotra((s) => s.bloom);
  const [blooming, setBlooming] = useState(false);

  useEffect(() => {
    if (bloom === 0) return;
    setBlooming(true);
    const t = setTimeout(() => setBlooming(false), 660);
    return () => clearTimeout(t);
  }, [bloom]);

  return (
    <button
      type="button"
      aria-label={label}
      aria-pressed={phase === "listening"}
      onClick={onPress}
      className={`f-mascot-btn ${blooming ? "is-blooming" : ""}`}
    >
      <Mascot size={size} phase={phase} />
    </button>
  );
}

export function StageMascot({ size = 260 }: { size?: number }) {
  const { phase, onPress, label, errored } = useMascotPress();
  const bloom = useFotra((s) => s.bloom);
  const [blooming, setBlooming] = useState(false);
  const [micStream, setMicStream] = useState<MediaStream | null>(null);

  // persona change → one bloom pulse (Dots' identity beat)
  useEffect(() => {
    if (bloom === 0) return;
    setBlooming(true);
    const t = setTimeout(() => setBlooming(false), 660);
    return () => clearTimeout(t);
  }, [bloom]);

  // live mic stream for the waveform while listening
  useEffect(() => {
    if (phase === "listening") {
      const poll = setInterval(() => setMicStream(voiceInput.stream), 250);
      setMicStream(voiceInput.stream);
      return () => clearInterval(poll);
    }
    setMicStream(null);
  }, [phase]);

  return (
    <div className="flex flex-col items-center gap-5">
      <button
        type="button"
        aria-label={label}
        aria-pressed={phase === "listening"}
        onClick={onPress}
        className={`f-mascot-btn ${blooming ? "is-blooming" : ""}`}
      >
        <Mascot size={size} phase={phase} />
      </button>

      {/* the live waveform — mirrored bars while the mic is open, a breathing wave while it works */}
      <div className="f-wave-strip flex w-[min(240px,60vw)] items-center justify-center gap-2">
        {errored ? <MicOff size={13} className="shrink-0 text-danger" aria-hidden="true" /> : <Mic size={13} className="shrink-0 opacity-60" aria-hidden="true" />}
        <LiveWaveform stream={micStream ?? undefined} processing={phase === "thinking" || phase === "working"} height={26} />
      </div>
    </div>
  );
}
