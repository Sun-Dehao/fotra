"use client";

/* ————————————————————————————————————————————————
   FOTRA — the app shell v5: ONE COLUMN, NOTHING EXTRA
   The screen shows what the moment needs and nothing
   else:

   · idle      — the mascot, a line, the composer, a few
                 things to try. That's the whole app.
   · talking   — the thread, the composer.
   · working   — each tool brings its own live surface
                 into the thread (see Trail), and when it
                 drives a browser a window pops up so you
                 can watch (see BrowserStage).
   · done      — the work folds to a line; the window
                 tucks away.

   Everything else — sessions, files, routines, MCP,
   memory, settings — is one button or ⌘K away, never
   on screen uninvited.
   Multi-tab: the latest tab owns the conversation;
   others get read-only replay and a take-over.
   ———————————————————————————————————————————————— */

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, LayoutGroup, motion } from "framer-motion";
import { Command, PanelLeft, Settings2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Sheet, SheetContent, SheetDescription, SheetTitle } from "@/components/ui/sheet";
import { useFotra } from "@/lib/fotra/store";
import { wireVoice, stopEverything, reattachIfNeeded, wireAmbient, submitInput } from "@/lib/fotra/agent";
import { teardownCall } from "@/lib/fotra/voice-realtime";
import { voiceInput } from "@/lib/fotra/voice";
import { MascotButton } from "./mascot/StageMascot";
import { Mascot } from "./mascot/Mascot";
import { LiveWaveform } from "./mascot/live-waveform";
import { Thread } from "./Thread";
import { Composer, handleGlobalKeydown, handleGlobalKeyup } from "./Composer";
import { WidgetDock } from "./WidgetDock";
import { SettingsPanel } from "./SettingsPanel";
import { Onboarding } from "./Onboarding";
import { LeftRail } from "./LeftRail";
import { CommandPalette, openPalette } from "./CommandPalette";
import { BrowserStage } from "./BrowserStage";

const TAB_ID = `tab-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;

/* omp's entrance curve, shared with the CSS system */
const EASE = [0.16, 1, 0.3, 1] as const;
const WIDTH = { narrow: "max-w-[600px]", normal: "max-w-[736px]", wide: "max-w-[940px]" } as const;

export default function FotraApp() {
  const hydrated = useFotra((s) => s.hydrated);
  const onboarded = useFotra((s) => s.onboarded);
  const readOnly = useFotra((s) => s.readOnly);
  const hydrate = useFotra((s) => s.hydrate);
  const setReadOnly = useFotra((s) => s.setReadOnly);
  const persona = useFotra((s) => s.persona);
  const engine = useFotra((s) => s.settings.engine);
  const customModel = useFotra((s) => s.settings.custom.model);
  const ui = useFotra((s) => s.settings.ui);
  const phase = useFotra((s) => s.phase);
  const errorHint = useFotra((s) => s.errorHint);
  const statusLine = useFotra((s) => s.statusLine);
  const setSettingsOpen = useFotra((s) => s.setSettingsOpen);
  const widgets = useFotra((s) => s.widgets);
  const hasTurns = useFotra((s) => s.turns.length > 0);
  const stageDocked = useFotra((s) => s.stage.open && s.stage.size === "pip" && s.stage.frames.length > 0);

  const [libraryOpen, setLibraryOpen] = useState(false);

  // hydrate once; wire voice + ambient once; reattach to a live run; claim tab ownership
  useEffect(() => {
    hydrate();
    wireVoice();
    wireAmbient();
    void reattachIfNeeded();
    void settleBrain();

    // multi-tab: latest tab owns; others read-only with a take-over
    const bc = typeof BroadcastChannel !== "undefined" ? new BroadcastChannel("fotra-bus") : null;
    if (bc) {
      bc.onmessage = (e: MessageEvent) => {
        const msg = e.data as { t?: string; id?: string } | null;
        if (!msg || msg.id === TAB_ID) return;
        if (msg.t === "hello" && !useFotra.getState().readOnly) {
          bc.postMessage({ t: "owner", id: TAB_ID }); // I'm here — the newcomer goes read-only
        }
        if (msg.t === "owner") setReadOnly(true); // someone else owns the conversation
        if (msg.t === "takeover") setReadOnly(true);
        if (msg.t === "bye" && useFotra.getState().readOnly) {
          // the owner left — the oldest remaining tab takes over
          setReadOnly(false);
          void reattachIfNeeded();
        }
      };
      bc.postMessage({ t: "hello", id: TAB_ID });
      const bye = () => bc.postMessage({ t: "bye", id: TAB_ID });
      window.addEventListener("pagehide", bye);
      return () => {
        bye();
        window.removeEventListener("pagehide", bye);
        bc.close();
      };
    }
  }, [hydrate, setReadOnly]);

  // global keys: space = push-to-talk, esc = stop everything
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        const st = useFotra.getState();
        // esc peels one layer at a time: the wide browser window first, then the run
        if (st.stage.open && st.stage.size === "wide") {
          st.setStage({ size: "pip" });
          return;
        }
        stopEverything();
        setSettingsOpen(false);
        setLibraryOpen(false);
        return;
      }
      if (useFotra.getState().readOnly) return;
      handleGlobalKeydown(e);
    };
    const up = (e: KeyboardEvent) => handleGlobalKeyup(e);
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, [setSettingsOpen]);

  // cockpit events — the palette (and voice, one day) drives the shell through these
  useEffect(() => {
    const stop = () => stopEverything();
    const library = () => setLibraryOpen(true);
    window.addEventListener("fotra:stop", stop);
    window.addEventListener("fotra:rail-panel", library);
    window.addEventListener("fotra:toggle-thread", library);
    return () => {
      window.removeEventListener("fotra:stop", stop);
      window.removeEventListener("fotra:rail-panel", library);
      window.removeEventListener("fotra:toggle-thread", library);
    };
  }, []);

  // beforeunload: stop the mic + hang up any call cleanly
  useEffect(() => {
    const cleanup = () => {
      stopEverything();
      teardownCall();
    };
    window.addEventListener("beforeunload", cleanup);
    return () => window.removeEventListener("beforeunload", cleanup);
  }, []);

  if (!hydrated) {
    return (
      <main className="grid h-dvh place-items-center bg-paper">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, ease: EASE }}
          style={{ width: 120, height: 120, pointerEvents: "none" }}
          aria-hidden="true"
        >
          <Mascot size={120} phase="idle" decorative />
        </motion.div>
      </main>
    );
  }

  const idle = !hasTurns;
  const width = WIDTH[ui?.width ?? "normal"];
  const brainLabel =
    engine === "demo" ? "demo brain" : engine === "custom" ? customModel || "no model set" : engine === "provider" ? "providers.json" : "";

  return (
    <TooltipProvider delayDuration={350}>
      <main className="f-theme-swap relative flex h-dvh flex-col overflow-hidden bg-paper text-ink" data-density={ui?.density ?? "cozy"}>
        {!onboarded && <Onboarding />}
        <SettingsPanel />
        <CommandPalette />
        <BrowserStage />
        <div className="f-stage-wash" data-idle={idle} aria-hidden="true" />

        {/* read-only banner — another tab owns the conversation */}
        {readOnly && (
          <div className="f-fade z-30 flex items-center justify-between gap-3 bg-paper-2/90 px-4 py-2 sm:px-8">
            <p className="f-label !opacity-70">read-only — another tab owns the conversation</p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setReadOnly(false);
                if (typeof BroadcastChannel !== "undefined") {
                  new BroadcastChannel("fotra-bus").postMessage({ t: "takeover", id: TAB_ID });
                }
                void reattachIfNeeded();
              }}
              className="h-8 border-glow/50 text-glow hover:bg-glow/10"
            >
              take over
            </Button>
          </div>
        )}

        {/* the top bar — who you're talking to, and three quiet ways out */}
        <header className="relative z-30 flex items-center justify-between px-2.5 py-2 sm:px-4">
          <div className="flex items-center gap-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Open the library" onClick={() => setLibraryOpen(true)} className="f-rail-btn">
                  <PanelLeft size={16} />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom">threads · files · routines · tools · memory</TooltipContent>
            </Tooltip>
            <button
              type="button"
              onClick={() => setSettingsOpen(true)}
              className="flex min-h-[34px] items-center gap-2 rounded-full py-1 pl-1 pr-3 transition-colors hover:bg-paper-3/70"
              aria-label={`${persona.name} — persona and appearance`}
            >
              <Mascot size={26} showHalo={false} decorative />
              <span className="font-display text-sm font-semibold tracking-tight text-ink">{persona.name.toLowerCase()}</span>
            </button>
          </div>
          <div className="flex items-center gap-1">
            {brainLabel && (
              <button
                type="button"
                onClick={() => {
                  try {
                    localStorage.setItem("fotra.settings.tab", "brain");
                  } catch {
                    /* noop */
                  }
                  setSettingsOpen(true);
                }}
                className="f-brain-chip"
                data-demo={engine === "demo"}
                title={engine === "demo" ? "scripted, offline — connect a model for the real thing" : "the model answering you"}
              >
                {brainLabel}
                {engine === "demo" && <span className="text-glow"> · connect a model</span>}
              </button>
            )}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Command palette" onClick={() => openPalette()} className="f-rail-btn">
                  <Command size={15} />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom">everything · ⌘K</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Settings" onClick={() => setSettingsOpen(true)} className="f-rail-btn">
                  <Settings2 size={16} />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom">settings</TooltipContent>
            </Tooltip>
          </div>
        </header>

        {/* the library — everything the harness keeps, out of sight until asked for */}
        <Sheet open={libraryOpen} onOpenChange={setLibraryOpen}>
          <SheetContent side="left" className="w-[316px] gap-0 border-rule bg-paper-2/95 p-0 backdrop-blur-xl [&>button]:hidden" aria-label="Library">
            <SheetTitle className="sr-only">Library</SheetTitle>
            <SheetDescription className="sr-only">Threads, files, routines, connected tools and memory</SheetDescription>
            <LeftRail mobile onClose={() => setLibraryOpen(false)} />
          </SheetContent>
        </Sheet>

        {/* the one column */}
        <LayoutGroup>
          <div className="f-col relative z-10 flex min-h-0 flex-1 flex-col" data-stage={stageDocked}>
            {idle ? (
              <div className="flex min-h-0 flex-[1.15] flex-col items-center justify-end px-4 pb-7">
                <Hero />
              </div>
            ) : (
              <div className="min-h-0 flex-1">
                <Thread />
              </div>
            )}

            <motion.div layout="position" transition={{ duration: 0.5, ease: EASE }} className="relative z-20 px-3 pb-3 sm:px-6 sm:pb-5">
              <div className={`mx-auto ${width}`}>
                {/* an error says what broke, in place, and how to get past it */}
                <AnimatePresence>
                  {phase === "error" && (
                    <motion.div
                      key="error"
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 4 }}
                      transition={{ duration: 0.22, ease: EASE }}
                      className="mb-2 flex items-start justify-between gap-3 rounded-2xl border border-danger/40 bg-danger/5 px-4 py-3"
                      role="alert"
                    >
                      <div className="min-w-0">
                        <p className="text-sm leading-snug text-ink">{statusLine}</p>
                        {errorHint && <p className="mt-1 text-xs leading-relaxed text-dim">{errorHint}</p>}
                      </div>
                      <button type="button" onClick={() => useFotra.getState().clearError()} className="f-label shrink-0 rounded-full border border-rule px-2.5 py-1 !opacity-80 hover:border-dim/70">
                        dismiss
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* things it put on your screen — notes, a clock, a timer */}
                {widgets.length > 0 && (
                  <div className="f-scroll mb-2 flex gap-2 overflow-x-auto pb-1">
                    <WidgetDock />
                  </div>
                )}

                <Composer hero={idle} />
              </div>
            </motion.div>

            {idle && (
              <div className="flex min-h-0 flex-1 flex-col items-center px-4">
                <Suggestions />
              </div>
            )}
          </div>
        </LayoutGroup>
      </main>
    </TooltipProvider>
  );
}

/* ————————————————————————————————————————————————
   THE HERO — the idle screen is the mascot and a line.
   Press it (or hold space) to talk.
   ———————————————————————————————————————————————— */
function Hero() {
  const phase = useFotra((s) => s.phase);
  const name = useFotra((s) => s.persona.name);
  const greeting = useFotra((s) => s.settings.ui?.greeting ?? "");
  const liveCaption = useFotra((s) => s.liveCaption);
  const [micStream, setMicStream] = useState<MediaStream | null>(null);

  useEffect(() => {
    if (phase !== "listening") {
      setMicStream(null);
      return;
    }
    setMicStream(voiceInput.stream);
    const poll = setInterval(() => setMicStream(voiceInput.stream), 250);
    return () => clearInterval(poll);
  }, [phase]);

  const line = useMemo(() => {
    if (greeting) return greeting;
    const h = new Date().getHours();
    const tod = h < 5 ? "Still up" : h < 12 ? "Morning" : h < 17 ? "Afternoon" : h < 22 ? "Evening" : "Late one";
    return `${tod}. What are we doing?`;
    // the hour only matters when the idle screen mounts
     
  }, [greeting]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: EASE }}
      className="flex flex-col items-center gap-5 text-center"
    >
      <MascotButton size={132} />
      <div className="flex min-h-[3.4rem] flex-col items-center gap-1.5">
        {phase === "listening" ? (
          <>
            <div className="f-wave-strip w-[220px]">
              <LiveWaveform stream={micStream ?? undefined} height={26} />
            </div>
            <p className="max-w-[420px] text-sm text-ink-2">{liveCaption || "listening…"}</p>
          </>
        ) : (
          <>
            <h1 className="font-display text-[26px] font-semibold leading-tight tracking-tight text-ink sm:text-[30px]">{line}</h1>
            <p className="f-label !opacity-45">
              {name.toLowerCase()} · tap the face or hold space to talk
            </p>
          </>
        )}
      </div>
    </motion.div>
  );
}

/* a few things to try — the agent can rewrite these for you ("put my usual asks on the home screen") */
const TRY_DEMO = ["Find me a hotel in Tokyo", "Compare Kyoto and Tokyo", "Go compact and wear the ice coat", "Run some code: the first 20 primes", "Remember that I take my coffee black"];
const TRY_LIVE = ["Find me a hotel in Lisbon for this weekend", "What happened in AI this week?", "Be blunter from now on", "Every morning at 8, brief me on the news", "Plot the first 30 Fibonacci numbers"];

function Suggestions() {
  const custom = useFotra((s) => s.settings.ui?.suggestions ?? []);
  const engine = useFotra((s) => s.settings.engine);
  const readOnly = useFotra((s) => s.readOnly);
  const list = custom.length > 0 ? custom : engine === "demo" ? TRY_DEMO : TRY_LIVE;
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6, delay: 0.15 }}
      className="flex max-w-[640px] flex-wrap justify-center gap-2 pt-1"
    >
      {list.map((text, i) => (
        <motion.button
          key={text}
          type="button"
          disabled={readOnly}
          onClick={() => submitInput(text, "text")}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: EASE, delay: 0.2 + i * 0.05 }}
          className="f-try"
        >
          {text}
        </motion.button>
      ))}
    </motion.div>
  );
}

/** on boot: never sit on a brain this install can't run. If the built-in one is absent, use a wired
    provider; if nothing is wired, fall to the demo brain and say so in the header. */
async function settleBrain(): Promise<void> {
  try {
    const res = await fetch("/api/brain");
    if (!res.ok) return;
    const b = (await res.json()) as { builtin?: boolean; provider?: boolean };
    const s = useFotra.getState();
    if (s.settings.engine === "fotra" && !b.builtin) {
      s.updateSettings({ engine: b.provider ? "provider" : "demo" });
    }
  } catch {
    /* offline — the run itself will say what's missing */
  }
}
