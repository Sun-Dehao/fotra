"use client";

/* ————————————————————————————————————————————————
   THE COMMAND PALETTE — ⌘K, the whole cockpit in one
   keystroke. No mascot-first assistant on the board
   has one; fotra does. Every action the app can take,
   typeable: sessions, faces, coats, themes, voice,
   brains, panels, export. It reads the same store the
   voice path writes — one brain, many hands.
   ———————————————————————————————————————————————— */

import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import {
  Bot,
  CalendarClock,
  CircleDot,
  Download,
  FileText,
  History,
  MessagesSquare,
  Mic,
  Moon,
  Phone,
  PhoneOff,
  Plug,
  Plus,
  Settings2,
  Sparkles,
  Square,
  Sun,
  Trash2,
  Zap,
} from "lucide-react";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut,
} from "@/components/ui/command";
import { useFotra } from "@/lib/fotra/store";
import { callState, endCall, startCall } from "@/lib/fotra/voice-realtime";
import { MASCOT_COATS, MASCOT_SKINS } from "./mascot/Mascot";
import type { EngineMode, ThemeMode } from "@/lib/fotra/types";

interface SessionRow {
  id: string;
  title: string;
  turnCount: number;
  lastAt: string;
}

/** open it from anywhere — header buttons, voice, the works */
export function openPalette() {
  window.dispatchEvent(new CustomEvent("fotra:palette"));
}

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const [sessions, setSessions] = useState<SessionRow[] | null>(null);

  const readOnly = useFotra((s) => s.readOnly);
  const sessionId = useFotra((s) => s.settings.sessionId);
  const engine = useFotra((s) => s.settings.engine);
  const voiceMode = useFotra((s) => s.settings.voiceMode);
  const mode = useFotra((s) => s.settings.mode);
  const aura = useFotra((s) => s.persona.aura);
  const mascot = useFotra((s) => s.persona.mascot);
  const coat = useFotra((s) => s.persona.coat);
  const turns = useFotra((s) => s.turns);

  const setMode = useFotra((s) => s.setMode);
  const setCoat = useFotra((s) => s.setCoat);
  const patchPersona = useFotra((s) => s.patchPersona);
  const updateSettings = useFotra((s) => s.updateSettings);
  const switchSession = useFotra((s) => s.switchSession);
  const newSession = useFotra((s) => s.newSession);
  const setSettingsOpen = useFotra((s) => s.setSettingsOpen);
  const setMemoryOpen = useFotra((s) => s.setMemoryOpen);

  // ⌘K / Ctrl+K + the fotra:palette event
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((o) => !o);
      }
    };
    const onEvt = () => setOpen(true);
    window.addEventListener("keydown", onKey);
    window.addEventListener("fotra:palette", onEvt);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("fotra:palette", onEvt);
    };
  }, []);

  // sessions load when the palette opens
  useEffect(() => {
    if (!open) return;
    let alive = true;
    void fetch("/api/sessions")
      .then((r) => (r.ok ? r.json() : null))
      .then((j: { sessions?: SessionRow[] } | null) => {
        if (alive) setSessions(j?.sessions ?? []);
      })
      .catch(() => setSessions([]));
    return () => {
      alive = false;
    };
  }, [open]);

  const close = useCallback(() => setOpen(false), []);

  function exportThread() {
    close();
    if (sessionId) {
      window.open(`/api/session?id=${sessionId}&export=md`, "_blank", "noopener");
      toast.success("thread exported", { description: "the full server log, as markdown" });
      return;
    }
    const name = useFotra.getState().persona.name;
    const md = turns.map((t) => `${t.role === "user" ? "**you**" : `**${name}**`}: ${t.text}`).join("\n\n");
    const blob = new Blob([`# fotra thread\n\n${md || "(empty)"}\n`], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "fotra-thread.md";
    a.click();
    URL.revokeObjectURL(url);
    toast.success("thread exported", { description: "the visible thread, as markdown" });
  }

  function openRailPanel(panel: "files" | "routines" | "mcp") {
    close();
    window.dispatchEvent(new CustomEvent("fotra:rail-panel", { detail: panel }));
  }

  const call = callState();
  const onCall = call.status === "active" || call.status === "connecting";

  const ENGINE_LABEL: Record<EngineMode, string> = {
    fotra: "fotra brain — server harness, zero keys",
    custom: "your model — any OpenAI-compatible endpoint",
    provider: "providers.json — server-side roles",
    demo: "demo brain — offline, scripted, alive",
  };

  return (
    <CommandDialog
      open={open}
      onOpenChange={setOpen}
      title="fotra command palette"
      description="Everything the cockpit can do — type it"
      className="sm:max-w-[520px]"
    >
      <CommandInput placeholder="type a command — faces, coats, sessions, brains…" />
      <CommandList className="max-h-[420px]">
        <CommandEmpty>nothing matches — esc to leave</CommandEmpty>

        <CommandGroup heading="thread">
          <CommandItem onSelect={() => { close(); newSession(); }} disabled={readOnly} value="new thread new session">
            <Plus />
            new thread
            <CommandShortcut>fresh session</CommandShortcut>
          </CommandItem>
          <CommandItem onSelect={exportThread} value="export thread markdown download">
            <Download />
            export thread
            <CommandShortcut>.md</CommandShortcut>
          </CommandItem>
          <CommandItem onSelect={() => { close(); openRailPanel("files"); }} value="workspace files">
            <FileText />
            workspace files
          </CommandItem>
          <CommandItem onSelect={() => { close(); openRailPanel("routines"); }} value="routines schedule">
            <CalendarClock />
            routines
          </CommandItem>
          <CommandItem onSelect={() => { close(); openRailPanel("mcp"); }} value="mcp tools connect">
            <Plug />
            mcp servers
          </CommandItem>
          <CommandItem onSelect={() => { close(); if (turns.length && confirm("Clear the visible thread? The server log and memory stay.")) { useFotra.getState().resetThread(); toast.success("thread cleared"); } }} disabled={readOnly || turns.length === 0} value="clear thread reset">
            <Trash2 />
            clear the visible thread
          </CommandItem>
        </CommandGroup>

        {sessions && sessions.length > 0 && (
          <>
            <CommandSeparator />
            <CommandGroup heading="jump to a session">
              {sessions.slice(0, 8).map((s) => (
                <CommandItem
                  key={s.id}
                  value={`session ${s.title}`}
                  disabled={readOnly}
                  onSelect={() => {
                    close();
                    if (s.id !== sessionId) void switchSession(s.id);
                  }}
                  className={s.id === sessionId ? "data-[selected=true]:bg-glow/10" : ""}
                >
                  <History />
                  <span className="min-w-0 flex-1 truncate">{s.title}</span>
                  <CommandShortcut>{s.turnCount} turns{s.id === sessionId ? " · current" : ""}</CommandShortcut>
                </CommandItem>
              ))}
            </CommandGroup>
          </>
        )}

        <CommandSeparator />
        <CommandGroup heading="appearance">
          <CommandItem
            value="light mode dark mode theme canvas"
            onSelect={() => { close(); const next: ThemeMode = mode === "dark" ? "light" : "dark"; setMode(next); toast.success(`${next} mode`, { description: next === "light" ? "ink on paper — the same coat in daylight" : "the native canvas — phosphor in the dark" }); }}
          >
            {mode === "dark" ? <Sun /> : <Moon />}
            {mode === "dark" ? "light mode" : "dark mode"}
            <CommandShortcut>day / night</CommandShortcut>
          </CommandItem>
          <CommandItem
            value={`aura halo ${aura} ring calm pulse spark`}
            onSelect={() => { close(); const order = ["calm", "pulse", "spark"] as const; const next = order[(order.indexOf(aura) + 1) % order.length]; patchPersona({ aura: next }); toast.success(`the ${next} halo`, { description: next === "calm" ? "a slow breath" : next === "pulse" ? "a heartbeat" : "an electric flicker" }); }}
          >
            <Sparkles />
            the {aura === "calm" ? "pulse" : aura === "pulse" ? "spark" : "calm"} halo — switch the aura
          </CommandItem>
          {MASCOT_SKINS.map((sk) => (
            <CommandItem
              key={sk.id}
              value={`wear the ${sk.label} face mascot ${sk.id}`}
              disabled={mascot === sk.id}
              onSelect={() => { close(); patchPersona({ mascot: sk.id }); toast.success(`wearing the ${sk.label} face`); }}
            >
              <CircleDot />
              wear the {sk.label} face
              <CommandShortcut>{sk.note.split(" — ")[1] ?? ""}</CommandShortcut>
            </CommandItem>
          ))}
          {MASCOT_COATS.map((c) => (
            <CommandItem
              key={c.id}
              value={`the ${c.label} coat — reskins everything · theme accent ${c.id}`}
              disabled={coat === c.id}
              onSelect={() => { close(); setCoat(c.id); toast.success(`the ${c.label} coat`, { description: "one skin — the accent and the mascot re-skin together" }); }}
            >
              <Sparkles />
              the {c.label} coat
            </CommandItem>
          ))}
        </CommandGroup>

        <CommandSeparator />
        <CommandGroup heading="voice">
          {onCall ? (
            <CommandItem value="end call hang up realtime" onSelect={() => { close(); void endCall(); toast("call ended"); }}>
              <PhoneOff />
              end the call
            </CommandItem>
          ) : (
            <CommandItem value="start call realtime webrtc phone" onSelect={() => { close(); void startCall(); }}>
              <Phone />
              start a realtime call
              <CommandShortcut>webrtc</CommandShortcut>
            </CommandItem>
          )}
          <CommandItem value="push to talk hold space mic" onSelect={() => { close(); toast("hold space", { description: "the mic opens anywhere the input isn't focused" }); }}>
            <Mic />
            how do I just talk?
            <CommandShortcut>hold space</CommandShortcut>
          </CommandItem>
          <CommandItem
            value="voice mode browser realtime switch"
            onSelect={() => { close(); const next = voiceMode === "browser" ? "realtime" : "browser"; updateSettings({ voiceMode: next }); toast.success(`${next === "browser" ? "browser voice — zero keys" : "realtime calls — needs a server key"}`); }}
          >
            {voiceMode === "browser" ? <Phone /> : <Mic />}
            switch to {voiceMode === "browser" ? "realtime calls" : "browser voice"}
          </CommandItem>
        </CommandGroup>

        <CommandSeparator />
        <CommandGroup heading="brain">
          {(Object.keys(ENGINE_LABEL) as EngineMode[]).map((e) => (
            <CommandItem
              key={e}
              value={`engine ${ENGINE_LABEL[e]}`}
              disabled={engine === e}
              onSelect={() => { close(); updateSettings({ engine: e }); toast.success(`${e === "fotra" ? "the fotra brain" : e === "demo" ? "the demo brain" : e === "custom" ? "your model" : "providers.json"} — same harness, same tools`); }}
            >
              <Bot />
              {ENGINE_LABEL[e]}
              {engine === e && <CommandShortcut>active</CommandShortcut>}
            </CommandItem>
          ))}
        </CommandGroup>

        <CommandSeparator />
        <CommandGroup heading="cockpit">
          <CommandItem value="settings preferences" onSelect={() => { close(); setSettingsOpen(true); }}>
            <Settings2 />
            settings
          </CommandItem>
          <CommandItem value="memory what it knows" onSelect={() => { close(); setMemoryOpen(true); }}>
            <Zap />
            memory
          </CommandItem>
          <CommandItem value="transcript thread panel" onSelect={() => { close(); window.dispatchEvent(new CustomEvent("fotra:toggle-thread")); }}>
            <MessagesSquare />
            toggle the transcript
          </CommandItem>
          <CommandItem value="stop everything abort esc" onSelect={() => { close(); window.dispatchEvent(new CustomEvent("fotra:stop")); }}>
            <Square />
            stop everything
            <CommandShortcut>esc</CommandShortcut>
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
