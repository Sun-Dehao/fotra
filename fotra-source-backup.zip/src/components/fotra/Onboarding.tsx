"use client";

/* ————————————————————————————————————————————————
   ONBOARDING — thirty seconds, then straight in
   Pick a coat (the whole skin — accent, mascot,
   canvas tint in one), pick a canvas (dark or
   light), then talk. Mic permission is asked on
   the first orb press — never on load.
   ———————————————————————————————————————————————— */

import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useFotra } from "@/lib/fotra/store";
import type { ThemeMode } from "@/lib/fotra/types";
import { MASCOT_COATS } from "./mascot/Mascot";
import { Mascot } from "./mascot/Mascot";

const EASE = [0.16, 1, 0.3, 1] as const;

const COAT_NOTES: Record<string, string> = {
  verdant: "phosphor green · the signature",
  ember: "warm red · the night shift",
  iris: "violet pink · the soft one",
  ice: "glacier blue · the cool head",
  rose: "petal red · the warm one",
  mono: "graphite · the purist",
};

export function Onboarding() {
  const coat = useFotra((s) => s.persona.coat);
  const mode = useFotra((s) => s.settings.mode);
  const setCoat = useFotra((s) => s.setCoat);
  const setMode = useFotra((s) => s.setMode);
  const setOnboarded = useFotra((s) => s.setOnboarded);
  const setSettingsOpen = useFotra((s) => s.setSettingsOpen);
  const [step, setStep] = useState(0);

  return (
    <div className="fixed inset-0 z-[60] grid place-items-center overflow-y-auto bg-paper px-6 py-10 f-fade" role="dialog" aria-modal="true" aria-label="Welcome">
      {step === 0 ? (
        <motion.div
          key="step-0"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: EASE }}
          className="w-full max-w-lg text-center"
        >
          <h1 className="font-display text-3xl font-semibold tracking-tight text-ink">fotra</h1>
          <p className="mt-3 leading-relaxed text-dim">
            An agent that shows its work while it happens — the search, the page, the browser it&apos;s
            driving — then gets out of the way. Talk to it or type.
          </p>
          <p className="f-label !opacity-70 mb-4 mt-8">pick its coat — one skin, the whole app follows</p>
          <div className="grid grid-cols-3 gap-3" role="radiogroup" aria-label="Coat">
            {MASCOT_COATS.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setCoat(c.id)}
                aria-pressed={coat === c.id}
                className={`group rounded-xl border p-4 transition-all ${
                  coat === c.id ? "border-glow/70 bg-glow/5" : "border-rule hover:border-dim/60"
                }`}
              >
                <span className="mx-auto block w-fit transition-transform group-hover:scale-105">
                  <Mascot size={56} skin="orb" coat={c.id} showFace={false} showHalo={coat === c.id} phase="idle" decorative />
                </span>
                <span className="mt-2.5 block font-display font-semibold capitalize text-ink">{c.label}</span>
                <span className="mt-0.5 block text-xs text-dim">{COAT_NOTES[c.id] ?? ""}</span>
              </button>
            ))}
          </div>
          <p className="f-label !opacity-70 mt-6 mb-3">and the canvas</p>
          <div className="mx-auto grid max-w-[280px] grid-cols-2 gap-3" role="radiogroup" aria-label="Mode">
            {(["dark", "light"] as ThemeMode[]).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMode(m)}
                aria-pressed={mode === m}
                className={`rounded-lg border px-3 py-2 text-sm transition-colors ${
                  mode === m ? "border-glow/70 bg-glow/5 text-ink" : "border-rule text-ink-2 hover:border-dim/60"
                }`}
              >
                {m === "dark" ? "night — native" : "day — paper"}
              </button>
            ))}
          </div>
          <Button
            type="button"
            onClick={() => setStep(1)}
            className="mt-8 min-h-[44px] rounded-full bg-glow px-6 text-sm font-semibold text-glow-ink hover:brightness-110"
          >
            continue <ArrowRight size={15} />
          </Button>
        </motion.div>
      ) : (
        <motion.div
          key="step-1"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: EASE }}
          className="w-full max-w-md text-center"
        >
          <p className="f-label !opacity-70">last thing</p>
          <h2 className="font-display mt-3 text-2xl font-semibold leading-snug text-ink">
            Three things worth knowing.
          </h2>
          <p className="mt-4 leading-relaxed text-dim">
            It starts on a scripted demo brain so you can feel the whole thing with zero keys.
            Connect any OpenAI-compatible model in settings → brain and the same interface does
            it for real: web search, a browser you watch it drive, code, memory, routines.
          </p>
          <p className="mt-3 text-sm leading-relaxed text-dim">
            Hold <kbd className="f-data rounded border border-rule px-1.5 py-0.5 text-xs text-ink-2">space</kbd> or tap
            its face to talk; typing mid-run steers it instead of queueing. Tell it to change itself —
            “be blunter”, “go compact”, “wear the ice coat” — and “undo that” puts it back.{" "}
            <kbd className="f-data ml-1 rounded border border-rule px-1.5 py-0.5 text-xs text-ink-2">⌘K</kbd> is
            everything else.
          </p>
          <Button
            type="button"
            onClick={() => setOnboarded()}
            className="mt-8 min-h-[44px] rounded-full bg-glow px-8 text-sm font-semibold text-glow-ink hover:brightness-110"
          >
            begin <ArrowRight size={15} />
          </Button>
          <div>
            <button
              type="button"
              onClick={() => {
                try {
                  localStorage.setItem("fotra.settings.tab", "brain");
                } catch {
                  /* noop */
                }
                setOnboarded();
                setSettingsOpen(true);
              }}
              className="mt-4 text-xs text-dim underline-offset-4 hover:text-ink hover:underline"
            >
              connect a model first
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
}
