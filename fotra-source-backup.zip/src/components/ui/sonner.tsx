"use client"

import { useTheme } from "next-themes"
import { Toaster as Sonner, ToasterProps } from "sonner"

const Toaster = ({ ...props }: ToasterProps) => {
  const { theme = "system" } = useTheme()

  return (
    <Sonner
      theme={theme as ToasterProps["theme"]}
      className="toaster group"
      style={
        {
          "--normal-bg": "var(--f-paper-3)",
          "--normal-text": "var(--f-ink)",
          "--normal-border": "var(--f-rule)",
        } as React.CSSProperties
      }
      {...props}
    />
  )
}

export { Toaster }
