import { NextRequest, NextResponse } from "next/server";

/* ————————————————————————————————————————————————
   FOTRA — the front door (§6.1, Phase 0 auth)
   Single-user app, no accounts. Default: open on
   localhost. Exposed: set FOTRA_TOKEN —
     · /api mutations need the token (header or cookie)
     · origin/host CSRF check on every mutation
     · the app itself sits behind /unlock
     · comparisons are constant-time
   ———————————————————————————————————————————————— */

const MUTATION = new Set(["POST", "PUT", "PATCH", "DELETE"]);

/** constant-time compare (edge-safe — no node:crypto) */
function tokensMatch(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function tokenFrom(req: NextRequest): string {
  const header = req.headers.get("x-fotra-token");
  if (header) return header;
  const cookie = req.cookies.get("fotra_token")?.value ?? "";
  try {
    return decodeURIComponent(cookie);
  } catch {
    return cookie;
  }
}

export function middleware(req: NextRequest) {
  const expected = (process.env.FOTRA_TOKEN ?? "").trim();
  if (!expected) return NextResponse.next(); // open mode (localhost)

  const { pathname } = req.nextUrl;
  const isUnlock = pathname === "/unlock" || pathname.startsWith("/api/unlock");
  const hasToken = tokensMatch(tokenFrom(req), expected);

  if (isUnlock) {
    // an unlocked visitor hitting /unlock goes straight home
    if (hasToken && pathname === "/unlock") {
      return NextResponse.redirect(new URL("/", req.url));
    }
    return NextResponse.next();
  }

  if (!hasToken && !pathname.startsWith("/api/")) {
    // page gate → /unlock
    const url = new URL("/unlock", req.url);
    return NextResponse.redirect(url);
  }

  if (pathname.startsWith("/api/")) {
    if (!MUTATION.has(req.method)) return NextResponse.next(); // reads pass
    if (!hasToken) {
      return NextResponse.json({ error: "locked — POST the token to /api/unlock" }, { status: 401 });
    }
    // CSRF: mutations must come from this origin
    const origin = req.headers.get("origin");
    if (origin) {
      try {
        if (new URL(origin).host !== req.headers.get("host")) {
          return NextResponse.json({ error: "cross-origin mutation refused" }, { status: 403 });
        }
      } catch {
        return NextResponse.json({ error: "bad origin" }, { status: 403 });
      }
    }
    const res = NextResponse.next();
    res.headers.set("Cache-Control", "no-store");
    return res;
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
