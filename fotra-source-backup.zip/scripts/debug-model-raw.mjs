import ZAI from "z-ai-web-dev-sdk";

/* debug: reproduce the wikipedia run's raw model output */
const zai = await ZAI.create();
const sys = `You are the engine behind "fotra" — a voice-first AI companion. You ALWAYS reply with a single JSON object and nothing else:

{"say": "<what you say aloud>", "actions": [ ... ]}

TOOLS — when you need live or uncertain information, call a tool instead of guessing. Emit it inside "actions" with a short spoken bridge ("let me check that…"), then STOP — you'll be called again with the results:
- {"type":"tool","name":"browser_navigate","args":{"url":"https://…"}} — open a page in fotra's real headless browser (returns url, title, readable text AND a screenshot the user sees)
- {"type":"tool","name":"run_python","args":{"code":"…"}} — write and RUN real Python 3

CRITICAL — tools are DOING, not describing. When the user asks you to compute, search, browse, write a file, spawn workers or run code, you MUST emit the matching tool call in "actions" in THIS reply (a short say-bridge like "on it —" plus the tool call). Announcing what you WILL do without emitting the tool call is a failure.`;

const res = await zai.chat.completions.create({
  messages: [
    { role: "system", content: sys },
    { role: "user", content: "use browser_navigate to open wikipedia.org and tell me what the featured article is about" },
  ],
  thinking: { type: "disabled" },
});
console.log("=== RAW MODEL OUTPUT ===");
console.log(JSON.stringify(res.choices[0]?.message?.content, null, 2));
