#!/bin/bash
# FOTRA v5 E2E — THE COMPACTION PORT (stolen from oh-my-pi, proven deterministic)
# Tier 1 prune (old tool results elided outside the protect window)
# Tier 2 compact (handoff summary splices over the covered prefix, once per run)
# + no-false-positive control run at the default window.
# Usage: bash scripts/e2e-v5.sh [base_url]      (mock brain auto-started on 8788)
set -u
BASE="${1:-http://localhost:3000}"
MOCK_PORT=8788
MOCK="http://localhost:$MOCK_PORT/v1"
PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  ✓ $1"; }
bad()  { FAIL=$((FAIL+1)); echo "  ✗ $1"; }
# say events stream in fragments — join all "text" deltas before any phrase assertion
says() { echo "$1" | grep -o '"text":"[^"]*"' | sed 's/^"text":"//;s/"$//' | tr -d '\n'; }
PERSONA='"persona":{"name":"fotra","tagline":"y","aura":"verdant","voiceURI":null,"voiceRate":1,"voicePitch":1}'

echo "—— fotra v5 E2E (the oh-my-pi compaction port) ——"

# — boot the mock brain (deterministic model) —
node /home/z/my-project/scripts/mock-brain.mjs $MOCK_PORT >/tmp/mock-v5.log 2>&1 &
MOCK_PID=$!
sleep 1
curl -s -o /dev/null -m 5 "http://localhost:$MOCK_PORT/v1/chat/completions" -X POST -H "Content-Type: application/json" -d '{"messages":[{"role":"user","content":"ping"}],"stream":false}' && ok "mock brain up on :$MOCK_PORT" || bad "mock brain did not boot"
CUSTOM="\"custom\":{\"baseUrl\":\"$MOCK\",\"apiKey\":\"k\",\"model\":\"mock\",\"temperature\":0.7}"

run() { curl -s -N -X POST "$BASE/api/run" -H "Content-Type: application/json" -d "$1" -m 300; }

# ————— RUN A: small window (8000 tokens) → prune + compact must fire —————
echo "[A] chunk-dump load @ window 8000 — compaction forced"
OUT_A=$(run "{\"text\":\"run the chunk dump load scenario\",\"userTurnId\":\"c5-u1\",\"assistantTurnId\":\"c5-a1\",\"history\":[],$PERSONA,\"brain\":\"custom\",$CUSTOM,\"contextWindow\":8000}")

echo "$OUT_A" | grep -q '"name":"compact"' && ok "compact event fired (tier 2)" || bad "no compact event"
COMPACT_COUNT=$(echo "$OUT_A" | grep -o '"name":"compact"' | wc -l)
[ "$COMPACT_COUNT" -eq 1 ] && ok "compacted exactly once (no spiral)" || bad "compact fired $COMPACT_COUNT times"
echo "$OUT_A" | grep -q '"name":"prune"' && ok "prune event fired (tier 1, post-compact pressure valve)" || bad "no prune event"
SAY_A=$(says "$OUT_A")
echo "$SAY_A" | grep -q 'compaction held' && ok "run completed cleanly after compaction" || bad "run did not reach the final say"
echo "$OUT_A" | grep -q '"type":"error"' && bad "run errored" || ok "zero error events"
echo "$OUT_A" | grep -o '"summary":"context compacted[^"]*"' | head -1 | grep -q "handoff summary kept" && ok "compact summary reported the handoff" || bad "compact summary line missing"
PRUNED_MSGS=$(echo "$OUT_A" | grep -c "Older tool output elided" || true)
CELL_SAYS=$(echo "$SAY_A" | grep -o 'Chunk [0-9] landed' | wc -l)
[ "$CELL_SAYS" -ge 6 ] && ok "the cell counter survived context replacement ($CELL_SAYS cell bridges seen)" || bad "cells lost mid-run (only $CELL_SAYS bridges)"

SID_A=$(echo "$OUT_A" | grep -o '"sessionId":"[^"]*"' | head -1 | cut -d'"' -f4)
node -e "
const {PrismaClient} = require('@prisma/client');
const db = new PrismaClient();
db.session.findUnique({where:{id:'$SID_A'}}).then(s => {
  const good = s && s.summary && s.summary.includes('## Goal') && s.summaryUpTo && s.summaryUpTo.startsWith('run:');
  console.log(good ? 'SUMMARY-OK' : 'SUMMARY-BAD:' + JSON.stringify({summary: s?.summary?.slice(0,80), upTo: s?.summaryUpTo}));
  process.exit(good ? 0 : 1);
}).catch(e => { console.log('SUMMARY-BAD:' + e.message); process.exit(1); });
" && ok "session.summary persisted with the omp handoff shape (## Goal…)" || bad "session summary not persisted correctly"

# ————— RUN B: default window (131072) — zero compaction noise —————
echo "[B] same load @ default window — compaction must NOT fire"
OUT_B=$(run "{\"text\":\"run the chunk dump load scenario too\",\"userTurnId\":\"c5-u2\",\"assistantTurnId\":\"c5-a2\",\"history\":[],$PERSONA,\"brain\":\"custom\",$CUSTOM}")

echo "$OUT_B" | grep -q '"name":"compact"' && bad "compact fired at the default window (false positive)" || ok "no compact at the default window"
echo "$OUT_B" | grep -q '"name":"prune"' && bad "prune fired at the default window (false positive)" || ok "no prune at the default window"
says "$OUT_B" | grep -q 'compaction held' && ok "control run completed cleanly" || bad "control run did not complete"

kill $MOCK_PID 2>/dev/null
echo ""
echo "—— v5 compaction results: $PASS pass · $FAIL fail ——"
[ "$FAIL" -eq 0 ] && echo "ALL GREEN" || exit 1
