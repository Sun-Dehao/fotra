#!/usr/bin/env python3
"""Merge cover + body into the final Fotra report PDF (normalized to A4)."""
from pypdf import PdfReader, PdfWriter

A4_W, A4_H = 595.28, 841.89

def normalize(page):
    w, h = float(page.mediabox.width), float(page.mediabox.height)
    if abs(w - A4_W) > 0.1 or abs(h - A4_H) > 0.1:
        page.scale_to(A4_W, A4_H)
    return page

writer = PdfWriter()
writer.add_page(normalize(PdfReader('/home/z/my-project/download/fotra-cover.pdf').pages[0]))
for p in PdfReader('/home/z/my-project/download/fotra-body.pdf').pages:
    writer.add_page(normalize(p))
writer.add_metadata({
    '/Title': 'FOTRA - Research Report & Product Blueprint',
    '/Author': 'Z.ai',
    '/Creator': 'Z.ai',
    '/Subject': 'Research report and product blueprint for Fotra, a voice-first web AI assistant',
})
out = '/home/z/my-project/download/FOTRA-Research-Report-and-Product-Blueprint.pdf'
with open(out, 'wb') as f:
    writer.write(f)
print('merged ->', out, '| pages:', len(writer.pages))
