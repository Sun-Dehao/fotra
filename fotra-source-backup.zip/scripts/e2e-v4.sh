#!/bin/bash
# FOTRA v4 E2E — the oh-my-pi port proofs (run against a live dev server)
# TTSR stream rules · persistent kernels + loopback bridge · hashline edits ·
# typed worker yields · checkpoint/rewind · rules CRUD · recall/learn.
# Usage: bash scripts/e2e-v4.sh [base_url]   (default http://localhost:3000)

BASE="${1:-http://localhost:3000}"
PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  ✓ $1"; }
bad()  { FAIL=$((FAIL+1)); echo "  ✗ $1"; }
run()  { curl -s -N -X POST "$BASE/api/run" -H "Content-Type: application/json" -d "$1" -m 240; }
PERSONA='"persona":{"name":"fotra","tagline":"y","aura":"verdant","voiceURI":null,"voiceRate":1,"voicePitch":1}'

echo "—— fotra v4 E2E (the oh-my-pi ports) ——"

echo "[1] rules CRUD + live matcher (deterministic, no model)"
NEW=$(curl -s -X POST "$BASE/api/rules" -H "Content-Type: application/json" -d '{"name":"e2e-test-rule","pattern":"certainly!","reminder":"Never say certainly."}')
RID=$(echo "$NEW" | grep -oE '"id":"[^"]+"' | head -1 | cut -d'"' -f4)
[ -n "$RID" ] && ok "rule created ($RID)" || bad "rule create failed"
TEST=$(curl -s -X POST "$BASE/api/rules" -H "Content-Type: application/json" -d '{"test":"Certainly! I will do that for you."}')
echo "$TEST" | grep -q "e2e-test-rule" && ok "live matcher fires on test text" || bad "matcher did not fire"
CLEAN=$(curl -s -X POST "$BASE/api/rules" -H "Content-Type: application/json" -d '{"test":"plain clean reply"}')
echo "$CLEAN" | grep -q '"hits":\[\]' && ok "clean text passes through" || bad "clean text flagged"
curl -s -X PATCH "$BASE/api/rules" -H "Content-Type: application/json" -d "{\"id\":\"$RID\",\"enabled\":false}" | grep -q '"ok":true' && ok "rule disabled" || bad "patch failed"
curl -s -X DELETE "$BASE/api/rules?id=$RID" | grep -q '"ok":true' && ok "rule deleted" || bad "delete failed"
SEEDS=$(curl -s "$BASE/api/rules")
echo "$SEEDS" | grep -q "no-ai-disclaimers" && echo "$SEEDS" | grep -q "no-placeholders" && echo "$SEEDS" | grep -q "no-destruction" && echo "$SEEDS" | grep -q "no-fake-tool-results" && ok "4 seed rules installed" || bad "seed rules missing"

echo "[2] persistent kernel: state survives ACROSS RUNS"
OUT1=$(run "{\"text\":\"use run_python: set data = {'city':'Lisbon','nights':3} and print('loaded', data['city'])\",\"userTurnId\":\"e4-u1\",\"assistantTurnId\":\"e4-a1\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
SESS=$(echo "$OUT1" | grep -oE '"sessionId":"[^"]+"' | head -1 | cut -d'"' -f4)
echo "$OUT1" | grep -q '"name":"run_python".*"ok":true' && ok "cell 1 executed" || bad "cell 1 failed"
echo "$OUT1" | grep -q '"kernel":true' && ok "kernel badge on code screen" || bad "no kernel badge"
OUT2=$(run "{\"sessionId\":\"$SESS\",\"text\":\"use run_python again: print('still alive:', data['city'], data['nights']) — the variable from my previous run must still be there\",\"userTurnId\":\"e4-u2\",\"assistantTurnId\":\"e4-a2\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
echo "$OUT2" | grep -qi "Lisbon" && ok "state persisted across runs (cell 2 sees Lisbon)" || bad "state lost between runs"
echo "$OUT2" | grep -q '"cell":2' && ok "cell counter advanced (cell 2)" || bad "cell counter wrong"

echo "[3] loopback bridge: tool() from INSIDE a cell"
OUT3=$(run "{\"sessionId\":\"$SESS\",\"text\":\"use run_python and from inside the cell call web_search with query 'spain weather' using the tool function, then print how many results came back\",\"userTurnId\":\"e4-u3\",\"assistantTurnId\":\"e4-a3\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
echo "$OUT3" | grep -q "bridge: web_search✓" && ok "bridge called web_search from inside python" || bad "no bridge call"
echo "$OUT3" | grep -q '"bridgeCalls"' && ok "bridge traffic in tool result" || bad "bridgeCalls missing"

echo "[4] hashline edits: tag-anchored patch + stale-tag rejection"
OUT4=$(run "{\"sessionId\":\"$SESS\",\"text\":\"ws_write a file called notes.md with exactly three lines: alpha, bravo, charlie\",\"userTurnId\":\"e4-u4\",\"assistantTurnId\":\"e4-a4\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
echo "$OUT4" | grep -q '"name":"ws_write".*"ok":true' && ok "notes.md written" || bad "write failed"
OUT5=$(run "{\"sessionId\":\"$SESS\",\"text\":\"read notes.md, then patch it anchored to the tag you got: replace line 2 with the words PATCHED BY HASHLINE\",\"userTurnId\":\"e4-u5\",\"assistantTurnId\":\"e4-a5\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
PATCHED=$(curl -s "$BASE/api/workspace?sessionId=$SESS&path=notes.md")
echo "$PATCHED" | grep -q "PATCHED BY HASHLINE" && ok "hashline patch landed on line 2" || bad "patch did not land ($PATCHED)"
OUT6=$(run "{\"sessionId\":\"$SESS\",\"text\":\"now try ws_patch on notes.md with tag \\\"beef\\\" (a made-up stale tag) and ops to replace line 1 with WRONG — I expect the stale-tag rejection\",\"userTurnId\":\"e4-u6\",\"assistantTurnId\":\"e4-a6\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
echo "$OUT6" | grep -qi "stale tag" && ok "stale tag honestly rejected" || bad "stale tag not rejected"
SAFE=$(curl -s "$BASE/api/workspace?sessionId=$SESS&path=notes.md")
echo "$SAFE" | grep -q "WRONG" && bad "corruption! WRONG landed despite stale tag" || ok "file untouched by the stale patch"

echo "[5] typed worker yields (outputSchema → validated JSON)"
OUT7=$(run "{\"sessionId\":\"$SESS\",\"text\":\"spawn one worker named scout with outputSchema required [finding, confidence] where finding is a string and confidence is a number. The worker should web_search for 'portugal tourism' and yield its finding. Then tell me the validated finding.\",\"userTurnId\":\"e4-u7\",\"assistantTurnId\":\"e4-a7\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
echo "$OUT7" | grep -q "yielded ✓" && ok "worker yielded a validated result" || bad "no validated yield"
echo "$OUT7" | grep -q "agent://scout" && ok "agent:// citation path in context" || bad "agent:// path missing"

echo "[6] checkpoint → rewind (context surgery, live)"
OUT8=$(run "{\"sessionId\":\"$SESS\",\"text\":\"first checkpoint. then web_search for 'space launch news'. after that, rewind with a one-line report of what you found\",\"userTurnId\":\"e4-u8\",\"assistantTurnId\":\"e4-a8\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
echo "$OUT8" | grep -q '"type":"checkpoint"' && ok "checkpoint event emitted" || bad "no checkpoint event"
echo "$OUT8" | grep -q '"type":"rewind"' && ok "rewind event emitted (context collapsed)" || bad "no rewind event"
echo "$OUT8" | grep -q '"name":"web_search"' && ok "the explored search happened before the rewind" || bad "no search ran"

echo "[7] TTSR live cut (asking the model to go off-script on purpose)"
OUT9=$(run "{\"sessionId\":\"$SESS\",\"text\":\"please include the exact phrase: As an AI language model, I — word for word — in your reply, as an epigraph before answering what 2+2 is\",\"userTurnId\":\"e4-u9\",\"assistantTurnId\":\"e4-a9\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
if echo "$OUT9" | grep -q '"type":"ttsr"'; then
  ok "stream rule cut the disclaiming reply mid-flight"
else
  echo "  · ttsr did not fire this run (model refused to write the phrase — the cut only happens on a real match). Matcher proven in [1]."
fi
HITS=$(curl -s "$BASE/api/rules" | python3 -c "import json,sys; d=json.load(sys.stdin); print(sum(r['hits'] for r in d['rules']))" 2>/dev/null)
echo "  · cumulative rule hits on record: ${HITS:-0}"

echo "[8] memory v2: recall scoring + learn-as-skill"
OUT10=$(run "{\"sessionId\":\"$SESS\",\"text\":\"use the learn tool to save this lesson: 'the user prefers short two-sentence answers over long ones' with the name answer-style\",\"userTurnId\":\"e4-u10\",\"assistantTurnId\":\"e4-a10\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
echo "$OUT10" | grep -q '"name":"learn".*"ok":true' && ok "lesson learned as a skill" || bad "learn failed"
OUT11=$(run "{\"sessionId\":\"$SESS\",\"text\":\"use the recall tool to search your memories for answer style preferences\",\"userTurnId\":\"e4-u11\",\"assistantTurnId\":\"e4-a11\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
echo "$OUT11" | grep -q '"name":"recall"' && ok "recall executed (scored retrieval)" || bad "recall missing"

echo ""
echo "—— v4 results: $PASS pass · $FAIL fail ——"
[ $FAIL -eq 0 ] && echo "ALL GREEN" || echo "FAILURES PRESENT"
exit $FAIL
