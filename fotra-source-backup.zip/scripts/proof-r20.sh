#!/usr/bin/env bash
# fotra r20 proof — the six owner fixes, proven in the real UI:
#   [A] onboarding: the coat picker (6) replaces the world picker; pick ember → data-coat
#   [B] the coat drives the app accent (computed --f-glow changes with the coat)
#   [C] settings sheet: wider (640, not 384), old world group GONE, aura picker live-previews
#   [D] the halo works: data-aura on the stage mascot + animation per aura (calm/pulse/spark)
#   [E] voice runs and finishes: a demo reply SPEAKS and the run finalizes to ready
#       (the old bug: speechOut.speak was never called — runs hung in "speaking")
#   [F] enter steers a live run — no more cutting it off: steer button + steered chip
#       + run completes on its own; the next prompt sends without a stop
# Self-contained: boots the dev server + the mock brain, drives the real DOM.
set -u
cd /home/z/my-project
DL=/home/z/my-project/download/r20-shots
mkdir -p "$DL"
MOCK_PORT=8788

pkill -f "next dev" 2>/dev/null; pkill -f "next-server" 2>/dev/null; pkill -f "mock-brain" 2>/dev/null; sleep 1
nohup npx next dev -p 3000 > /tmp/fotra-dev.log 2>&1 &
for i in $(seq 1 90); do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null)
  [ "$code" = "200" ] && break; sleep 1
done
echo "server: $code"; [ "$code" = "200" ] || { tail -20 /tmp/fotra-dev.log; exit 1; }

node scripts/mock-brain.mjs $MOCK_PORT > /tmp/mock-brain-r20.log 2>&1 &
MOCK_PID=$!
sleep 1
kill -0 $MOCK_PID 2>/dev/null && echo "mock brain up on :$MOCK_PORT" || { echo "mock brain failed"; exit 1; }
cleanup() { kill $MOCK_PID 2>/dev/null; }
trap cleanup EXIT

PASS=0; FAIL=0
JQ() { agent-browser eval "$1" | sed 's/^"//; s/"$//; s/\\"/"/g'; }
CLICK() { agent-browser eval "$1" >/dev/null; }
TYPE() { agent-browser eval "(()=>{const i=document.querySelector('[cmdk-input]');if(!i)return false;const s=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;s.call(i,'$1');i.dispatchEvent(new Event('input',{bubbles:true}));return true})()" >/dev/null; }
SETMSG() { agent-browser eval "(()=>{const t=document.querySelector('[aria-label=\"Message\"]');if(!t)return false;const s=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;s.call(t,'$1');t.dispatchEvent(new Event('input',{bubbles:true}));t.focus();return true})()" >/dev/null; }
ESC() { agent-browser eval "document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}))" >/dev/null; agent-browser wait 700; }
ok() { echo "  ✓ $1"; PASS=$((PASS+1)); }
bad() { echo "  ✗ $1 — got: $2"; FAIL=$((FAIL+1)); }
CHK() { if echo "$2" | rg -q "$3"; then ok "$1"; else bad "$1" "$2"; fi; }

agent-browser close 2>/dev/null
agent-browser set viewport 1600 1000

echo "== A. fresh boot → onboarding: the coat picker =="
agent-browser open http://localhost:3000
agent-browser wait 1500
agent-browser storage local clear
agent-browser open http://localhost:3000
agent-browser wait 3000
R=$(JQ "JSON.stringify({onboard:!!document.querySelector('[aria-label=\"Welcome\"]'),coats:document.querySelectorAll('[aria-label=\"Coat\"] button').length,oldWorlds:document.querySelectorAll('[aria-label=\"Theme\"]').length,modeBtns:document.querySelectorAll('[aria-label=\"Mode\"] button').length})")
CHK "onboarding: 6 coats + canvas, no world picker" "$R" '"onboard":true,"coats":6,"oldWorlds":0,"modeBtns":2'
CLICK "(()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent.includes('ember')&&x.closest('[aria-label=\"Coat\"]'));if(b){b.click();return true}return false})()"
agent-browser wait 400
R=$(JQ "document.documentElement.dataset.coat")
CHK "picking the ember coat re-skins pre-begin (data-coat)" "$R" '^ember$'
agent-browser screenshot "$DL/01-onboarding-coats.png"

echo "== B. begin → the coat drives the whole app accent =="
CLICK "(()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent.includes('continue'));if(b){b.click();return true}return false})()"
agent-browser wait 600
CLICK "(()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent.includes('begin'));if(b){b.click();return true}return false})()"
GONE=""
for i in $(seq 1 10); do
  G=$(JQ "document.querySelector('[aria-label=\"Welcome\"]')===null?'1':'0'")
  [ "$G" = "1" ] && { GONE="yes"; break; }
  agent-browser wait 400
done
CHK "onboarding completed (overlay gone)" "$GONE" '^yes$'
R=$(JQ "JSON.stringify({coat:document.documentElement.dataset.coat,mode:document.documentElement.dataset.mode,glow:getComputedStyle(document.documentElement).getPropertyValue('--f-glow').trim(),halo:!!document.querySelector('section[aria-label=\"Fotra\"] .f-m-halo'),aura:document.querySelector('section[aria-label=\"Fotra\"] .f-mascot')?.dataset.aura})")
CHK "ember coat live: data-coat + accent + stage halo (calm)" "$R" '"coat":"ember","mode":"dark","glow":"oklch\(70% \.?17 28\)","halo":true,"aura":"calm"'
# switch to the verdant coat through the palette — the accent must follow
CLICK "(()=>{const b=document.querySelector('[aria-label=\"Command palette\"]');if(b){b.click();return true}return false})()"
agent-browser wait 700
TYPE "verdant coat"
agent-browser wait 400
agent-browser press Enter
agent-browser wait 1000
R=$(JQ "JSON.stringify({coat:document.documentElement.dataset.coat,glow:getComputedStyle(document.documentElement).getPropertyValue('--f-glow').trim()})")
CHK "palette coat switch → verdant accent follows" "$R" '"coat":"verdant","glow":"oklch\(78% \.?165 152\)"'
agent-browser screenshot "$DL/02-verdant-accent.png"

echo "== C. settings sheet — tabbed now, world-free, aura previews =="
CLICK "(()=>{const b=document.querySelector('[aria-label=\"Settings\"]');if(b){b.click();return true}return false})()"
OPEN=""
for i in $(seq 1 10); do
  O=$(JQ "document.querySelector('[data-slot=\"sheet-content\"]')!==null?'1':'0'")
  [ "$O" = "1" ] && { OPEN="yes"; break; }
  agent-browser wait 300
done
CHK "settings sheet opened" "$OPEN" '^yes$'
R=$(JQ "JSON.stringify({w:document.querySelector('[data-slot=\"sheet-content\"]').offsetWidth,tabs:document.querySelectorAll('[data-slot=\"sheet-content\"] [role=tab]').length,activeTab:document.querySelector('[data-slot=\"sheet-content\"] [role=tab][aria-selected=true]')?.getAttribute('data-tab'),panes:document.querySelectorAll('[data-slot=\"sheet-content\"] section').length,oldWorlds:document.querySelectorAll('[data-slot=\"sheet-content\"] [aria-label=\"Theme\"]').length,coats:document.querySelectorAll('[data-slot=\"sheet-content\"] [aria-label=\"Mascot coat\"] [role=radio]').length,auras:document.querySelectorAll('[data-slot=\"sheet-content\"] [aria-label=\"Aura\"] [role=radio]').length,auraPreviews:document.querySelectorAll('[data-slot=\"sheet-content\"] [aria-label=\"Aura\"] .f-mascot').length})")
CHK "sheet ~760px, 8 tabs, ONE section pane, no world group, 6 coats, 3 live aura previews" "$R" '"w":7[2-6][0-9],"tabs":8,"activeTab":"appearance","panes":1,"oldWorlds":0,"coats":6,"auras":3,"auraPreviews":3'
agent-browser screenshot "$DL/03-settings-sheet.png"

# tab switching + persistence: jump to brain, verify its pane renders alone, close, reopen → still brain
CLICK "(()=>{const b=document.querySelector('[data-tab=\"brain\"]');if(b){b.click();return true}return false})()"
agent-browser wait 400
R=$(JQ "JSON.stringify({active:document.querySelector('[data-slot=\"sheet-content\"] [role=tab][aria-selected=true]')?.getAttribute('data-tab'),brain:document.querySelector('[data-slot=\"sheet-content\"] section h3')?.textContent,engines:document.querySelectorAll('[data-slot=\"sheet-content\"] [aria-label=\"Engine mode\"] [role=radio]').length,appearanceGone:document.querySelectorAll('[data-slot=\"sheet-content\"] [aria-label=\"Aura\"]').length})")
CHK "brain tab: single pane, 4 engines, appearance unmounted" "$R" '"active":"brain","brain":"brain","engines":4,"appearanceGone":0'
CLICK "(()=>{const x=[...document.querySelectorAll('[data-slot=\"sheet-content\"] button')].find(b=>b.querySelector('.sr-only')?.textContent==='Close');if(x){x.click();return true}return false})()"
agent-browser wait 400
CLICK "(()=>{const b=document.querySelector('[aria-label=\"Settings\"]');if(b){b.click();return true}return false})()"
agent-browser wait 500
R=$(JQ "JSON.stringify({stayed:document.querySelector('[data-slot=\"sheet-content\"] [role=tab][aria-selected=true]')?.getAttribute('data-tab'),ls:localStorage.getItem('fotra.settings.tab')})")
CHK "reopening the sheet returns to the last section (brain), persisted" "$R" '"stayed":"brain","ls":"brain"'
CLICK "(()=>{const b=document.querySelector('[data-tab=\"appearance\"]');if(b){b.click();return true}return false})()"
agent-browser wait 300

echo "== D. the halo — aura types actually do something =="
CLICK "(()=>{const b=[...document.querySelectorAll('[data-slot=\"sheet-content\"] [aria-label=\"Aura\"] [role=radio]')].find(x=>x.textContent.includes('pulse'));if(b){b.click();return true}return false})()"
agent-browser wait 600
R=$(JQ "JSON.stringify({stage:document.querySelector('section[aria-label=\"Fotra\"] .f-mascot')?.dataset.aura,anim:getComputedStyle(document.querySelector('section[aria-label=\"Fotra\"] .f-m-halo')).animationName})")
CHK "aura=pulse → stage mascot data-aura + halo anim runs" "$R" '"stage":"pulse","anim":"f-halo-pulse"'
CLICK "(()=>{const b=[...document.querySelectorAll('[data-slot=\"sheet-content\"] [aria-label=\"Aura\"] [role=radio]')].find(x=>x.textContent.includes('spark'));if(b){b.click();return true}return false})()"
agent-browser wait 600
R=$(JQ "getComputedStyle(document.querySelector('section[aria-label=\"Fotra\"] .f-m-halo')).animationName")
CHK "aura=spark → f-halo-spark anim" "$R" '^f-halo-spark$'
CLICK "(()=>{const b=[...document.querySelectorAll('[data-slot=\"sheet-content\"] [aria-label=\"Aura\"] [role=radio]')].find(x=>x.textContent.includes('calm'));if(b){b.click();return true}return false})()"
agent-browser wait 400
ESC
agent-browser screenshot "$DL/04-halo-pulse.png"

echo "== E. voice: the demo reply SPEAKS and the run settles (the old hang, fixed) =="
# demo brain + no hands-free auto-mic (headless has no mic) — voiceOutput stays ON (the point)
CLICK "(()=>{const s=JSON.parse(localStorage.getItem('fotra.settings.v1')||'{}');s.engine='demo';s.handsFree=false;s.voiceOutput=true;localStorage.setItem('fotra.settings.v1',JSON.stringify(s));return true})()"
agent-browser open http://localhost:3000
agent-browser wait 3000
R=$(JQ "JSON.stringify({tts:typeof speechSynthesis,voiceOut:JSON.parse(localStorage.getItem('fotra.settings.v1')).voiceOutput})")
CHK "speechSynthesis present + voiceOutput on" "$R" '"tts":"object","voiceOut":true'
SETMSG "call yourself Nova and say hi"
agent-browser press Enter
agent-browser wait 1500
# wait for the run to finish speaking and settle — the bug was: never ready again
SETTLED=""
for i in $(seq 1 30); do
  PH=$(JQ "document.querySelector('[aria-live=\"polite\"]')?.textContent.trim()")
  if [ "$PH" = "ready" ]; then SETTLED="yes"; break; fi
  agent-browser wait 500
done
CHK "demo run finalized (status word back to ready — voice no longer hangs the run)" "$SETTLED" '^yes$'
R=$(JQ "document.querySelector('[aria-label=\"Persona and appearance settings\"] span.text-xs')?.textContent")
CHK "the reply landed (Nova rename path)" "$R" '^nova$'
agent-browser screenshot "$DL/05-voice-settled.png"

echo "== F. enter STEERS a live run — no more cutting it off =="
# wire the mock brain as the custom engine through settings storage
CLICK "(()=>{const s=JSON.parse(localStorage.getItem('fotra.settings.v1')||'{}');s.engine='custom';s.custom={baseUrl:'http://localhost:$MOCK_PORT',apiKey:'',model:'mock',temperature:0.1};localStorage.setItem('fotra.settings.v1',JSON.stringify(s));return true})()"
agent-browser open http://localhost:3000
agent-browser wait 3000
# start a long-enough run (the scheduler scenario runs real tools for seconds)
SETMSG "scheduler-proof — run the exact batch and report the arrival order"
agent-browser press Enter
RUNNING=""
for i in $(seq 1 20); do
  W=$(JQ "document.querySelector('[aria-label=\"Steer the current run\"]')!==null?'1':'0'")
  [ "$W" = "1" ] && { RUNNING="yes"; break; }
  agent-browser wait 300
done
CHK "while running, the send button becomes STEER (aria-label)" "$RUNNING" '^yes$'
# type + enter mid-run → steers, no stop needed
SETMSG "also mention the moon"
agent-browser press Enter
agent-browser wait 800
STEERED=""
for i in $(seq 1 20); do
  L=$(JQ "document.body.textContent.includes('steered into the run')?'1':'0'")
  [ "$L" = "1" ] && { STEERED="yes"; break; }
  agent-browser wait 400
done
CHK "the mid-run enter STEERED (queue label: steered into the run)" "$STEERED" '^yes$'
agent-browser screenshot "$DL/06-steered-chip.png"
# the run finishes on its own — no manual cut-off
DONE=""
for i in $(seq 1 40); do
  W=$(JQ "document.querySelector('[aria-label=\"Send message\"]')!==null?'1':'0'")
  [ "$W" = "1" ] && { DONE="yes"; break; }
  agent-browser wait 500
done
CHK "run completed on its own — composer back to send (no stop pressed)" "$DONE" '^yes$'
# and the next prompt sends fresh, no queue residue
Q=$(JQ "document.body.textContent.includes('queued behind the current run')?'1':'0'")
CHK "no residue: queue drained after the steered run" "$Q" '^0$'

echo ""
echo "——————————————————"
echo "r20 PROOF: $PASS pass · $FAIL fail"
[ "$FAIL" = "0" ] && echo "ALL GREEN" || exit 1
