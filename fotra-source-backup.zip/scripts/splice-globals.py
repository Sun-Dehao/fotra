#!/usr/bin/env python3
"""Splice globals.css: replace the old ORB + MASCOT blocks with the new
mascot-v2 + stage CSS, then clean reduced-motion + compact-orb leftovers."""

CSS = "/home/z/my-project/src/app/globals.css"
NEW = "/home/z/my-project/scripts/mascot-stage.css"

with open(CSS) as f:
    lines = f.readlines()
with open(NEW) as f:
    new_css = f.read()

# --- locate the old ORB banner start (the /* —— line above "THE ORB —") ---
start = None
for i, ln in enumerate(lines):
    if "THE ORB — fotra's single instrument" in ln:
        # backtrack to the banner opener "/* ———"
        j = i
        while j > 0 and not lines[j].lstrip().startswith("/*"):
            j -= 1
        start = j
        break
assert start is not None, "orb banner not found"

# --- locate the end: the f-m-orbit keyframes closing brace ---
end = None
for i, ln in enumerate(lines):
    if "@keyframes f-m-orbit" in ln:
        # find closing "}" at line start after this
        k = i
        while k < len(lines) and not lines[k].rstrip().endswith("}"):
            k += 1
        end = k
        break
assert end is not None, "f-m-orbit keyframes not found"

out = lines[:start] + [new_css, "\n"] + lines[end + 1 :]

# --- clean the reduced-motion block: drop dead .f-orb selectors ---
text = "".join(out)
text = text.replace(
    """  .f-orb-body,
  .f-orb-ring,
  .f-orb.is-blooming .f-orb-body,
  .f-orb.is-blooming .f-m-body,
  .f-mascot .f-m-body,
  .f-mascot .f-m-eye,
  .f-mascot .f-m-eyes,
  .f-m-orbit,
""",
    """  .f-mascot.is-blooming,
  .f-mascot .f-m-body,
  .f-mascot .f-m-eye,
  .f-mascot .f-m-eyes,
  .f-mascot .f-m-face,
""",
)

# --- remove the compact-orb block at the bottom (now dead) ---
import re

text = re.sub(
    r"\n/\* compact orb — the composer's state circle on mobile \*/\n.f-orb\.f-compact \{[^}]*\}\n(.|\n)*?@media \(max-width: 1023px\) \{\n  \.f-orb:not\(\.f-compact\) \{[^}]*\}\n(.|\n)*?\}\n",
    "\n",
    text,
)

with open(CSS, "w") as f:
    f.write(text)

# report
print(f"spliced: old block lines {start + 1}–{end + 1} replaced")
print(f"result: {len(text.splitlines())} lines")
print("dead .f-orb refs remaining:", text.count(".f-orb"))
