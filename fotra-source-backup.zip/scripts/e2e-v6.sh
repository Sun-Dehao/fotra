#!/bin/bash
# FOTRA v6 E2E — THE STEAL-BATCH PROOF (mock-brain edition)
# Proves the four new omp/openmuse steals end-to-end, through the REAL harness:
#   [1] openmuse identity injection — persona name + tagline reach the system prompt
#   [2] omp shared/exclusive scheduler — batch-order tool results (not completion order)
#   [3] omp steering interjection wrapper — mid-run user text lands in <system-notice>
#   [4] omp speakable segmenter — constants + sanitization (unit suite, 13 checks)
# Zero SDK-quota dependency: the mock plays the model, everything else is real.
# Usage: bash scripts/e2e-v6.sh [base_url]   (default http://localhost:3000)

BASE="${1:-http://localhost:3000}"
MOCK_PORT=8787
PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  ✓ $1"; }
bad()  { FAIL=$((FAIL+1)); echo "  ✗ $1"; }

node scripts/mock-brain.mjs $MOCK_PORT &>/tmp/mock-brain.log &
MOCK_PID=$!
sleep 1
kill -0 $MOCK_PID 2>/dev/null && ok "mock brain up on :$MOCK_PORT" || { bad "mock brain failed to boot"; cat /tmp/mock-brain.log; exit 1; }

run()  { curl -s -N -X POST "$BASE/api/run" -H "Content-Type: application/json" -d "$1" -m 120; }
# say events stream in fragments — join all "text" deltas before any phrase assertion
says() { echo "$1" | grep -o '"text":"[^"]*"' | sed 's/^"text":"//;s/"$//' | tr -d '\n'; }
cleanup() { kill $MOCK_PID 2>/dev/null; }
trap cleanup EXIT

# persona carrying BOTH a distinctive name and a marker tagline
VELORA='"persona":{"name":"Velora","tagline":"runs speedruns, SPEEDRUNS-TAGLINE-MARKER, never late","aura":"verdant","mascot":"dot","coat":"iris","voiceURI":null,"voiceRate":1,"voicePitch":1}'
CUSTOM="\"custom\":{\"baseUrl\":\"http://localhost:$MOCK_PORT\",\"apiKey\":\"\",\"model\":\"mock\",\"temperature\":0.1}"

echo "—— fotra v6 E2E · the steal-batch proof (mock model, real harness) ——"

echo "[1] openmuse identity injection: name + tagline reach the SYSTEM prompt"
OUT1=$(run "{\"text\":\"whoami-check — report your identity fields exactly as scripted\",\"userTurnId\":\"m6-u1\",\"assistantTurnId\":\"m6-a1\",\"history\":[],$VELORA,\"brain\":\"custom\",$CUSTOM}")
SAY1=$(says "$OUT1")
echo "$SAY1" | grep -q "name=Velora-OK" && ok "persona NAME injected into the system prompt" || bad "name not injected: $SAY1"
echo "$SAY1" | grep -q "tagline=TAGLINE-OK" && ok "persona TAGLINE injected (openmuse identity loop)" || bad "tagline not injected: $SAY1"
SESS=$(echo "$OUT1" | grep -oE '"sessionId":"[^"]+"' | head -1 | cut -d'"' -f4)

echo "[2] omp shared/exclusive scheduler: results in BATCH order, not completion order"
OUT2=$(run "{\"sessionId\":\"$SESS\",\"text\":\"scheduler-proof — run the exact batch and report the arrival order\",\"userTurnId\":\"m6-u2\",\"assistantTurnId\":\"m6-a2\",\"history\":[],$VELORA,\"brain\":\"custom\",$CUSTOM}")
SAY2=$(says "$OUT2")
echo "$SAY2" | grep -q "scheduler order: run_python,recall,run_js" && ok "tool results arrived in BATCH order (slow exclusive first — in-order emission held)" || bad "order wrong: $SAY2"
echo "$OUT2" | grep -q '"name":"run_python".*"ok":true' && ok "the slow exclusive cell executed for real" || bad "exclusive cell failed"
echo "$OUT2" | grep -q '"name":"recall".*"ok":true' && ok "the shared read executed" || bad "shared read failed"

echo "[3] omp steering wrapper: mid-run interjection lands in <system-notice>"
rm -f /tmp/m6-steer.out
( run "{\"sessionId\":\"$SESS\",\"text\":\"steering-wrapper-proof — start it\",\"userTurnId\":\"m6-u3\",\"assistantTurnId\":\"m6-a3\",\"history\":[],$VELORA,\"brain\":\"custom\",$CUSTOM}" > /tmp/m6-steer.out 2>&1 ) &
RUNBG=$!
RID=""
for i in $(seq 1 40); do
  RID=$(grep -oE '"runId":"[^"]+"' /tmp/m6-steer.out 2>/dev/null | head -1 | cut -d'"' -f4)
  [ -n "$RID" ] && break
  sleep 0.1
done
if [ -n "$RID" ]; then
  ok "runId captured mid-stream ($RID)"
  sleep 0.4   # inside the python sleep(1.5) window
  STEER=$(curl -s -X POST "$BASE/api/run/steer" -H "Content-Type: application/json" -d "{\"runId\":\"$RID\",\"text\":\"actually check the wrapper\"}")
  echo "$STEER" | grep -q '"steered":true' && ok "steer accepted while the tool ran" || bad "steer rejected: $STEER"
else
  bad "runId never appeared in the stream"
fi
wait $RUNBG
SAY3=$(says "$(cat /tmp/m6-steer.out)")
echo "$SAY3" | grep -q "WRAPPED-OK" && ok "interjection arrived WRAPPED in omp's system-notice priority frame" || bad "wrapper missing: $SAY3"

echo "[4] omp speakable segmenter: constants + sanitization + streaming takes"
SPK=$(node --experimental-strip-types scripts/test-speakable.mjs 2>/dev/null)
SPK_N=$(echo "$SPK" | grep -c "^PASS")
if [ "${SPK_N:-0}" -ge 13 ]; then
  ok "speakable unit suite: $SPK_N/13 (constants verbatim · fences swallowed · URLs→hosts · paths→basenames · first-take@12 · clause cuts · 280 cap)"
else
  bad "speakable unit suite: ${SPK_N:-0}/13"
  echo "$SPK" | grep "^FAIL"
fi

echo
echo "—— v6 steal-batch results: $PASS pass · $FAIL fail ——"
[ "$FAIL" -eq 0 ] && echo "ALL GREEN" || { echo "FAILURES PRESENT"; exit 1; }
