/* fotra mock brain — a deterministic Openai-compatible SSE server for E2E.
   It plays "the model": scripted protocol replies per scenario, streamed as
   real SSE deltas. The harness (tools, kernels, TTSR, yields) all run REAL —
   only the model's decisions are scripted. Run: node scripts/mock-brain.mjs 8787 */
import http from "node:http";

const port = Number(process.argv[2] ?? 8787);

/** route on the conversation: (lastUserMsg, fullText) → protocol reply string */
function script(messages) {
  const lastUser = [...messages].reverse().find((m) => m.role === "user")?.content ?? "";
  const all = messages.map((m) => m.content).join("\n");

  // — scenario: HANDOFF SUMMARY (compaction's summarizer call — replies with the
  //   omp-format structured summary, plain text, NOT protocol JSON) —
  if (all.includes("handoff summary for another LLM")) {
    return "## Goal\nRun the chunk-dump load scenario to force context compaction.\n\n## Progress\n\n### Done\n- [x] Started chunk-dump cells\n\n### In Progress\n- [ ] Remaining chunk cells\n\n## Key Decisions\n- **Continue cells after compaction**: the counter rides in the tool results.\n\n## Next Steps\n1. Keep running chunk cells until the final one\n2. Report completion\n\n## Critical Context\n- Cells print \"chunk dump N of 8\" — N is the live counter.";
  }

  // — scenario: CHUNK DUMP (forces compaction: 6 python cells × ~4.2k-char outputs;
  //   counter parsed from the LAST tool result so it survives context replacement) —
  if (all.includes("chunk dump")) {
    if (lastUser.includes("refused): budget")) {
      // the harness budgeted the tool out — end cleanly, the scenario still proved its point
      return JSON.stringify({ say: "Budget cut the chunks short — compaction still held.", actions: [] });
    }
    if (lastUser.includes("TOOL RESULT")) {
      const m = lastUser.match(/chunk dump (\d+) of 8/);
      const n = m ? Number(m[1]) : 0;
      if (n >= 8) {
        return JSON.stringify({ say: "All eight chunks processed — compaction held, the run stayed alive.", actions: [] });
      }
      return JSON.stringify({
        say: `Chunk ${n} landed. Running chunk ${n + 1}.`,
        actions: [{ type: "tool", name: "run_python", args: { code: `print("chunk dump ${n + 1} of 8 " + "x" * 4200)` } }],
      });
    }
    return JSON.stringify({
      say: "Running the chunk dump.",
      actions: [{ type: "tool", name: "run_python", args: { code: 'print("chunk dump 1 of 8 " + "x" * 4200)' } }],
    });
  }

  // TTSR retry: the injected interrupt is in context — the model behaves now
  if (all.includes("system-interrupt") || all.includes("[system reminder")) {
    if (all.includes("As an AI language model")) {
      return JSON.stringify({ say: "Two plus two is four.", actions: [] });
    }
  }

  // — scenario: kernel cell 1 —
  if (lastUser.includes("set data =")) {
    return JSON.stringify({
      say: "Loading it into the kernel.",
      actions: [{ type: "tool", name: "run_python", args: { code: "data = {'city': 'Lisbon', 'nights': 3}\nprint('loaded', data['city'])" } }],
    });
  }
  // — scenario: kernel cell 2 (after cell 1's result) —
  if (lastUser.includes("still alive") || (all.includes("still alive") && lastUser.includes("TOOL RESULT"))) {
    if (lastUser.includes("TOOL RESULT")) {
      return JSON.stringify({ say: "The kernel remembered.", actions: [] });
    }
    return JSON.stringify({
      say: "Checking the kernel's memory.",
      actions: [{ type: "tool", name: "run_python", args: { code: "print('still alive:', data['city'], data['nights'])" } }],
    });
  }
  // — scenario: loopback bridge (LOCAL tool — no SDK dependency) —
  if (lastUser.includes("from inside the cell") && (lastUser.includes("read") || lastUser.includes("file")) || (all.includes("loopback") && lastUser.includes("TOOL RESULT"))) {
    if (lastUser.includes("TOOL RESULT")) {
      return JSON.stringify({ say: "The bridge brought the file into the cell.", actions: [] });
    }
    return JSON.stringify({
      say: "Reading the file from inside the cell.",
      actions: [{ type: "tool", name: "run_python", args: { code: "content = read_file('notes.md')\nprint('bridge read', len(str(content)), 'chars')" } }],
    });
  }
  // — scenario: hashline write → read+patch → stale reject —
  if (lastUser.includes("alpha, bravo, charlie")) {
    if (lastUser.includes("TOOL RESULT")) return JSON.stringify({ say: "File's on disk.", actions: [] });
    return JSON.stringify({
      say: "Writing the file.",
      actions: [{ type: "tool", name: "ws_write", args: { path: "notes.md", content: "alpha\nbravo\ncharlie" } }],
    });
  }
  if (lastUser.includes("replace line 2")) {
    if (lastUser.includes("TOOL RESULT")) return JSON.stringify({ say: "Patched on the anchor.", actions: [] });
    return JSON.stringify({
      say: "Reading it, then patching on the tag.",
      actions: [
        { type: "tool", name: "ws_read", args: { path: "notes.md" } },
      ],
    });
  }
  if (lastUser.includes("TOOL RESULT for ws_read")) {
    // extract the REAL tag from the read result — exactly what a model does
    const m = lastUser.match(/"tag":"([0-9a-f]{4})"/) ?? all.match(/"tag":"([0-9a-f]{4})"/);
    const tag = m ? m[1] : undefined;
    return JSON.stringify({
      say: "Anchored to the tag.",
      actions: [{ type: "tool", name: "ws_patch", args: { path: "notes.md", ...(tag ? { tag } : {}), ops: [{ line: 2, replace: "PATCHED BY HASHLINE" }] } }],
    });
  }
  if (lastUser.includes("beef")) {
    if (lastUser.includes("TOOL RESULT")) return JSON.stringify({ say: "Rejected, as it should be.", actions: [] });
    return JSON.stringify({
      say: "Trying the stale tag.",
      actions: [{ type: "tool", name: "ws_patch", args: { path: "notes.md", tag: "beef", ops: [{ line: 1, replace: "WRONG" }] } }],
    });
  }
  // — scenario: the SCOUT worker (its own message stream) —
  if (all.includes("You are scout")) {
    if (lastUser.includes("TOOL RESULT")) {
      return JSON.stringify({
        say: "Computed it.",
        actions: [{ type: "tool", name: "yield", args: { finding: "25 times 4 is 100", confidence: 0.99 } }],
      });
    }
    return JSON.stringify({
      say: "Computing.",
      actions: [{ type: "tool", name: "run_python", args: { code: "print(25 * 4)" } }],
    });
  }
  // — scenario: typed yield (LOCAL compute — no SDK dependency) —
  if (lastUser.includes("outputSchema") || lastUser.includes("scout")) {
    if (lastUser.includes("WORKER RESULT")) {
      return JSON.stringify({ say: "The scout yielded validated JSON.", actions: [] });
    }
    return JSON.stringify({
      say: "Spawning the scout.",
      actions: [
        {
          type: "tool",
          name: "spawn_task",
          args: {
            name: "scout",
            task: "compute 25 times 4 using run_python and report the product",
            outputSchema: { required: ["finding", "confidence"], properties: { finding: "string", confidence: "number" } },
          },
        },
      ],
    });
  }
  // — scenario: WHOAMI (persona identity injection proof — the system message
  //   must carry the persona NAME and TAGLINE; the mock verifies and reports) —
  if (lastUser.includes("whoami-check")) {
    const sys = messages.find((m) => m.role === "system")?.content ?? "";
    const name = sys.match(/You are ([A-Za-z0-9' -]+?) —/)?.[1] ?? "";
    const tagOk = sys.includes("SPEEDRUNS-TAGLINE-MARKER");
    const nameOk = sys.includes("Velora");
    return JSON.stringify({
      say: `whoami: name=${nameOk ? "Velora-OK" : "NAME-MISSING"} tagline=${tagOk ? "TAGLINE-OK" : "TAGLINE-MISSING"}`,
      actions: [],
    });
  }

  // — scenario: SCHEDULER PROOF (mixed batch: slow exclusive first, fast shared
  //   after; on the result turn the mock reports the ORDER the TOOL RESULTs
  //   arrived in — must be BATCH order (omp in-order emission), not completion
  //   order (the python sleeps 1.5s, the recall returns instantly) —
  if (all.includes("scheduler-proof")) {
    if (lastUser.includes("TOOL RESULT")) {
      const order = [...messages]
        .filter((m) => m.role === "user" && String(m.content).startsWith("TOOL RESULT for "))
        .map((m) => String(m.content).match(/TOOL RESULT for (\w+)/)?.[1] ?? "?");
      return JSON.stringify({
        say: `scheduler order: ${order.join(",")}`,
        actions: [],
      });
    }
    return JSON.stringify({
      say: "Running the scheduler proof batch.",
      actions: [
        { type: "tool", name: "run_python", args: { code: "import time; time.sleep(1.5); print('slow exclusive done')" } },
        { type: "tool", name: "recall", args: { query: "anything at all" } },
        { type: "tool", name: "run_js", args: { code: "1 + 1" } },
      ],
    });
  }

  // — scenario: STEERING WRAPPER PROOF (mid-run interjection must arrive
  //   wrapped in omp's <system-notice> priority frame; the mock checks) —
  if (all.includes("steering-wrapper-proof")) {
    if (all.includes("<system-notice>") && all.includes("actually check the wrapper")) {
      return JSON.stringify({ say: "steering wrapper: WRAPPED-OK", actions: [] });
    }
    if (lastUser.includes("TOOL RESULT")) {
      return JSON.stringify({ say: `steering wrapper: ${all.includes("<system-notice>") ? "WRAPPED-OK" : "WRAPPER-MISSING"}`, actions: [] });
    }
    return JSON.stringify({
      say: "Starting the steering wrapper proof.",
      actions: [{ type: "tool", name: "run_python", args: { code: "import time; time.sleep(1.5); print('steer window open')" } }],
    });
  }

  // — scenario: checkpoint → explore (local) → rewind —
  if (lastUser.includes("explore and rewind") || (all.includes("rewind") && lastUser.includes("TOOL RESULT"))) {
    if (lastUser.includes("TOOL RESULT")) {
      return JSON.stringify({
        say: "Collapsing the detour.",
        actions: [{ type: "tool", name: "rewind", args: { report: "explored with a local computation; result received" } }],
      });
    }
    return JSON.stringify({
      say: "Marking the context first.",
      actions: [
        { type: "tool", name: "checkpoint", args: { label: "before exploring" } },
        { type: "tool", name: "run_python", args: { code: "print('exploring:', 6 * 7)" } },
      ],
    });
  }
  // — scenario: TTSR (goes off-script, gets cut, then behaves) —
  if (lastUser.includes("As an AI language model")) {
    // stream the disclaiming reply — the watcher should cut it mid-stream
    return JSON.stringify({ say: "As an AI language model, I cannot do math. But 2+2 is four.", actions: [] });
  }
  // — scenario: learn + recall —
  if (lastUser.includes("answer-style")) {
    if (lastUser.includes("TOOL RESULT")) return JSON.stringify({ say: "Lesson stored as a skill.", actions: [] });
    return JSON.stringify({
      say: "Learning the lesson.",
      actions: [{ type: "tool", name: "learn", args: { lesson: "the user prefers short two-sentence answers over long ones", name: "answer-style" } }],
    });
  }
  if (lastUser.includes("recall tool") || lastUser.includes("memories for")) {
    if (lastUser.includes("TOOL RESULT")) return JSON.stringify({ say: "That's what I remember.", actions: [] });
    return JSON.stringify({
      say: "Recalling.",
      actions: [{ type: "tool", name: "recall", args: { query: "answer style preferences" } }],
    });
  }
  // — scenario: always-fail (fallback-chain proof; primary endpoint 500s) —
  if (lastUser.includes("fallback-probe")) {
    return "HTTP-500"; // signal handled below
  }

  return JSON.stringify({ say: "Scenario not scripted — ask includes: " + lastUser.slice(0, 60), actions: [] });
}

const server = http.createServer((req, res) => {
  if (req.method !== "POST" || !req.url.includes("/chat/completions")) {
    res.writeHead(404).end();
    return;
  }
  let body = "";
  req.on("data", (d) => (body += d));
  req.on("end", () => {
    let messages = [];
    let stream = true;
    try {
      const parsed = JSON.parse(body);
      messages = parsed.messages ?? [];
      stream = parsed.stream !== false; // honor stream:false like real endpoints
    } catch {
      /* bad body */
    }
    const reply = script(messages);
    if (process.env.MOCK_TRACE) {
      const lu = [...messages].reverse().find((m) => m.role === "user")?.content ?? "";
      console.log(`[mock] msgs=${messages.length} lastUser[0..120]=${JSON.stringify(lu.slice(0, 120))} -> reply[0..80]=${JSON.stringify(reply.slice(0, 80))}`);
    }
    if (reply === "HTTP-500") {
      res.writeHead(500, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: { message: "mock primary endpoint is down (scenario: fallback-probe)" } }));
      return;
    }
    if (!stream) {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ choices: [{ message: { content: reply } }] }));
      return;
    }
    // stream as real SSE deltas, ~14 chars per chunk — TTSR cuts are visible mid-stream
    res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-store" });
    const step = 14;
    let i = 0;
    const timer = setInterval(() => {
      if (i >= reply.length) {
        clearInterval(timer);
        res.write("data: [DONE]\n\n");
        res.end();
        return;
      }
      const chunk = reply.slice(i, i + step);
      i += step;
      res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: chunk } }] })}\n\n`);
    }, 12);
    // NOTE: res close (NOT req close — req 'close' fires when the body is
    // consumed, which would kill the timer before the first tick)
    res.on("close", () => clearInterval(timer));
  });
});

server.listen(port, () => console.log(`mock brain on :${port} (deterministic SSE)`));
