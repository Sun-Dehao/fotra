#!/usr/bin/env python3
"""Rewrite flushSpeech in agent.ts to use the omp takeSpeakable segmenter."""
import sys

P = "/home/z/my-project/src/lib/fotra/agent.ts"
src = open(P).read()

lines = src.split("\n")
# locate the function by its doc comment
start = next(i for i, l in enumerate(lines) if l.strip() == "/** sentence-flush the say buffer into the voice */")
# find the closing brace of the function: first line that is exactly "}" after start
end = next(i for i in range(start + 1, len(lines)) if lines[i] == "}")

new_body = '''/** omp speakable flush \u2014 streaming segmentation of the say buffer into the voice.
 *  The FIRST take needs only 12 chars at a boundary, so speech starts while the
 *  model is still generating; later takes use full sentences / clause cuts; the
 *  final take drains whatever remains. Sanitization (fences, URLs, paths) inside. */
function flushSpeech(final: boolean) {
  const s = get();
  if (!s.settings.voiceOutput || run.replay) {
    run.speechDone = true;
    run.sayBuffer = "";
    return;
  }
  let flushable = "";
  while (true) {
    const [take, rest] = takeSpeakable(run.sayBuffer, final && run.sayBuffer.trim().length > 0, !run.speechStarted);
    if (take.trim().length === 0) break;
    flushable += take;
    run.sayBuffer = rest;
    run.speechStarted = true;
    if (!final) break; // one take per flush \u2014 non-final flushes leave room for the queue
  }
  if (final && run.sayBuffer.trim()) {
    flushable += run.sayBuffer;
    run.sayBuffer = "";
  }'''

lines[start:end] = new_body.split("\n")
open(P, "w").write("\n".join(lines))
print(f"replaced lines {start+1}..{end+1} OK")
