#!/usr/bin/env node
// Extract plain text from page_reader JSON outputs
const fs = require('fs');
const path = require('path');
const dir = '/home/z/my-project/research/pages';
const files = fs.readdirSync(dir).filter(f => f.endsWith('.json'));
for (const f of files) {
  let j;
  try { j = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')); } catch (e) { console.log('PARSE FAIL', f); continue; }
  const d = j.data || j;
  let text = d.text || d.html || '';
  if (!text && typeof d === 'string') text = d;
  // strip tags if html-only
  if (text.includes('<')) {
    text = text
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, ' ')
      .replace(/<!--[\s\S]*?-->/g, ' ')
      .replace(/<\/(p|div|h[1-6]|li|tr|section|article|blockquote|pre)>/gi, '\n')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<[^>]*>/g, ' ')
      .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
      .replace(/[ \t]+/g, ' ')
      .replace(/\n\s*\n\s*\n+/g, '\n\n');
  }
  text = text.trim();
  const cap = 18000; // ~18k chars per page is plenty
  const out = `# ${f.replace('.json','')}\n# title: ${d.title || ''}\n# url: ${d.url || ''}\n\n${text.slice(0, cap)}${text.length > cap ? '\n\n[...TRUNCATED...]' : ''}`;
  fs.writeFileSync(path.join(dir, f.replace('.json', '.txt')), out);
  console.log(f.replace('.json',''), '->', text.length, 'chars', d.title ? ('| ' + d.title.slice(0, 60)) : '');
}
