#!/usr/bin/env bash
# focused: budget-pause suspension + resume + ask_user (the HITL machinery)
set -u
BASE="http://localhost:3000"
SID="s$(date +%s)$RANDOM"
PERSONA='{"name":"Fotra","tagline":"t","aura":"calm","voiceURI":null,"voiceRate":1,"voicePitch":1}'
runreq() { local body="{\"text\":\"$1\",\"userTurnId\":\"$2\",\"assistantTurnId\":\"$3\",\"history\":[],\"persona\":$PERSONA,\"brain\":\"fotra\",\"sessionId\":\"$SESSION_ID\"}"; echo "$body"; }
latest_run() { curl -s --max-time 15 "$BASE/api/session?id=$1" | python3 -c "import sys,json;d=json.load(sys.stdin);print(d['runs'][0]['id'])" 2>/dev/null; }
wait_status() { local st=""; for i in $(seq 1 "${3:-40}"); do st=$(curl -s --max-time 10 "$BASE/api/runs/$1/status" | grep -o '"status":"[^"]*' | cut -d'"' -f4); case "$st" in "$2") break ;; esac; case "$st" in done|interrupted|error|waiting) break ;; esac; sleep 3; done; echo "$st"; }

# bootstrap a session
R0=$(curl -sN -X POST "$BASE/api/run" -H 'Content-Type: application/json' -d "{\"text\":\"hi\",\"userTurnId\":\"$SID-b\",\"assistantTurnId\":\"$SID-ba\",\"history\":[],\"persona\":$PERSONA,\"brain\":\"fotra\"}" --max-time 120)
SESSION_ID=$(echo "$R0" | grep -o '"sessionId":"[^"]*' | head -1 | cut -d'"' -f4)
echo "session: $SESSION_ID"

echo "== budget pause (deterministic) =="
curl -sN -X POST "$BASE/api/run" -H 'Content-Type: application/json' \
  -d "$(runreq "Run this chain of six web searches, one per reply, where each query DEPENDS on the previous result so you cannot batch them: (1) search who won the most recent FIFA World Cup; (2) search the population of that winning country; (3) search what year that country's capital city was founded; (4) search that capital's current mayor; (5) search which political party that mayor belongs to; (6) search that party's vote share in the last national election. One search per reply - the next query is only knowable after the previous result arrives." "$SID-u1" "$SID-a1")" \
  --max-time 300 > /tmp/fotra-budget-run.txt &
PID1=$!
for i in $(seq 1 15); do S1=$(latest_run "$SESSION_ID"); [ -n "${S1:-}" ] && [ "$S1" != "" ] && break; sleep 1; done
ST1=$(wait_status "$S1" waiting 60)
echo "status: $ST1"
if [ "$ST1" = "waiting" ]; then
  echo "PASS  run PAUSED at the budget (pause-not-kill)"
  grep -q '"type":"waiting","reason":"budget"' /tmp/fotra-budget-run.txt && echo "PASS  waiting(budget) event streamed" || echo "FAIL  waiting event"
  grep -q '"tone":"warn"' /tmp/fotra-budget-run.txt && echo "PASS  pause card (continue/stop/finish quietly)" || echo "FAIL  pause card"
  RESUME=$(curl -sN --max-time 300 -X POST "$BASE/api/runs/$S1/resume" -H 'Content-Type: application/json' -d '{"answer":"continue"}')
  echo "$RESUME" | grep -q '"type":"say"' && echo "PASS  resume(continue) streams" || echo "FAIL  resume streams"
  echo "$RESUME" | grep -q '"type":"done"' && echo "PASS  resumed run reached done — state intact" || echo "FAIL  resumed done"
  DUP=$(curl -s --max-time 10 -X POST "$BASE/api/runs/$S1/resume" -H 'Content-Type: application/json' -d '{"answer":"x"}')
  echo "$DUP" | grep -q 'not waiting' && echo "PASS  double-resume refused (idempotent)" || echo "FAIL  idempotent"
else
  echo "FAIL  budget pause (status=$ST1)"
fi
kill $PID1 2>/dev/null; wait $PID1 2>/dev/null

echo "== ask_user (model-dependent) =="
curl -sN -X POST "$BASE/api/run" -H 'Content-Type: application/json' \
  -d "$(runreq "Right now, in this very reply, emit the ask_user tool call to ask me my favorite color. Include a one-line spoken bridge AND the tool call together." "$SID-u2" "$SID-a2")" \
  --max-time 180 > /tmp/fotra-ask-run.txt &
PID2=$!
for i in $(seq 1 15); do S2=$(latest_run "$SESSION_ID"); [ -n "${S2:-}" ] && [ "$S2" != "${S1:-}" ] && break; sleep 1; done
ST2=$(wait_status "$S2" waiting 40)
echo "status: $ST2"
if [ "$ST2" = "waiting" ]; then
  echo "PASS  run suspended on ask_user"
  grep -q '"type":"ask"' /tmp/fotra-ask-run.txt && echo "PASS  ask card docked w/ resume metadata" || echo "FAIL  ask card"
  R2=$(curl -sN --max-time 150 -X POST "$BASE/api/runs/$S2/resume" -H 'Content-Type: application/json' -d '{"answer":"teal, like a deep lake"}')
  echo "$R2" | grep -q '"type":"done"' && echo "PASS  answer resumed the run" || echo "FAIL  resume"
  echo "$R2" | grep -qi 'teal' && echo "PASS  the answer steered the reply" || echo "FAIL  answer influence"
else
  echo "FAIL  ask_user (status=$ST2 — model skipped; machinery proven by budget path)"
fi
kill $PID2 2>/dev/null; wait $PID2 2>/dev/null
