import asyncio
import os
from playwright.async_api import async_playwright

HTML = "/home/z/my-project/scripts/fotra-backend-arch.html"
OUT = "/home/z/my-project/download/fotra-backend-architecture.png"


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(
            viewport={"width": 1700, "height": 1200},
            device_scale_factor=2,
        )
        await page.goto(f"file://{HTML}", wait_until="networkidle")
        # wait until the connector script has drawn + settled
        await page.wait_for_function("window.__diagramReady === true", timeout=15000)
        await page.wait_for_timeout(400)

        el = page.locator("#root")
        bbox = await el.bounding_box()
        if bbox:
            fit_w = max(1700, int(bbox["width"] + 60))
            fit_h = int(bbox["height"] + 60)
            await page.set_viewport_size({"width": fit_w, "height": fit_h})
            await page.wait_for_timeout(300)
            # redraw after resize so connector geometry is recomputed
            await page.evaluate("() => { document.getElementById('overlay').innerHTML=''; window.__diagramReady=false; draw(); }")
            await page.wait_for_function("window.__diagramReady === true", timeout=15000)
            await page.wait_for_timeout(300)

        await el.screenshot(path=OUT)
        await browser.close()
        print(f"OK {OUT} ({os.path.getsize(OUT)/1024:.0f} KB)")


asyncio.run(main())
