#!/bin/sh
# fotra dev server — daemonized double-fork (survives tool-call reaping, PPID=1)
cd /home/z/my-project
rm -f /tmp/fotra-dev.ready
nohup sh -c 'nohup node node_modules/next/dist/bin/next dev -p 3000 >> dev.log 2>&1 &'
# wait for readiness (up to 90s)
i=0
while [ $i -lt 90 ]; do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ 2>/dev/null)
  if [ "$code" = "200" ]; then echo "dev server up (attempt $i)"; exit 0; fi
  sleep 1
  i=$((i+1))
done
echo "dev server failed to come up in 90s"; tail -5 dev.log; exit 1
