#!/bin/bash
# FOTRA v3 E2E — the harness proofs (run against a live dev server)
# Every capability the redo added, proven through the real engine.
# Usage: bash scripts/e2e-v3.sh [base_url]   (default http://localhost:3000)

BASE="${1:-http://localhost:3000}"
PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  ✓ $1"; }
bad()  { FAIL=$((FAIL+1)); echo "  ✗ $1"; }
run()  { # run <json> → SSE stream text
  curl -s -N -X POST "$BASE/api/run" -H "Content-Type: application/json" -d "$1" -m 200
}
PERSONA='"persona":{"name":"fotra","tagline":"y","aura":"verdant","voiceURI":null,"voiceRate":1,"voicePitch":1}'

echo "—— fotra v3 E2E ——"

echo "[1] sandbox: run_python writes a file"
OUT=$(run "{\"text\":\"use run_python to compute 6*7 and write the answer to e2e.txt\",\"userTurnId\":\"e3-u1\",\"assistantTurnId\":\"e3-a1\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
echo "$OUT" | grep -q '"name":"run_python".*"ok":true' && ok "run_python executed" || bad "run_python missing"
echo "$OUT" | grep -q '"component":"code"' && ok "code screen auto-docked" || bad "no code screen"
FILES=$(curl -s "$BASE/api/workspace?sessionId=$(echo "$OUT" | grep -oE '"sessionId":"[^"]+"' | head -1 | cut -d'"' -f4)")
echo "$FILES" | grep -q "e2e.txt" && ok "workspace file persisted + listed" || bad "file not in workspace"

echo "[2] browser computer: navigate + extract"
OUT=$(run "{\"text\":\"use browser_navigate to open example.com and tell me the heading\",\"userTurnId\":\"e3-u2\",\"assistantTurnId\":\"e3-a2\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
echo "$OUT" | grep -q '"name":"browser_navigate".*"ok":true' && ok "browser_navigate executed" || bad "browser_navigate missing"
echo "$OUT" | grep -q '"component":"browser"' && ok "browser frame (with screenshot) docked" || bad "no browser frame"
echo "$OUT" | grep -qi "example domain" && ok "page text extracted" || bad "no page text"

echo "[3] sub-agents: parallel workers"
OUT=$(run "{\"text\":\"spawn two workers in parallel: one named a1 to compute 5*5 using run_python, one named a2 to count letters in banana using run_js. report both\",\"userTurnId\":\"e3-u3\",\"assistantTurnId\":\"e3-a3\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
echo "$OUT" | grep -q 'spawn_task:a1' && echo "$OUT" | grep -q 'spawn_task:a2' && ok "both workers reported" || bad "workers missing"
echo "$OUT" | grep -q '"component":"worker"' && ok "worker cards docked" || bad "no worker cards"

echo "[4] multi-artifact: board + chart in one run (nudge-guarded)"
OUT=$(run "{\"text\":\"two things: set up a todo board with 3 steps for a trip (step 1 doing), and show a bar chart of 1,2,3,4\",\"userTurnId\":\"e3-u4\",\"assistantTurnId\":\"e3-a4\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
echo "$OUT" | grep -q '"component":"todo"' && ok "todo board delivered" || bad "todo board missing"
echo "$OUT" | grep -q '"component":"chart"' && ok "chart delivered" || bad "chart missing"

echo "[5] routines: schedule + fire + ambient answer"
SESS=$(curl -s "$BASE/api/session?sessionId=none" > /dev/null; echo "e2e-$(date +%s)")
# create a session via a tiny run, then a routine on it
OUT=$(run "{\"text\":\"say hi\",\"userTurnId\":\"e3-u5\",\"assistantTurnId\":\"e3-a5\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
SESS=$(echo "$OUT" | grep -oE '"sessionId":"[^"]+"' | head -1 | cut -d'"' -f4)
RID=$(curl -s -X POST "$BASE/api/routines" -H "Content-Type: application/json" -d "{\"sessionId\":\"$SESS\",\"name\":\"e2e pulse\",\"prompt\":\"say the word banana\",\"schedule\":\"every 1440 minutes\"}" | grep -oE '"id":"[^"]+"' | cut -d'"' -f4)
[ -n "$RID" ] && ok "routine created ($RID)" || bad "routine create failed"
curl -s -X PATCH "$BASE/api/routines" -H "Content-Type: application/json" -d "{\"id\":\"$RID\",\"action\":\"run\"}" | grep -q '"fired":true' && ok "routine fired" || bad "routine fire failed"
sleep 12
POLL=$(curl -s "$BASE/api/session/poll?sessionId=$SESS&since=2020-01-01T00:00:00Z")
echo "$POLL" | grep -q '"origin":"system"' && ok "ambient poll sees routine turns" || bad "poll empty"
curl -s -X DELETE "$BASE/api/routines?id=$RID" > /dev/null

echo "[6] MCP: honest failure on bogus endpoint"
CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE/api/mcp" -H "Content-Type: application/json" -d '{"name":"bogus","url":"https://127.0.0.1:9/mcp"}')
[ "$CODE" = "502" ] || [ "$CODE" = "200" ] && ok "mcp connect handled honestly ($CODE)" || bad "mcp connect broken ($CODE)"

echo "[7] nudge guard: say_reset keeps transcript clean under retries"
OUT=$(run "{\"text\":\"use run_js to compute 2+2\",\"userTurnId\":\"e3-u7\",\"assistantTurnId\":\"e3-a7\",\"history\":[],$PERSONA,\"brain\":\"fotra\"}")
echo "$OUT" | grep -q '"name":"run_js"' && ok "run_js executed (nudge path if needed)" || bad "run_js missing"

echo ""
echo "—— results: $PASS pass · $FAIL fail ——"
[ "$FAIL" = "0" ] && echo "ALL GREEN" || exit 1
