#!/usr/bin/env bash
# ————————————————————————————————————————————————
# FOTRA slop gate — the machine-checkable design rules
# (DESIGN.md §"Machine-checked rules"). Exit 1 = slop.
# ————————————————————————————————————————————————
set -u
cd "$(dirname "$0")/.."
fail=0

echo "— slop gate —"

# 1. no emoji in src/ (vendored ui/ excluded)
emoji=$(grep -rPn '[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}\x{2B50}]' src/lib/fotra src/components/fotra src/app --include='*.ts' --include='*.tsx' 2>/dev/null | head -5)
if [ -n "$emoji" ]; then
  echo "FAIL: emoji found in fotra source:"
  echo "$emoji"
  fail=1
else
  echo "ok   no emoji in fotra source"
fi

# 2. no hex colors in fotra components — tokens only (vendored ui/ excluded)
hex=$(grep -rnE '#[0-9a-fA-F]{6}|#[0-9a-fA-F]{3}[^0-9a-fA-F]' src/components/fotra --include='*.tsx' 2>/dev/null | head -5)
if [ -n "$hex" ]; then
  echo "FAIL: hex colors in fotra components (use tokens):"
  echo "$hex"
  fail=1
else
  echo "ok   no hex in fotra components"
fi

# 3. no linear-gradient in fotra components
grad=$(grep -rn 'linear-gradient(' src/components/fotra src/lib 2>/dev/null | head -5)
if [ -n "$grad" ]; then
  echo "FAIL: linear-gradient in fotra code (the orb's depth lives in globals.css only):"
  echo "$grad"
  fail=1
else
  echo "ok   no linear-gradient in fotra code"
fi

# 4. banned copy (word-bounded; lines that QUOTE the ban for the model are the rules themselves)
banned=$(grep -rniwE "certainly|i'd be happy to|oops" src/lib/fotra src/components/fotra src/app --include='*.ts' --include='*.tsx' 2>/dev/null | grep -viE 'never .(certainly|oops)' | head -5)
if [ -n "$banned" ]; then
  echo "FAIL: banned copy found:"
  echo "$banned"
  fail=1
else
  echo "ok   no banned copy"
fi

# 5. console.log forbidden in fotra components
logs=$(grep -rn 'console\.log' src/components/fotra 2>/dev/null | head -5)
if [ -n "$logs" ]; then
  echo "FAIL: console.log in fotra components:"
  echo "$logs"
  fail=1
else
  echo "ok   no console.log in fotra components"
fi

# 6. key hygiene: no sk- values in the tracked providers file
if [ -f providers.json ]; then
  if grep -qE 'sk-[A-Za-z0-9_-]{8,}' providers.json; then
    echo "FAIL: pasted key in providers.json (keys belong in .env.local)"
    fail=1
  else
    echo "ok   providers.json clean of pasted keys"
  fi
fi

if [ "$fail" -eq 0 ]; then
  echo "— clean —"
  exit 0
fi
echo "— slop detected —"
exit 1
