#!/usr/bin/env bash
# fotra v5 visual proof — boots the dev server, drives agent-browser through the
# mascot flows, screenshots each state, checks console errors, tears down.
set -u
cd /home/z/my-project
DL=/home/z/my-project/download
LOG=/tmp/fotra-dev.log

pkill -f "next dev" 2>/dev/null; pkill -f "next-server" 2>/dev/null; sleep 1
npx next dev -p 3000 > "$LOG" 2>&1 &
SRV=$!

for i in $(seq 1 40); do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null)
  [ "$code" = "200" ] && break
  sleep 1
done
code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000)
echo "server: $code"
[ "$code" != "200" ] && { echo "SERVER FAILED"; tail -20 "$LOG"; kill $SRV 2>/dev/null; exit 1; }

agent-browser close 2>/dev/null
agent-browser set viewport 1600 1000
agent-browser open http://localhost:3000
agent-browser wait 3500

echo "== 1. idle dot (default) =="
agent-browser screenshot "$DL/fotra-v5-idle-dot.png"

echo "== 2. settings → appearance (skin picker) =="
agent-browser find role button click --name "Settings" || agent-browser find text "settings" click
agent-browser wait 800
agent-browser screenshot "$DL/fotra-v5-settings-skins.png"

echo "== 3. swap to the π face =="
agent-browser find role radio click --name "π" || agent-browser find text "π" click
agent-browser wait 600
agent-browser screenshot "$DL/fotra-v5-pi-picker.png"
agent-browser press Escape
agent-browser wait 600

echo "== 4. π on stage + thread =="
agent-browser screenshot "$DL/fotra-v5-stage-pi.png"

echo "== 5. swap to bot via demo brain (face-swap by voice) =="
agent-browser find role textbox fill "wear the bot face"
agent-browser press Enter
agent-browser wait 4500
agent-browser screenshot "$DL/fotra-v5-bot-swap.png"

echo "== 6. ember theme =="
agent-browser eval "useFotra" >/dev/null 2>&1
agent-browser find role button click --name "Persona and appearance settings" || true
agent-browser wait 500
agent-browser find text "ember" click 2>/dev/null || agent-browser find role radio click --name "ember" || true
agent-browser wait 800
agent-browser screenshot "$DL/fotra-v5-ember.png"
agent-browser press Escape

echo "== 7. console + errors =="
agent-browser errors
agent-browser console | tail -8

echo "== 8. mascot presence audit (DOM) =="
agent-browser eval "JSON.stringify({mascots: document.querySelectorAll('.f-mascot').length, svg: document.querySelectorAll('.f-mascot svg').length, skin: document.querySelector('.f-mascot')?.getAttribute('data-skin'), pal: document.querySelector('.f-mascot')?.getAttribute('data-pal'), orb: document.querySelectorAll('.f-orb').length, liveDots: document.querySelectorAll('.f-live-dot').length})"

agent-browser close
kill $SRV 2>/dev/null
pkill -f "next dev" 2>/dev/null; pkill -f "next-server" 2>/dev/null
echo "PROOF DONE"
