#!/usr/bin/env node
// Digest all search result JSONs into one compact overview
const fs = require('fs');
const path = require('path');
const dir = '/home/z/my-project/research/search';
const files = fs.readdirSync(dir).filter(f => f.endsWith('.json')).sort();
let out = [];
for (const f of files) {
  let data;
  try { data = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')); } catch (e) { continue; }
  if (!Array.isArray(data) || data.length === 0) { out.push(`## ${f}: EMPTY`); continue; }
  out.push(`## ${f.replace('.json','')}`);
  for (const r of data.slice(0, 6)) {
    const snip = (r.snippet || '').replace(/\s+/g, ' ').slice(0, 160);
    out.push(`- [${(r.name || '').slice(0, 90)}](${r.url}) ${(r.date || '').slice(0, 10)}\n  ${snip}`);
  }
}
fs.writeFileSync('/home/z/my-project/research/search-digest.md', out.join('\n'));
console.log('Digest written:', out.length, 'lines for', files.length, 'files');
