const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();
(async () => {
  const ss = await db.session.findMany({
    orderBy: { lastAt: "desc" },
    take: 6,
    include: { _count: { select: { turns: true, runs: true } } },
  });
  console.log("sessions:", ss.length);
  ss.forEach((s) => console.log(" -", s.id.slice(0, 12), "turns:", s._count.turns, "runs:", s._count.runs));
  await db.$disconnect();
})();
