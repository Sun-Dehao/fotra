#!/bin/bash
# Fotra research: batch web searches via z-ai CLI
OUT=/home/z/my-project/research/search
mkdir -p "$OUT"

run() {
  name="$1"; query="$2"; num="$3"
  if [ -s "$OUT/$name.json" ]; then echo "SKIP $name (exists)"; return; fi
  echo "--- $name : $query"
  z-ai function -n web_search -a "{\"query\": \"$query\", \"num\": $num}" -o "$OUT/$name.json" >/dev/null 2>&1 || echo "FAIL $name"
}

# --- Product / UI landscape ---
run ui_instinct1 "Instinct AI assistant Appllama" 8
run ui_instinct2 "Instinct AI agent app review" 8
run ui_opendots "CopilotKit OpenDots open source OpenAI assistant" 8
run ui_openmuse "CopilotKit openmuse Meta Muse open source" 8
run ui_openbot "CopilotKit openbot open source assistant platform" 8
run ui_muse "Meta Muse AI assistant app" 8
run ui_grok "Grok app voice mode orb interface design" 8
run ui_openai_voice "OpenAI ChatGPT voice mode dots animation interface" 8
run ui_hallmark "Nutlope hallmark anti-slop design system" 8
run ui_affectui "AffectUI emotional AI interface components" 8
run ui_inspora "Inspora design motion" 8
run ui_jarvis "Jarvis style AI assistant interface web app" 8

# --- Harness landscape & sentiment ---
run h_best1 "best AI coding agent harness 2026" 10
run h_best2 "Claude Code vs Codex vs OpenCode comparison" 10
run h_instinct "Instinct AI harness what people think" 10
run h_codex "OpenAI Codex CLI open source architecture" 8
run h_opencode "OpenCode terminal coding agent open source" 8
run h_goose "Block Goose open source AI agent" 8
run h_crush "Charm Crush terminal coding agent" 8
run h_minimax "MiniMax agent harness coding" 8
run h_zcode "z.ai coding agent CLI GLM" 8
run h_pi "pi coding agent Mario Zechner minimal" 8
run h_design1 "what makes a good agent harness design" 10
run h_design2 "agent harness context compaction subagents architecture" 8
run h_hn "Hacker News best coding agent harness discussion" 10

# --- Voice-first tech ---
run v_webspeech "Web Speech API SpeechRecognition voice assistant interruption" 8
run v_realtime "OpenAI Realtime API web voice assistant" 8
run v_vad "browser voice activity detection javascript library" 8
run v_bargein "voice agent barge-in interruption handling UX" 8

# --- Generative UI ---
run g_vercel "Vercel AI SDK generative UI streamObject React" 8
run g_copilot "CopilotKit useCopilotAction generative UI" 8
run g_json "AI JSON structured output render UI screens" 8

# --- Long context / memory ---
run m_letta "Letta MemGPT agent memory architecture" 8
run m_mem0 "Mem0 agent memory layer" 8
run m_long "long term memory personal AI assistant architecture" 8

# --- X posts / people ---
run x_victor "VictorTaelin AI agents" 8
run x_sawyer "Sawyer Hood AI agent assistant" 8
run x_rabi "rabi guha AI" 8
run x_kashyap "KashyapVisharad AI" 8
run x_ahmad "ahmadafterhours AI" 8

echo "=== ALL SEARCHES DONE ==="
