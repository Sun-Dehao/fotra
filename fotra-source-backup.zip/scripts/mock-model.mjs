#!/usr/bin/env node
// A deterministic OpenAI-compatible endpoint that plays "the model" so the REAL harness
// (server run loop, tools, browser, self-edit, event log) can be exercised with no API key.
// It speaks fotra's wire protocol and picks a script from the user's message:
//
//   "search …"            → web_search, then an answer with a sources screen
//   "browse …"/"open …"   → browser_navigate → browser_click by element number → answer
//   "be …"/"go …"/"wear…" → self_edit
//   "undo"                → self_edit {undo:true}
//   "thanks"/"ok"/…       → a tapback and nothing else
//   "every …"             → routine_create
//   "code"/"compute"      → run_js
//   anything else         → a plain one-line answer
//
// Usage: node scripts/mock-model.mjs [port]   (default 4010)
// Then: settings → brain → your model → base URL http://127.0.0.1:4010, model "mock".
import http from "node:http";

const port = Number(process.argv[2] || process.env.MOCK_PORT || 4010);

const reply = (say, actions = []) => JSON.stringify({ say, actions });
const tool = (name, args) => ({ type: "tool", name, args });

function lastUser(messages) {
  for (let i = messages.length - 1; i >= 0; i--) if (messages[i].role === "user") return String(messages[i].content ?? "");
  return "";
}
/** the ask that started this run: the last user message that isn't a tool result or harness note */
function ask(messages) {
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (m.role !== "user") continue;
    const c = String(m.content ?? "");
    if (/^(TOOL RESULT|WORKER RESULT|\[harness\]|\[advisor|\[budget\]|\[system)/.test(c)) continue;
    return c.replace(/<system-notice>[\s\S]*?<\/system-notice>\s*/g, "").trim();
  }
  return "";
}
function toolResults(messages) {
  return messages.filter((m) => m.role === "user" && /^TOOL RESULT for /.test(String(m.content ?? ""))).map((m) => String(m.content));
}

function script(messages) {
  const q = ask(messages);
  const lower = q.toLowerCase();
  const results = toolResults(messages);
  const last = lastUser(messages);

  // side calls the harness makes on its own (compaction handoffs, advisor) — keep them inert
  if (/You are fotra's advisor/.test(String(messages[0]?.content ?? ""))) return '{"kind":"none"}';
  if (/handoff|summar/i.test(String(messages[0]?.content ?? "")) && messages.length <= 2) return "## Goal\n(mock summary)";

  if (/^(thanks|thank you|ok|okay|cool|lol|you still there\??|nice)[\s!.?]*$/.test(lower)) {
    const emoji = /lol/.test(lower) ? "\u{1F602}" : /ok|cool|nice/.test(lower) ? "\u{1F44D}" : "\u{2764}\u{FE0F}";
    return reply("", [{ type: "react", emoji }]);
  }

  if (/^undo/.test(lower)) {
    if (results.length === 0) return reply("Putting it back.", [tool("self_edit", { undo: true })]);
    return reply("Back the way it was.");
  }

  if (/^(be |go |wear |call yourself|always |from now on|stop )/.test(lower)) {
    if (results.length === 0) {
      const args = { why: q.slice(0, 80) };
      if (/compact/.test(lower)) args.ui = { ...(args.ui ?? {}), density: "compact" };
      if (/wide/.test(lower)) args.ui = { ...(args.ui ?? {}), width: "wide" };
      const coat = lower.match(/\b(ice|rose|iris|mono|ember|verdant)\b/);
      if (coat) args.persona = { ...(args.persona ?? {}), coat: coat[1] };
      const name = lower.match(/call yourself (\w+)/);
      if (name) args.persona = { ...(args.persona ?? {}), name: name[1][0].toUpperCase() + name[1].slice(1) };
      if (/light|day/.test(lower)) args.mode = "light";
      if (/dark|night/.test(lower)) args.mode = "dark";
      if (/^(be |always |from now on|stop )/.test(lower)) args.instructions = { add: [q.replace(/[.!]+$/, "")] };
      return reply("On it.", [tool("self_edit", args)]);
    }
    return reply("Done — that's how I am now. Say “undo that” if it's wrong.");
  }

  if (/^every |routine|remind me every/.test(lower)) {
    if (results.length === 0) {
      const when = lower.match(/every [a-z0-9 ]*?(?:minutes?|hours?|morning|evening|night|day)(?: at \d{1,2}(?::\d{2})?\s*(?:am|pm)?)?/)?.[0] ?? "daily at 8:00";
      return reply("Setting that up.", [tool("routine_create", { name: q.split(/\s+/).slice(0, 4).join(" "), prompt: q, when })]);
    }
    return reply("Scheduled. It runs on its own and the answer lands here.");
  }

  if (/code|compute|calculate|prime/.test(lower)) {
    if (results.length === 0) {
      return reply("Running it.", [tool("run_js", { code: "const p=[];for(let n=2;p.length<20;n++){if(p.every(x=>n%x))p.push(n)}\nconsole.log(p.join(', '));" })]);
    }
    const out = last.match(/"stdout":"([^"]*)"/)?.[1]?.replace(/\\n/g, "").trim() ?? "";
    return reply(out ? `There they are: ${out}.` : "It ran, but printed nothing.");
  }

  if (/brows|open |go to |visit |use the computer/.test(lower)) {
    const url = q.match(/https?:\/\/\S+/)?.[0] ?? (q.match(/\b([a-z0-9-]+\.(?:com|org|net|io|dev))\b/i)?.[1] ?? "example.com");
    if (results.length === 0) return reply("Opening it — watch the window.", [tool("browser_navigate", { url })]);
    if (results.length === 1) {
      // pick the first link from the numbered elements list the harness handed back
      const m = last.match(/"(\d+) link [“"]([^”"\\]+)/);
      if (m) return reply("", [tool("browser_click", { target: Number(m[1]) })]);
      return reply("I've got the page open. Nothing obvious to click, so here's what it says: " + (last.match(/"title":"([^"]*)"/)?.[1] ?? "untitled") + ".");
    }
    const title = last.match(/"title":"([^"]*)"/)?.[1] ?? "the next page";
    return reply(`Opened it and followed the first link — I'm on “${title}” now.`);
  }

  if (/search|look up|find |what happened|news|latest|who is|what is/.test(lower)) {
    if (results.length === 0) {
      const query = q.replace(/^(search( the web)?( for)?|look up|find)\s*/i, "").replace(/[?.!]+$/, "") || q;
      return reply("Let me look.", [tool("web_search", { query, num: 5 })]);
    }
    const hits = [...last.matchAll(/"title":"((?:[^"\\]|\\.)*)","url":"((?:[^"\\]|\\.)*)","host":"((?:[^"\\]|\\.)*)"/g)].slice(0, 3);
    if (hits.length === 0) return reply("The search came back empty — try different words.");
    return reply(`Top result: ${hits[0][1].replace(/\\"/g, '"')}. The sources are below.`, [
      { type: "screen", id: `src-${Date.now().toString(36)}`, component: "sources", props: { items: hits.map((h) => ({ title: h[1].replace(/\\"/g, '"'), url: h[2], host: h[3] })) } },
    ]);
  }

  return reply("Mock model here — I only know a few scripts: search, browse, code, “be …”, “undo”, “every …”, and “thanks”.");
}

const server = http.createServer((req, res) => {
  if (req.method !== "POST") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ ok: true, mock: true }));
    return;
  }
  let body = "";
  req.on("data", (c) => (body += c));
  req.on("end", () => {
    let parsed = {};
    try {
      parsed = JSON.parse(body);
    } catch {
      /* fall through with an empty request */
    }
    const text = script(Array.isArray(parsed.messages) ? parsed.messages : []);
    if (parsed.stream === false) {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ choices: [{ message: { role: "assistant", content: text } }] }));
      return;
    }
    res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-store" });
    const chunks = text.match(/[\s\S]{1,18}/g) ?? [];
    let i = 0;
    const timer = setInterval(() => {
      if (i >= chunks.length) {
        clearInterval(timer);
        res.write("data: [DONE]\n\n");
        res.end();
        return;
      }
      res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: chunks[i++] } }] })}\n\n`);
    }, 18);
    res.on("close", () => clearInterval(timer));
  });
});

server.listen(port, "127.0.0.1", () => console.log(`mock model on http://127.0.0.1:${port}`));
