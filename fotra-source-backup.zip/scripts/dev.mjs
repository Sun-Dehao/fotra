#!/usr/bin/env node
// Cross-platform dev launcher (the old `next dev | tee dev.log` only ran on a unix shell).
// Makes sure the child can find node and git even when the parent's PATH is stale,
// then hands off to Next.
import { execFileSync, spawn } from "node:child_process";
import { existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
// an explicit port on the command line wins: the browser keys saved settings, keys and threads
// to the origin, so the port has to stay the same from one launch to the next
const port = process.argv[2] || process.env.PORT || "3000";

const extra = [path.dirname(process.execPath)];
if (process.platform === "win32") {
  for (const p of ["C:\\Program Files\\Git\\cmd", path.join(process.env.LOCALAPPDATA ?? "", "Programs", "Git", "cmd")]) {
    if (p && existsSync(p)) extra.push(p);
  }
}
const sep = process.platform === "win32" ? ";" : ":";
const env = { ...process.env, PATH: [...extra, process.env.PATH ?? process.env.Path ?? ""].join(sep) };
if (process.platform === "win32") env.Path = env.PATH;
env.NODE_OPTIONS = [env.NODE_OPTIONS, "--max-old-space-size=4096"].filter(Boolean).join(" ");

// Model calls leave from this process. A browser follows the system proxy (VPN apps set one);
// Node does not unless told — so carry it across, or providers that only answer through the
// proxy would work in the browser and fail here.
let proxy = env.HTTPS_PROXY || env.https_proxy || env.HTTP_PROXY || env.http_proxy || env.ALL_PROXY || "";
if (!proxy && process.platform === "win32") {
  try {
    const key = "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings";
    const out = execFileSync("reg", ["query", key], { encoding: "utf8", windowsHide: true });
    const enabled = /ProxyEnable\s+REG_DWORD\s+0x1\b/i.test(out);
    const server = out.match(/ProxyServer\s+REG_SZ\s+(\S+)/i)?.[1] ?? "";
    if (enabled && server) {
      // "host:port" or "http=host:port;https=host:port"
      const pick = server.includes("=") ? (server.split(";").find((p) => /^https=/i.test(p)) ?? server.split(";")[0]).split("=")[1] : server;
      proxy = /^\w+:\/\//.test(pick) ? pick : `http://${pick}`;
    }
  } catch {
    /* no registry access — go direct */
  }
}
if (proxy) {
  env.HTTPS_PROXY = env.HTTPS_PROXY || proxy;
  env.HTTP_PROXY = env.HTTP_PROXY || proxy;
  env.NO_PROXY = env.NO_PROXY || "localhost,127.0.0.1,::1";
  env.NODE_USE_ENV_PROXY = "1";
  console.log(`[fotra] outbound requests go through the proxy ${proxy}`);
}

const next = path.join(root, "node_modules", "next", "dist", "bin", "next");
const child = spawn(process.execPath, [next, "dev", "-p", String(port)], { cwd: root, env, stdio: "inherit" });
child.on("exit", (code) => process.exit(code ?? 0));
for (const sig of ["SIGINT", "SIGTERM"]) process.on(sig, () => child.kill(sig));
