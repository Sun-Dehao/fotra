/* kernel protocol smoke test — spawns the runners exactly like kernels.ts does,
   validates: persistence across cells, bridge round-trip, error frames, exit. */
import { spawn } from "node:child_process";
import { writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";
import os from "node:os";

const dir = path.join(os.tmpdir(), `ktest-${Date.now()}`);
mkdirSync(dir, { recursive: true });

// same runners kernels.ts embeds — import them via a tsx-less trick: read the file and eval?
// No — just re-declare minimal copies here won't test the real thing. Instead: compile kernels.ts
// string constants by reading the file.
const src = (await import("node:fs")).readFileSync("/home/z/my-project/src/lib/fotra/server/kernels.ts", "utf8");
const BT = String.fromCharCode(96); // backtick
function grab(name) {
  const open = "const " + name + " = String.raw" + BT;
  const start = src.indexOf(open);
  if (start < 0) throw new Error("runner " + name + " not found");
  const end = src.indexOf(BT + ";", start);
  return src.slice(start + open.length, end);
}
const PY = path.join(dir, "py-runner.py");
const JS = path.join(dir, "js-runner.mjs");
writeFileSync(PY, grab("PY_RUNNER"));
writeFileSync(JS, grab("JS_RUNNER"));

function boot(cmd, args) {
  const child = spawn(cmd, args, { cwd: dir, stdio: ["pipe", "pipe", "pipe", "pipe", "pipe"] });
  const state = { wire: "", frames: [], pending: null, out: "", err: "" };
  child.stdout.on("data", (d) => (state.out += d));
  child.stderr.on("data", (d) => (state.err += d));
  child.stdio[3].on("data", (d) => {
    state.wire += d.toString();
    let nl;
    while ((nl = state.wire.indexOf("\n")) >= 0) {
      const line = state.wire.slice(0, nl).trim();
      state.wire = state.wire.slice(nl + 1);
      if (!line) continue;
      const f = JSON.parse(line);
      if (f.type === "bridge" && state.pending) {
        // fake bridge: ws_list → files, echo tool
        const v = f.tool === "ws_list" ? { files: ["a.txt"] } : { echo: f.args };
        child.stdio[4].write(JSON.stringify({ type: "bridgeResult", bid: f.bid, ok: true, value: v }) + "\n");
      } else if (f.type === "result" && state.pending) {
        const p = state.pending;
        state.pending = null;
        p(f);
      }
    }
  });
  return { child, state };
}

function cell(h, code, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error("cell timeout")), timeoutMs);
    h.state.pending = (f) => {
      clearTimeout(t);
      // stdout (fd1) and the result frame (fd3) are different pipes — give
      // trailing stdout a beat to land before the caller asserts on it
      setTimeout(() => resolve(f), 60);
    };
    h.child.stdin.write(JSON.stringify({ type: "exec", id: "t" + Math.random().toString(36).slice(2, 6), code }) + "\n");
  });
}

let failures = 0;
const check = (name, cond, extra = "") => {
  console.log(`${cond ? "PASS" : "FAIL"} — ${name}${extra ? " · " + extra : ""}`);
  if (!cond) failures++;
};

// —— Python ——
{
  const h = boot("python3", ["-I", "-u", PY]);
  const r1 = await cell(h, "import math\nx = 41\nprint('hello from cell 1', math.pi)");
  check("py cell1 ok", r1.ok === true);
  check("py cell1 stdout", h.state.out.includes("hello from cell 1"));
  const r2 = await cell(h, "print('x is now', x + 1)");
  check("py state persists (x+1=42)", h.state.out.includes("x is now 42"), h.state.out.trim().slice(-60));
  const r3 = await cell(h, "files = tool('ws_list')\nprint('FILES:', files['files'])");
  check("py bridge ws_list", h.state.out.includes("FILES: ['a.txt']"));
  const r4 = await cell(h, "1/0");
  check("py error frame", r4.ok === false && /ZeroDivision/.test(r4.error || ""), r4.error);
  const r5 = await cell(h, "print('still alive after error:', x)");
  check("py kernel alive after error", h.state.out.includes("still alive after error: 41"));
  h.child.stdin.write(JSON.stringify({ type: "exit" }) + "\n");
  await new Promise((r) => setTimeout(r, 300));
  console.log("— python done —");
}

// —— JS ——
{
  const h = boot(process.execPath, [JS]);
  const r1 = await cell(h, "var x = 41; console.log('js cell1', typeof fetch);");
  check("js cell1 ok", r1.ok === true, JSON.stringify(r1).slice(0, 120));
  check("js cell1 stdout", h.state.out.includes("js cell1 function"));
  const r2 = await cell(h, "console.log('x is', x + 1)");
  check("js state persists", h.state.out.includes("x is 42"));
  const r3 = await cell(h, "const files = tool('ws_list'); console.log('FILES', JSON.stringify(files.files));");
  check("js bridge ws_list", h.state.out.includes('FILES ["a.txt"]'));
  const r4 = await cell(h, "null.crash");
  check("js error frame", r4.ok === false, r4.error);
  const r5 = await cell(h, "console.log('alive:', x)");
  check("js kernel alive after error", h.state.out.includes("alive: 41"));
  const r6 = await cell(h, "const fs = require('node:fs'); fs.writeFileSync('made-by-kernel.txt', 'hi'); console.log('wrote')");
  check("js require + file write", h.state.out.includes("wrote"));
  h.child.stdin.write(JSON.stringify({ type: "exit" }) + "\n");
  await new Promise((r) => setTimeout(r, 300));
  console.log("— js done —");
}

console.log(failures === 0 ? "ALL KERNEL TESTS PASS" : `${failures} FAILURES`);
process.exit(failures === 0 ? 0 : 1);
