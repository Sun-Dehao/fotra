/* ————————————————————————————————————————————————
   FOTRA — suspension/resume unit proof
   Crafts a Run row in the exact shape the engine's
   suspend() writes (same record, field for field),
   then resumes it through the REAL route with ONE
   model call — proving the resume machinery without
   burning the eight calls the budget path needs.
   ———————————————————————————————————————————————— */

import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const BASE = "http://localhost:3000";
const PERSONA = { name: "Fotra", tagline: "t", aura: "calm", voiceURI: null, voiceRate: 1, voicePitch: 1 };

async function probeModel() {
  try {
    const res = await fetch(`${BASE}/api/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text: "Say exactly: awake.",
        userTurnId: `probe-${Date.now()}`,
        assistantTurnId: `probe-a-${Date.now()}`,
        history: [],
        persona: PERSONA,
        brain: "fotra",
      }),
    });
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let all = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      all += dec.decode(value);
    }
    return all.includes('"type":"say"') && !all.includes('"type":"error"');
  } catch {
    return false;
  }
}

async function main() {
  // 1) a session for the suspended run
  const session = await db.session.create({ data: {} });
  const runId = `resume-test-${Date.now().toString(36)}`;
  const assistantTurnId = `a-${runId}`;

  // 2) the suspension record — mirror of engine.suspend()'s SuspensionRecord
  const rec = {
    kind: "ask",
    toolCallId: `ask-${runId}-1`,
    question: "What is your favorite color?",
    options: ["teal", "red"],
    params: {
      sessionId: session.id,
      runId,
      text: "ask me my favorite color",
      userTurnId: `u-${runId}`,
      history: [],
      persona: PERSONA,
      assistantTurnId,
      brain: "fotra",
      custom: { baseUrl: "", apiKey: "", model: "", temperature: 0.7 },
    },
    state: {
      messages: [
        { role: "system", content: 'You are the engine behind "fotra". Reply as {"say":"...","actions":[]}. One or two short sentences.' },
        { role: "user", content: "ask me my favorite color" },
      ],
      outChars: 0,
      assistantText: "Sure — one question coming up.",
      stepsTaken: 1,
      stepsAllowed: 1,
      usedTools: [],
      evidence: "",
    },
  };

  await db.run.create({
    data: {
      id: runId,
      sessionId: session.id,
      status: "waiting",
      brain: "fotra",
      suspension: JSON.stringify(rec),
    },
  });
  console.log("crafted waiting run:", runId);

  // 3) resume through the real route — the answer routes through the same path as a card click
  const res = await fetch(`${BASE}/api/runs/${runId}/resume`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ answer: "teal, like a deep lake" }),
  });
  if (res.status !== 200) {
    console.log("FAIL resume refused:", res.status, await res.text());
    process.exit(1);
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let all = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    all += dec.decode(value);
  }

  const said = all.includes('"type":"say"');
  const finished = all.includes('"type":"done"');
  const mentionsTeal = /teal|color/i.test(all);

  // 4) idempotency — a second resume must be refused
  const dup = await fetch(`${BASE}/api/runs/${runId}/resume`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ answer: "again" }),
  });
  const dupText = await dup.text();

  // 5) the run row must reflect the resume
  const row = await db.run.findUnique({ where: { id: runId } });
  const turn = await db.turn.findUnique({ where: { id: assistantTurnId } });

  console.log(`${said ? "PASS" : "FAIL"}  resume streams say events`);
  console.log(`${finished ? "PASS" : "FAIL"}  resumed run reached done`);
  console.log(`${mentionsTeal ? "PASS" : "FAIL"}  the answer influenced the reply`);
  console.log(`${dup.status === 409 && dupText.includes("not waiting") ? "PASS" : "FAIL"}  double-resume refused (idempotent)`);
  console.log(`${row?.status === "done" ? "PASS" : "FAIL"}  run row finalized (status=${row?.status})`);
  console.log(`${turn && /teal|color/i.test(turn.text) ? "PASS" : "FAIL"}  assistant turn persisted with the answer in context`);

  const pass = [said, finished, mentionsTeal, dup.status === 409, row?.status === "done", !!turn].every(Boolean);
  console.log(pass ? "— SUSPEND/RESUME MACHINERY: PROVEN —" : "— FAILED —");
  await db.$disconnect();
  process.exit(pass ? 0 : 1);
}

// probe first — one cheap call; bail if the brain is rate-limited
const probe = await probeModel();
if (!probe) {
  console.log("brain rate-limited — retry when the window clears");
  process.exit(2);
}
await main();
