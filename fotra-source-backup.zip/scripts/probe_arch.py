import asyncio, json
from playwright.async_api import async_playwright

HTML = "/home/z/my-project/scripts/fotra-backend-arch.html"

PROBE = r"""
() => {
  const out = { nodes: {}, paths: [], labels: [], rootBox: null, issues: [] };
  const root = document.getElementById('root').getBoundingClientRect();
  const stack = document.getElementById('stack').getBoundingClientRect();
  out.rootBox = { w: root.width, h: root.height };

  // collect node boxes (interior shrunk 2px)
  document.querySelectorAll('.node, .store, .rail, .band-head').forEach(n => {
    if (!n.id) return;
    const r = n.getBoundingClientRect();
    out.nodes[n.id] = { L: r.left, R: r.right, T: r.top, B: r.bottom };
  });

  // svg paths
  const svg = document.getElementById('overlay');
  svg.querySelectorAll('path').forEach(p => {
    out.paths.push(p.getAttribute('d'));
  });
  // labels
  svg.querySelectorAll('text').forEach(t => {
    const r = t.getBoundingClientRect();
    out.labels.push({ txt: t.textContent, L: r.left, R: r.right, T: r.top, B: r.bottom });
  });

  // parse path d -> segments
  function parseD(d) {
    const toks = d.replace(/M|L/g, ' ').trim().split(/\s+/);
    const pts = [];
    for (let i = 0; i < toks.length; i += 2) pts.push([parseFloat(toks[i]) + stack.left, parseFloat(toks[i+1]) + stack.top]);
    return pts;
  }
  function segIntersectsBox(a, b, box) {
    // axis-aligned segments only
    const L = box.L + 2, R = box.R - 2, T = box.T + 2, B = box.B - 2;
    if (a[0] === b[0]) { // vertical
      const x = a[0], y0 = Math.min(a[1], b[1]), y1 = Math.max(a[1], b[1]);
      return x > L && x < R && y1 > T && y0 < B;
    } else { // horizontal
      const y = a[1], x0 = Math.min(a[0], b[0]), x1 = Math.max(a[0], b[0]);
      return y > T && y < B && x1 > L && x0 < R;
    }
  }
  out.paths.forEach((d, pi) => {
    const pts = parseD(d);
    for (let i = 0; i < pts.length - 1; i++) {
      for (const [nid, box] of Object.entries(out.nodes)) {
        if (segIntersectsBox(pts[i], pts[i+1], box)) {
          out.issues.push(`PATH ${pi} seg${i} [${pts[i]} -> ${pts[i+1]}] crosses node ${nid}`);
        }
      }
    }
  });
  out.labels.forEach(lb => {
    for (const [nid, box] of Object.entries(out.nodes)) {
      if (lb.R > box.L + 2 && lb.L < box.R - 2 && lb.B > box.T + 2 && lb.T < box.B - 2) {
        out.issues.push(`LABEL "${lb.txt}" overlaps node ${nid}`);
      }
    }
    if (lb.R > root.right || lb.L < root.left) out.issues.push(`LABEL "${lb.txt}" outside root`);
  });
  // anything outside root?
  for (const [nid, box] of Object.entries(out.nodes)) {
    if (box.R > root.right + 1 || box.L < root.left - 1) out.issues.push(`NODE ${nid} outside root`);
  }
  return out;
}
"""

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": 1700, "height": 1200}, device_scale_factor=2)
        await page.goto(f"file://{HTML}", wait_until="networkidle")
        await page.wait_for_function("window.__diagramReady === true", timeout=15000)
        await page.wait_for_timeout(300)
        res = await page.evaluate(PROBE)
        print("ROOT:", res["rootBox"])
        print("\n--- ISSUES ---")
        if res["issues"]:
            for i in res["issues"]:
                print(" *", i)
        else:
            print("NONE — no path/label geometric violations")
        print("\n--- LABELS ---")
        for lb in res["labels"]:
            print(f"  '{lb['txt']}'  x=[{lb['L']:.0f},{lb['R']:.0f}] y=[{lb['T']:.0f},{lb['B']:.0f}]")
        await browser.close()

asyncio.run(main())
