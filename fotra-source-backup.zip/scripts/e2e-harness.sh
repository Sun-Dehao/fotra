#!/usr/bin/env bash
# ————————————————————————————————————————————————
# FOTRA harness E2E — prove the claims, don't state them.
# Exercises: run + event log + replay, memory + git vault,
# steering, disconnect≠abort, ask_user suspend + resume,
# search + export, providers, voice no-key honesty.
# ————————————————————————————————————————————————
set -u
BASE="http://localhost:3000"
PASS=0; FAIL=0
SID="e2e$(date +%s)$RANDOM"  # unique per suite run — turn-id collisions silently skip inserts
PERSONA='{"name":"Fotra","tagline":"t","aura":"calm","voiceURI":null,"voiceRate":1,"voicePitch":1}'
ok()   { PASS=$((PASS+1)); echo "  PASS  $1"; }
bad()  { FAIL=$((FAIL+1)); echo "  FAIL  $1"; }

runreq() { # runreq <text> <userTurnId> <assistantTurnId> <sessionId-or-empty>
  local sid="$4"
  local body="{\"text\":\"$1\",\"userTurnId\":\"$2\",\"assistantTurnId\":\"$3\",\"history\":[],\"persona\":$PERSONA,\"brain\":\"fotra\""
  [ -n "$sid" ] && body="$body,\"sessionId\":\"$sid\""
  echo "$body}"
}
latest_run() { # latest_run <sessionId>
  curl -s --max-time 15 "$BASE/api/session?id=$1" | python3 -c "import sys,json;d=json.load(sys.stdin);print(d['runs'][0]['id'])" 2>/dev/null
}
wait_status() { # wait_status <runId> <want> <maxTries>
  local st=""
  for i in $(seq 1 "${3:-30}"); do
    st=$(curl -s --max-time 10 "$BASE/api/runs/$1/status" | grep -o '"status":"[^"]*' | cut -d'"' -f4)
    case "$st" in "$2") break ;; esac
    case "$st" in done|interrupted|error|waiting) break ;; esac
    sleep 3
  done
  echo "$st"
}

echo "== 1. run + say events + done =="
RUN_RESP=$(curl -sN -X POST "$BASE/api/run" -H 'Content-Type: application/json' \
  -d "$(runreq 'Say exactly: the harness works. No tools needed.' "$SID-u1" "$SID-a1" "")" \
  --max-time 150)
SESSION_ID=$(echo "$RUN_RESP" | grep -o '"sessionId":"[^"]*' | head -1 | cut -d'"' -f4)
RUN_ID=$(echo "$RUN_RESP" | grep -o '"runId":"[^"]*' | head -1 | cut -d'"' -f4)
[ -n "$RUN_ID" ] && ok "run started (runId=$RUN_ID)" || bad "run started"
echo "$RUN_RESP" | grep -q '"type":"say"' && ok "say events streamed" || bad "say events streamed"
echo "$RUN_RESP" | grep -q '"type":"done"' && ok "done event" || bad "done event"
echo "$RUN_RESP" | grep -q '"seq"' && ok "seq rides the wire" || bad "seq rides the wire"

echo "== 2. event log replay (reattach contract) =="
ST1=$(wait_status "$RUN_ID" done 25)
[ "$ST1" = "done" ] && ok "run reached done" || bad "run reached done ($ST1)"
REPLAY=$(curl -sN --max-time 15 "$BASE/api/runs/$RUN_ID/events?after=0")
REPLAY_COUNT=$(echo "$REPLAY" | grep -c '^data: ')
[ "$REPLAY_COUNT" -ge 3 ] && ok "replay serves $REPLAY_COUNT events (incl. logged session event)" || bad "replay serves $REPLAY_COUNT events (want >=3)"
echo "$REPLAY" | grep -q '"type":"session"' && ok "replay carries session identity (reattach knows the turn)" || bad "replay carries session identity"
curl -s -o /dev/null -w '%{http_code}' --max-time 15 "$BASE/api/runs/$RUN_ID/status" | grep -q 200 && ok "status endpoint answers" || bad "status endpoint"

echo "== 3. memory + git vault =="
RUN2=$(curl -sN -X POST "$BASE/api/run" -H 'Content-Type: application/json' \
  -d "$(runreq "remember that my sister's name is Mira" "$SID-u2" "$SID-a2" "")" \
  --max-time 150)
SESSION_ID=$(echo "$RUN2" | grep -o '"sessionId":"[^"]*' | head -1 | cut -d'"' -f4)
MEM=$(curl -s --max-time 15 "$BASE/api/memory?sessionId=$SESSION_ID")
echo "$MEM" | grep -qi "Mira" && ok "memory persisted server-side (deterministic extraction)" || bad "memory persisted"
grep -rq "Mira" .fotra/memory/topics/ 2>/dev/null && ok "vault markdown contains the fact" || bad "vault markdown contains the fact"
GITLOG=$(git -C .fotra log --oneline 2>/dev/null | head -3)
[ -n "$GITLOG" ] && ok "vault has git history: $(echo "$GITLOG" | head -1)" || bad "vault git history"

echo "== 4. memory_search via the model =="
RUN3=$(curl -sN -X POST "$BASE/api/run" -H 'Content-Type: application/json' \
  -d "$(runreq "Use the memory_search tool with query 'sister' and tell me what it found." "$SID-u3" "$SID-a3" "$SESSION_ID")" \
  --max-time 150)
echo "$RUN3" | grep -qi 'memory_search' && ok "memory_search tool called" || bad "memory_search tool called"
echo "$RUN3" | grep -qi 'Mira' && ok "recalled Mira from memory" || bad "recalled Mira"

echo "== 5. steering (queue-and-steer, server-side) =="
curl -sN -X POST "$BASE/api/run" -H 'Content-Type: application/json' \
  -d "$(runreq 'Search the web for news about Starlink launches AND news about Blue Origin New Glenn, open and read three of the articles with open_link, then give me a very detailed report. Take your time and be thorough.' "$SID-u4" "$SID-a4" "$SESSION_ID")" \
  --max-time 180 > /tmp/fotra-steer-run.txt &
RUN_PID=$!
sleep 2
S4=$(latest_run "$SESSION_ID")
STEER_RES=$(curl -s --max-time 10 -X POST "$BASE/api/run/steer" -H 'Content-Type: application/json' -d "{\"runId\":\"$S4\",\"text\":\"also mention the company's next milestone\"}")
echo "$STEER_RES" | grep -q '"steered":true' && ok "steer accepted mid-run" || bad "steer accepted mid-run ($STEER_RES)"
wait $RUN_PID
sleep 4
RUN_ROW=$(curl -s --max-time 15 "$BASE/api/session?id=$SESSION_ID" | python3 -c "import sys,json;d=json.load(sys.stdin);r=[x for x in d['runs'] if x['id']=='$S4'][0];print(json.dumps(r))" 2>/dev/null)
echo "$RUN_ROW" | grep -q milestone && ok "steering audited on the run row (drained + recorded)" || bad "steering audited on run row"

echo "== 6. disconnect does NOT abort =="
curl -sN -X POST "$BASE/api/run" -H 'Content-Type: application/json' \
  -d "$(runreq 'Search the web for facts about Mercury, Venus, and Mars (one search each), then give me a very detailed comparative report. Take your time.' "$SID-u5" "$SID-a5" "$SESSION_ID")" \
  --max-time 180 > /tmp/fotra-orphan.txt &
ORPHAN_PID=$!
for i in $(seq 1 20); do
  S5=$(latest_run "$SESSION_ID")
  [ -n "${S5:-}" ] && [ "$S5" != "${S4:-}" ] && break
  sleep 1
done
sleep 4
kill $ORPHAN_PID 2>/dev/null  # the client vanishes mid-run
sleep 2
STATUS_AFTER_KILL=$(curl -s --max-time 10 "$BASE/api/runs/$S5/status" | grep -o '"status":"[^"]*' | cut -d'"' -f4)
[ "$STATUS_AFTER_KILL" = "running" ] && ok "run still running after client disconnect" || bad "run died on disconnect (status=$STATUS_AFTER_KILL)"
ST=$(wait_status "$S5" done 30)
[ "$ST" = "done" ] && ok "orphaned run finished on its own (disconnect≠abort)" || bad "orphaned run finished (status=$ST)"
EVENTS_AFTER=$(curl -sN --max-time 10 "$BASE/api/runs/$S5/events?after=0" | grep -c '^data: ')
[ "$EVENTS_AFTER" -ge 4 ] && ok "full event log replayable after the drop ($EVENTS_AFTER events)" || bad "event log after drop ($EVENTS_AFTER)"

echo "== 6b. budget pause suspends the run; 'continue' resumes it (deterministic HITL) =="
BUDGET_OK=0
for ATTEMPT in 1 2; do
  [ $ATTEMPT -gt 1 ] && { echo "  … retry $ATTEMPT"; sleep 15; }
  curl -sN -X POST "$BASE/api/run" -H 'Content-Type: application/json' \
    -d "$(runreq "Do these six web searches ONE AT A TIME - search, report one line, then the next: (1) Mars weather, (2) price of oolong tea, (3) Eiffel tower height, (4) cheetah top speed, (5) Iceland population, (6) distance to the Moon. Never batch two searches in one reply." "$SID-u6-$ATTEMPT" "$SID-a6-$ATTEMPT" "$SESSION_ID")" \
    --max-time 240 > /tmp/fotra-budget-run.txt &
  ASK_PID=$!
  for i in $(seq 1 20); do
    S6=$(latest_run "$SESSION_ID")
    [ -n "${S6:-}" ] && [ "$S6" != "${S5:-}" ] && break
    sleep 1
  done
  ST6=$(wait_status "$S6" waiting 50)
  [ "$ST6" = "waiting" ] && { BUDGET_OK=1; break; }
  [ "$ST6" = "error" ] && continue
  break
done

if [ "$BUDGET_OK" = "1" ]; then
  ok "run PAUSED at the budget (status=waiting — pause, not kill)"
  grep -q '"type":"waiting","reason":"budget"' /tmp/fotra-budget-run.txt && ok "waiting(budget) event streamed" || bad "waiting(budget) event streamed"
  grep -q '"tone":"warn"' /tmp/fotra-budget-run.txt && ok "budget pause card docked (continue / stop / finish quietly)" || bad "budget pause card docked"
  RESUME=$(curl -sN --max-time 240 -X POST "$BASE/api/runs/$S6/resume" -H 'Content-Type: application/json' -d '{"answer":"continue"}')
  echo "$RESUME" | grep -q '"type":"say"' && ok "resume(continue) streams say events" || bad "resume streams say events"
  echo "$RESUME" | grep -q '"type":"done"' && ok "resumed run reached done — state intact" || bad "resumed run reached done"
  DUP=$(curl -s --max-time 10 -X POST "$BASE/api/runs/$S6/resume" -H 'Content-Type: application/json' -d '{"answer":"again"}')
  echo "$DUP" | grep -q 'not waiting' && ok "double-resume refused (idempotent)" || bad "double-resume refused"
else
  bad "run paused at the budget (status=$ST6)"
fi
kill $ASK_PID 2>/dev/null
wait $ASK_PID 2>/dev/null
sleep 8

echo "== 6c. ask_user (same suspend/resume machinery, model-dependent) =="
curl -sN -X POST "$BASE/api/run" -H 'Content-Type: application/json' \
  -d "$(runreq "Right now, in this very reply, emit the ask_user tool call to ask me my favorite color. Include a one-line spoken bridge AND the tool call together." "$SID-u7" "$SID-a7" "$SESSION_ID")" \
  --max-time 180 > /tmp/fotra-ask-run.txt &
ASK2_PID=$!
for i in $(seq 1 20); do
  S7=$(latest_run "$SESSION_ID")
  [ -n "${S7:-}" ] && [ "$S7" != "${S6:-}" ] && break
  sleep 1
done
ST7=$(wait_status "$S7" waiting 40)
if [ "$ST7" = "waiting" ]; then
  ok "run suspended on ask_user (status=waiting)"
  grep -q '"type":"ask"' /tmp/fotra-ask-run.txt && ok "ask card action docked (with resume metadata)" || bad "ask card action docked"
  RESUME2=$(curl -sN --max-time 150 -X POST "$BASE/api/runs/$S7/resume" -H 'Content-Type: application/json' -d '{"answer":"teal, like a deep lake"}')
  echo "$RESUME2" | grep -q '"type":"done"' && ok "answer resumed the run to done" || bad "answer resumed the run"
  echo "$RESUME2" | grep -qi 'teal' && ok "the answer steered the resumed reply" || bad "answer influenced the reply"
else
  bad "ask_user suspension (status=$ST7 — model skipped the tool; machinery proven by 6b)"
fi
kill $ASK2_PID 2>/dev/null
wait $ASK2_PID 2>/dev/null
sleep 6

echo "== 7. search + export =="
HITS=$(curl -s --max-time 15 "$BASE/api/session?id=$SESSION_ID&q=Mira")
echo "$HITS" | grep -q '"hits"' && ok "thread search answers" || bad "thread search"
HITN=$(echo "$HITS" | python3 -c "import sys,json;print(len(json.load(sys.stdin)['hits']))" 2>/dev/null)
[ "${HITN:-0}" -ge 1 ] && ok "search finds Mira ($HITN hits)" || bad "search finds Mira"
EXPORT=$(curl -s --max-time 15 "$BASE/api/session?id=$SESSION_ID&export=md")
echo "$EXPORT" | grep -q "fotra thread export" && ok "markdown export" || bad "markdown export"
echo "$EXPORT" | grep -q "Mira" && ok "export includes memory" || bad "export includes memory"

echo "== 8. providers + key hygiene =="
curl -s --max-time 15 "$BASE/api/providers" | grep -q '"valid":true' && ok "providers.json validates" || bad "providers.json validates"
cp providers.json /tmp/providers.bak
echo '{"providers":{"x":{"baseUrl":"https://x.com","apiKeyEnv":"sk-pastedkeyvalue123"}},"roles":{}}' > providers.json
sleep 0.3
curl -s --max-time 15 "$BASE/api/providers" | grep -q '"valid":false' && ok "pasted-key hard-fail detected" || bad "pasted-key hard-fail"
mv /tmp/providers.bak providers.json
sleep 0.3
curl -s --max-time 15 "$BASE/api/providers" | grep -q '"valid":true' && ok "providers restored" || bad "providers restored"

echo "== 9. voice: honest no-key path =="
VR=$(curl -s -o /tmp/fotra-voice.json -w '%{http_code}' --max-time 15 -X POST "$BASE/api/voice/calls" -H 'Content-Type: application/json' -d "{\"sessionId\":\"$SESSION_ID\",\"sdp\":\"v=0\"}")
if [ "$VR" = "501" ]; then
  grep -q "OPENAI_API_KEY" /tmp/fotra-voice.json && ok "voice refuses honestly without a key (501 + named env var)" || bad "voice 501 message"
else
  ok "voice relay reachable (a key exists: HTTP $VR)"
fi

echo "== 10. unlock: open mode =="
curl -s --max-time 15 "$BASE/api/unlock" | grep -q '"locked":false' && ok "open mode when FOTRA_TOKEN unset" || bad "unlock status"

echo
echo "== RESULT: $PASS passed, $FAIL failed =="
[ "$FAIL" -eq 0 ] && exit 0 || exit 1
