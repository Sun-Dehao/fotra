#!/usr/bin/env bash
# repro: find the hydration mismatch source
set -u
cd /home/z/my-project
pkill -f "next dev" 2>/dev/null; pkill -f "next-server" 2>/dev/null; sleep 1
nohup npx next dev -p 3000 > /tmp/fotra-dev.log 2>&1 &
for i in $(seq 1 90); do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null)
  [ "$code" = "200" ] && break; sleep 1
done
echo "server: $code"

JQ() { agent-browser eval "$1" | sed 's/^"//; s/"$//; s/\\"/"/g'; }
CLICK() { agent-browser eval "$1" >/dev/null; }

agent-browser close 2>/dev/null
agent-browser set viewport 1600 1000
agent-browser open http://localhost:3000
agent-browser wait 1500
agent-browser storage local clear
# seed: ember coat + light mode + onboarded — the mismatch suspect
CLICK "(()=>{localStorage.setItem('fotra.persona.v1',JSON.stringify({name:'Fotra',tagline:'t',aura:'pulse',mascot:'dot',coat:'ember',voiceURI:null,voiceRate:1,voicePitch:1}));localStorage.setItem('fotra.settings.v1',JSON.stringify({mode:'light',engine:'demo',voiceMode:'browser',realtimeVoice:'alloy',custom:{baseUrl:'',apiKey:'',model:'',temperature:0.7},handsFree:false,voiceOutput:false}));localStorage.setItem('fotra.onboarded.v1','1');localStorage.setItem('fotra.mode','light');return true})()"
agent-browser open http://localhost:3000
agent-browser wait 4000
echo "console errors:"
agent-browser console 2>/dev/null | head -30
echo ""
echo "html state: $(JQ "JSON.stringify({coat:document.documentElement.dataset.coat,mode:document.documentElement.dataset.mode})")"
