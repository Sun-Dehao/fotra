// Parser regression: fuzz every chunk-split of real protocol output
// and compare against JSON.parse ground truth. Any hang, mismatch, or
// truncation fails. Run: bun scripts/repro-parser-hang.ts
import { ProtocolParser } from "/home/z/my-project/src/lib/fotra/protocol";

const CASES: string[] = [
  // 1. the exact input shape that hung the old parser (concat is still valid JSON)
  '{"say":"hi there ","actions' + '":[{"type":"remember","fact":"x"}]}',
  // 2. nested arrays (table rows) + escapes + multiple actions
  JSON.stringify({
    say: "Here's the plan — \"quoted\" and all.",
    actions: [
      { type: "screen", id: "t1", component: "table", props: { title: "Compare", columns: ["A", "B"], rows: [["x", "y"], ["z", "]not the end["]] } },
      { type: "remember", fact: "likes tables", topic: "prefs" },
    ],
  }),
  // 3. tool action
  JSON.stringify({ say: "let me check", actions: [{ type: "tool", name: "web_search", args: { query: "starlink india", num: 5 } }] }),
  // 4. whitespace around colons, empty actions
  '{ "say" : "clean." , "actions" : [ ] }',
  // 5. actions first, say after
  JSON.stringify({ actions: [{ type: "theme", value: "ember" }], say: "going red." }),
  // 6. say with escaped quote and newline
  JSON.stringify({ say: 'line one\nline "two"', actions: [] }),
];

// plain text (protocol ignored) — checked separately below
const PLAIN = "Sure thing, no JSON here at all.";

let failures = 0;

for (let ci = 0; ci < CASES.length; ci++) {
  const src = CASES[ci];
  const expected = JSON.parse(src) as { say: string; actions: unknown[] };

  // fuzz: fixed slice sizes + every single split point + whole
  const slicePlans: string[][] = [];
  for (const size of [1, 2, 3, 5, 7, 11, 48]) {
    const parts: string[] = [];
    for (let i = 0; i < src.length; i += size) parts.push(src.slice(i, i + size));
    slicePlans.push(parts);
  }
  for (let cut = 1; cut < src.length; cut++) {
    slicePlans.push([src.slice(0, cut), src.slice(cut)]);
  }
  slicePlans.push([src]);

  let planFails = 0;
  for (const parts of slicePlans) {
    const p = new ProtocolParser();
    let sayAll = "";
    let actCount = 0;
    for (const part of parts) {
      const { sayDelta, newActions } = p.feed(part);
      sayAll += sayDelta;
      actCount += newActions.length;
    }
    const fin = p.finish();
    const gotSay = (sayAll || fin.say).trim();
    const okSay = gotSay === expected.say.trim();
    const okActs = actCount === expected.actions.length && JSON.stringify(fin.actions) === JSON.stringify(expected.actions);
    if (!okSay || !okActs) {
      failures++; planFails++;
      console.error(`  FAIL case ${ci + 1} (chunk ${parts[0]?.length}): say=${JSON.stringify(gotSay)} acts=${JSON.stringify(fin.actions)}`);
    }
  }
  console.log(`case ${ci + 1} ${planFails === 0 ? "ok" : `(${planFails} fails)`}`);
}

// plain-text degradation
{
  const p = new ProtocolParser();
  for (const part of ["Sure thing", ", no JSON", " here at all."]) p.feed(part);
  const fin = p.finish();
  const ok = p.plainText && fin.say === PLAIN && fin.actions.length === 0;
  console.log(`case 7 (plain) ${ok ? "ok" : "FAIL"}`);
  if (!ok) failures++;
}

console.log(failures === 0 ? "ALL PASS — parser is stream-safe" : `${failures} FAILURES`);
// process.exit moved to the very end after the v2 rescue cases

// ———— v2 additions: plainText rescue (bare JSON tools inside prose) ————
const PLAIN_RESCUE: Array<{ input: string; wantSayIncludes: string; wantActions: number; wantNoJsonInSay: boolean }> = [
  {
    input: 'Let me check who won...\n{"type":"tool","name":"web_search","args":{"query":"world cup winner","num":5}}',
    wantSayIncludes: "Let me check who won...",
    wantActions: 1,
    wantNoJsonInSay: true,
  },
  {
    input: 'Prose then a screen {"type":"screen","id":"s1","component":"card","props":{"title":"T","body":"B"}} then more prose.',
    wantSayIncludes: "then more prose",
    wantActions: 1,
    wantNoJsonInSay: true,
  },
  {
    input: 'Not JSON at all: {oops unbalanced',
    wantSayIncludes: "{oops unbalanced",
    wantActions: 0,
    wantNoJsonInSay: false,
  },
  {
    input: 'Braces in speech "like {this}" stay speech.',
    wantSayIncludes: "like {this}",
    wantActions: 0,
    wantNoJsonInSay: false,
  },
];

for (const c of PLAIN_RESCUE) {
  // fuzz: feed at every chunk size 1..7 to catch split-object bugs
  for (const size of [1, 2, 3, 5, 7]) {
    const p = new ProtocolParser();
    for (let i = 0; i < c.input.length; i += size) p.feed(c.input.slice(i, i + size));
    const fin = p.finish();
    if (c.wantNoJsonInSay && fin.say.includes('"type"')) {
      failures++;
      console.error(`RESCUE FAIL (size ${size}): JSON leaked into say: ${fin.say}`);
    }
    if (c.wantActions > 0 && fin.actions.length !== c.wantActions) {
      failures++;
      console.error(`RESCUE FAIL (size ${size}): expected ${c.wantActions} actions, got ${fin.actions.length} — say="${fin.say}"`);
    }
    if (!fin.say.includes(c.wantSayIncludes)) {
      failures++;
      console.error(`RESCUE FAIL (size ${size}): say lost "${c.wantSayIncludes}" — got "${fin.say}"`);
    }
  }
}
console.log(PLAIN_RESCUE.length ? `plainText-rescue cases × 5 chunk sizes: ${failures === 0 ? "ALL PASS" : failures + " FAILURES"}` : "");
process.exit(failures === 0 ? 0 : 1);
