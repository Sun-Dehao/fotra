#!/usr/bin/env python3
"""FOTRA Research Report & Product Blueprint - body PDF generator (ReportLab).

Chapter numbering plan (Step 3.5):
  outline 1 = cover (merged separately, no number)
  outline 2 = TOC (roman i, no chapter number)
  outline 3..11 = content chapters 1..9 (already numbered in source markdown)

Parses /home/z/my-project/research/fotra-research-and-plan.md
"""
import hashlib
import os
import re
import sys

PDF_SKILL_DIR = '/home/z/my-project/skills/pdf'
sys.path.insert(0, os.path.join(PDF_SKILL_DIR, 'scripts'))

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.pdfmetrics import stringWidth, registerFontFamily
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (CondPageBreak, HRFlowable, KeepTogether,
                                PageBreak, Paragraph, SimpleDocTemplate,
                                Spacer, Table, TableStyle, XPreformatted)
from reportlab.platypus.tableofcontents import TableOfContents

# ---------------- fonts ----------------
FONT_DIR = '/usr/share/fonts'
pdfmetrics.registerFont(TTFont('FreeSerif', f'{FONT_DIR}/truetype/freefont/FreeSerif.ttf'))
pdfmetrics.registerFont(TTFont('FreeSerif-Bold', f'{FONT_DIR}/truetype/freefont/FreeSerifBold.ttf'))
pdfmetrics.registerFont(TTFont('FreeSerif-Italic', f'{FONT_DIR}/truetype/freefont/FreeSerifItalic.ttf'))
pdfmetrics.registerFont(TTFont('FreeSerif-BoldItalic', f'{FONT_DIR}/truetype/freefont/FreeSerifBoldItalic.ttf'))
pdfmetrics.registerFont(TTFont('NotoSerifSC', f'{FONT_DIR}/truetype/noto-serif-sc/NotoSerifSC-Regular.ttf'))
pdfmetrics.registerFont(TTFont('NotoSerifSC-Bold', f'{FONT_DIR}/truetype/noto-serif-sc/NotoSerifSC-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuSans', f'{FONT_DIR}/truetype/dejavu/DejaVuSansMono.ttf'))
registerFontFamily('FreeSerif', normal='FreeSerif', bold='FreeSerif-Bold',
                   italic='FreeSerif-Italic', boldItalic='FreeSerif-BoldItalic')
registerFontFamily('NotoSerifSC', normal='NotoSerifSC', bold='NotoSerifSC-Bold')
registerFontFamily('DejaVuSans', normal='DejaVuSans', bold='DejaVuSans')

from pdf import install_font_fallback  # noqa: E402
install_font_fallback()

# ---------------- cascade palette (design_engine.py palette-cascade --intent nature --mode minimal --seed 7) ----------------
PAGE_BG       = colors.HexColor('#eff1f0')
SECTION_BG    = colors.HexColor('#f0f2f1')
CARD_BG       = colors.HexColor('#e4e8e6')
TABLE_STRIPE  = colors.HexColor('#ebeeed')
HEADER_FILL   = colors.HexColor('#335042')
COVER_BLOCK   = colors.HexColor('#5a8670')
BORDER        = colors.HexColor('#b8cfc4')
ICON          = colors.HexColor('#528c6f')
ACCENT        = colors.HexColor('#2a8759')
ACCENT_2      = colors.HexColor('#3ab43a')
TEXT_PRIMARY  = colors.HexColor('#1a1c1b')
TEXT_MUTED    = colors.HexColor('#6f7873')

TABLE_HEADER_COLOR = HEADER_FILL
TABLE_HEADER_TEXT  = colors.white
TABLE_ROW_EVEN     = colors.white
TABLE_ROW_ODD      = TABLE_STRIPE

# ---------------- page geometry ----------------
PAGE_W, PAGE_H = A4
MARGIN = 0.9 * inch                    # symmetric left/right
TOP_MARGIN = 1.02 * inch
BOTTOM_MARGIN = 0.85 * inch
AVAIL_W = PAGE_W - 2 * MARGIN
AVAIL_H = PAGE_H - TOP_MARGIN - BOTTOM_MARGIN
DOC_TITLE = 'FOTRA - Research Report & Product Blueprint'
OUT = '/home/z/my-project/download/fotra-body.pdf'
MD = '/home/z/my-project/research/fotra-research-and-plan.md'

# ---------------- styles ----------------
S = {}
S['body'] = ParagraphStyle('Body', fontName='FreeSerif', fontSize=10.5, leading=16.5,
                           alignment=TA_JUSTIFY, textColor=TEXT_PRIMARY, spaceAfter=8)
S['lead'] = ParagraphStyle('Lead', parent=S['body'], fontSize=11.5, leading=18,
                           textColor=TEXT_PRIMARY, spaceAfter=10)
S['meta'] = ParagraphStyle('Meta', parent=S['body'], fontName='FreeSerif-Italic',
                           fontSize=9.5, leading=14, textColor=TEXT_MUTED,
                           alignment=TA_LEFT, spaceAfter=8)
S['h1'] = ParagraphStyle('H1', fontName='FreeSerif', fontSize=20, leading=25,
                         textColor=HEADER_FILL, spaceBefore=18, spaceAfter=4)
S['h2'] = ParagraphStyle('H2', fontName='FreeSerif', fontSize=13.5, leading=18,
                         textColor=HEADER_FILL, spaceBefore=13, spaceAfter=6)
S['bullet'] = ParagraphStyle('Bullet', parent=S['body'], alignment=TA_LEFT,
                             leftIndent=14, bulletIndent=3, spaceAfter=5)
S['num'] = ParagraphStyle('Num', parent=S['body'], alignment=TA_LEFT,
                          leftIndent=18, firstLineIndent=-14, spaceAfter=6)
S['code'] = ParagraphStyle('Code', fontName='DejaVuSans', fontSize=8, leading=11,
                           textColor=TEXT_PRIMARY, alignment=TA_LEFT)
S['cell'] = ParagraphStyle('Cell', fontName='FreeSerif', fontSize=9, leading=12.5,
                           textColor=TEXT_PRIMARY, alignment=TA_LEFT, wordWrap='CJK')
S['cellhead'] = ParagraphStyle('CellHead', fontName='FreeSerif', fontSize=9.2,
                               leading=12.5, textColor=TABLE_HEADER_TEXT,
                               alignment=TA_LEFT)
S['stat'] = ParagraphStyle('Stat', fontName='FreeSerif', fontSize=19, leading=23,
                           textColor=ACCENT, alignment=TA_CENTER)
S['statlabel'] = ParagraphStyle('StatLabel', fontName='FreeSerif', fontSize=8.5,
                                leading=11.5, textColor=TEXT_MUTED, alignment=TA_CENTER)
S['toc0'] = ParagraphStyle('TOC0', fontName='FreeSerif', fontSize=11.5, leading=20,
                           textColor=TEXT_PRIMARY, leftIndent=6)
S['toc1'] = ParagraphStyle('TOC1', fontName='FreeSerif', fontSize=9.5, leading=15,
                           textColor=TEXT_MUTED, leftIndent=26)
S['toctitle'] = ParagraphStyle('TocTitle', fontName='FreeSerif', fontSize=18,
                               leading=24, textColor=HEADER_FILL, spaceAfter=14)

# ---------------- inline markdown -> ReportLab markup ----------------
# entity strings built by concatenation so code.sanitize cannot rewrite them
_ENT_AMP = '&' + 'amp;'
_ENT_LT = '&' + 'lt;'
_ENT_GT = '&' + 'gt;'

def esc(t):
    return t.replace('&', _ENT_AMP).replace('<', _ENT_LT).replace('>', _ENT_GT)

def inline_md(t):
    t = esc(t)
    t = re.sub(r'`([^`]+)`',
               r'<font face="DejaVuSans" size="8.6">\1</font>', t)
    t = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\w*])\*([^*\n]+)\*(?![\w*])', r'<i>\1</i>', t)
    # bind spaced em-dashes and middle dots to the preceding word so they never start a line
    t = t.replace(' \u2014 ', '\u00a0\u2014 ')
    t = t.replace(' \u00b7 ', '\u00a0\u00b7 ')
    return t

# ---------------- doc template with TOC ----------------
class TocDocTemplate(SimpleDocTemplate):
    def afterFlowable(self, flowable):
        if hasattr(flowable, 'bookmark_name'):
            level = getattr(flowable, 'bookmark_level', 0)
            text = getattr(flowable, 'bookmark_text', '')
            key = getattr(flowable, 'bookmark_key', '')
            self.notify('TOCEntry', (level, text, self.page, key))

def add_heading(text, style, level=0):
    key = 'h_%s' % hashlib.md5(text.encode()).hexdigest()[:8]
    p = Paragraph('<a name="%s"/><b>%s</b>' % (key, inline_md(text)), style)
    p.bookmark_name = key
    p.bookmark_level = level
    p.bookmark_text = re.sub(r'[`*]', '', text)
    p.bookmark_key = key
    return p

# ---------------- header / footer ----------------
ROMAN = {1: 'i', 2: 'ii', 3: 'iii', 4: 'iv', 5: 'v'}

def on_page(canvas, doc):
    canvas.saveState()
    # header
    canvas.setFont('FreeSerif', 7.5)
    canvas.setFillColor(TEXT_MUTED)
    canvas.drawString(MARGIN, PAGE_H - 0.55 * inch, DOC_TITLE.upper())
    canvas.setStrokeColor(ACCENT)
    canvas.setLineWidth(1.2)
    canvas.line(MARGIN, PAGE_H - 0.62 * inch, PAGE_W - MARGIN, PAGE_H - 0.62 * inch)
    # footer
    canvas.setFont('FreeSerif', 7.5)
    canvas.setFillColor(TEXT_MUTED)
    canvas.drawString(MARGIN, 0.5 * inch, 'Fotra Research')
    if doc.page == 1:
        num = ROMAN.get(doc.page, 'i')
    else:
        num = str(doc.page - 1)
    canvas.drawRightString(PAGE_W - MARGIN, 0.5 * inch, num)
    canvas.setStrokeColor(BORDER)
    canvas.setLineWidth(0.5)
    canvas.line(MARGIN, 0.62 * inch, PAGE_W - MARGIN, 0.62 * inch)
    canvas.restoreState()

# ---------------- table builder ----------------
def col_widths_for(rows, n_cols):
    # weight = 90th percentile content length per column (rough proxy)
    weights = []
    for c in range(n_cols):
        lens = [len(re.sub(r'[*`]', '', r[c])) for r in rows if len(r) > c]
        lens.sort()
        w = lens[int(len(lens) * 0.85)] if lens else 10
        weights.append(max(min(w, 220), 8))
    total = sum(weights)
    ratios = [w / total for w in weights]
    # clamp: no column narrower than 9% or wider than 46% (for 2-4 col tables)
    if n_cols <= 4:
        ratios = [min(max(r, 0.11), 0.46) for r in ratios]
        ratios = [r / sum(ratios) for r in ratios]
    return [r * AVAIL_W for r in ratios]

def build_table(header, rows):
    n_cols = len(header)
    data = [[Paragraph('<b>%s</b>' % inline_md(c), S['cellhead']) for c in header]]
    for r in rows:
        data.append([Paragraph(inline_md(c), S['cell']) for c in r])
    widths = col_widths_for([header] + rows, n_cols)
    assert sum(widths) <= AVAIL_W + 0.5
    t = Table(data, colWidths=widths, repeatRows=1, hAlign='CENTER')
    style = [
        ('BACKGROUND', (0, 0), (-1, 0), TABLE_HEADER_COLOR),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('GRID', (0, 0), (-1, -1), 0.5, BORDER),
        ('LEFTPADDING', (0, 0), (-1, -1), 7),
        ('RIGHTPADDING', (0, 0), (-1, -1), 7),
        ('TOPPADDING', (0, 0), (-1, -1), 5.5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5.5),
    ]
    for i in range(1, len(data)):
        style.append(('BACKGROUND', (0, i), (-1, i),
                      TABLE_ROW_EVEN if i % 2 == 1 else TABLE_ROW_ODD))
    t.setStyle(TableStyle(style))
    return t

def build_code_block(lines):
    text = '\n'.join(esc(l) for l in lines).rstrip('\n')
    pre = XPreformatted(text, S['code'])
    t = Table([[pre]], colWidths=[AVAIL_W - 6])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), CARD_BG),
        ('LINEBEFORE', (0, 0), (0, -1), 2.5, ACCENT),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ('TOPPADDING', (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
    ]))
    t.hAlign = 'CENTER'
    return t

def stat_callouts():
    w = (AVAIL_W - 20) / 2
    data = [
        [Paragraph('<b>+20 pts</b>', S['stat']), Paragraph('', S['statlabel']),
         Paragraph('<b>3.1x</b>', S['stat'])],
        [Paragraph('pass-rate spread across 8 harnesses<br/>running the same model (Composio 2026)', S['statlabel']),
         Paragraph('', S['statlabel']),
         Paragraph('token cost difference, Pi vs Claude Code \u2014<br/>same model, same success rate (Databricks)', S['statlabel'])],
    ]
    t = Table(data, colWidths=[w, 20, w], hAlign='CENTER')
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, 1), SECTION_BG),
        ('BACKGROUND', (2, 0), (2, 1), SECTION_BG),
        ('BOX', (0, 0), (0, 1), 1, ACCENT),
        ('BOX', (2, 0), (2, 1), 1, ACCENT),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 2),
        ('TOPPADDING', (0, 1), (-1, 1), 2),
        ('BOTTOMPADDING', (0, 1), (-1, 1), 10),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
    ]))
    return t

# ---------------- markdown parser ----------------
def parse_md(path):
    with open(path, encoding='utf-8') as f:
        lines = f.read().split('\n')
    story = []
    toc = TableOfContents()
    toc.levelStyles = [S['toc0'], S['toc1']]
    story.append(Paragraph('<b>Table of Contents</b>', S['toctitle']))
    story.append(toc)
    story.append(PageBreak())

    i = 0
    n = len(lines)
    first_h1_done = False
    intro_pending = True
    while i < n:
        line = lines[i]

        if line.startswith('```'):
            block = []
            i += 1
            while i < n and not lines[i].startswith('```'):
                block.append(lines[i])
                i += 1
            i += 1
            story.append(Spacer(1, 4))
            story.append(build_code_block(block))
            story.append(Spacer(1, 8))
            continue

        if line.startswith('|') and i + 1 < n and re.match(r'^\|[\s:|-]+\|$', lines[i + 1].strip()):
            header = [c.strip() for c in line.strip().strip('|').split('|')]
            i += 2
            rows = []
            while i < n and lines[i].startswith('|'):
                rows.append([c.strip() for c in lines[i].strip().strip('|').split('|')])
                i += 1
            story.append(Spacer(1, 6))
            story.append(build_table(header, rows))
            story.append(Spacer(1, 10))
            continue

        if line.startswith('## '):
            title = line[3:].strip()
            story.append(CondPageBreak(AVAIL_H * 0.25))
            h = add_heading(title, S['h1'], level=0)
            rule = HRFlowable(width='100%', color=ACCENT, thickness=1.6,
                              spaceBefore=0, spaceAfter=10)
            story.append(KeepTogether([h, rule]))
            first_h1_done = True
            intro_pending = False
            i += 1
            continue

        if line.startswith('### '):
            title = line[4:].strip()
            h = add_heading(title, S['h2'], level=1)
            # keep heading with the next paragraph
            nxt = []
            j = i + 1
            while j < n and lines[j].strip() == '':
                j += 1
            if j < n and not lines[j].startswith(('#', '|', '```')):
                nxt = [Paragraph(inline_md(lines[j].strip()), S['body'])]
                i = j
            story.append(CondPageBreak(AVAIL_H * 0.12))
            if nxt:
                story.append(KeepTogether([h] + nxt))
            else:
                story.append(h)
            if title.startswith('4.1'):
                story.append(Spacer(1, 4))
                story.append(stat_callouts())
                story.append(Spacer(1, 6))
            i += 1
            continue

        if line.strip() == '---' or line.strip() == '':
            i += 1
            continue

        if line.startswith('# '):
            i += 1
            continue

        stripped = line.strip()
        if stripped.startswith('- '):
            txt = stripped[2:]
            story.append(Paragraph(inline_md(txt), S['bullet'], bulletText='\u2022'))
            i += 1
            continue

        m = re.match(r'^(\d+)\.\s+(.*)$', stripped)
        if m and first_h1_done:
            story.append(Paragraph('<b>%s.</b> %s' % (m.group(1), inline_md(m.group(2))), S['num']))
            i += 1
            continue

        # lead-in paragraphs before chapter 1
        if intro_pending:
            if stripped.startswith('*') and stripped.endswith('*') and not stripped.startswith('**'):
                story.append(Paragraph(inline_md(stripped.strip('*')), S['meta']))
            else:
                story.append(Paragraph(inline_md(stripped), S['lead']))
            i += 1
            continue

        # sources footer line (italic)
        if stripped.startswith('*Sources:') or (stripped.startswith('*') and stripped.endswith('*')):
            story.append(Paragraph(inline_md(stripped.strip('*')), S['meta']))
            i += 1
            continue

        story.append(Paragraph(inline_md(stripped), S['body']))
        i += 1

    return story

def main():
    story = parse_md(MD)
    doc = TocDocTemplate(
        OUT, pagesize=A4,
        leftMargin=MARGIN, rightMargin=MARGIN,
        topMargin=TOP_MARGIN, bottomMargin=BOTTOM_MARGIN,
        title=DOC_TITLE, author='Z.ai', creator='Z.ai',
        subject='Research report and product blueprint for Fotra, a voice-first web AI assistant')
    doc.multiBuild(story, onFirstPage=on_page, onLaterPages=on_page)
    print('body pages:', doc.page)
    print('written:', OUT)

if __name__ == '__main__':
    main()
