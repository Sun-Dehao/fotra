#!/bin/bash
# Parallel web search runner for Fotra research
OUT=/home/z/my-project/research/search
LIST="$OUT/queries.tsv"
mkdir -p "$OUT"

one() {
  line="$1"
  name="${line%%|*}"; rest="${line#*|}"
  query="${rest%%|*}"; num="${rest##*|}"
  [ -s "$OUT/$name.json" ] && { echo "SKIP $name"; return; }
  for attempt in 1 2 3; do
    timeout 90 z-ai function -n web_search -a "{\"query\": \"$query\", \"num\": $num}" -o "$OUT/$name.json" >/dev/null 2>&1 \
      && { echo "OK $name (try $attempt)"; return; }
    sleep $((attempt * 3))
  done
  echo "FAIL $name"
}
export -f one
export OUT

# name|query|num  (queries must not contain double quotes or pipes)
cat > "$LIST" <<'EOF'
ui_instinct1|Instinct AI assistant Appllama|6
ui_instinct2|Instinct AI agent app review what people think|6
ui_instinct3|Instinct AI assistant how it works harness|6
ui_opendots|CopilotKit OpenDots open source OpenAI assistant|6
ui_openmuse|CopilotKit openmuse Meta Muse open source|6
ui_openbot|CopilotKit openbot open source assistant platform|6
ui_muse|Meta Muse AI assistant app|6
ui_grok|Grok app voice mode interface design orb|6
ui_openai_voice|OpenAI ChatGPT voice mode dots animation|6
ui_hallmark|Nutlope hallmark anti-slop design system|6
ui_affectui|AffectUI emotional AI interface components|6
ui_inspora|Inspora design|6
ui_jarvis|Jarvis style AI assistant web interface|6
h_best1|best AI coding agent harness 2026|8
h_best2|Claude Code vs Codex vs OpenCode comparison which best|8
h_codex|OpenAI Codex CLI open source architecture|6
h_opencode|OpenCode open source terminal coding agent|6
h_goose|Block Goose open source AI agent|6
h_crush|Charm Crush terminal coding agent|6
h_minimax|MiniMax agent coding harness|6
h_zcode|z.ai GLM coding agent|6
h_pi|pi coding agent Mario Zechner badlogic minimal harness|6
h_design1|what makes a good agent harness design patterns|8
h_hn|Hacker News agent harness discussion Claude Code Codex|8
h_claudearch|Claude Code architecture subagents hooks skills|6
v_webspeech|Web Speech API SpeechRecognition voice assistant browser support|6
v_realtime|OpenAI Realtime API voice assistant WebRTC|6
v_vad|voice activity detection browser javascript|6
v_barvel|voice agent barge-in interruption handling|6
g_vercel|Vercel AI SDK generative UI streamObject|6
g_json|AI structured output render React components pattern|6
m_letta|Letta MemGPT agent memory architecture|6
m_mem0|Mem0 agent memory|6
m_long|long term memory personal AI assistant architecture|6
x_victor|VictorTaelin agents AI protocol|6
x_sawyer|Sawyer Hood AI agent|6
x_rabi|rabi guha AI agent Instinct|6
x_kashyap|KashyapVisharad Instinct AI|6
x_ahmad|ahmadafterhours AI|6
EOF

# run 6 in parallel
grep -v '^#' "$LIST" | xargs -d '\n' -P 1 -I{} bash -c 'one "$@"' _ {}
echo "=== PARALLEL BATCH DONE ==="
