/* fotra speakable unit test — the omp segmenter port.
   Run: node --experimental-strip-types scripts/test-speakable.mjs */
import { sanitizeForSpeech, segmentSpeech, takeSpeakable, FIRST_SEGMENT_MIN, SOFT_CLAUSE_LEN, MAX_SEGMENT } from "../src/lib/fotra/speakable.ts";

let pass = 0, fail = 0;
const ok = (m) => { pass++; console.log(`PASS — ${m}`); };
const bad = (m) => { fail++; console.log(`FAIL — ${m}`); };
const eq = (a, b, m) => (a === b ? ok(`${m}`) : bad(`${m} (got ${JSON.stringify(a)}, want ${JSON.stringify(b)})`));

// — omp's constants, verbatim —
eq(FIRST_SEGMENT_MIN, 12, "FIRST_SEGMENT_MIN = 12 (omp speakable.ts)");
eq(SOFT_CLAUSE_LEN, 160, "SOFT_CLAUSE_LEN = 160");
eq(MAX_SEGMENT, 280, "MAX_SEGMENT = 280");

// — sanitize: fences swallowed —
const s1 = sanitizeForSpeech("before ```js\nconst x = 1;\nconsole.log(x);\n```\n after");
if (s1.includes("[code]") && !s1.includes("const x")) ok("code fences swallowed — [code] marker, contents never spoken");
else bad(`fence swallow broken: ${JSON.stringify(s1)}`);

// — sanitize: URL → host —
const s2 = sanitizeForSpeech("see https://example.com/a/very/long/path?q=1&x=2 now");
if (s2.includes("example.com") && !s2.includes("q=1") && !s2.includes("/a/very")) ok("URLs spoken as hosts — no paths, no query strings");
else bad(`URL rewrite broken: ${JSON.stringify(s2)}`);

// — sanitize: long paths → basename —
const s3 = sanitizeForSpeech("open /home/z/work/src/components/fotra/Thread.tsx please");
if (s3.includes("Thread.tsx") && !s3.includes("/home/z")) ok("long paths spoken as basenames");
else bad(`path rewrite broken: ${JSON.stringify(s3)}`);

// — sanitize: markdown emphasis stripped —
const s4 = sanitizeForSpeech("**bold** and *ital* and `code`");
if (s4.includes("bold") && !s4.includes("*") && s4.includes("code")) ok("markdown emphasis/inline-code stripped for speech");
else bad(`markdown strip broken: ${JSON.stringify(s4)}`);

// — takeSpeakable: the first take fires at 12+ chars (speech starts early) —
const [t1, r1] = takeSpeakable("Sure thing, boss", false, true);
if (t1.trim() === "Sure thing," && r1.trim() === "boss") ok(`first take fires early (took ${JSON.stringify(t1.trim())} at the clause; the ${r1.trim().length}-char tail holds)`);
else bad(`first take dead: ${JSON.stringify([t1, r1])}`);

// — takeSpeakable: non-first takes HOLD for a full sentence (anti-chop) —
const [t2] = takeSpeakable("Sure thing", false, false);
eq(t2, "", "a short non-first buffer holds — no choppy speech");

// — takeSpeakable: soft-clause cut past 160 —
const longish = "This is a very long opening clause without terminal punctuation, and it keeps going well past the soft clause length, and then some more words to push it over one hundred sixty characters in total you see";
const [t3, r3] = takeSpeakable(longish, false, false);
if (t3.length > 0 && r3.length > 0 && /[;,]$/.test(t3.trim())) ok(`soft-clause cut at ${t3.length} chars — mid-sentence clauses ship`);
else bad(`soft-clause cut broken: took=${JSON.stringify(t3.slice(0, 40))}`);

// — takeSpeakable: final drains everything —
const [t4, r4] = takeSpeakable("leftover words", true, false);
if (t4.includes("leftover") && r4 === "") ok("final take drains the remainder");
else bad(`final drain broken: ${JSON.stringify([t4, r4])}`);

// — segmentSpeech: batch segmentation caps at MAX_SEGMENT —
const huge = "Word ".repeat(200).trim(); // 999 chars, no punctuation
const segs = segmentSpeech(huge);
const worst = Math.max(...segs.map((s) => s.length));
if (worst <= MAX_SEGMENT + 5) ok(`batch segmentation: ${segs.length} segments, longest ${worst} ≤ ~MAX_SEGMENT`);
else bad(`segment cap broken: longest ${worst}`);

// — segmentSpeech: sentences stay whole when short —
const whole = segmentSpeech("One sentence. Two sentences! Three?");
eq(whole.length, 3, "short sentences each ship as one segment");

console.log(`\n${pass} pass · ${fail} fail`);
process.exit(fail === 0 ? 0 : 1);
