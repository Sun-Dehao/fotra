#!/usr/bin/env bash
# debug the F flow — why didn't the steer button show during the mock run?
set -u
cd /home/z/my-project
MOCK_PORT=8788

pkill -f "next dev" 2>/dev/null; pkill -f "next-server" 2>/dev/null; pkill -f "mock-brain" 2>/dev/null; sleep 1
nohup npx next dev -p 3000 > /tmp/fotra-dev.log 2>&1 &
for i in $(seq 1 90); do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null)
  [ "$code" = "200" ] && break; sleep 1
done
echo "server: $code"
node scripts/mock-brain.mjs $MOCK_PORT > /tmp/mock-brain-r20.log 2>&1 &
MOCK_PID=$!
sleep 1
kill -0 $MOCK_PID 2>/dev/null && echo "mock up"
cleanup() { kill $MOCK_PID 2>/dev/null; }
trap cleanup EXIT

JQ() { agent-browser eval "$1" | sed 's/^"//; s/"$//; s/\\"/"/g'; }
CLICK() { agent-browser eval "$1" >/dev/null; }

agent-browser close 2>/dev/null
agent-browser set viewport 1600 1000
agent-browser open http://localhost:3000
agent-browser wait 1500
# seed: onboarded, engine=custom → mock brain, demo persona
CLICK "(()=>{localStorage.setItem('fotra.onboarded.v1','1');localStorage.setItem('fotra.settings.v1',JSON.stringify({mode:'dark',engine:'custom',voiceMode:'browser',realtimeVoice:'alloy',custom:{baseUrl:'http://localhost:$MOCK_PORT',apiKey:'',model:'mock',temperature:0.1},handsFree:false,voiceOutput:false,sessionId:'',lastRunId:'',lastSeq:0}));return true})()"
agent-browser open http://localhost:3000
agent-browser wait 3000
echo "state: $(JQ "JSON.stringify({engine:JSON.parse(localStorage.getItem('fotra.settings.v1')).engine, statusWord:document.querySelector('[aria-live=\"polite\"]')?.textContent})")"

# send the scheduler-proof prompt
CLICK "(()=>{const t=document.querySelector('[aria-label=\"Message\"]');const s=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;s.call(t,'scheduler-proof — run the exact batch and report the arrival order');t.dispatchEvent(new Event('input',{bubbles:true}));t.focus();return true})()"
agent-browser press Enter
for i in $(seq 1 24); do
  S=$(JQ "JSON.stringify({word:document.querySelector('[aria-live=\"polite\"]')?.textContent.trim(), steerBtn:document.querySelector('[aria-label=\"Steer the current run\"]')!==null, stopBtn:document.querySelector('[aria-label=\"Stop the current run\"]')!==null, activity:document.querySelectorAll('[aria-label=\"Tool activity\"] > div').length})")
  echo "t$i: $S"
  agent-browser wait 500
done
echo "mock log:"; tail -5 /tmp/mock-brain-r20.log
