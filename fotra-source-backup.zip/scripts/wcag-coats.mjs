/* WCAG contrast audit — every coat × mode, computed the way the browser does.
   Checks: body ink on paper, accent-on-paper (UI accents), glow-ink on glow (buttons). */
function oklchToSRGB(L, C, H) {
  const h = (H * Math.PI) / 180;
  const a = C * Math.cos(h);
  const b = C * Math.sin(h);
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
  const s_ = L - 0.0894841775 * a - 1.291485548 * b;
  const l = l_ ** 3, m = m_ ** 3, s = s_ ** 3;
  return [
    Math.min(1, Math.max(0, +4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s)),
    Math.min(1, Math.max(0, -1.2684380046 * l + 2.6097574011 * m - 0.3413193761 * s)),
    Math.min(1, Math.max(0, -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s)),
  ];
}
function lum([r, g, b]) {
  const f = (c) => (c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4);
  // input is linear-ish 0..1 already; the browser's channel values here are linear so just gamma
  const lin = (c) => (c <= 0.0031308 ? 12.92 * c : 1.055 * c ** (1 / 2.4) - 0.055);
  const R = lin(r), G = lin(g), B = lin(b);
  return 0.2126 * f(R) + 0.7152 * f(G) + 0.0722 * f(B);
}
function contrast(c1, c2) {
  const l1 = lum(oklchToSRGB(...c1)), l2 = lum(oklchToSRGB(...c2));
  const [hi, lo] = l1 > l2 ? [l1, l2] : [l2, l1];
  return (hi + 0.05) / (lo + 0.05);
}

const coats = {
  iris: { hue: 310, d: [72, 0.165], l: [50, 0.16], dangerHue: 25 },
  verdant: { hue: 152, d: [78, 0.165], l: [52, 0.155], dangerHue: 25 },
  ember: { hue: 28, d: [70, 0.17], l: [50, 0.165], dangerHue: 150 },
  ice: { hue: 225, d: [76, 0.14], l: [48, 0.135], dangerHue: 25 },
  rose: { hue: 348, d: [74, 0.155], l: [52, 0.15], dangerHue: 145 },
  mono: { hue: 270, d: [66, 0.015], l: [42, 0.012], dangerHue: 25 },
};

let fails = 0;
for (const [name, c] of Object.entries(coats)) {
  // dark canvas
  const dPaper = [12.5 / 100, 0.008, c.hue], dInk = [94 / 100, 0.005, c.hue], dGlow = [c.d[0] / 100, c.d[1], c.hue], dGlowInk = [16 / 100, 0.02, c.hue];
  // light canvas
  const lPaper = [97.5 / 100, 0.005, c.hue], lInk = [15.5 / 100, 0.008, c.hue], lGlow = [c.l[0] / 100, c.l[1], c.hue], lGlowInk = [98 / 100, 0.012, c.hue];

  const rows = [
    ["dark  ink/paper", contrast(dInk, dPaper), 7],
    ["dark  glow-ink/glow (btn)", contrast(dGlowInk, dGlow), 3],
    ["dark  glow/paper (accent)", contrast(dGlow, dPaper), 3],
    ["light ink/paper", contrast(lInk, lPaper), 7],
    ["light glow-ink/glow (btn)", contrast(lGlowInk, lGlow), 3],
    ["light glow/paper (accent)", contrast(lGlow, lPaper), 3],
  ];
  for (const [label, v, min] of rows) {
    const ok = v >= min;
    if (!ok) fails++;
    console.log(`${ok ? "✓" : "✗"} ${name.padEnd(8)} ${label.padEnd(26)} ${v.toFixed(2)}:1 (min ${min})`);
  }
}
console.log(fails === 0 ? "\nWCAG AUDIT: ALL PASS" : `\nWCAG AUDIT: ${fails} FAILS`);
process.exit(fails === 0 ? 0 : 1);
