#!/usr/bin/env bash
# fotra v5 DOM proof, take 2 — eval-driven clicks (deterministic), fixed selectors.
set -u
cd /home/z/my-project
DL=/home/z/my-project/download
LOG=/tmp/fotra-dev.log

pkill -f "next dev" 2>/dev/null; pkill -f "next-server" 2>/dev/null; sleep 1
npx next dev -p 3000 > "$LOG" 2>&1 &
SRV=$!
for i in $(seq 1 40); do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null)
  [ "$code" = "200" ] && break; sleep 1
done
echo "server: $code"; [ "$code" = "200" ] || { tail -20 "$LOG"; exit 1; }

agent-browser close 2>/dev/null
agent-browser set viewport 1600 1000
agent-browser open http://localhost:3000
agent-browser wait 1500
agent-browser storage local set fotra.onboarded.v1 "1"
agent-browser storage local set fotra.settings.v1 '{"engine":"demo"}'
agent-browser storage local set fotra.persona.v1 '{"name":"Fotra","mascot":"dot"}'
agent-browser open http://localhost:3000
agent-browser wait 3000

JQ() { agent-browser eval "$1"; }
CLICK() { agent-browser eval "$1" >/dev/null; }

echo "== A. idle dot anatomy (stage · header chip · thread avatar) =="
JQ "JSON.stringify({
  mascots: document.querySelectorAll('.f-mascot').length,
  stageSkin: document.querySelector('.f-orb .f-mascot')?.getAttribute('data-skin'),
  pal: document.querySelector('.f-orb .f-mascot')?.getAttribute('data-pal'),
  eyes: document.querySelectorAll('.f-orb .f-m-eye').length,
  bodyAnim: getComputedStyle(document.querySelector('.f-orb .f-m-body')).animationName,
  blinkAnim: getComputedStyle(document.querySelector('.f-orb .f-m-eye')).animationName,
  micChip: !!document.querySelector('.f-orb .f-orb-mic svg'),
  compactMicHidden: (() => { const m = document.querySelector('.f-orb.f-compact .f-orb-mic'); return m ? getComputedStyle(m).display === 'none' : 'no-compact-orb'; })(),
  personaChip: !!document.querySelector('header .f-mascot'),
  threadMascot: !!document.querySelector('section[aria-label=\"Conversation\"] .f-mascot'),
  ambient: !!document.querySelector('.f-ambient'),
  stageScrolls: (() => { const els = document.querySelectorAll('aside[aria-label=\"Fotra\"] .f-scroll'); return els.length ? getComputedStyle(els[0]).overflowY : 'MISSING'; })()
})"

echo "== B. settings → skin picker (4 previews) → click pi =="
CLICK "document.querySelector('[aria-label=\"Persona and appearance settings\"]').click()"
agent-browser wait 700
JQ "JSON.stringify({
  open: !!document.querySelector('[role=dialog][aria-label=\"Settings\"]'),
  skinRadios: document.querySelectorAll('[aria-label=\"Mascot skin\"] [role=radio]').length,
  previews: document.querySelectorAll('[aria-label=\"Mascot skin\"] .f-mascot').length,
  lineageNote: document.querySelector('[role=dialog]').textContent.includes('OpenDots trick')
})"
CLICK "document.querySelectorAll('[aria-label=\"Mascot skin\"] [role=radio]')[2].click()"
agent-browser wait 600
JQ "JSON.stringify({
  stageSkin: document.querySelector('.f-orb .f-mascot')?.getAttribute('data-skin'),
  piPath: document.querySelector('.f-orb .f-mascot[data-skin=pi] path')?.getAttribute('d'),
  markA: getComputedStyle(document.querySelector('.f-orb .f-mascot')).getPropertyValue('--m-mark-a').trim(),
  personaLS: localStorage.getItem('fotra.persona.v1')
})"
agent-browser screenshot "$DL/fotra-v5-settings-pi-picked.png"
CLICK "document.querySelector('[aria-label=\"Close settings\"]').click()"
agent-browser wait 500

echo "== C. voice face-swap: 'wear the bot face' (demo brain) =="
agent-browser find role textbox fill "wear the bot face"
agent-browser press Enter
agent-browser wait 5000
JQ "JSON.stringify({
  stageSkin: document.querySelector('.f-orb .f-mascot')?.getAttribute('data-skin'),
  botHead: !!document.querySelector('.f-orb .f-mascot[data-skin=bot] rect'),
  replyMentionsSwap: document.body.textContent.includes('Face swapped') || document.body.textContent.includes('Already wearing'),
  chipSkin: document.querySelector('header .f-mascot')?.getAttribute('data-skin'),
  avatarSkin: document.querySelector('section[aria-label=\"Conversation\"] .f-mascot')?.getAttribute('data-skin'),
  personaLS: localStorage.getItem('fotra.persona.v1')
})"
agent-browser screenshot "$DL/fotra-v5-bot-faceswap.png"

echo "== D. theme coat: ember flips coat 0 =="
CLICK "document.querySelector('[aria-label=\"Persona and appearance settings\"]').click()"
agent-browser wait 600
JQ "JSON.stringify({ themeRadios: document.querySelectorAll('[aria-label=\"Theme\"] [role=radio]').length })"
CLICK "document.querySelectorAll('[aria-label=\"Theme\"] [role=radio]')[1].click()"
agent-browser wait 800
JQ "JSON.stringify({
  theme: document.documentElement.getAttribute('data-theme'),
  coatHue: getComputedStyle(document.querySelector('.f-orb .f-mascot')).getPropertyValue('--m-hue').trim(),
  themeLS: localStorage.getItem('fotra.settings.v1')
})"
CLICK "document.querySelector('[aria-label=\"Close settings\"]').click()"
agent-browser wait 400
agent-browser screenshot "$DL/fotra-v5-ember-coat.png"

echo "== E. working row mid-run + bloom on persona change =="
agent-browser find role textbox fill "entertain me"
agent-browser press Enter
for i in $(seq 1 16); do
  R=$(JQ "JSON.stringify({wr: !!document.querySelector('.f-work-intent'), live: !!document.querySelector('.f-live-dot'), stopBtn: !!document.querySelector('.f-work-intent')?.closest('div')?.querySelector('button'), phase: document.querySelector('.f-orb')?.getAttribute('data-state')})")
  echo "  tick $i: $R"
  echo "$R" | rg -q 'wr.{1,4}true' && { agent-browser screenshot "$DL/fotra-v5-working-row.png"; echo "  (working row screenshot captured)"; break; }
  sleep 0.5
done

echo "== F. console + errors =="
agent-browser errors
agent-browser console | rg -i "error|warn" || echo "console: clean"

agent-browser close
kill $SRV 2>/dev/null; pkill -f "next dev" 2>/dev/null; pkill -f "next-server" 2>/dev/null
echo "PROOF B2 DONE"
