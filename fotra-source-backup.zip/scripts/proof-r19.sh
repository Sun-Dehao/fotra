#!/usr/bin/env bash
# fotra r19 proof — the shadcn rebuild: light mode, ⌘K palette, sessions,
# Sheet drawers, toasts, mobile. Deterministic DOM assertions + screenshots.
# NOTE: agent-browser eval JSON-escapes string results — JQ() un-escapes them.
set -u
cd /home/z/my-project
DL=/home/z/my-project/download/r19-shots
mkdir -p "$DL"

pkill -f "next dev" 2>/dev/null; pkill -f "next-server" 2>/dev/null; sleep 1
nohup npx next dev -p 3000 > /tmp/fotra-dev.log 2>&1 &
for i in $(seq 1 60); do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null)
  [ "$code" = "200" ] && break; sleep 1
done
echo "server: $code"; [ "$code" = "200" ] || { tail -20 /tmp/fotra-dev.log; exit 1; }

PASS=0; FAIL=0
JQ() { agent-browser eval "$1" | sed 's/^"//; s/"$//; s/\\"/"/g'; }
CLICK() { agent-browser eval "$1" >/dev/null; }
TYPE() { agent-browser eval "(()=>{const i=document.querySelector('[cmdk-input]');if(!i)return false;const s=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;s.call(i,'$1');i.dispatchEvent(new Event('input',{bubbles:true}));return true})()" >/dev/null; }
ESC() { agent-browser eval "document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}))" >/dev/null; agent-browser wait 700; }
ok() { echo "  ✓ $1"; PASS=$((PASS+1)); }
bad() { echo "  ✗ $1 — got: $2"; FAIL=$((FAIL+1)); }
CHK() { if echo "$2" | rg -q "$3"; then ok "$1"; else bad "$1" "$2"; fi; }

agent-browser close 2>/dev/null
agent-browser set viewport 1600 1000

echo "== 0. APIs =="
APIS=$(curl -s http://localhost:3000/api/sessions)
CHK "sessions API lists server sessions" "$APIS" '"sessions":\['

echo "== A. fresh boot → onboarding (now with the canvas picker) =="
agent-browser open http://localhost:3000
agent-browser wait 1500
agent-browser storage local clear
agent-browser open http://localhost:3000
agent-browser wait 3000
R=$(JQ "JSON.stringify({onboard:!!document.querySelector('[aria-label=\"Welcome\"]'),coats:document.querySelectorAll('[aria-label=\"Coat\"] button').length,modeButtons:document.querySelectorAll('[aria-label=\"Mode\"] button').length})")
CHK "onboarding: coat + canvas pickers" "$R" '"onboard":true,"coats":6,"modeButtons":[24]'

echo "== B. begin → dark stage anatomy (shadcn header, rail, mascot) =="
CLICK "[...document.querySelectorAll('button')].find(b=>b.textContent.includes('begin'))"
agent-browser wait 2500
R=$(JQ "JSON.stringify({mode:document.documentElement.dataset.mode,coat:document.documentElement.dataset.coat,paletteBtn:!!document.querySelector('[aria-label=\"Command palette\"]'),railSessions:!!document.querySelector('[aria-label=\"Sessions\"]'),mascot:!!document.querySelector('.f-mascot'),waveform:!!document.querySelector('.f-wave-strip')})")
CHK "dark idle: palette btn + sessions rail + mascot" "$R" '"mode":"dark","coat":"verdant","paletteBtn":true,"railSessions":true,"mascot":true'
agent-browser screenshot "$DL/01-dark-idle.png"

echo "== C. ⌘K palette → light mode =="
CLICK "document.querySelector('[aria-label=\"Command palette\"]').click()"
agent-browser wait 600
R=$(JQ "JSON.stringify({dialog:!!document.querySelector('[cmdk-root]'),input:!!document.querySelector('[cmdk-input]'),groups:document.querySelectorAll('[cmdk-group]').length,items:document.querySelectorAll('[cmdk-item]').length})")
CHK "palette opens with grouped commands" "$R" '"dialog":true,"input":true,"groups":[1-9],"items":[2-9][0-9]'
agent-browser screenshot "$DL/02-palette.png"
TYPE "light mode"
agent-browser wait 400
R=$(JQ "document.querySelectorAll('[cmdk-item]').length")
CHK "filtering narrows to the light-mode command" "$R" '^[1-4]$'
agent-browser press Enter
agent-browser wait 900
R=$(JQ "JSON.stringify({mode:document.documentElement.dataset.mode,ls:localStorage.getItem('fotra.mode'),bg:getComputedStyle(document.body).backgroundColor})")
CHK "light mode applied + persisted" "$R" '"mode":"light","ls":"light"'
agent-browser screenshot "$DL/03-light-idle.png"

echo "== D. palette: wear the π face =="
CLICK "document.querySelector('[aria-label=\"Command palette\"]').click()"
agent-browser wait 500
TYPE "wear the pi"
agent-browser wait 400
agent-browser press Enter
agent-browser wait 800
R=$(JQ "JSON.stringify({skin:document.querySelector('section[aria-label=\"Fotra\"] .f-mascot')?.getAttribute('data-skin'),ls:JSON.parse(localStorage.getItem('fotra.persona.v1')||'{}').mascot})")
CHK "face swap via palette, persisted" "$R" '"skin":"pi","ls":"pi"'
agent-browser screenshot "$DL/04-pi-face.png"

echo "== E. settings — the shadcn Sheet, tabbed =="
CLICK "document.querySelector('[aria-label=\"Settings\"]').click()"
agent-browser wait 900
R=$(JQ "JSON.stringify({sheet:!!document.querySelector('[data-slot=\"sheet-content\"]'),tabs:document.querySelectorAll('[data-slot=\"sheet-content\"] [role=tab]').length,active:document.querySelector('[data-slot=\"sheet-content\"] [role=tab][aria-selected=true]')?.getAttribute('data-tab'),canvas:document.querySelectorAll('[data-slot=\"sheet-content\"] [aria-label=\"Mode\"] button').length,skins:document.querySelectorAll('[data-slot=\"sheet-content\"] [aria-label=\"Mascot skin\"] [role=radio]').length,coats:document.querySelectorAll('[data-slot=\"sheet-content\"] [aria-label=\"Mascot coat\"] [role=radio]').length})")
CHK "settings Sheet: 8 tabs, appearance active, canvas + 5 skins + 6 coats" "$R" '"sheet":true,"tabs":8,"active":"appearance","canvas":2,"skins":5,"coats":6'
agent-browser screenshot "$DL/05-settings-sheet.png"
CLICK "[...document.querySelectorAll('[data-slot=\"sheet-content\"] [aria-label=\"Mode\"] button')].find(b=>b.textContent.includes('night')).click()"
agent-browser wait 500
R=$(JQ "document.documentElement.dataset.mode")
CHK "mode toggle in settings works" "$R" '^dark$'
CLICK "(()=>{const b=document.querySelector('[data-slot=\"sheet-content\"] [data-tab=\"persona\"]');if(b){b.click();return true}return false})()"
agent-browser wait 500
R=$(JQ "JSON.stringify({active:document.querySelector('[data-slot=\"sheet-content\"] [role=tab][aria-selected=true]')?.getAttribute('data-tab'),sliders:document.querySelectorAll('[data-slot=\"sheet-content\"] [data-slot=\"slider\"]').length,nameField:!!document.querySelector('[data-slot=\"sheet-content\"] [aria-label=\"Assistant name\"]')})")
CHK "persona tab: rate + pitch sliders + name field" "$R" '"active":"persona","sliders":[2-4],"nameField":true'
ESC

echo "== F. sessions — the rail panel, switch, replay =="
CLICK "document.querySelector('[aria-label=\"Sessions\"]').click()"
agent-browser wait 900
R=$(JQ "JSON.stringify({rows:(()=>{const nav=document.querySelector('nav[aria-label=\"Harness surfaces\"]');const fly=nav&&nav.nextElementSibling;return fly?fly.querySelectorAll('li').length:0})(),newBtn:!![...document.querySelectorAll('button')].find(b=>b.textContent.includes('new thread'))})")
CHK "sessions panel lists server sessions + new thread" "$R" '"rows":[1-9][0-9]*,"newBtn":true'
agent-browser screenshot "$DL/06-sessions-panel.png"
CLICK "(()=>{const nav=document.querySelector('nav[aria-label=\"Harness surfaces\"]');const fly=nav&&nav.nextElementSibling;const btns=fly?[...fly.querySelectorAll('li button')]:[];const b=btns.find(x=>/[2-9][0-9] turns/.test(x.textContent));if(b){b.click();return true}return false})()"
agent-browser wait 2500
R=$(JQ "JSON.stringify({lsSession:(()=>{const s=JSON.parse(localStorage.getItem('fotra.settings.v1')||'{}');return (s.sessionId||'EMPTY').slice(0,8)})(),threadCount:(()=>{try{const t=JSON.parse(localStorage.getItem('fotra.thread.v1')||'[]');return t.length}catch(e){return -1}})()})")
CHK "switch replayed the recorded session + persisted sessionId" "$R" '"lsSession":"cm[^"]*","threadCount":[1-9][0-9]*'
agent-browser screenshot "$DL/07-session-replayed.png"

echo "== G. new thread (panel is already open — no re-toggle) =="
CLICK "[...document.querySelectorAll('button')].find(b=>b.textContent.includes('new thread')).click()"
agent-browser wait 800
R=$(JQ "JSON.stringify({turns:(()=>{try{const t=JSON.parse(localStorage.getItem('fotra.thread.v1')||'[]');return t.length}catch(e){return -1}})(),session:(JSON.parse(localStorage.getItem('fotra.settings.v1')||'{}').sessionId||'EMPTY')})")
CHK "new thread cleared the replay + session id" "$R" '"turns":0,"session":"EMPTY"'

echo "== H. mobile 390×844 — Sheet drawers =="
agent-browser set viewport 390 844
agent-browser wait 800
CLICK "document.querySelector('[aria-label=\"Open harness panels\"]').click()"
agent-browser wait 900
R=$(JQ "JSON.stringify({railSheet:!!document.querySelector('[data-slot=\"sheet-content\"]'),sessionsMobile:!!document.querySelector('[aria-label=\"Sessions\"]')})")
CHK "mobile rail Sheet opens with sessions" "$R" '"railSheet":true,"sessionsMobile":true'
agent-browser screenshot "$DL/08-mobile-rail.png"
ESC
CLICK "[...document.querySelectorAll('header button')].find(b=>(b.getAttribute('aria-label')||'').includes('transcript')).click()"
agent-browser wait 900
R=$(JQ "JSON.stringify({threadSheet:document.querySelectorAll('[data-slot=\"sheet-content\"]').length, emptyThread:document.body.textContent.includes('One thread, forever')})")
CHK "mobile transcript Sheet opens (and only it)" "$R" '"threadSheet":1'
agent-browser screenshot "$DL/09-mobile-thread.png"
ESC
R=$(JQ "[...document.querySelectorAll('.f-mascot-btn')].length")
CHK "composer mini-mascot on mobile (stage + mini)" "$R" '^[2-9]$'

echo "== I. console + errors =="
ERRS=$(agent-browser errors | rg -c "pageerror" || true)
if [ "$ERRS" = "0" ] || [ -z "$ERRS" ]; then ok "zero page errors"; else bad "$ERRS page errors" ""; fi
CONSOLE=$(agent-browser console | rg -i "error|warn" | rg -v "Download the React DevTools" || true)
if [ -z "$CONSOLE" ]; then ok "console clean"; else bad "console noise" "$CONSOLE"; fi

echo ""
echo "===================================="
echo "r19 PROOF: $PASS passed, $FAIL failed"
echo "===================================="
[ "$FAIL" = "0" ] || exit 1
