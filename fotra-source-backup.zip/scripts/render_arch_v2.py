from playwright.sync_api import sync_playwright
import pathlib
src = pathlib.Path("scripts/fotra-backend-arch-v2.html").resolve()
out = pathlib.Path("download/fotra-backend-architecture.png").resolve()
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1468, "height": 1600}, device_scale_factor=2)
    pg.goto(f"file://{src}")
    pg.wait_for_timeout(400)
    el = pg.locator("body")
    el.screenshot(path=str(out))
    b.close()
print("rendered", out)
