#!/bin/bash
# Deep page reading for Fotra research (sequential with retries, rate-limit friendly)
OUT=/home/z/my-project/research/pages
mkdir -p "$OUT"

declare -A PAGES=(
  [harness_winder]="https://winder.ai/ai-agent-harness-comparison"
  [harness_tensorlake]="https://www.tensorlake.ai/blog/best-ai-coding-agents-2026"
  [harness_composio]="https://composio.dev/content/best-ai-agent-harnesses"
  [harness_fowler]="https://martinfowler.com/articles/harness-engineering.html"
  [harness_langchain]="https://www.langchain.com/blog/the-anatomy-of-an-agent-harness"
  [harness_anthropic]="https://www.anthropic.com/engineering/harness-design-long-running-apps"
  [harness_dolthub]="https://www.dolthub.com/blog/2026-08-05-best-coding-agent-2026"
  [instinct_vellum]="https://www.vellum.ai/blog/official-instinct-breakdown"
  [instinct_spinnable]="https://www.spinnable.ai/blog/what-is-instinct-ai-guide"
  [instinct_dapta]="https://dapta.ai/blog-posts/ai-news-instinct-ai"
  [instinct_x_yash]="https://x.com/yashhsm/status/2105380670688346335"
  [pi_zechner]="https://mariozechner.at/posts/2025-11-30-pi-coding-agent"
  [pi_dev]="https://pi.dev"
  [codex_platform]="https://developers.openai.com/blog/codex-as-a-platform"
  [minimax_team]="https://agent.minimax.io/docs/techblog/agent-team"
  [letta_memory]="https://www.letta.com/blog/agent-memory"
  [bargein_poly]="https://poly.ai/blog/barge-in-voice-ai-interruption-handling"
  [bargein_hamming]="https://hamming.ai/resources/voice-agent-interruption-handling-runbook"
  [dots_openai]="https://openai.com/index/introducing-dots"
  [dots_opendots_blog]="https://www.copilotkit.ai/blog/introducing-opendots"
  [muse_meta]="https://ai.meta.com/muse"
  [affectui]="https://www.affectui.com/?v=2"
  [inspora]="https://www.inspora.design"
  [assistants_substack]="https://artificialinvestment.substack.com/p/what-do-these-new-ai-assistants-actually"
  [instinct_reddit]="https://www.reddit.com/r/AI_Agents/comments/1wak4is/ive_been_stresstesting_instinct_with_reallife"
  [x_victor]="https://x.com/VictorTaelin/status/2108200878553588091"
  [x_rabi]="https://x.com/rabi_guha/status/2108238432355123572"
  [x_kashyap]="https://x.com/KashyapVisharad/status/2108239102676250933"
  [x_ahmad]="https://x.com/ahmadafterhours/status/2108325993979277417"
  [x_sawyer]="https://x.com/sawyerhood/status/2107872386339287239"
)

order=(harness_winder harness_tensorlake harness_composio harness_fowler harness_langchain harness_anthropic harness_dolthub instinct_vellum instinct_spinnable pi_zechner codex_platform letta_memory bargein_poly dots_openai dots_opendots_blog muse_meta affectui inspora assistants_substack minimax_team pi_dev instinct_dapta instinct_x_yash instinct_reddit x_victor x_rabi x_kashyap x_ahmad x_sawyer bargein_hamming)

for key in "${order[@]}"; do
  url="${PAGES[$key]}"
  f="$OUT/$key.json"
  if [ -s "$f" ]; then echo "SKIP $key"; continue; fi
  ok=0
  for attempt in 1 2 3; do
    if timeout 100 z-ai function -n page_reader -a "{\"url\": \"$url\"}" -o "$f" >/dev/null 2>&1; then
      if [ -s "$f" ]; then echo "OK $key (try $attempt)"; ok=1; break; fi
    fi
    sleep $((attempt * 5))
  done
  [ $ok -eq 0 ] && echo "FAIL $key $url"
  sleep 2
done
echo "=== PAGES DONE ==="
