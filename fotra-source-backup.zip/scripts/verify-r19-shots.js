const ZAI = require("z-ai-web-dev-sdk").default;
const fs = require("fs");

async function main() {
  const zai = await ZAI.create();
  const shots = ["01-dark-idle.png", "03-light-idle.png", "02-palette.png", "07-session-replayed.png"];
  for (const s of shots) {
    const b64 = fs.readFileSync(`/home/z/my-project/download/r19-shots/${s}`).toString("base64");
    try {
      const res = await zai.chat.completions.create({
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: "Describe this UI screenshot in 2 sentences: what mode (dark/light) is it, what components are visible (mascot, palette, rail, thread), and any visual defects (washed-out text, broken layout, overlapping elements)." },
              { type: "image_url", image_url: { url: `data:image/png;base64,${b64}` } },
            ],
          },
        ],
      });
      console.log(`\n=== ${s} ===`);
      console.log(res.choices[0].message.content);
    } catch (e) {
      console.log(`\n=== ${s} === VLM unavailable: ${e.message?.slice(0, 120)}`);
    }
  }
}
main().catch((e) => { console.error("fatal:", e.message); process.exit(1); });
