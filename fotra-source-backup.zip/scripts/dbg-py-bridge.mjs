import { spawn } from "node:child_process";
import { writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";
import os from "node:os";

const dir = path.join(os.tmpdir(), `kdbg-${Date.now()}`);
mkdirSync(dir, { recursive: true });
const src = (await import("node:fs")).readFileSync("/home/z/my-project/src/lib/fotra/server/kernels.ts", "utf8");
const BT = String.fromCharCode(96);
function grab(name) {
  const open = "const " + name + " = String.raw" + BT;
  const start = src.indexOf(open);
  const end = src.indexOf(BT + ";", start);
  return src.slice(start + open.length, end);
}
const PY = path.join(dir, "py-runner.py");
writeFileSync(PY, grab("PY_RUNNER"));

const child = spawn("python3", ["-I", "-u", PY], { cwd: dir, stdio: ["pipe", "pipe", "pipe", "pipe", "pipe"] });
let wire = "";
let pending = null;
let out = "";
let err = "";
child.stdout.on("data", (d) => (out += d));
child.stderr.on("data", (d) => (err += d));
child.stdio[3].on("data", (d) => {
  wire += d.toString();
  let nl;
  while ((nl = wire.indexOf("\n")) >= 0) {
    const line = wire.slice(0, nl).trim();
    wire = wire.slice(nl + 1);
    if (!line) continue;
    const f = JSON.parse(line);
    if (f.type === "bridge" && pending) {
      console.log("[host] bridge frame:", JSON.stringify(f));
      child.stdio[4].write(JSON.stringify({ type: "bridgeResult", bid: f.bid, ok: true, value: { files: ["a.txt"] } }) + "\n");
      console.log("[host] bridgeResult written");
    } else if (f.type === "result" && pending) {
      const p = pending;
      pending = null;
      p(f);
    }
  }
});

function cell(code) {
  return new Promise((resolve) => {
    pending = resolve;
    child.stdin.write(JSON.stringify({ type: "exec", id: "x1", code }) + "\n");
  });
}

const r3 = await cell("files = tool('ws_list')\nprint('FILES:', files['files'])");
console.log("result frame:", JSON.stringify(r3));
console.log("stdout:", JSON.stringify(out));
console.log("stderr:", JSON.stringify(err));
process.exit(0);
