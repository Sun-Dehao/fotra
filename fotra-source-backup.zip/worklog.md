# Fotra Research Project — Worklog

Project: Research + flawless planning for "Fotra" — a voice-first, minimal, Jarvis-style web AI assistant (green/red themes, generative UI previews, great harness, ultra-long context). Owner request: research phase only tonight; build later with user's own AI APIs.

---
Task ID: 1
Agent: main
Task: Setup workspace, clone all referenced GitHub repos

Work Log:
- Created /home/z/my-project/research/{repos,search,pages}, scripts/, download/
- Cloned (shallow): CopilotKit/CopilotKit, CopilotKit/openmuse, CopilotKit/OpenDots, CopilotKit/openbot, Nutlope/hallmark, Appllama/appllama-skills into /home/z/my-project/research/repos/

Stage Summary:
- All 6 repos available locally. openmuse (Meta Muse-style: Expo mobile + server agent engine + browser computer + JEV generative UI), OpenDots (OpenAI-style voice assistant: Vite React + voice + spaces + mascot + learning skills), openbot (multi-harness bot platform: Tauri desktop + Expo mobile + supervisor + 9 harness adapters), hallmark (anti-slop design skill system), appllama-skills (Instinct's app design skills).
- Next: 3 parallel Explore agents (2-a openmuse+OpenDots, 2-b openbot+CopilotKit, 2-c hallmark+appllama-skills) + main agent web research (harness landscape, Instinct, UI refs, X posts).

---
Task ID: 2
Agent: main
Task: Full web research + repo teardowns via 3 parallel Explore agents (2-a, 2-b, 2-c)

Work Log:
- Explore agent 2-a: openmuse + OpenDots teardown -> /research/agent-notes/2-a.md (voice useVoice WebRTC architecture, JEV grounded generative UI, mascot CSS animation, theme system, durable CAS task engine)
- Explore agent 2-b: openbot + CopilotKit teardown -> /research/agent-notes/2-b.md (AG-UI harness abstraction, two-kinds-of-tools split, ask_agent voice delegation, model-providers.json, A2UI, routines/memory/learning)
- Explore agent 2-c: hallmark + appllama-skills digest -> /research/agent-notes/2-c.md (58 slop gates, OKLCH token system, orb-must-be-apparatus resolution, motion physics, Appllama simulator loop)
- 39 web searches digested -> /research/search-digest.md
- 30 key pages read -> /research/pages/*.txt (X posts: VictorTaelin=UniiChat/OptMem infinite context; sawyerhood=build muse/dots/grok-bot with pi-durable; rabi_guha=ChatGPT Intelligent UI DIL reverse-engineering; KashyapVisharad=Thesys OpenUI; ahmadafterhours=Agently generative UI)
- Read: OpenAI Dots launch, Meta Muse, Instinct harness teardown (yashhsm) + Vellum deep dive, harness benchmarks (composio 8-harness study, tensorlake 14-day, winder), Pi design philosophy (Zechner), Letta memory, barge-in best practices (PolyAI), Fowler harness engineering, LangChain harness anatomy, Anthropic GAN planner/generator/evaluator harness, affectUI library

Stage Summary:
- The Oct 2026 landscape fully mapped: OpenAI Dots + Intelligent UI (DIL), Meta Muse (Secure VM), Instinct ($10B, single-thread text agent w/ git-markdown memory), Grok Bot, CopilotKit open-source recreations (OpenDots/openmuse/openbot), Pi minimal harness (85k stars, powers OpenClaw), pi-durable, OptMem infinite memory, Thesys OpenUI standard
- Harness benchmarks: same model across harnesses = 68-88% pass rate variance; Pi = 3x fewer tokens than Claude Code; "pick harness first, model second"
- Next: synthesize Fotra blueprint doc -> grade via subagents -> render PDF deliverable

---
Task ID: 3
Agent: main
Task: Synthesize + grade + refine the Fotra research & blueprint document

Work Log:
- Wrote /research/fotra-research-and-plan.md (~7k words, 9 sections) from all research
- GRADE-1 (research auditor agent): SHIP-WITH-FIXES -> /research/agent-notes/grade-1.md (11 fidelity errors, 14 missing findings, 11 softenings)
- GRADE-2 (blueprint critic agent): SHIP-WITH-FIXES -> /research/agent-notes/grade-2.md (8 blocking spec holes B1-B8, 18 non-blocking improvements, cut list, phase restructure)
- Gap-filled research: MiniMax Code (open-sourced MIT, permission inspection), ZCode (Z.ai official GLM-5.3 harness, Goal Mode), OptMem (426-token hierarchical memory-tree prompt)
- Applied all fixes: fidelity corrections (Instinct anecdote, Appllama=Antmind Ventures not Instinct, approval-gate scoping, attribution hedges, DoltHub counterweight, Letta Code 59.1% vs 41.6%, MiniMax/ZCode paragraphs), blueprint patches (B1 voice-during-run queueing, B2 show_screen reclassified deployment-executed + SCREEN_DELTA lifecycle, B3 budget guard w/ caps + pause-not-kill, B4 auth in Phase 0, B5 persistent-host deployment + SSE contract, B6 run persistence/reattach, B7 approvals-by-voice, B8 key hygiene), persona/entertainment spec, capability matrix, cut list (AppBlock/MCP/routines/browser-computer -> v2 seams), phase split 1a/1b, quality budget 30-40%, 6-component registry w/ HotelCard first-class

Stage Summary:
- Final plan: /research/fotra-research-and-plan.md (~7.5k words) - graded SHIP-WITH-FIXES twice, all fixes applied
- Next: render PDF deliverable to /home/z/my-project/download/

---
Task ID: 4
Agent: main
Task: Produce final graded PDF deliverable

Work Log:
- Read full pdf skill chain (SKILL.md, fonts.md, report.md, cover.md, palette.md, overflow.md, pagination.md, typography.md, fill-engine.md)
- Generated cascade palette (nature/minimal/seed 7 - green family matching Fotra Verdant)
- Built body PDF via ReportLab (md-driven generator: TOC 2 levels w/ clickable links, tables w/ Paragraph cells + repeatRows, XPreformatted code blocks, stat callouts, header/footer w/ roman TOC page + arabic body, CondPageBreak H1 guards) - 25 pages
- Built cover via Template 01 HUD Data Terminal (Playwright/html2poster, 794px, validated by poster_validate + cover_validate after fixing 2 overlaps)
- Merged via pypdf w/ A4 normalization; meta.brand; font.check 0 issues; toc.check pass; pdf_qa 13 warnings -> 4 benign (2 mirrored callout symmetry false-positives, 2 mono-span middle-dot wraps)
- Fixed along the way: code.sanitize entity-rewriting bug (concat-built entities), em-dash/middle-dot line-start binding, lone-dash table cells -> n/a, page-size normalization threshold

Stage Summary:
- FINAL DELIVERABLE: /home/z/my-project/download/FOTRA-Research-Report-and-Product-Blueprint.pdf (26 pages, 233KB, vector, clickable TOC)
- Companions: source markdown, cover HTML source, 3 full research-notes teardowns in download/
- Research phase COMPLETE. Build phase (Phase 0 of the blueprint) is the next session's work.

---
Task ID: 5
Agent: main
Task: Build fotra Phase 0+1a+2 (Sandbox MVP) — voice-first AI companion per the blueprint

Work Log:
- Loaded fullstack-dev skill; initialized Next.js 16 + Tailwind 4 scaffold
- Implemented the blueprint's design system: Verdant/Ember OKLCH token themes, pre-paint script, Space Grotesk/Geist/Geist Mono typography, pure-CSS orb (6 states, never rotates), motion vocabulary with reduced-motion support (globals.css, layout.tsx)
- Core libs in src/lib/fotra/: types.ts (wire protocol + action vocabulary), protocol.ts (tolerant progressive JSON parser + PROTOCOL_DOC system prompt), store.ts (zustand state machine, hand-rolled localStorage persistence with secret scrubbing), voice.ts (Web Speech STT w/ AnalyserNode mic-energy → orb amplitude, silence auto-send, sentence-chunked TTS w/ barge-in cancel), demo-engine.ts (intent router w/ ~30 intents, Instinct-tone persona, multi-turn hotel/RPS/quiz flows w/ sessionStorage pending, interleave steps = screens build WHILE speaking), agent.ts (single-run loop, queue-and-steer, abort semantics, action application incl. pin-rescue, custom BYO-model adapter streaming via SSE + progressive parse)
- API routes: /api/chat (SSE proxy to any OpenAI-compatible endpoint, URL normalization), /api/test-model ("prove it" call)
- UI components in src/components/fotra/: Orb, Thread (transcript + live captions + docked screens), Composer (send/stop pill, queue bar, pinned chips, mobile-docked compact orb), Screens (registry: Card/Stat/Table/Checklist/Hotel/Ask w/ progressive build-in, pin/expand/dismiss lifecycle), WidgetDock (agent-spawned note/clock/todo/timer), SettingsPanel (theme/aura/persona+voice/brain+prove-it/memory/data/honest capability matrix), Onboarding (theme pick → begin), FotraApp (60/40 workbench shell, real telemetry)
- E2E verified via agent-browser + VLM design review (2 rounds): onboarding, theme by voice + settings, full hotel flow (progressive build → budget steering → ordinal/name/button selection → ask card → confirm → booked), rename persona, widget spawn/remove, memory write/query/forget, compare table, checklist, entertainment, queue-and-steer, custom-brain unwired error state, reload persistence (thread + screens + pinned + persona + settings), pin-rescue
- Bugs found & fixed in verification: duplicate screen dock (idempotent attach), user turn text never set, hotel name-matcher matching "the", pin blocked by already-pinned screen, screens lost on reload (now persisted with thread), budget slider prop-sync, mobile layout compaction (orb docks into composer row per blueprint)
- Final state: ESLint 0 errors, console 0 errors, dev server stable, VLM verdicts: desktop CLEAN (9/10 anti-slop), mobile CLEAN

Stage Summary:
- fotra MVP live on the preview: voice-first orb assistant, demo brain (zero keys) + BYO OpenAI-compatible endpoint, generative screens that build mid-sentence, self-customizing persona (rename/theme/aura), agent-spawned widgets, persistent memory + thread, green/red themes
- Deliberately out of scope for sandbox MVP (v2 seams per blueprint): realtime WebRTC voice, server-side SQLite/git memory, background jobs, web_search/open_link tools

---
Task ID: 6
Agent: main
Task: Explain fotra's backend + draw the architecture graph (user request: "what is the backend like? draw a graph")

Work Log:
- Read charts skill chain (SKILL.md -> playwright-css.md -> _rules.md); architecture diagram > 6 nodes -> Playwright+CSS route
- Verified all claims against actual code before drawing: /api/chat (SSE proxy, key never stored, abort propagates), /api/test-model (16-token prove-it), agent.ts (one-run, queue-and-steer, partials kept), protocol.ts (progressive JSON), voice.ts (Web Speech + speechSynthesis), store.ts (localStorage, thread last 120 turns, scrub() redacts sk-keys/phones from persisted text)
- Built 3-band layered diagram (scripts/fotra-backend-arch.html): ① BROWSER the harness (barge-in rail, 4-node pipeline: STT -> agent loop -> prompt builder -> brain switch; demo brain dashed offline path -> parser; parser fan-out say{}/action{} -> voice out + generative screens; STATE bar) ② NEXT.JS SERVER thin (2 routes, no db/sessions/queue) ③ pluggable OpenAI-compatible endpoints; right corridor carries request-down/tokens-up between brain switch, /api/chat and parser (zero line crossings)
- Rendered via Playwright (scripts/render_fotra_arch.py, dsf=2) -> download/fotra-backend-architecture.png
- QA round 1 (geometry probe script + VLM): found 4 labels overlapping neighbor nodes (gaps narrower than labels); fixed by widening r1 gap 24->76, r2 gap 24->104, shortening "turn + queue"->"turn", tightening corridor 182->150px
- QA round 2: probe = ZERO violations; VLM = CLEAN 8.5/10 PASS; applied 2 padding polish tweaks, re-rendered

Stage Summary:
- download/fotra-backend-architecture.png (3200x3246 @2x, 577KB): honest system map of the thin-pipe backend, every claim code-verified
- Reusable artifacts: scripts/fotra-backend-arch.html (editable source), render_fotra_arch.py, probe_arch.py (geometry overlap checker)

---
Task ID: 7
Agent: main
Task: Build the REAL harness (user pushback: "why is this just a demo") — server-side runs, tools, persistent memory, long context

Work Log:
- Loaded fullstack-dev + web-search skills; recon'd agent.ts/types.ts/protocol.ts/SettingsPanel
- Prisma schema rewritten (Session/Turn/Run/ToolCall/Memory) + db:push
- src/lib/fotra/server/tools.ts: budgeted tool registry — web_search (SDK), open_link (fetch+html-clean), remember/forget (SQLite) with per-run caps
- src/lib/fotra/server/engine.ts: the run engine — tool loop (max 6 steps, both brains), zai SDK brain (zero keys) + BYO OpenAI-compatible streaming brain, steering registry + abort registry, budget guard (pause-not-kill, 24k char cap), deterministic remember-extraction (harness-side regex — never trusts model goodwill), memory+summary injection into system prompt, rolling compaction (turns>26 → 120-word summary via model), run records + tool-call audit trail
- API: /api/run (SSE, session+runId first event, req.signal→engine abort), /api/run/steer, /api/run/abort, /api/session (turns/runs/tools/memories), zombie-run watchdog (15min reaper)
- Client: EngineMode "fotra" default; serverRespond adapter in agent.ts replaces client-direct customRespond (BYO now runs THROUGH the harness: same tools); userTurnId threaded; sessionId persisted in settings
- UI: 3-way brain picker (fotra brain / your model / demo), honest capability matrix updated, onboarding + header badge copy updated ("fotra brain · live")
- E2E verified: live web_search run (real Oct-2026 Starlink/Ambani data), tool loop visible mid-run ("thinking with the results…"), stat screen docked through server brain, deterministic memory ("sister's name is Mira") persisted + recalled in a LATER run, reload persistence, lint clean
- CRITICAL BUG found + fixed: ProtocolParser infinite spin (i += -1 on split "actions" key → net-zero loop) — WEDGED the dev server at 100% CPU. Rewrote the parser streaming-safe: cross-chunk carry, partial key matching, nested-array fix (] at depth>0 no longer truncates actions), fuzz regression (7 cases × 7 slice sizes × every split point → ALL PASS, scripts/repro-parser-hang.ts)
- Hardening: 90s model-call timeout (zai), 120s BYO fetch timeout (AbortSignal.any), empty-reply guard, zombie reaper
- Dev server had to be revived after the wedge (kill -9) — double-fork daemonized so it survives tool-call reaping (PPID=1, like agent-browser)

Stage Summary:
- fotra is now a real harness, not a demo: server-side tool-using runs (web_search + open_link + memory), SQLite audit trail (sessions/turns/runs/tool-calls/memories), long-context compaction, budgets, steering/abort endpoints, deterministic memory, pluggable brains (SDK default + BYO endpoint, both tooled)
- Known gaps (v2): WebRTC realtime voice, browser-computer tool, MCP, client-side steer UX (endpoint exists, client still uses local queue), durable runs across server restarts

---
Task ID: 8
Agent: main
Task: Build the complete v1 per the blueprint — "follow the research and plan and code until everything is finished" (user directive after demo-scope pushback)

Work Log:
- Audited blueprint §6–§8 against the Task-7 code → gap list: event-sourced runs/reattach, client server-steering wiring, ask_user HITL suspension+resume, budget pause card, git-markdown vault, memory viewer, providers.json, realtime voice port, Phase-0 debt (auth/Docker/README/DESIGN/PERSONA/slop gate), thread export/search, multi-tab, PWA
- Prisma v2: RunEvent (per-seq event log), Job (CAS-lease queue), Run.suspension, Memory.source → pushed
- NEW server libs: vault.ts (~/.fotra git-markdown memory: per-topic files, commit-per-edit, write-time scrub incl. OTP-context detection, core block ≤8k chars, vaultSearch, md export, daily consolidation), jobs.ts (in-process worker: nap compaction + daily + zombie reaper, CAS claims, heartbeats, system-turn progress lines), providers.ts (providers.json: boot validation, sk- hard-fail, role resolution, prove-it), realtime.ts (OpenDots VoiceService port: SDP relay, ask_fotra delegation w/ steer-waiting-resume routing, 6-cap, 90s cap, receipts)
- engine.ts v2: every emit persisted w/ seq + fanned to subscribers (pending-subscriber registry = order-safe) · disconnect ≠ abort (SSE writer is a subscriber, not owner) · ask_user + budget step-cap SUSPEND runs (state JSON → Run.suspension) · resumeRun (claim-atomic, budget: continue/stop/finish-quietly, ask: answer injection; seeds subscribers race-free) · grounding (table/hotel rows must trace to this turn's tool corpus; drops flagged honestly) · undrained steering restored via unsteered event (never lost) · 3 brains (sdk/byo/providers-role) · session event logged as event #1 (replay identity)
- Routes: runs/[id]/events (replay+live tail SSE, 15s heartbeats), runs/[id]/resume, runs/[id]/status, session (+export=md, +q= search, steerMsgs exposed), memory CRUD, providers(+test), voice/calls(+/active/end/compute), unlock; middleware.ts (FOTRA_TOKEN gate: constant-time compare, origin CSRF, /unlock page)
- Client v2 (agent.ts rewritten): single ingestServerEvent for live/resumed/replayed · steering via POST + steered-queue marking · answerSuspended (card click OR spoken — one path) · reattachIfNeeded (status check → full-log replay even for terminal runs; retry on cold compile) · reconnect-by-seq on stream break · open_link handoff action · multi-tab BroadcastChannel (owner/readOnly/takeover) · store: restoreAssistantTurn, pushSystemTurn, markSteered, readOnly
- UI: AskBody resume-aware (budget hint line), Thread system hairlines + voice-receipt chips, Composer call bar (timer/mute/speaker/end, 14:30 danger), SettingsPanel: voice mode + realtime voice select + key status, 4-way brain picker w/ provider lights + prove-it, server-backed memory viewer (edit/delete/provenance), thread search + server export; Orb swatches token-ized (f-swatch in globals.css); PWA manifest + icon
- Packaging: Dockerfile (standalone, git in image, /data + /fotra-home), compose.yml, README (serverless-out-of-scope statement), DESIGN.md, PERSONA.md (10 dialogues), slop-gate.sh (emoji/hex/gradient/banned-copy/console.log/sk- checks — wired as npm run slop/check)
- protocol.ts: plainText rescue — bare JSON tool calls inside prose are extracted as actions + stripped from speech (balanced-brace scanner, string/escape-aware)
- E2E PROOF (scripts/e2e-harness.sh + e2e-suspend.sh + e2e-resume-unit.mjs, all persisted): 26/28 full suite + 6/6 budget pause (pause card → continue resume → done, double-resume refused) + 6/6 resume unit + LIVE ask_user completion (model asked → suspended → spoken answer resumed → run continued WITH a fresh web search) + browser E2E via agent-browser (tool-using stat screen, mid-run reload → full event-log reconstruction + continued run, 0 console errors) + parser fuzz extended (4 rescue cases × 5 chunk sizes, ALL PASS)
- Bugs found & fixed in verification: subscribe-before-register silent no-op (client saw only session event — fixed w/ registerHandle pending-drain + route reordering); session event missing from log (broke replay identity); cut -f3/f4 extraction; E2E turn-id collisions silently skipping inserts; steering lost when run ends before drain (unsteered restore); rate-limit (429) resilience via pacing + retries; instrumentation process.exit breaking edge bundle (split instrumentation-node.ts)
- Artifacts: download/fotra-backend-architecture.png regenerated (v2 topology, VLM 9/10 PASS), scripts/fotra-backend-arch-v2.html source

Stage Summary:
- fotra is now the full blueprint v1: event-sourced tool-using runs that survive reloads/disconnects, HITL suspend/resume on one path for touch+voice, budget pause-not-kill, grounded comparison screens, git-markdown memory vault with scrubbing + daily consolidation, providers.json w/ key hygiene, realtime voice relay (ask_fotra → same harness; honest 501 without key), auth/self-host packaging, PERSONA/DESIGN docs + slop gate
- Remaining honest seams (documented, not faked): realtime WebRTC leg needs a server OpenAI key to exercise end-to-end; browser-computer / routines / MCP are v2 per blueprint cut list; client steering UX marks steered items but server-side queue persistence across restarts is the v2 refinement

---
Task ID: 9
Agent: main
Task: THE FULL REDO — "REDO FULLY TONIGHT… better than any vibe coded oh my pi, better than openclaw, muse, bot, dots, and all harnesses" + "just follow the research plan"

Work Log:
- Audited the gap between the built v1 and the SOTA set (Muse Secure VM + browser computer + 60 apps; pi/OpenClaw sub-agents + routines + MCP; Dots proactive): the engine was solid but the capability layer and the shell were missing — the app still looked like the MVP chat
- Prisma v3: Artifact, Routine, McpServer, TodoItem models + Run.parentRunId/workerName/origin (sub-agent linkage) — pushed + regenerated
- NEW server capability layer (6 libs):
  · sandbox.ts — run_js/run_python: real child processes (node / python3 -I) in the session workspace cwd, 20s hard kill, output caps, new-file detection → Artifact rows
  · browser-computer.ts — headless chromium (playwright, persistent per-session context): navigate/click/type/extract + jpeg screenshot every action (≤6/run), 5-min idle reaper
  · workspace.ts — per-session file tree under ~/.fotra/workspace (path-traversal guard, binary sniff, 200k caps), read/write/patch
  · subagents.ts — spawn_task: child Runs (parentRunId), focused 3-step loop, banned tools (ask_user/spawn_task/mcp_connect), worker screens stream progress into the PARENT run, ≤3 parallel
  · mcp.ts — MCP streamable-HTTP client (initialize → tools/list → tools/call, SSE-wrapped responses handled), namespaced mcp_<server>_<tool>, DB-persisted connections
  · routines.ts — "every N minutes"/"daily@HH:MM" parser, 30s in-process ticker, fireRoutine → real executeRun (same tools/audit), marker system turn + ambient answer
- events.ts — shared ServerEvent + ToolCtx (emit callback) to kill the engine↔tools import cycle; tools get a progress channel (screenshots, worker phases) into the run stream
- tools.ts v2 — 20-tool registry + dynamic mcp tools (toolDoc(await mcpToolDoc())), auto-screens (code/browser/files/todo) as the ui-payload of the pi llm/ui split
- engine.ts v3 — PARALLEL tool batches (Promise.allSettled, atomic sync budget claims), spawn_task grouped into parallel workers, auto-screen emission from ToolResult.screen, MAX_STEPS 8, ms on tool events
- NUDGE GUARD (the reliability fix): model announce-without-doing detected two ways — (a) zero actions on tool-shaped asks (userDemandsTools: explicit tool names / "use the X tool" / "in parallel"), (b) PARTIAL artifacts (expectedArtifacts vs deliveredArtifacts: board/chart/table/checklist, todo_write counts) — up to 2 corrective retries w/ escalation (2nd = exact JSON template), say_reset event keeps the transcript undoubled, honest "couldn't produce X" status when spent
- protocol.ts v2 — new screen components documented (todo/code/browser/worker/chart), CRITICAL tools-are-doing + all-artifacts-in-one-reply doctrine, de-anchored the "on it —" phrase
- API: /api/routines (CRUD + run-now), /api/mcp (connect/list/disconnect), /api/workspace (list/read/write), /api/artifacts, /api/todo, /api/session/poll (ambient layer); instrumentation boots the routine ticker
- Client: ServerEvent say_reset ingest + resetTurnText; tool events → toolActivity feed (ms timings) + workspace refresh hooks; wireAmbient (25s poll — routine answers land in the thread while idling, quiet marker lines)
- UI REDO — the instrument panel: FotraApp 3-zone shell (harness rail · thread · orb stage + activity rail), LeftRail (files w/ inline read · routines w/ create/pause/run-now/delete · MCP connect w/ live tool lists · memory), ActivityRail (live tool telemetry), mobile drawer + hint strip; 6 new screen components in Screens.tsx (Code w/ stdout/stderr/exit/ms · BrowserFrame w/ screenshot · WorkerCard w/ phases · TodoBoard · Files · Chart SVG bar/line w/ data-ink ramp tokens in both themes)
- demo-engine v2 — 7 new zero-key demo flows (code computes for real client-side; browser frame w/ rendered SVG mock; parallel worker cards animating; files; board; chart; routine explainer) — the demo brain now demos the whole surface
- README + SettingsPanel capability matrix rewritten honestly (20 tools listed; sandbox = timeout-bounded not VM-isolated; realtime needs server key)
- E2E PROOF: scripts/e2e-v3.sh — 15/15 ALL GREEN (sandbox+file+code screen · browser navigate+frame+extraction · parallel workers+cards · multi-artifact board+chart · routine create/fire/ambient-poll · MCP honest 502 · nudge-guarded run_js)
- Live UI E2E via agent-browser: python squares.csv run (code screens docked, files rail auto-refreshed, inline CSV read, activity rail w/ timings), wikipedia browser_navigate (real screenshot in frame, real featured-article answer), Lisbon board+chart (nudge fired mid-run: "missing board — asking again" → delivered), routine fired from rail zap → ambient answer landed w/ marker line; fresh-console ZERO errors; screenshots: fotra-redo-hero-desktop / -ember / -ember-settings / -code-run / -browser / -routine / -chart-board / -mobile
- Stability fixes along the way: playwright installed as project dep (was global-only), wsList import fix, dev server daemonized via scripts/start-dev.sh (double-fork, survives reaping), tsc OOM worked around via eslint + route-compile checks
- Model-flake fixes proven in event logs: say_reset + escalated nudge turned tool-less replies into delivered runs (chart-only → +todo after one nudge)

Stage Summary:
- fotra is now the full SOTA harness per the blueprint with the v2 seams PULLED FORWARD and proven: sandbox (js+python), browser computer (screenshotted), parallel sub-agents, workspace files, todo board, charts, routines (scheduled autonomous runs), MCP client, 20-tool belt, parallel tool batches, nudge-guarded reliability, ambient results — the instrument-panel UI telegraphs all of it (rail + activity telemetry), demo brain demos every capability zero-key, and 15/15 E2E + live browser proofs back every claim
- Honest remaining seams (documented in README + settings): realtime WebRTC leg needs a server OpenAI key to exercise end-to-end; sandbox is timeout-bounded (not VM-isolated) — single-user self-host trust model; steering queue persistence across server restarts is v-next

---
Task ID: 10
Agent: main
Task: "literally oh my pi is the easiest way to make your own instinct/dots / your current one is still basic / go clone and refer to it" — clone can1357/oh-my-pi, teardown, port the winning mechanisms into fotra, prove them

Work Log:
- Cloned can1357/oh-my-pi (★34.9k, fork of badlogic/pi-mono, 292MB/8.9k files) into research/repos/oh-my-pi; located via GitHub API search after web-search 429'd
- 3 parallel Explore teardowns -> research/agent-notes/{t-a-omp-agent-loop, t-b-omp-tools, t-c-omp-memory-compaction}.md with file:line receipts: agent loop (NO max-steps — deadline+abort only; tools run on stop too), TTSR (TtsrManager: regex traits analysis, mid-stream abort, transcript rewind, ttsr-injection custom message, retry-from-same-point), 10 model roles + fallback chains + xxHash32 session-sticky creds, eval (persistent py/bun kernels, fd-multiplexed NDJSON protocol, /v1/tool loopback bridge w/ bearer tokens), task (hidden yield tool, outputSchema validation, 3-retry-then-override, worktree isolation), hashline edit (xxHash32-of-normalized-file tags, stale recovery via diff remap, unseen-anchor rejection), memory (retain/recall/reflect/learn + manage_skill), checkpoint/rewind (branchWithSummary), magic keywords (prose-masked), snapcompact (deterministic, keep-source-re-render), advisor (aside/concern/blocker), Agent Hub
- Prisma v4: StreamRule model + push
- NEW server libs: ttsr.ts (rules CRUD + sync StreamWatcher.feedAndCheck per-delta matcher + 4 anti-slop seed rules), kernels.ts (persistent py/js kernels, 5-fd stdio protocol: 0=commands 1=stdout 2=stderr 3=protocol-wire 4=bridge-results, tool()/web_search()/read_file()/write_file() prelude, bridge budget 6/cell, banned re-entry tools, 20s cell kill, 10min idle reaper, generation-checked replacement), advisor.ts (second-model reviewer: aside/concern/blocker JSON, ≤2/run)
- workspace.ts: hashline — contentTag (sha1-4hex of normalized content), session edit-store snapshots on every read/write, wsPatchHashline (tag+line ops, stale detection, 1-line drift remap recovery, fresh-tag issue)
- subagents.ts v2: OutputSchema (lite schema), hidden yield tool interception, validateYield (missing/badType), 3-retry-then-best-effort, worker BYO now stream:false, smol role resolution
- vault.ts v2: vaultRecall (token overlap × exp recency decay, index + vault tiers, dedupe), vaultLearn (skill file in vault/skills + memory row so recall finds it), vaultSkills/matchSkills (trigger-matched injection into system prompt), reflect in tools.ts (model synthesis over memories w/ citations)
- engine.ts v4: TTSR integration (cut → ttsr event + say-reset-free retry same step, TTSR_MAX_RETRIES 2 then reminder-in-context), SteerKick (interrupt-steering kicks the CURRENT call, ≤4/run), deadline 6min pause-not-kill (MAX_STEPS 8→24 ceiling), magic keywords (ultrathink → thinking enabled + notice; orchestrate → fan-out contract injection, prose-masked), advisor pass per step + BLOCKER forces corrective turn, checkpoint/rewind context surgery (event-log collapse + report), brain fallback chain (custom/provider → fotra sdk floor, 2min endpoint cooldowns), 429 backoff on the sdk path (2s/5s/10s), parseOutputSchema, skills block in buildMessages
- tools.ts v3: run_js/run_python → runCell (persistent kernels + bridge closure re-entering runTool with the same ctx), kernel_reset, ws_read returns tag, ws_patch hashline+legacy modes, recall/memory_search alias, reflect, learn, checkpoint/rewind stubs for workers, spawn_task outputSchema — 25 tools
- protocol.ts: PROTOCOL_DOC v4 (kernels + bridge calls, tag discipline, outputSchema yields + agent:// citation, checkpoint/rewind, advisor notes, stream-rules behavior)
- API: /api/rules (GET/POST/PATCH/DELETE + live test box)
- Client: agent.ts ingest for ttsr/advisor/checkpoint/rewind events (logTool chips + status lines), Code screen v2 (kernel · cell N badge, bridge chips w/ ok/fail), SettingsPanel RulesSection (list/toggle/delete/add + regex test box, "would cut on" feedback), capability matrix rewritten honestly, demo-engine v4 flows (kernel 2-cell demo, ttsr, advisor, rewind) + route fix (show-demo no longer hijacks harness asks)
- E2E INFRASTRUCTURE: scripts/mock-brain.mjs — a deterministic OpenAI-compatible SSE server that plays "the model" (scripted protocol replies per scenario, streams 14-char deltas, honors stream:false, real tag extraction from tool results, TTSR retry behavior) — makes the harness provable without SDK quota
- BUGS FOUND + FIXED: (1) TtsrCut swallowed by the SSE line-parse catch in byoCompleteStream (onChunk inside try — moved control-flow rethrow), (2) fd1/fd3 pipe race — stdout lands a tick after the result frame (40ms drain beat), (3) worker BYO expected non-streaming JSON while defaulting to stream (now explicit stream:false), (4) vaultLearn memory row missing sessionId (silently failed FK), (5) mock req.on("close") fired at body-consume (Node 18+ semantics) killing the stream interval (res.on("close")), (6) demo "show me" route hijacked harness-keyword asks, (7) stale dev-server processes held port 3000 across restarts (kill + clean restart), (8) prisma client not regenerated after schema push
- E2E PROOF: scripts/e2e-v4.sh (rules CRUD + matcher: 6/6) and scripts/e2e-v4b.sh DETERMINISTIC (mock model, real harness): 31/31 ALL GREEN — kernel state persists ACROSS RUNS (cell 2 sees cell 1's variables), loopback bridge (ws_read✓ from inside python + chip on screen), hashline (patch-on-tag landed, lines 1+3 untouched, stale tag "beef" rejected, zero corruption), typed yield (scout yielded validated JSON + agent://scout + audit), checkpoint/rewind events, TTSR (mid-stream cut, rule named, clean regeneration, disclaimer never reached transcript, hit counter +), learn→recall audit-verified
- Kernel protocol unit test: scripts/test-kernels.mjs 14/14 PASS (persistence, bridge round-trip, error frames, kernel-alive-after-error, require+file writes)
- Live UI proof via agent-browser: kernel demo (KERNEL · CELL 1 → CELL 2 + BRIDGE → chips docked mid-speech), ttsr + advisor demo cards, settings rules editor with live test ("NO-AI-DISCLAIMERS would cut on 'As an AI'"), fresh console 0 errors; screenshots: download/fotra-v4-{kernel-demo,ttsr-advisor-demos,rules-editor}.png
- SDK quota note: the z-ai SDK 429'd for the entire late session (teardown agents burned it) — every mechanism proven via the deterministic mock path instead; the SDK-live re-verification (e2e-v3.sh suite, v4 [9] fallback-chain live fire, a real web_search run) is queued for when the quota window resets

Stage Summary:
- fotra now ports oh-my-pi's entire winning mechanism set: TTSR mid-stream stream rules (CRUD + editor UI), persistent kernels with the loopback tool bridge, hashline tag-anchored edits, typed worker yields with agent:// citation, an inline advisor, checkpoint/rewind context surgery, interrupt-steering, deadline-not-steps, brain fallback chains with cooldowns, magic keywords, recall/reflect/learn-as-skill memory — all E2E-proven deterministically (31/31 + 6/6 + 14/14), plus the honest seams kept honest (kernels are timeout-bounded not VM-isolated; recall is scored keywords not embeddings; realtime WebRTC still needs a server key)

---
Task ID: 5
Agent: main
Task: The copy-paste mandate — steal oh-my-pi's TESTED compaction subsystem verbatim instead of remaking; audit what "still basic" meant; report the backend honestly

Work Log:
- Audited the v4 port fidelity against oh-my-pi source: our TTSR is a 194-line miniature of their 1,148-line TtsrManager (regex-only, no ast-grep/scoping/markdown rules); our nap job was a naive 120-word summary vs their 7,475-line compaction subsystem (17 files: provider-native transports, branch-summarization, streaming v2, pruning, shake, tool-protection)
- Confirmed the user's instinct: the biggest UNPORTED tested mechanism was COMPACTIION — the ultra-long-context story (day-one requirement) was the weakest seam
- NEW src/lib/fotra/server/compaction.ts — the steal, not the remake: their exact constants (protectTokens 40k, minimumSavings 20k, DEFAULT_RESERVE_TOKENS 16384, reserve = max(15% window, floor), summary budget = floor(0.8 × reserve)), their exact notices (SUPERSEDED_NOTICE "[Superseded by a newer read of this file]", USELESS_NOTICE), their handoff prompt VERBATIM (prompts/compaction-summary.md — Goal/Constraints/Progress/Decisions/Next Steps/Critical Context)
- Two tiers, their ladder: tier 1 prune (blank old oversized/superseded TOOL RESULTs outside protect window, warm-tail guarded, minimum-savings floor with undo), tier 2 compact (handoff summary splices over the covered prefix, once per run, persists to session.summary for the next run's buildMessages injection)
- Honest adaptations, documented in-file: chars/4 token estimation (no tokenizer), window from RunParams/env (BYO models declare their own), warm tail scaled to window share clamped to their 8-message cap, small-window reserve clamp
- Engine wiring: RunParams.contextWindow + LoopState.compacted (+ state0/reviveState), maintainContext hook at every loop step BEFORE the model call (emits prune/compact tool chips + status lines), summarizer routes through the SAME brain path (complete()) so E2E's mock brain serves handoffs too
- jobs.ts nap compression: naive prompt replaced with the stolen omp handoff format (capped for the 1500-char column)
- run route passes body.contextWindow through
- Kernel budgets raised 4 → 12 (local tools, MAX_STEPS 24 + 6-min deadline already bound the run; a real data task needs 6+ cells — found via E2E when cell 5 got budget-refused)
- Mock brain: handoff-summary scenario (recognizes the summarizer call, replies canned omp-format summary), chunk-dump scenario (8 python cells × 4.2k-char outputs, counter rides in tool results so it survives context replacement, budget-refusal branch), MOCK_TRACE request logging
- E2E scripts/e2e-v5.sh DETERMINISTIC (mock model, real harness): [A] window 8000 → compact fires exactly once (no spiral), prune fires as the post-compact pressure valve, run completes cleanly through context replacement (7 cell bridges), session.summary persisted with the omp handoff shape (## Goal…, summaryUpTo run:…), zero error events; [B] default window 131072 → zero compact/prune false positives, clean completion — 12/12 ALL GREEN
- Bug found + fixed en route: say events stream in fragments — phrase assertions must join "text" deltas first (e2e says() helper); stale mock threshold after sed; warm tail dead-code at small windows
- Regression: e2e-v4b.sh 31/31 ALL GREEN, test-kernels.mjs 14/14 PASS — total 57 green checks live
- Scoped typecheck (tsconfig.check.json, src only): zero errors in compaction.ts/engine.ts/jobs.ts/run route (pre-existing friction elsewhere untouched; full-project tsc OOMs on the research clones — include pattern, not ours to fix tonight)

Stage Summary:
- fotra now steals omp's compaction subsystem at the source-code level: their numbers, their notices, their prompt — with adaptations documented in-file. The ultra-long-context story is now mechanism, not aspiration: prune reclaims old tool output, compact hands off when the window would overflow, the summary persists across runs
- Remaining honest gaps vs oh-my-pi (the "not yet stolen" list): TTSR depth (ast-grep, text/thinking/tool scoping, markdown rules), 60+ provider registry + auth gateway, provider-native compaction transports (anthropic/openai native endpoints), branch-summarization + shake tiers, speculative-execution (961 lines), mnemopi embedding memory, Rust structural editing (pi-edit/ast — desktop-IDE machinery, mostly N/A for a voice web assistant)
- E2E state: 57 green (31 v4 + 14 kernels + 12 v5)

---
Task ID: 6
Agent: main
Task: "keep stealing also i don't like our UI / revamp it and add like the dots/grok bot/muse/oh my pi mascots thing" — steal the mascot systems from the cloned references, revamp the UI around a face

Work Log:
- 4 parallel source teardowns with file:line receipts: OpenDots (CopilotKit — the plush-dot mascot: state-as-CSS-class, single-50%-keyframe loops, hash×31 stable character color, "name is state" alt narration, reduced-motion kill switch; their exact constants: bob 2s/−5px ease-in-out, call-breathe 1.5s/scale 1.06, saturate(0.5) paused; favicon SVG geometry = the dot's canonical shape), openmuse (static capybara mascot + framing recipe; NO animation/voice code exists — its steal was structural: framing, morph-button, status-string state machine), oh-my-pi (collab-web tokens.css discipline: "the ONLY file allowed raw colors", --ease-out cubic-bezier(0.16,1,0.3,1), sh-dot ping/warn dot grammar, working-row: spinner+elapsed+shimmering intent+stop, sh-ambient 6-7% wash, OmpMark π path + oklch mark stops, orbit spinner; TSP tone/fx vocabulary), fotra self-audit (4 broken classes: f-mono, f-btn-primary, f-btn-ghost, f-progress — Settings rendered native browser buttons; right stage unscrollable clipping widgets; dead --amp var; gutters misaligned; CallPhase never drove the orb during realtime calls)
- NEW Mascot.tsx — 4 SVG skins, one component: dot (OpenDots favicon path verbatim: plush body + ellipse eyes + q-smile, mouth opens when speaking), blob (Muse framing: ears+ squat body + calm small eyes + boxy snout + nostrils), pi (omp OmpMark path verbatim M10 14h44v9H43v33h-9V23h-9v22h-9V23H10z + their gradient stops as CSS vars), bot (rounded slab, accent-tipped antenna, speaker-slit mouth that widens when speaking); useId-unique svg defs; orbiting spark while working; coatFor = OpenDots' hash×31 %4 stable-identity trick (rename → new coat)
- globals.css: full mascot animation system with stolen constants (f-m-bob = their bob verbatim; f-m-speak = their call-breathe × our --spk-level; f-m-listen × --mic-level; blink 5.4s; lookup 480ms; shake+desaturate error), 4 coats as oklch hue vars (coat 0 follows the locked theme per [data-theme="ember"] rule; coats 1-3 fixed sky/gold/orchid), omp mark stops verbatim; FIXED all 4 broken classes (f-mono → geist mono, f-btn-primary/f-btn-ghost → the two app buttons, f-progress → omp-style indeterminate meter), NEW f-live-dot (ping ring, omp sh-dot), f-work-intent (text-shimmer sweep, omp intent), f-ambient (6-7% stage wash), --f-ease (omp entrance curve) wired into f-rise 320ms; orb body → halo (state-tinted radial, --amp revived as max(mic,spk)); reduced-motion extended to every mascot animation
- Orb.tsx: the mascot IS the orb now — button semantics kept, character inside f-orb-fill, mic moved to a corner chip (hidden at compact 44px), bloom applies to the character
- FotraApp.tsx: stage rebuilt — scrollable (f-scroll overflow-y-auto; the clipped-widgets bug), ambient wash, NEW WorkingRow (omp steal: live dot + mm:ss elapsed ticking 1s + shimmering statusLine + esc/stop button; driven by new store.runStartedAt), header persona chip (mascot + name → opens settings), hydration splash = mascot, gutters unified px-4 sm:px-8
- Thread.tsx: empty state centers the mascot (88px) + "try saying" gains "Wear the π face"; assistant turns wear a 26px avatar; working line uses f-live-dot
- Composer.tsx: input → auto-growing textarea (1→5 lines, 148px cap, shift+enter newline); CallBar live dot
- SettingsPanel: appearance leads with the mascot skin picker — 4 live previews, lineage note (dot≈Dots, blob≈Muse, π≈omp, bot≈Grok), wired to persona.mascot persistence
- types/store: Persona.mascot (MascotSkin) + DEFAULT_PERSONA.mascot "dot" (back-compat via loadJSON spread); store.runStartedAt (epoch; agent.ts startRun stamps it, finalizeRun clears)
- voice-realtime.ts: patch() mirrors call phase into the store (the audit's "orb goes dark during realtime calls" gap — the face now reacts on calls; end-call hands back to idle unless an engine run owns the phase)
- demo-engine: face-swap handler ("wear the X face" → persona patch + remember) + mascotScript with per-skin voice; protocol.ts PROTOCOL_DOC documents the mascot field so real brains can face-swap too
- Screens.tsx worker card: proper .f-progress usage; Onboarding copy mentions the face; fixed 3 pre-existing persona literal bugs en route (routines route + server routines used aura:"verdant" — a theme value in an aura slot; voice-calls fallback persona lacked mascot)
- Deleted stale tailwind.config.ts (unreferenced — Tailwind v4 @theme in globals.css is the system)
- Typecheck (tsconfig.check.json, src only): ZERO mascot/persona errors; remaining 36 are pre-existing server-file friction (kernels/browser-computer/protocol casts), untouched tonight
- PROOF (scripts/proof-v5.sh + proof-v5b.sh, deterministic DOM assertions through agent-browser; SDK vision 429'd so proof is DOM-level): A idle dot anatomy 12/12 (4 mascots on surfaces, stageSkin dot, pal 2 gold, breathe+blink animationNames live, mic chip present + hidden at compact, persona chip, thread avatar, ambient wash, stage overflowY auto); B skin picker 7/7 (settings opens, 4 radios + 4 previews + lineage note; π click → stageSkin pi, OmpMark path verbatim in DOM, --m-mark-a resolves, persona persists mascot:"pi"); C voice face-swap 6/6 ("wear the bot face" via demo brain → stage+chip+avatar all bot, reply mentions the swap, LS persists); D theme 6/6 + D2 rename-recoat (ember persists; "call yourself Eve" → pal 2→0 live recoat, coat hue 152→28 when ember — coat 0 follows the theme by design); E working row caught mid-run (wr:true + live dot + stop button + phase thinking, screenshot); F console + page errors: CLEAN; screenshots: download/fotra-v5-{idle-dot,settings-skins,pi-picker,stage-pi,bot-swap,ember,settings-pi-picked,bot-faceswap,ember-coat,working-row,ember-eve-coat0}.png

Stage Summary:
- fotra now has the mascot thing the references have, stolen at the geometry-and-constants level: the Dots plush dot, the Muse blob, oh-my-pi's π mark (path + gradient stops verbatim), and a bot — one persona, four faces, hash-stable coats that re-mark on rename, amplitude-reactive to the live mic/speaker levels, fully wired to the phase state machine incl. realtime calls
- The UI revamp: scrollable mascot-centered stage with ambient wash + the omp working row (live dot · elapsed · shimmering intent · stop), persona chip in the header, avatars in the thread, a growing composer, and the four broken CSS classes fixed (no more native browser buttons anywhere)
- All greens tonight: DOM proof A-F across skins/picker/theme/swap/working-row/console-clean; scoped typecheck zero new errors; DESIGN.md constitution extended with the face section
- Honest seams, unchanged: realtime WebRTC still needs a server OpenAI key; the demo brain's face-swap is keyword-scoped; VLM screenshot verification was 429-blocked (quota window) so proof is DOM-level + screenshots saved for eyeballing

---
Task ID: ops-server-restart
Agent: main
Task: User reported "server isn't on" — restart dev server after session/context restart

Work Log:
- Confirmed localhost:3000 was down (no node processes, context restart had killed it)
- Relaunched `npm run dev` (nohup, background)
- Added `allowedDevOrigins: ["*.space-z.ai", "*.space-z.dev"]` to next.config.ts to silence cross-origin warning from preview domain
- Verified: GET / → 200 (title "fotra"), GET /unlock → 200

Stage Summary:
- Dev server UP on :3000, preview link working
- Pending work unchanged: oh-my-pi clone/teardown, keep-stealing, UI revamp + mascot system

---
Task ID: r17-ui-revamp-mascots
Agent: main
Task: "keep stealing also i don't like our UI / revamp it and add like the dots/grok bot/muse/oh my pi mascots thing"

Work Log:
- Cloned badlogic/pi-mono (upstream Pi) alongside existing oh-my-pi; dispatched 2 parallel research agents:
  (a) mascot implementations across OpenDots/openmuse/openbot — verdict: openbot's AgentOrb system (6-state motion vocabulary, MotionValue amplitude pipeline, MIT) is the goldmine; OpenDots contributes character faces + call-screen composition
  (b) oh-my-pi + pi-mono steal targets — collab-web cockpit, stt/tts pair, agent event contract, personality + theme systems mapped
- STOLE (copy-paste, adapted): ai-core.tsx (AIState + AI_STATE_MOTION + useAudioAmplitude + useSimulatedAmplitude, extended with fotra "working" preset), agent-orb.tsx (mesh orb), live-waveform.tsx (ElevenLabs bars) → src/components/fotra/mascot/
- Built new unified Mascot: mesh-orb body + 5 faces (dot/blob/pi/bot/orb) + 6 explicit coats (iris/verdant/ember/ice/rose/mono); phase→AIState 1:1 mapping; amplitude blending (real mic via voice.ts onLevel when listening — no second getUserMedia; simulated sines when speaking/working)
- voice.ts: added onLevel(cb) subscription + stream getter
- types/store: persona.coat field (migration-safe hydrate), MascotSkin + "orb", bloom on coat/mascot change
- globals.css: token retune (deeper near-neutral dark, radius 0.8rem), new mascot v2 CSS (coats, face, bloom, press button), THE STAGE styles (wash, glass, rail buttons, waveform strip); removed dead .f-orb system
- FotraApp rewritten as THE STAGE: mascot hero center, glass thread side panel (toggle → full stage), floating glass harness rail, activity strip (latest 3 tool calls), widget dock on stage, omp working-row kept, mobile = rail drawer + thread overlay + composer mini-mascot
- StageMascot/MascotButton: press-to-talk, barge-in, error dismiss, waveform strip
- SettingsPanel: 5-skin grid + 6-coat grid with live orb previews
- Fixed pre-existing bug: `import homedir from "node:os"` (default import) broke under Turbopack externals in workspace.ts + browser-computer.ts → named import (was causing 500s on all server APIs after cache cleared)
- Fixed: stray brace from CSS splice; AgentOrb default export

E2E (agent-browser, 11 screenshots in download/revamp-shots/):
- home 200, onboarding flow ✓, mascot geometrically centered in stage ✓
- full engine run via composer: note widget docked, back to idle ✓
- re-skin: name→Nova, skin→bot, coat→ember applied live + persisted across reload ✓
- thread collapse→full stage (mascot re-centers, width 1440) ✓; harness flyout ✓
- mobile 390×844: composer mini-mascot ✓, rail button ✓, thread overlay ✓
- console errors: ZERO

Stage Summary:
- UI v3 "The Stage" shipped: dark mascot-first cockpit, replaces the 3-zone instrument panel
- Mascot system: openbot's living mesh orb + fotra's 4 lineage faces + pure-orb 5th skin, 6 explicit coats — rename/re-skin fully realized (persona.name + persona.mascot + persona.coat, persisted)
- Steal ledger now: openbot (orb stack, waveform), OpenDots (faces, composition), openmuse (blob framing), oh-my-pi (π mark, working row, ambient wash), ElevenLabs (waveform bars)
- Dev server: launch with `setsid nohup npm run dev` (plain nohup gets reaped between shells)
- Pending from user's earlier asks: honest SOTA assessment vs other agents/harnesses (deferred), backend description (answered previously in r-series)

---
Task ID: r18-steal-batch
Agent: main
Task: "keep working and give zip code" — second steal batch from the fresh oh-my-pi/pi-mono + mascot teardowns, prove it, ship the zip

Work Log:
- 2 parallel Explore teardowns on the already-cloned repos: (a) oh-my-pi + pi-mono — pi-mono's minimal loop (~500 lines) vs omp's refinements; the shared/exclusive scheduler (agent-loop.ts L3768–3794, lastExclusive + sharedTasks chains); the 3-channel steering abort model ("never kill side-effecting tools mid-flight"); AgentToolResult content/details/useless split; speakable.ts (393 lines: FIRST_SEGMENT_MIN=12 / SOFT_CLAUSE_LEN=160 / MAX_SEGMENT=280, fence-swallowing, URL→host, path→basename); user-interjection.md steering wrapper verbatim; sessions-as-JSONL-trees; personalities-as-markdown; collab-web tokens.css discipline. (b) mascots — openbot AgentOrb + AIState contract (already stolen in r17), OpenDots character-skin pattern, openmuse /identity endpoint + `You are ${name}, a ${tone} agent` system-prompt injection
- STOLE (4 ports, all file:line-attributed in comments):
  1. omp shared/exclusive scheduler → engine.ts tool batch: EXCLUSIVE_TOOLS (ws_write/ws_patch/run_js/run_python/kernel_reset/todo_write/learn) serialize behind the last exclusive call; shared reads ride concurrently; results land in indexed slots → BATCH-order emission (providers require tool_use/tool_result order) + omp's synthetic-result discipline (every unfulfilled call still gets a paired result in the finally block)
  2. omp user-interjection steering wrapper → engine.ts steering drain: mid-run interjections now land as `<system-notice> priority; supersedes conflicting prior instructions…` instead of the bare `[steering, mid-run]` prefix
  3. omp speakable segmenter → NEW src/lib/fotra/speakable.ts (constants verbatim) + agent.ts flushSpeech (streaming takes: first take at 12 chars → speech starts while the model writes; run.speechStarted state + resets + say_reset re-arms it) + voice.ts chunk (batch segmentation for ambient speaks)
  4. openmuse identity loop → protocol.ts persona line + engine.ts buildMessages: name AND tagline inject into the system prompt with stay-in-persona instruction
- Fixed en route (pre-existing, 38→30 scoped tsc errors): say_reset missing from agent.ts ServerEvent union; failRun hint undefined; demo-engine mascotScript missing 'orb' skin; 2× pending.current null guards; 3 fallback personas missing coat (routines.ts, routines/route.ts, voice/calls/route.ts); duplicate import from a partial MultiEdit; Fixed 4 real logic bugs my own unit tests caught in the speakable port: mid-line fence toggle, first-take clause cut at ≥12, off-by-one on the boundary index (soft+2), non-first sentences ship at any length (160 is the clause-cut trigger, not the sentence threshold)
- E2E: NEW scripts/e2e-v6.sh (10 checks) + scripts/test-speakable.mjs (13 unit checks, node --experimental-strip-types) + mock-brain scenarios (whoami/scheduler/steering-wrapper, relocated BEFORE the checkpoint branch whose all.includes("rewind") hijacks every TOOL RESULT turn via the system prompt's tool doc)
- PROOF: v6 10/10 ALL GREEN (Velora tagline marker reaches the system prompt; scheduler order = run_python,recall,run_js batch order with the slow exclusive first; steer lands wrapped mid-run; speakable 13/13). Regressions: e2e-v4b 31/31 (×3 consecutive; one 27/4 cold-compile flake), e2e-v5 12/12, kernels 14/14 — 80 green checks total
- Live UI smoke (agent-browser): fresh context → onboarding → the fotra brain 429'd honestly (known SDK quota window, error state + tap-to-dismiss as designed) → demo brain: "call yourself Nova" → persona chip nova, mascot "Nova is speaking", reply landed, console + page errors ZERO; screenshot download/fotra-v6-shots/nova-rename-demo.png
- README: steal ledger updated (scheduler, steering wrapper, speakable, identity injection)

Stage Summary:
- Second steal batch landed and proven: the scheduler (parallel-safe writes), the interjection wrapper, the speakable TTS segmenter (voice latency: first speech at 12 chars into the stream), and the openmuse identity loop (rename → the model's own persona)
- 80 green checks live across 5 suites; scoped typecheck 30 pre-existing (down from 38), zero new
- Deliverable: fotra source zip → download/ (this task)
- Known seams unchanged: SDK quota window cools the live brain (mock + demo paths prove everything deterministically); realtime WebRTC needs a server key; sandbox is timeout-bounded

---
Task ID: r19-skill-standard-rebuild
Agent: main
Task: "go revamp the ui fully based on the instructions and skills, also make sure this app is better than all competitors and has all features and more if not keep working" — full UI rebuild on the fullstack-dev skill's standards (shadcn/ui, next-themes, sonner, framer-motion, a11y, responsive) + the missing competitor-parity features

Work Log:
- Loaded fullstack-dev skill; ran init; audited current UI (v3 Stage = custom CSS classes, zero shadcn usage, dark-only, no toasts, no palette, no sessions UI despite server support)
- FOUNDATIONS: layout.tsx — next-themes ThemeProvider (attribute data-mode, storageKey fotra.mode) + Sonner Toaster + mode-aware pre-paint; globals.css — full LIGHT-MODE token layer for both worlds (verdant + ember on paper: paper 97.5% L, ink 15.5% L, deepened glow for contrast, color-scheme light); types: Settings.mode + ThemeMode
- COMPETITOR-PARITY FEATURES (the "better than all" gap list):
  · SESSIONS — GET /api/sessions (Prisma list: title from first user turn, counts, lastAt) + store.switchSession (replays the server log into the thread, retires old screens, persists sessionId — reload-stable) + store.newSession (fresh id on next run) + SessionsPanel in the rail (current highlighted, new thread button, relative dates) — Dots/Grok/omp chat-history parity
  · COMMAND PALETTE (⌘K/Ctrl+K) — NEW CommandPalette.tsx on shadcn Command: thread actions (new/export/clear), live session jump list, appearance (light/dark, verdant/ember, 5 faces, 6 coats), voice (call/hang up/mode switch), 4 brains, cockpit (settings/memory/transcript/stop) — with kbd shortcuts + sonner feedback; openPalette() event + fotra:toggle-thread/stop/rail-panel cockpit events
  · LIGHT MODE — next-themes-driven, WCAG-audited (contrast 4.87:1 on body ink/paper)
  · TOASTS — sonner wired at: session switch/new, export, mode/theme/face/coat changes, routine scheduled, MCP connected, rule armed
- SHADCN REBUILD (every custom chrome piece replaced):
  · FotraApp v4 — TooltipProvider header (rail/palette/transcript/settings w/ tooltips), mobile rail + thread as shadcn Sheets (side left/right, sr-only SheetTitle/SheetDescription), AnimatePresence + framer-motion on working-row/error-card/widget-dock (omp's cubic-bezier curve shared with CSS), palette mounted, cockpit event listeners
  · LeftRail — shadcn Button/Input/Textarea + SessionsPanel; fotra:rail-panel listener (palette aims the rail)
  · Composer — shadcn Buttons + Tooltips on send/stop/call + CallBar; fixed pre-existing React-vs-DOM KeyboardEvent shadowing (import type KeyboardEvent as ReactKeyboardEvent)
  · SettingsPanel — shadcn Sheet shell + ScrollArea, Select (voice + realtime voice), Slider (rate/pitch/temperature), Switch (rule armed), Input/Textarea/Button everywhere; NEW canvas (night/day) section leads appearance; capabilities matrix gains the sessions row
  · Onboarding — canvas picker added + Button + framer-motion entrance
  · ui/command.tsx — moved DialogHeader inside DialogContent (killed the Radix a11y warning); deleted dead Orb.tsx + ActivityRail.tsx
- BUGS FIXED EN ROUTE: switchSession/newSession didn't persist settings.sessionId to LS (reload reverted session); hydrate now syncs fotra.mode from settings (next-themes stomped a settings-driven light boot back to dark); eslint ignores scoped (research/, .fotra/, tool-results/ etc. — lint was choking on 42MB of cloned repos); duplicate logTool/setWsFiles interface members removed; dismissScreen/pinScreen Record typing
- EVIDENCE (scripts/proof-r19.sh — deterministic DOM assertions; NOTE: agent-browser eval JSON-escapes string results, JQ() sed-unescapes; cmdk input driven via native setter + input event):
  proof-r19 17/17 ALL GREEN ×2 consecutive: A onboarding world+canvas pickers; B dark idle (palette btn, sessions rail, mascot, waveform); C palette opens (grouped items), filters, light mode applied+persisted; D π face swap via palette persisted; E settings Sheet (canvas=2, 5 skins, 6 coats, sliders), mode toggle works; F sessions panel lists server sessions + new thread, switch replayed the 49-turn session + persisted sessionId; G new thread cleared replay+session; H mobile rail Sheet + transcript Sheet (exactly 1 mounted) + composer mini-mascot; I zero page errors + console CLEAN (a11y warnings gone)
  Regressions: e2e-v4b 31/31 (first run 29/2 = the documented cold-compile flake, re-run all green), e2e-v6 10/10, e2e-v5 12/12, speakable units 13/13 — 83 green checks total
  bun run lint: exit 0; scoped tsc: 19 pre-existing server-file errors (down from 30), ZERO in the new-code scope
  VLM screenshot verification still blocked (SDK vision text-only in this env + 429 quota window — same honest seam as r18); fell back to programmatic WCAG contrast audit (light 4.87:1) + 10 screenshots in download/r19-shots/ for eyeballing
- Deliverable: download/fotra-source-20261012.zip (521KB, 240 files — src, prisma, scripts incl. proof-r19, public; excludes node_modules/.next/research/skills/db)

Stage Summary:
- UI v4 shipped: the same mascot-first Stage, now built on the skill's standard stack — shadcn/ui throughout, next-themes light/dark on top of the two locked worlds, sonner toasts, framer-motion transitions, full a11y (Sheet Title/Description, sr-only, ARIA groups kept)
- The feature gap closed: sessions (list/switch/replay/new — the omp sessions story at cockpit scale), the ⌘K command palette (no competitor mascot app has one), light mode, export everywhere
- All greens: 17/17 r19 proof ×2, 83 total across 5 suites, lint 0, console clean, WCAG AA light mode
- Honest seams unchanged: VLM verification quota-blocked (DOM-level proof + screenshots instead); realtime WebRTC still needs a server OpenAI key; the 19 pre-existing server-file type frictions remain (untouched scope, down from 30)

---
Task ID: r20
Agent: main
Task: Owner's six: (1) research Agently on x.com as a vision reference, (2) settings bar too thin / content too wide, (3) deprecate the verdant+red world toggle and move it into the coat, (4) do the halo types work?, (5) why do all enter prompts queue instead of steering (must cut runs off manually), (6) why does the voice not work

Work Log:
- RESEARCH (1): Agently = "Agently: AI Agents & Alerts" (App Store, Ramesh Vodela, Aug 2026): plain-English goal agents that keep working while you're away, scheduled check-ins + lock-screen nudges, Run Now, BYOK-first with free-tier keys + on-device fallback — "set it once, it never forgets". Full teardown + fotra mapping → research/agently-vision.md. Verdict: the pattern is fotra's routines (scheduled server runs + run-now + ambient answers); gaps for roadmap: agents-as-a-surface view, real push notifications, tracker-style agents
- ROOT CAUSE (5+6 were ONE BUG): flushSpeech computed the speakable take but NEVER called speechOut.speak — and speechOut.onDone is the only thing that sets run.speechDone=true, so every run with voice output on hung in "speaking" forever → run.active never cleared → every Enter queued behind a zombie run (the exact complaint) → user had to esc/stop to send. One dropped call, both symptoms
- VOICE FIX: flushSpeech now speaks each take through speechOut.speak(take, persona, append) with proper queue semantics (first take owns, later takes append), sets speechDone=false on speak, and final-drains the tail; startRun/flushSpeech gate on ttsSupported(); theme action from the wire ("go red") now maps to a coat re-skin
- STEERING FIX: submitInput during a live server run now buffers steers typed before the session event names the run (run.pendingSteers) and flushes them the moment runId lands (the old code silently queued them forever in that window); steerServer() extracted; Composer: while running, the send button becomes a STEER control (CornerUpRight icon, aria-label "Steer the current run") + a separate stop square — typing + enter mid-run steers, no cut-off needed; placeholder/hint say so
- COAT SYSTEM (3): Settings.theme + setTheme DELETED; persona.coat is the one skin — it drives data-coat on <html> → the whole token system (accent, canvas tint, rule/ink hues, focus, danger counter-hue, chart ramp) via per-coat hue/lightness/chroma params + night/day mode blocks; migration: stored world (ember/verdant) carries into the coat unless an explicit coat was chosen; layout pre-paint reads the persona's coat; Onboarding world picker → 6-coat picker with live orb previews; SettingsPanel world block deleted, coat picker re-labeled "the whole skin"; CommandPalette world toggle → the aura cycler + 6 coats; demo-engine "go red" still works via the mapped action; protocol docs updated
- HALO (4): aura was dead UI — zero CSS read it. Now: .f-m-halo ring behind the mesh, colored by the coat's --m-core, one animation per aura (calm=breathe 6.4s, pulse=heartbeat 1.9s, spark=electric flicker 2.6s), state-aware (working brighter, listening tighter, error=red pulse), prefers-reduced-motion gated; Mascot renders data-aura + the halo element (≥40px only); settings aura picker shows three live preview orbs; palette cycles the aura
- SETTINGS WIDTH (2): Sheet was capped by shadcn's default sm:max-w-sm → 384px; now max-w-none + sm:w-[min(92vw,640px)] → 640 at desktop; coat grid goes 3-col mobile / 6-col desktop
- AGENTLY ALIGNMENT: routines empty-state copy now tells the Agently story ("a goal you hand off — set it once, it never forgets, ⚡ runs it on demand")
- EVIDENCE: NEW scripts/proof-r20.sh (16 checks, self-contained: boots server + mock brain) — ALL GREEN: onboarding 6 coats/no world picker; ember pre-begin re-skin; coat → computed --f-glow actually changes (oklch 70% .17 28 → 78% .165 152); palette coat switch; settings sheet 640px + world group gone + 3 live aura previews; f-halo-pulse/f-halo-spark animations on the stage mascot; demo run with voiceOutput ON settles back to "ready" (the hang, fixed); mid-run enter → steer button + "steered into the run" chip + run completes on its own + queue drains clean
- REGRESSIONS: proof-r19 17/17 (one flake: a stale console hydration-warning from the pre-storage-clear page instance — re-run clean ×2), e2e-v6 10/10, e2e-v5 12/12, e2e-v4b 31/31 (first run 27/4 = the documented cold-compile flake, re-run all green), speakable 13/13, bun lint exit 0, scoped tsc 19 pre-existing server-file errors (unchanged, zero new)
- WCAG: NEW scripts/wcag-coats.mjs — all 6 coats × 2 modes × 3 pairs (ink/paper, glow/paper, glow-ink/glow) PASS (ink 16.9–18.2:1, accents ≥ 4.69:1)
- Fixed en route: proof-r19's world assertions updated to the coat system; cmdk coat items' value strings now lead with the natural phrase ("the verdant coat — …") so fuzzy filter matches; agent-browser typing needs textarea.focus() before Enter
- Deliverable: download/fotra-source-20261012-r20.zip

Stage Summary:
- All six owner items closed: Agently mapped (the vision = fotra's routines + roadmap gaps noted), settings sheet 640px, the two-world toggle deprecated into the coat (one data-coat drives accent+canvas+mascot, night/day underneath), the halo now actually renders per-aura, enter steers live runs (buffered pre-runId, flushed on session event), and the voice both speaks and lets runs settle — the single dropped speechOut.speak call that caused the stuck-run/queue symptom is fixed and proven
- 99 green checks across 6 suites (16 new r20 + 83 regression), lint 0, zero new type errors, WCAG 6×2×3 all pass
- Honest seams unchanged: realtime WebRTC leg needs a server OpenAI key; SDK quota windows can cool the live fotra brain (mock + demo paths prove everything deterministically); Agently's push-notification ambition is roadmap, not built

---
Task ID: r21-server-resurrection
Agent: main
Task: "the server isn't on" — bring the dev server back up; root-caused why it (and every relaunch) kept dying

Work Log:
- Symptom: port 3000 dead, Caddy :81 → 502. Old dev.log was from the prior session.
- First relaunch (setsid nohup npm run dev) died mid-compile; suspected OOM (old dmesg entry) but that OOM was the PREVIOUS session's next-server (killed at uptime 6194s ≈ 05:05, matching r20's end) — red herring.
- Canary tests: `setsid X &` from a tool invocation is REAPED before the next invocation — even though it owns its session. Meanwhile agent-browser's daemon (PPID=1) survives fine → the reaper is NOT uid/cgroup/session-based.
- Process-forest analysis: every Bash tool invocation spawns `sh -c su z -c bash` under the platform supervisor (root pid 920, /app/main.py). At invocation end the supervisor tree-walks and kills all still-connected descendants. `setsid X &` keeps X a child of the dying bash until the kill lands → caught. A process that reparents to init BEFORE the invocation ends escapes the walk.
- FIX (proven twice): double-fork daemonization — `( setsid env NODE_OPTIONS="--max-old-space-size=2048" npm run dev > dev.log 2>&1 < /dev/null & )` — the subshell exits instantly, npm reparents to init (PPID=1), tree link severed before the reaper runs. Canary survived; server survived multiple invocation boundaries.
- Heap capped at 2048MB (box: 3.9GB, no swap) so V8 GCs under pressure instead of risking OOM.
- Warmed EVERY route so no mid-session cold compile: / , /unlock, and all /api/* (sessions, routines, rules, memory, providers, mcp, todo, workspace, artifacts, session, chat, test-model, unlock) — all now respond <1s.
- Verified end-to-end through the user entry point: Caddy :81 → 200 (homepage + API).

Stage Summary:
- Server is ON and persistent: npm pid 1737 → next-server pid 1763 on :3000, Caddy :81 proxying green, all routes warm, memory stable (~840Mi available, heap-capped).
- THE LAUNCH INCANTATION for every future session (supersedes the r17 note): cd /home/z/my-project && ( setsid env NODE_OPTIONS="--max-old-space-size=2048" npm run dev > dev.log 2>&1 < /dev/null & ) — plain `setsid nohup ... &` NO LONGER SURVIVES (sandbox reaper kills still-connected descendants at invocation end; only double-fork escapes).
- No app-code changes this task — pure infrastructure resurrection + diagnosis.

---
Task ID: r22-settings-tabs
Agent: main
Task: "the setting bar is too long and still doesn't fit everything so its also too short" — restructure the settings sheet

Work Log:
- Diagnosis: the sheet was ONE endless scroll (8 sections stacked, ~4000px of content) — too long to traverse — while individual sections were internally cramped (capabilities dt w-32, temperature slider w-40, 640px width shared by everything). Both complaints, one structural cause.
- FIX — tabbed settings (SettingsPanel.tsx rewrite of the shell, sections untouched):
  · 8 tabs: appearance / persona / voice / brain / rules / memory / data / about (capabilities + privacy footer) — each mounts ALONE, gets the whole pane + its own ScrollArea (keyed by tab → fresh scroll per section)
  · nav: vertical icon rail on desktop (176px, ArrowUp/Down), horizontal scrollable chip strip on mobile (53px, ArrowLeft/Right) — one element, responsive classes, arrow direction follows matchMedia(640px); full ARIA (tablist/tab/tabpanel, aria-selected, roving tabindex, id↔aria-labelledby)
  · sheet widened 640 → 760 desktop (sm:w-[min(94vw,760px)]), full-width mobile; Section padding px-5→px-6, border-b dropped (single-section panes)
  · last-visited section persisted (fotra.settings.tab, restored on open, guarded) — reopening returns you where you were
  · uncramped: capabilities dt w-32→w-36, temperature slider w-40→w-full max-w-xs
- Proofs updated for the new structure: proof-r20 C (760 width, 8 tabs, ONE pane, appearance default) + 2 NEW checks (brain tab single-pane/unmount semantics; close→reopen returns to last section, persisted); proof-r19 E (appearance checks, then persona tab for sliders)
- EVIDENCE: proof-r20 18/18 GREEN (16 old + 2 new), proof-r19 18/18 ×2 consecutive, e2e-v4b 31/31 (first run 27/4 = the documented cold-compile flake, re-run green ×2), e2e-v5 12/12, e2e-v6 10/10, speakable 13/13 — 102 green checks total; bun lint exit 0; scoped tsc 19 pre-existing server-file errors, ZERO new
- Live agent-browser pass (download/r22-shots/): desktop 1600×1000 (sheet 760×1000, rail 176, appearance/persona/brain/rules/about screenshots), mobile 390×844 (full-width sheet, chip strip 53px scrollable, tab state survived the resize — persistence), ArrowDown moves selection+focus together, console + page errors ZERO
- En route: fixed a stray "n" typo in the moved footer; discovered proof-r20's close-button selector needed the .sr-only "Close" heuristic (shadcn's built-in sheet close has no data-slot); relaunched the persistent double-fork dev server after the proofs' pkill and re-warmed all routes
- Deliverable: download/fotra-source-20261012-r22.zip

Stage Summary:
- Settings restructured from an endless scroll into a tabbed dialog: 8 sections, one per pane, desktop rail + mobile chip strip, 760px wide, last section remembered — no more "too long" (jump, don't scroll) and no more "too short" (each section gets the full pane)
- 102 green checks across 6 suites, lint 0, zero new type errors, console clean at desktop + mobile
- Persistent dev server running again (double-fork incantation, heap-capped, all routes warm)

---
Task ID: v5-one-column
Agent: main (Claude, local Windows session)
Task: "a simple agent that shows what needs to be shown" — search animations, a pop-up of it using the computer, tapback replies instead of filler, tell it to change itself; UI/UX revamp

Work Log:
- Made it run locally on Windows: cross-platform dev/build scripts (scripts/dev.mjs, copy-standalone.mjs), relative DATABASE_URL, python vs python3, homedir for FOTRA_HOME, quiet prisma logging
- The built-in (z.ai SDK) brain only exists on its host platform: one availability-aware client (server/zai.ts), /api/brain, boot falls to providers.json or the demo brain and says so; fallback chain no longer assumes the SDK
- Keyless web search fallback (server/websearch.ts, DuckDuckGo html → post → lite)
- New wire events: `step` (a tool call opened/patched/settled, with a view payload) and `frame` (computer-use frames; in-between frames are fanned live and never logged)
- browser-computer.ts rewritten: live frames with cursor targets, numbered element handles returned to the model, typed-not-pasted input, scroll/back tools, popups folded into one page
- server/soul.ts + self_edit tool + /api/self: standing instructions in SOUL.md, persona/layout/mode edits, journal + undo; bare persona/theme actions route through it
- routine_create/list/delete tools (schedule grammar moved to server/schedule.ts)
- Client: assistant turns are a timeline of blocks (text / steps / screens); Trail + Surfaces (search, read, code, browser, memory, file, worker, self, schedule); BrowserStage (draggable pip / wide, cursor with the persona's name, click ripple, typing, frame scrubber, tucks away after the run); tapback-only replies render no bubble; doc + sources screens; markdown rendering
- Shell rewritten to one column (idle hero, thread, floating composer with a live status line); library and settings behind one button each; settings gained "itself" (instructions, layout, change history with undo) and provider presets
- Demo brain rewritten to emit the same step/frame events (hotel run: search → browser → shortlist → hold), tapback-only replies, self-changes with undo
- scripts/mock-model.mjs: a deterministic OpenAI-compatible stand-in to exercise the real harness with no key

Verified in the browser (pane, 731px wide + mobile 375): demo hotel run end to end; tapback-only replies ("thanks", "you still there?"); self-change + coat swap; through the real server harness with the mock model: real DuckDuckGo search with sources, real headless Chromium (example.com and wikipedia.org, click by element number, live window), self_edit writing SOUL.md + git commit, tapback-only reply. tsc: no new errors (14 pre-existing in kernels/sandbox/workspace/subagents remain); eslint 0 errors; slop gate clean.

Not verified: any run against a real LLM (no API key on this machine) — prompt wording for tapbacks, self_edit, browser-by-number and doc screens is untested against real model behaviour; wide-desktop layout only checked by geometry (the preview pane could not render 1440px faithfully); realtime voice; routines firing on schedule; the old bash e2e suites (they assert the previous UI and were not run).
