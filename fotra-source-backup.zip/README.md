# fotra

An agent that shows its work while it happens, then gets out of the way — on top of a real harness: tools, persistent memory, event-sourced runs that survive reloads, and a pluggable model layer.

## What it feels like (v5)

The screen shows what the moment needs and nothing else.

- **Idle** — the mascot, one line, the composer. That's the whole app. Everything the harness keeps (threads, files, routines, MCP tools, memory, settings) is one button or `⌘K` away, never on screen uninvited.
- **The trail** — every tool call is a live step in the thread, in the order it happened. A search types its query and its sources fly in; a page gets skimmed; code runs and prints; a worker reports in. A beat after the work lands, the group folds into one line ("Searched the web · read 2 pages · 6s") that reopens to every step.
- **Computer use you can watch** — when it drives its browser a window pops up beside the thread: the real page, its cursor (wearing its name) gliding to what it's about to click, the ripple when it clicks, the words as it types. It tucks back into the thread when the work is done; the receipt replays every frame. The model acts on numbered element handles the harness hands it, not guessed selectors, and it stops to ask before anything that spends money.
- **It texts like a person** — when a message needs no words back ("thanks", "ok", "you still there?"), the whole reply is a tapback on your bubble. No filler sentence.
- **Tell it to change itself** — "be blunter", "go compact", "wear the ice coat", "always answer in Spanish". One tool (`self_edit`) covers behavior (standing instructions in `~/.fotra/memory/SOUL.md`, read before every reply), look, voice, and its own app's layout. Every change is journaled and undoable — "undo that", the undo button on the change card, or settings → itself.
- **Routines it sets up itself** — "every morning at 8, brief me" creates a scheduled run with every tool; the answer lands in the thread.

## Under it — the loop is the product
- **Server-side run engine v4** — a tool-calling loop with **parallel tool batches**, the **omp shared/exclusive scheduler** (reads run concurrently, writes serialize behind the last exclusive call; results always land in batch order — `agent-loop.ts` L3768–3794), budgets that pause (never kill), **interrupt-steering** (a queued message kicks the current model call, not just the next one, and lands **wrapped in omp's `<system-notice>` interjection frame** — priority over prior instructions), a **wall-clock deadline** instead of micro-steps (trust the model, bound the time), **brain fallback chains** (a dying endpoint cools off and degrades to the fotra brain — you get an answer, not an error page), and every event persisted to an append-only log. Drop the connection, reload the page, switch tabs: the run continues, the client replays it by sequence number.
- **TTSR — time-traveling stream rules** (the oh-my-pi port) — regex rules sit dormant until the model's live output goes off-script; a match **cuts the stream mid-token**, injects the reminder, and regenerates from the same point. Seeded with four anti-slop rules (no AI disclaimers, no placeholders, no destructive commands, no fake tool results); add your own in Settings → stream rules, with a live test box.
- **Persistent kernels + the loopback bridge** (oh-my-pi `eval`) — `run_js` / `run_python` run in long-lived kernels: variables survive across calls **and across runs**, and from inside a cell `tool("web_search", query="…")`, `read_file("data.csv")`, `write_file("out.md", text)` call back into fotra's own tool registry. The agent loads a CSV, searches the web, and charts — without leaving the kernel. Every bridge call is budgeted and shown as a chip on the code screen.
- **Hashline edits** (oh-my-pi `edit`) — every `ws_read` returns a `#tag`; patches anchor to it (`{line, replace} | {line, delete} | {after, insert}`). A stale tag is caught **before** anything corrupts — a one-line drift is recovered by offset remap, anything bigger demands a fresh read. No old-string retyping, no whitespace battles.
- **Typed worker yields** (oh-my-pi `task`) — `spawn_task` takes an `outputSchema`; the worker finishes via a hidden `yield` call whose payload is **validated** (missing fields → corrective retry, three attempts, then best-effort with the gaps named). The parent reads the JSON directly and cites fields as `agent://<name>/<field>`.
- **An advisor** (oh-my-pi `advisor`) — a second model reviews the main agent's steps inline on its own context: a quiet aside, a concern, or a blocker — and a blocker forces a corrective turn before the run finishes. At most two passes per run; it never blocks the reply's latency.
- **Checkpoint / rewind** — `checkpoint {}` marks the context; `rewind {"report":"…"}` collapses the exploration since into the report and frees the context while the run continues.
- **Magic keywords** — `ultrathink` in prose enables deep-reasoning mode; `orchestrate` switches the run to fan-out orchestration with typed workers (code spans and fences are masked — they only fire in prose).
- **Memory v2** — `remember` / `forget` as before, plus **`recall`** (scored retrieval: token overlap × recency decay, both tiers), **`reflect`** (synthesize an answer over memory, citing which memory each claim came from), and **`learn`** (capture a reusable lesson as a **skill file** in the git vault that auto-injects when its triggers match a future ask).
- **A 31-tool belt** — `web_search` (the host platform's search when present, a keyless DuckDuckGo fallback otherwise), `open_link`, `remember` / `forget` / `recall` / `reflect` / `learn`, `run_js` / `run_python` / `kernel_reset`, `browser_navigate` / `browser_click` / `browser_type` / `browser_scroll` / `browser_back` / `browser_extract`, `self_edit`, `routine_create` / `routine_list` / `routine_delete`, `ws_read` / `ws_write` / `ws_list` / `ws_patch` (hashline), `spawn_task` (typed yields), `checkpoint` / `rewind`, `todo_write`, `mcp_connect` + every connected server's tools as `mcp_<server>_<tool>`, `ask_user` (HITL). Every call budgeted, timed, and audited in SQLite.
- **The coat system — one skin** — the old two-world toggle (green/red) is deprecated: those hues live on as two of six coats (iris · verdant · ember · ice · rose · mono), and the coat now drives *everything* — the app accent, the canvas tint, the mascot mesh, the face palette — from one `data-coat` attribute. Night/day stays as the canvas underneath. All 6 coats × 2 modes pass WCAG (ink 16–18:1, accents ≥ 4.7:1).
- **The halo — auras that actually render** — the aura setting (calm · pulse · spark) is no longer dead UI: a soft ring around the mascot, colored by the coat, with a distinct animation per aura (slow breath · heartbeat · electric flicker), state-aware (brighter while working, tight while listening, red pulse on error) and gated by `prefers-reduced-motion`.
- **Steering without cutting it off** — typing mid-run **steers**: Enter injects the message into the live run (wrapped in omp's `<system-notice>` priority frame server-side), the composer's send button becomes a steer control while a run is live, and steers typed before the run is named are buffered and flushed the moment the runId lands. Nothing silently degrades into the queue anymore; esc still stops.
- **Routines** — schedule prompts ("every morning at 8, brief me") that fire as real server-side runs with the same tools and audit trail; answers land in your thread ambiently. Set it once, it never forgets, ⚡ runs it on demand — the Agently pattern, already wired.
- **Memory** — two tiers, both inspectable: an SQLite index for speed, and a **git-markdown vault** at `~/.fotra/memory/` (facts, topics, and learned **skills**) where every edit is a commit. Older turns fold into a rolling summary as a background job. One-time codes and key-shaped strings are scrubbed at write time.
- **Grounding** — comparison tables and hotel cards may only cite evidence recorded this turn; rows that trace to nothing get dropped, and it says so.
- **Speakable voice** (the oh-my-pi `speakable.ts` port) — the model's stream is segmented for speech as it arrives: the **first take fires at 12 chars** (speech starts while the model is still writing), later takes hold for full sentences, clause cuts past 160, a hard 280 ceiling — and code fences are swallowed, URLs spoken as hosts, paths as basenames. Markdown is never read aloud.
- **Identity injection** (the openmuse loop) — rename the agent or change its tagline and the change propagates into the model's system prompt: it *is* Nova, in its own voice, in every reply.
- **Nudge guard** — a tool-shaped or artifact-shaped ask never ships action-less: the harness detects announce-without-do replies and corrects the model (twice, with escalation) before you see it.
- **Voice** — browser voice (Web Speech, zero keys, hold space) and **realtime WebRTC calls** (bring a server-side OpenAI key: semantic-VAD barge-in, captions both ways, one `ask_fotra` tool that delegates into this same harness). Calls end with a quiet receipt chip, not a toast.
- **Generative screens** — twelve typed components (stat, table, checklist, hotel, ask, **code (kernel badges + bridge chips)**, browser frame, worker card, todo board, files, chart) that build progressively while it speaks. Pin what matters; the next user turn retires the rest.
- **The instrument panel** — a harness rail (workspace files · routines · MCP · memory) on the left, the thread in the middle, and the orb stage with live tool telemetry (real ms timings, advisor notes, rule cuts, rewind markers) on the right.
- **Brains** — the built-in one (zero keys), your own OpenAI-compatible endpoint, or a `providers.json` role (workers resolve to the cheap `small` role first). All three run through the same harness with the same tools.

## Run it

```bash
npm install
npx prisma db push              # SQLite — sessions, runs, events, tool calls
npx playwright install chromium # once — the browser it drives
npm run dev                     # http://localhost:3000 (PORT=… to change) — works on Windows, macOS, Linux
```

It boots on the **demo brain** (scripted, offline) so the whole interface can be felt with zero keys. Connect a model in settings → brain — any OpenAI-compatible endpoint, with one-click presets for Anthropic, OpenAI, OpenRouter, DeepSeek, Moonshot, Groq, Ollama and LM Studio — and the same interface does it for real.

No key handy but want to see the real harness run (real web search, a real Chromium, real self-edits)? `node scripts/mock-model.mjs` starts a deterministic stand-in model on `http://127.0.0.1:4010`; point "your model" at it (model name `mock`) and say "search for …", "browse wikipedia.org", "be blunter", "undo", "thanks".

## Self-host (the supported path)

```bash
cp .env.example .env.local   # optional keys (see below)
docker compose up -d
```

> **Not serverless.** SQLite, minute-long runs, and the git memory vault need a persistent Node process. Vercel/Netlify functions will not work and that is by design.

State lives in two volumes: `/data` (the database) and `/fotra-home` (`~/.fotra` — memory vault, git history).

## Keys (all optional)

Keys go in **`.env.local`** (untracked). The tracked `providers.json` holds **env-var names only** — the app hard-fails if it finds a pasted `sk-…` in the tracked file.

| Variable | Unlocks |
|---|---|
| `OPENAI_API_KEY` | realtime voice + the `openai` provider |
| `OPENROUTER_API_KEY` | the openrouter provider |
| `FOTRA_TOKEN` | locks the whole app behind one owner token (`/unlock`) |
| `FOTRA_REALTIME_MODEL` | voice model override (default `gpt-realtime`) |

## BYO model, three ways

1. **Browser path** — Settings → brain → *your model*: paste any OpenAI-compatible base URL + key. The key lives in your browser, is sent per-request only, and never touches disk.
2. **providers.json** — name providers + roles at the repo root (`roles.chat`, `roles.small`), keys in `.env.local`. Status lights and a prove-it call in Settings.
3. **The built-in brain** — only on the z.ai host platform this project was first built on (it needs that platform's config file). Everywhere else it is simply absent, and the app says so instead of failing mid-run.

## The honest capability matrix

| Works today | not yet (said plainly, never faked) |
|---|---|
| voice (browser + realtime), barge-in, queue-and-steer (enter steers mid-run) | realtime leg needs a server key to exercise |
| 25 tools: persistent kernels + bridge, hashline files, browser computer, typed workers, board, charts, web, recall/reflect/learn, checkpoint/rewind, MCP | kernels are timeout-bounded, not VM-isolated; recall is scored keyword+recency (no embeddings in the zero-key build) |
| sub-agents (parallel spawn_task) + routines (scheduled runs, run-now) | cross-restart queue persistence is v-next |
| persistent + git memory, daily consolidation | full dictation polish (draft/send intents) |
| event-sourced runs, parallel tool batches, reattach, multi-tab | |
| grounded screens, nudge guard, pause-not-kill budgets | |

## Layout

```
src/lib/fotra/server/   the harness: engine, tools, kernels, browser-computer, workspace,
                        subagents, mcp, routines, soul (self-edit), websearch, vault, jobs,
                        providers, realtime, events
src/lib/fotra/          the client loop: agent, protocol parser, voice, store, demo brain
src/app/api/            run / runs / session / poll / routines / mcp / workspace /
                        artifacts / todo / memory / providers / voice / unlock
src/components/fotra/   the one-column shell, thread (timeline), trail + surfaces (live steps),
                        browser stage, reactions, composer, result screens, library, settings
providers.json          BYO model layer (env-var names only)
PERSONA.md              the voice + tone spec, reviewed like code
DESIGN.md               the design constitution
```
